# City Builder

Ứng dụng iOS (SwiftUI + SceneKit) để đặt nhà, tòa nhà, cây, đường phố trong không gian 3D rồi xuất file OBJ / USDZ cho game.

## Cách dùng
- Chọn công cụ ở thanh dưới, chạm lên nền để đặt.
- **Đường**: chạm điểm đầu, rồi chạm các điểm tiếp theo. Bấm "Dừng đường" khi xong.
- **Chọn**: chạm vật thể rồi xoay, đổi cỡ, đổi màu, dời, xóa.
- Một ngón kéo = xoay camera, hai ngón = dời, chụm = zoom.
- Miền Tây: Nhà sàn (mái lá / tôn), Nhà tôn, Dừa, Dừa nước, Cỏ, Kênh (bờ đất / kè gạch), Cầu khỉ, Xuồng. Chọn kênh hoặc đường rồi bấm "Màu" để đổi kiểu.
- Menu → "Tạo xóm miền Tây mẫu" hoặc "Tạo khu phố mẫu" để xem thử nhanh.
- Menu → "Xuất OBJ" rồi lưu vào Tệp hoặc gửi đi.
- Dự án tự lưu, mở lại app vẫn còn.

## Nhập mô hình 3D
Nhóm **Mô hình** ở thanh dưới → **Nhập**. Nhận được:
- file **.zip** (ví dụ gói tải từ Sweet Home 3D, Blend Swap: .obj + .mtl + ảnh texture) — app tự giải nén;
- file mô hình lẻ `.usdz` / `.obj` / `.scn` / `.dae` / `.glb` / `.gltf`;
- chọn cùng lúc nhiều file `.obj` + `.mtl` + ảnh.

Mô hình hiện trong danh sách; chọn rồi chạm lên nền để đặt, dùng Xoay / To / Nhỏ / Dời / Xóa như vật thể khác. App tự đoán đơn vị (mét hoặc cm), đặt chân xuống đất; OBJ không có màu sẽ hiện xám ấm. Giữ lâu một mô hình trong danh sách để xóa. Cũng có thể chép thẳng vào Tệp → Trên iPhone → City Builder → Models.
**Chuyển động cho mô hình nhập:** chọn mô hình đã đặt → nút gió trên thanh thao tác, bấm để đổi: Đứng yên → Đung đưa (cả mô hình nghiêng theo gió) → Lá lay (uốn ngọn, hợp cây cỏ) → Nhún (nhấp nhô nhẹ) → Đi vòng (đi quanh điểm đặt trên vòng vàng bán kính 3 m, nút Hướng đi quay thêm 90° mỗi lần bấm nếu mô hình đi ngang hoặc ngược). Mô hình có sẵn hoạt ảnh (xương, đi, chạy) ở dạng USDZ / DAE / SCN sẽ tự chạy.
File **GLB / GLTF** (ví dụ tải từ Tripo, Meshy) đọc trực tiếp, kể cả texture nhúng; chưa hỗ trợ file nén Draco/Meshopt, xương và hoạt ảnh (xuất lại không nén nếu gặp lỗi). Nhớ ghi nguồn tác giả nếu giấy phép là CC-BY.

## Thư viện mô hình: tìm kiếm, chuyên mục, sao lưu, đồng bộ
Nhóm **Mô hình** ở thanh dưới → ô **Thư viện** (hình giá sách) mở màn hình quản lý:
- **Tìm kiếm**: gõ tên hoặc tên chuyên mục, không phân biệt hoa thường và dấu tiếng Việt.
- **Chuyên mục**: bấm **+ Chuyên mục** để tạo; giữ lâu một chuyên mục để đổi tên hoặc xóa (mô hình trong đó không bị xóa). Giữ lâu một mô hình (hoặc vuốt) để chuyển chuyên mục hoặc xóa.
- **Nhập vào chuyên mục**: chọn chuyên mục ở hàng trên rồi bấm dấu **+** (góc phải) để nhập; mô hình mới vào thẳng chuyên mục đó. Đang ở "Tất cả" thì vào "Chưa phân loại".
- **Sắp xếp** (nút mũi tên lên xuống): theo tên, theo chuyên mục (chia nhóm), hoặc mới nhất.
- **Sao lưu** (nút mây → Sao lưu thư viện): tạo file `.zip` gồm toàn bộ mô hình, chuyên mục và thành phố đang dựng; lưu vào Tệp / iCloud Drive hoặc gửi đi. **Khôi phục** từ file đó: thêm các mô hình còn thiếu, gộp chuyên mục; nếu bản sao lưu có thành phố thì hỏi có thay thành phố hiện tại không.
- **Đồng bộ giữa các máy** (nút mây → Chọn thư mục đồng bộ): chọn một thư mục bất kỳ trong Tệp (nên là thư mục trong iCloud Drive, hoặc Dropbox / OneDrive nếu đã cài). Trên mỗi máy chọn cùng thư mục đó rồi bấm **Đồng bộ ngay**: mô hình chỉ có ở một bên được chép sang bên kia, chuyên mục được gộp (khác nhau thì bản sửa sau cùng thắng). Dữ liệu nằm trong thư mục con `CityBuilder`. Việc **xóa** mô hình hoặc thành phố không được đồng bộ; thành phố dùng Sao lưu / Khôi phục.

## Mô hình đóng sẵn
Thư mục `Builtin/` chứa mô hình được đóng thẳng vào app (hiện có **Nhân vật nam**, `Male_Character.obj` + `.mtl`). Lần chạy đầu app chép chúng vào thư viện Mô hình; xóa đi thì không tự thêm lại. Muốn thêm mô hình khác: bỏ file vào `Builtin/` và thêm một dòng vào danh sách `list` trong `installBuiltinModels()` (SceneController.swift).

## Điều khiển camera (kiểu bản đồ)
- **Kéo một ngón**: lướt đi bất kỳ đâu (điểm dưới ngón tay dính theo ngón, thả tay còn trượt tiếp). Có thể đi xa tới 290 m quanh tâm và xây ở đó.
- **Chụm hai ngón**: zoom, giữ nguyên điểm ở giữa hai ngón. **Xoay hai ngón**: xoay hướng nhìn. **Kéo dọc hai ngón**: nghiêng góc nhìn.
- **Chạm**: đặt công trình hoặc chọn để sửa, ở mọi vị trí đang nhìn thấy.
- Nút **◎** (trên cùng) hoặc menu ⋯ → Góc nhìn: về giữa thành phố, hoặc nhìn thẳng từ trên xuống.
- **Đi dạo kiểu game 3D** (nút 🚶 trên cùng): camera như người chơi game.
  - **Cần tròn bên trái**: đẩy lên = đi tới, kéo xuống = lùi, sang hai bên = đi ngang. Kéo càng xa càng nhanh, thả tay thì dừng.
  - **Kéo một ngón ở phần còn lại của màn hình**: nhìn quanh (kéo phải = quay phải, kéo lên = ngước lên).
  - Nút **Bay / Xuống đất**: bay thì đẩy cần tới sẽ bay theo hướng đang nhìn (nhìn xuống thì hạ thấp, ngước lên thì lên cao); xuống đất thì đi bộ ngang tầm mắt người (1,7 m).
  - Khi đi dạo, toàn bộ giao diện được ẩn: chỉ còn cần tròn và hai nút nhỏ mờ ở góc trên phải (Bay / Thoát). Chạm không đặt / chọn / xóa gì. Nút **Thoát** để về camera bản đồ tại đúng chỗ đang đứng.
  - Lúc vào, camera giữ nguyên vị trí và hướng nhìn hiện tại (ở trạng thái bay).
- **Tới đây** (thanh nút khi đã chọn một vật): đưa camera tới vật đó.
- **Mở từ Tệp:** trong ứng dụng Tệp, giữ file zip / usdz / obj → Chia sẻ → City Builder, app tự nhập (đường dự phòng nếu nút Nhập có vấn đề).

## Chuyển động
Nước kênh chảy liên tục (hai lớp gợn trôi lệch tốc độ). Cây, dừa, dừa nước, cỏ đung đưa theo một hướng gió chung; tán lá và tàu dừa rung nhẹ riêng. Xuồng nhấp nhô theo sóng.

## Hình ảnh thực tế
Mọi mô hình dùng vật liệu PBR có texture (gỗ, mái lá, tôn gỉ, ngói, gạch, vữa, vỏ dừa, cỏ, nước...), tàu lá dừa có lá chét thật, ánh sáng bầu trời, bóng đổ mềm, sương mù chân trời.

Texture mặc định được app tự vẽ bằng code. Muốn dùng **ảnh chụp thật**, chép ảnh vào thư mục `Sources/` (hoặc `Sources/Textures/`) với đúng tên, định dạng `.jpg` hoặc `.png`, ảnh nên vuông, lặp liền mạch (tileable), 512–1024 px:

`grass, dirt, asphalt, concrete, wood, woodDark, woodPaint, thatch, tole, brick, roofTile, plaster, palmBark, water, bamboo`

Ảnh lá có nền trong suốt (PNG): `needle` (lá kim thông, phủ kín), `frondMask` (tàu lá dừa, trục nằm ngang, gốc bên trái), `nipaMask` (lá dừa nước, cùng kiểu), `leafMask` (mảng lá phủ kín cho tán cây), `grassTuft` (bụi cỏ, gốc ở đáy ảnh).

Ghi chú xuất file: USDZ giữ texture; OBJ có thể mất texture/độ trong suốt của lá tùy trình xem.

## Build bằng GitHub Actions
1. Đưa toàn bộ thư mục này lên repo GitHub (đảm bảo có `.github/workflows/build.yml`, `project.yml` và thư mục `Sources` ở gốc repo).
2. Tab **Actions** → **Build iOS IPA** → **Run workflow**.
3. Khi xong, tải artifact **CityBuilder-ipa** (file `CityBuilder.ipa`, chưa ký).
4. Ký lại bằng chứng chỉ cá nhân của bạn rồi cài lên iPhone.
