# City Builder

Ứng dụng iOS (SwiftUI + SceneKit) để đặt nhà, tòa nhà, cây, đường phố trong không gian 3D rồi xuất file OBJ / USDZ cho game.

## Cách dùng
- Chọn công cụ ở thanh dưới, chạm lên nền để đặt.
- **Đất vườn / Bờ ao / Đường làng** (mục Miền Tây và Hạ tầng): luống rau rào tre, ao có bờ đất / cầu ao / kè gạch, đường làng đất đỏ / lát gạch / đan bê tông. Bấm "Màu" để đổi kiểu.
- **Thời tiết** (nút biểu tượng mặt trời / mây trên thanh trên cùng, cả khi đi dạo): Nắng, Nhiều mây, Gió, Mưa, Giông bão, Tuyết rơi, Sương mù. Mây thật trôi chậm trên trời, mưa có vệt rơi và bọt nước bắn, tuyết phủ dần mặt đất, giông có sét.
- **Đường**: chạm điểm đầu, rồi chạm các điểm tiếp theo. Bấm "Dừng đường" khi xong.
- **Chọn**: chạm vật thể rồi xoay, đổi cỡ, đổi màu, dời, xóa.
- Một ngón kéo = xoay camera, hai ngón = dời, chụm = zoom.
- Miền Tây: Nhà sàn (mái lá / tôn), Nhà tôn, Dừa, Dừa nước, Cỏ, Kênh (bờ đất / kè gạch), Cầu khỉ, Xuồng. Chọn kênh hoặc đường rồi bấm "Màu" để đổi kiểu.
- Menu → "Tạo xóm miền Tây mẫu" hoặc "Tạo khu phố mẫu" để xem thử nhanh.
- Menu → "Xuất OBJ" rồi lưu vào Tệp hoặc gửi đi.
- Dự án tự lưu, mở lại app vẫn còn.

## Nhập mô hình 3D
Nhóm **Mô hình** ở thanh dưới → **Nhập**. Nhận được:
- file **.zip** (ví dụ gói tải từ Sweet Home 3D, Blend Swap: .obj + .mtl + ảnh texture) — app tự giải nén;
- file mô hình lẻ `.usdz` / `.obj` / `.scn` / `.dae` / `.glb` / `.gltf`;
- chọn cùng lúc nhiều file `.obj` + `.mtl` + ảnh.

Mô hình hiện trong danh sách; chọn rồi chạm lên nền để đặt, dùng Xoay / To / Nhỏ / Dời / Xóa như vật thể khác. App tự đoán đơn vị (mét hoặc cm), đặt chân xuống đất; OBJ không có màu sẽ hiện xám ấm. Giữ lâu một mô hình trong danh sách để xóa. Cũng có thể chép thẳng vào Tệp → Trên iPhone → City Builder → Models.
**Chuyển động cho mô hình nhập:** chọn mô hình đã đặt → nút gió trên thanh thao tác, bấm để đổi: Đứng yên → Đung đưa (cả mô hình nghiêng theo gió) → Lá lay (uốn ngọn, hợp cây cỏ) → Nhún (nhấp nhô nhẹ) → Đi vòng (đi quanh điểm đặt trên vòng vàng bán kính 3 m, nút Hướng đi quay thêm 90° mỗi lần bấm nếu mô hình đi ngang hoặc ngược). Mô hình có sẵn hoạt ảnh (xương, đi, chạy) ở dạng USDZ / DAE / SCN sẽ tự chạy.
File **GLB / GLTF / VRM** (ví dụ tải từ Tripo, Meshy, Mixamo) đọc trực tiếp, kể cả texture nhúng, **xương (skin) và hoạt ảnh**; chưa hỗ trợ file nén Draco/Meshopt và morph target (xuất lại không nén nếu gặp lỗi). **FBX** chưa đọc trực tiếp: hãy chuyển sang USDZ / GLB / DAE (Blender, Reality Converter) hoặc tải Mixamo dạng DAE. Nhớ ghi nguồn tác giả nếu giấy phép là CC-BY.

## Nhân vật có xương: đi lại và thao tác
Định dạng nên dùng: **USDZ, DAE, SCN, GLB, GLTF, VRM** có xương (skeleton). OBJ không có xương nên chỉ đứng yên hoặc đi vòng giả.
1. **Chọn nhân vật**: nhập mô hình nhân vật vào thư viện, giữ lâu mô hình → **Dùng làm nhân vật đi dạo**. Bấm nút 🚶 trên cùng để vào chế độ đi dạo. Đánh dấu nhiều nhân vật thì có nút **Đổi nhân vật** (hai người) trên thanh nhỏ góc phải.
2. **Tự chỉnh cỡ**: nhân vật tự co về cao 1,7 m, chân chạm đất, quay mặt về +Z. Nếu bị quay ngược hoặc ngang, bấm nút **Xoay mặt** (hai mũi tên tròn), lưu riêng cho từng nhân vật. VRM 0.x tự xoay 180°.
3. **Hoạt ảnh theo cần điều khiển**: đứng yên → clip *Idle*, đẩy nhẹ → *Walk*, đẩy hết cỡ hoặc bật chạy → *Run*; tốc độ clip theo quãng đường thật nên không trượt chân, chuyển clip có trộn mượt. Không có clip nào thì nhân vật nhún và nghiêng theo bước đi.
4. **Hoạt ảnh nhập riêng**: Thư viện → nút mây → **Nhập hoạt ảnh**. Nhận `.zip` (Mixamo tải về dạng zip), `.dae`, `.usdz`, `.glb`… không cần kèm hình. **Đặt tên file theo việc**: `Idle`, `Walk`, `Run`, `Jump` (tên có các từ đó là được); tên khác (`Wave`, `Dance`…) thành clip của nút **Hành động** (✨). Clip khớp theo tên xương (không phân biệt tiền tố `mixamorig:` hay hoa thường) nên dùng chung cho mọi nhân vật cùng bộ xương (ví dụ nhân vật Mixamo). Nhân vật có clip sẵn trong file thì dùng luôn. Hoạt ảnh được đưa vào Sao lưu / Khôi phục.
5. **Hành động** (✨): chạy lần lượt các clip còn lại; không có clip thì nhảy tại chỗ.
6. Mô hình nhân vật đặt trong cảnh: chọn → nút gió → **Đi vòng** thì chạy clip Walk, các kiểu khác chạy clip Idle (mỗi lần chỉ một clip).

## Mô hình không có xương: tự gắn xương
Giữ lâu mô hình trong Thư viện → **Gắn xương cho nhân vật…** (dùng được cho OBJ, USDZ, GLB tĩnh…; mô hình đã có xương thì không cần).
- Mô hình phải đứng thẳng, **mặt hướng về +Z**, dang tay chữ T hoặc xuôi tay chữ A.
- **Đoán tự động**: đặt sẵn 15 điểm theo kích thước mô hình. Sau đó **chạm vào nhân vật** để chỉnh từng điểm (đỉnh đầu, cổ, hông, vai, khuỷu, cổ tay, khớp háng, đầu gối, cổ chân; mỗi bên một bộ). Bật "Lấy giữa thân" để điểm nằm trong tay, chân thay vì trên da.
- Kéo để xoay, hai ngón để phóng to; nên đặt khuỷu và đầu gối khi nhìn ngang nếu bị che.
- **Xem thử**: đứng, đi, chạy, Hành động (nhảy, vẫy tay, nhảy múa) ngay trong màn hình. Ổn thì bấm **Lưu**, nhân vật được dùng luôn để đi dạo.
- App tự tính trọng số cho từng đỉnh (gần đoạn xương nào thì theo xương đó), nên vùng khớp có thể hơi méo; đặt điểm sát khớp thật sẽ đẹp hơn. Điểm đã đặt lưu trong máy (chưa nằm trong Sao lưu).

## Điều hướng kiểu game khi đang sửa (bên ngoài)
- **Cần tròn góc dưới trái**: đẩy lên đi tới, kéo xuống lùi, sang hai bên đi ngang (đi xa nhanh hơn khi camera ở cao).
- **Vuốt một ngón trên màn hình**: xoay hướng nhìn. Vuốt trái quay trái, vuốt phải quay phải, vuốt lên ngước lên (góc thấp dần), vuốt xuống cúi xuống (nhìn từ cao hơn).
- **Nút Trên cao** (góc dưới phải): bay lên xem toàn cảnh từ trên xuống; bấm **Hạ xuống** để về đúng góc nhìn cũ. Giữ mũi tên ▲ / ▼ để nâng hoặc hạ camera từ từ.
- Hai ngón: chụm để zoom, xoay hai ngón để quay hướng nhìn (vẫn dùng được).

## Cây cối, hoa lá thật và bộ miền Tây (có sẵn, không cần nhập file)
Cây dựng từ từng phiến lá riêng (có gân, cong, rủ, đung đưa theo gió), gom vào một khối nên không nặng máy.
- **Nhóm Cây cối** (thêm): Cây ăn trái (xoài, nhãn, bưởi, cam, mận), Chuối (buồng xanh / chín / chuối con), Tre (xanh / vàng), Hồ sen (hồng / trắng / chỉ lá), Bồn hoa cúc (5 màu), Dâm bụt (đỏ / hồng / vàng), Mai vàng (nở rộ / có lá), Cây bần (rễ thở cọc bần), Ruộng lúa (xanh / chín / mạ non), Thanh long (đỏ / vàng).
- **Nhóm Miền Tây**: Nhà cổ Nam Bộ, Chùa Khmer, Ghe chợ nổi có cây bẹo, Bè cá, Lò gạch, Đống rơm, Giàn bầu / mướp / bí, Lu nước, Đàn vịt, Trâu bò, Bến sông, Quán võng.
- Bấm **Chọn** → chạm vật thể → **Màu** để đổi kiểu. Menu → xóm miền Tây mẫu có sẵn các loại này.

## Thư viện mô hình: tìm kiếm, chuyên mục, sao lưu, đồng bộ
Nhóm **Mô hình** ở thanh dưới → ô **Thư viện** (hình giá sách) mở màn hình quản lý:
- **Tìm kiếm**: gõ tên hoặc tên chuyên mục, không phân biệt hoa thường và dấu tiếng Việt.
- **Chuyên mục**: bấm **+ Chuyên mục** để tạo; giữ lâu một chuyên mục để đổi tên hoặc xóa (mô hình trong đó không bị xóa). Giữ lâu một mô hình (hoặc vuốt) để chuyển chuyên mục hoặc xóa.
- **Nhập vào chuyên mục**: chọn chuyên mục ở hàng trên rồi bấm dấu **+** (góc phải) để nhập; mô hình mới vào thẳng chuyên mục đó. Đang ở "Tất cả" thì vào "Chưa phân loại".
- **Sắp xếp** (nút mũi tên lên xuống): theo tên, theo chuyên mục (chia nhóm), hoặc mới nhất.
- **Sao lưu** (nút mây → Sao lưu thư viện): tạo file `.zip` gồm toàn bộ mô hình, chuyên mục và thành phố đang dựng; lưu vào Tệp / iCloud Drive hoặc gửi đi. **Khôi phục** từ file đó: thêm các mô hình còn thiếu, gộp chuyên mục; nếu bản sao lưu có thành phố thì hỏi có thay thành phố hiện tại không.
- **Đồng bộ giữa các máy** (nút mây → Chọn thư mục đồng bộ): chọn một thư mục bất kỳ trong Tệp (nên là thư mục trong iCloud Drive, hoặc Dropbox / OneDrive nếu đã cài). Trên mỗi máy chọn cùng thư mục đó rồi bấm **Đồng bộ ngay**: mô hình chỉ có ở một bên được chép sang bên kia, chuyên mục được gộp (khác nhau thì bản sửa sau cùng thắng). Dữ liệu nằm trong thư mục con `CityBuilder`. Việc **xóa** mô hình hoặc thành phố không được đồng bộ; thành phố dùng Sao lưu / Khôi phục.

## Mô hình đóng sẵn
Thư mục `Builtin/` chứa mô hình được đóng thẳng vào app (hiện có **Nhân vật nam**, `Male_Character.obj` + `.mtl`). Lần chạy đầu app chép chúng vào thư viện Mô hình; xóa đi thì không tự thêm lại. Muốn thêm mô hình khác: bỏ file vào `Builtin/` và thêm một dòng vào danh sách `list` trong `installBuiltinModels()` (SceneController.swift).

## Điều khiển camera (kiểu bản đồ)
- **Kéo một ngón**: lướt đi bất kỳ đâu (điểm dưới ngón tay dính theo ngón, thả tay còn trượt tiếp). Có thể đi xa tới 290 m quanh tâm và xây ở đó.
- **Chụm hai ngón**: zoom, giữ nguyên điểm ở giữa hai ngón. **Xoay hai ngón**: xoay hướng nhìn. **Kéo dọc hai ngón**: nghiêng góc nhìn.
- **Chạm**: đặt công trình hoặc chọn để sửa, ở mọi vị trí đang nhìn thấy.
- Nút **◎** (trên cùng) hoặc menu ⋯ → Góc nhìn: về giữa thành phố, hoặc nhìn thẳng từ trên xuống.
- **Đi dạo cùng nhân vật 3D** (nút 🚶 trên cùng): một nhân vật 3D xuất hiện đúng chỗ camera đang nhìn, camera đi theo sau lưng như game góc nhìn thứ ba.
  - **Nửa trái màn hình**: chạm chỗ nào cần đi hiện ra ngay chỗ đó. Đẩy lên = nhân vật đi ra xa camera, kéo xuống = đi về phía camera, sang hai bên = đi ngang. Đẩy nhẹ thì đi bộ, đẩy hết cỡ thì đi nhanh; nhân vật tự quay người về hướng đi, chân tay đánh theo bước đi; thả tay thì đứng lại.
  - **Nửa phải màn hình**: kéo để xoay camera quanh nhân vật (vuốt phải = quay phải, vuốt trái = quay trái, vuốt lên = camera hạ thấp, vuốt xuống = camera lên cao); thả tay vẫn trượt thêm một chút cho mượt.
  - **Bay lên cao** (nút lớn góc dưới phải): camera lùi ra và nhìn từ trên xuống để xem toàn thành phố, nhân vật vẫn điều khiển được; bấm **Xuống đất** để về sau lưng nhân vật. Giữ ▲ / ▼ để lùi xa hoặc lại gần.
  - Nút nhỏ góc trên phải: **Đổi trang phục**, **Chạy nhanh** (gấp 2,2 lần), **Thoát** (về camera bản đồ, nhìn đúng chỗ nhân vật đứng).
  - Nhân vật không đi xuyên nhà, chùa, lò gạch và thân cây (trượt dọc theo tường). Kênh, ao, ruộng thì chưa chặn.
  - Khi đi dạo, toàn bộ giao diện khác được ẩn. Chạm không đặt / chọn / xóa gì.
- **Tới đây** (thanh nút khi đã chọn một vật): đưa camera tới vật đó.
- **Mở từ Tệp:** trong ứng dụng Tệp, giữ file zip / usdz / obj → Chia sẻ → City Builder, app tự nhập (đường dự phòng nếu nút Nhập có vấn đề).

## Rừng đước, vuông tôm, mương nước Cà Mau
Dựng theo mô hình **tôm - rừng** ở Cà Mau (Năm Căn, Ngọc Hiển): đê bao đất quanh vuông, mương nước bao quanh tán rừng đước, rừng chiếm khoảng 60% và mặt nước khoảng 40%.
- **Cây đước** (nhóm Cây cối): thân thẳng, nhiều rễ chống cong xuống bùn, lá dày bóng, trái dài rủ xuống, cây con cắm trong bùn. Bấm "Màu" để đổi đước già / đước non.
- **Rừng đước** (nhóm Cây cối): cụm 7 - 11 cây trên nền bùn có vũng nước. Bấm "Màu" để đổi rừng già cao / rừng non dày.
- **Vuông tôm** (nhóm Miền Tây): vuông 16 x 12 m có đê bao phủ cỏ, cống bọng lấy nước kèm mương dẫn, chòi canh mái lá có cầu tre, xuồng, bèo tây, đước non trên đê. Bấm "Màu" để đổi: rừng bao (lỏi rừng giữa vuông, mương chạy vòng) / dạng líp (rừng trồng trên líp xen mương, có vó tôm) / vuông quảng canh nhiều mặt nước.
- **Mương nước** (nhóm Hạ tầng): chạm điểm đầu rồi các điểm tiếp theo như Kênh, nhưng hẹp hơn (2,4 m). Bấm "Màu" để đổi bờ đất cỏ / kè cừ tràm / bờ trồng đước con giữ đất. Nước chảy nhẹ.
- Menu → "Vuông tôm rừng đước Cà Mau" tạo cảnh mẫu: sông, mương dẫn nước, bốn vuông tôm, rừng đước phòng hộ, xóm nhà sàn.

## Chuyển động
Nước kênh chảy liên tục (hai lớp gợn trôi lệch tốc độ). Cây, dừa, dừa nước, cỏ đung đưa theo một hướng gió chung; tán lá và tàu dừa rung nhẹ riêng. Xuồng nhấp nhô theo sóng.

## Hình ảnh thực tế
Mọi mô hình dùng vật liệu PBR có texture (gỗ, mái lá, tôn gỉ, ngói, gạch, vữa, vỏ dừa, cỏ, nước...), tàu lá dừa có lá chét thật, ánh sáng bầu trời, bóng đổ mềm, sương mù chân trời.

Texture mặc định được app tự vẽ bằng code. Muốn dùng **ảnh chụp thật**, chép ảnh vào thư mục `Sources/` (hoặc `Sources/Textures/`) với đúng tên, định dạng `.jpg` hoặc `.png`, ảnh nên vuông, lặp liền mạch (tileable), 512–1024 px:

`grass, dirt, asphalt, concrete, wood, woodDark, woodPaint, thatch, tole, brick, roofTile, plaster, palmBark, water, bamboo`

Ảnh lá có nền trong suốt (PNG): `needle` (lá kim thông, phủ kín), `frondMask` (tàu lá dừa, trục nằm ngang, gốc bên trái), `nipaMask` (lá dừa nước, cùng kiểu), `leafMask` (mảng lá phủ kín cho tán cây), `grassTuft` (bụi cỏ, gốc ở đáy ảnh).

Ghi chú xuất file: USDZ giữ texture; OBJ có thể mất texture/độ trong suốt của lá tùy trình xem.

## Build bằng GitHub Actions
1. Đưa toàn bộ thư mục này lên repo GitHub (đảm bảo có `.github/workflows/build.yml`, `project.yml` và thư mục `Sources` ở gốc repo).
2. Tab **Actions** → **Build iOS IPA** → **Run workflow**.
3. Khi xong, tải artifact **CityBuilder-ipa** (file `CityBuilder.ipa`, chưa ký).
4. Ký lại bằng chứng chỉ cá nhân của bạn rồi cài lên iPhone.

## Rừng đước thật (v13)
Cây đước, rừng đước, vuông tôm và mương nước Cà Mau được dựng lại theo ảnh thật rừng đước:
- **Thân** thẳng, thon, vỏ xám be nứt dọc có mắt vỏ (ảnh `barkDuoc`).
- **Rễ chống** nâu sẫm cong như vòm, có rễ phụ chẻ nhánh, chân loe cắm xuống bùn.
- **Lá** bầu dục dày bóng, mọc đối chéo chữ thập ở đầu cành, chồi ngọn lá non vàng xanh (ảnh `leafDuoc`).
- **Trái** hình thoi dài đỏ nâu, cổ xanh vàng, rủ thành chùm; trái rụng cắm xuống bùn thành cây con (ảnh `fruitDuoc`).
- **Bùn** xám be có mảng nâu ướt, gồ ghề nhẹ, lỗ cua, lá mục, trái rụng, vũng nước đọng (ảnh `mudWet`).
- **Nước lợ** xanh ô liu đục, có bóng thân cây và ánh phù sa, chảy nhẹ (ảnh `waterBrack`).
Các ảnh nằm trong `Sources/Assets.xcassets`; muốn đổi bằng ảnh chụp thật, thay file cùng tên trong từng thư mục `.imageset`. Mỗi cây chỉ gồm 5 khối hình nên nhẹ máy.
