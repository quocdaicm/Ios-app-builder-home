# City Builder

Ứng dụng iOS (SwiftUI + SceneKit) để đặt nhà, tòa nhà, cây, đường phố trong không gian 3D rồi xuất file OBJ / USDZ cho game.

## Cách dùng
- Chọn công cụ ở thanh dưới, chạm lên nền để đặt.
- **Đường**: chạm điểm đầu, rồi chạm các điểm tiếp theo. Bấm "Dừng đường" khi xong.
- **Chọn**: chạm vật thể rồi xoay, đổi cỡ, đổi màu, dời, xóa.
- Một ngón kéo = xoay camera, hai ngón = dời, chụm = zoom.
- Miền Tây: Nhà sàn (mái lá / tôn), Nhà tôn, Dừa, Dừa nước, Cỏ, Kênh (bờ đất / kè gạch), Cầu khỉ, Xuồng. Chọn kênh hoặc đường rồi bấm "Màu" để đổi kiểu.
- Menu → "Tạo xóm miền Tây mẫu" hoặc "Tạo khu phố mẫu" để xem thử nhanh.
- Menu → "Xuất OBJ" rồi lưu vào Tệp hoặc gửi đi.
- Dự án tự lưu, mở lại app vẫn còn.

## Hình ảnh thực tế
Mọi mô hình dùng vật liệu PBR có texture (gỗ, mái lá, tôn gỉ, ngói, gạch, vữa, vỏ dừa, cỏ, nước...), tàu lá dừa có lá chét thật, ánh sáng bầu trời, bóng đổ mềm, sương mù chân trời.

Texture mặc định được app tự vẽ bằng code. Muốn dùng **ảnh chụp thật**, chép ảnh vào thư mục `Sources/` (hoặc `Sources/Textures/`) với đúng tên, định dạng `.jpg` hoặc `.png`, ảnh nên vuông, lặp liền mạch (tileable), 512–1024 px:

`grass, dirt, asphalt, concrete, wood, woodDark, woodPaint, thatch, tole, brick, roofTile, plaster, palmBark, water, bamboo`

Ảnh lá có nền trong suốt (PNG): `needle` (lá kim thông, phủ kín), `frondMask` (tàu lá dừa, trục nằm ngang, gốc bên trái), `nipaMask` (lá dừa nước, cùng kiểu), `leafMask` (mảng lá phủ kín cho tán cây), `grassTuft` (bụi cỏ, gốc ở đáy ảnh).

Ghi chú xuất file: USDZ giữ texture; OBJ có thể mất texture/độ trong suốt của lá tùy trình xem.

## Build bằng GitHub Actions
1. Đưa toàn bộ thư mục này lên repo GitHub (đảm bảo có `.github/workflows/build.yml`, `project.yml` và thư mục `Sources` ở gốc repo).
2. Tab **Actions** → **Build iOS IPA** → **Run workflow**.
3. Khi xong, tải artifact **CityBuilder-ipa** (file `CityBuilder.ipa`, chưa ký).
4. Ký lại bằng chứng chỉ cá nhân của bạn rồi cài lên iPhone.
