import SceneKit
import UIKit

// MARK: - Nối đoạn đường / kênh / mương

/// Thông tin chỗ nối ở hai đầu một đoạn. `tanStart` / `tanEnd` = tan(φ/2) với φ là góc rẽ có dấu
/// giữa đoạn này và đoạn nối tiếp (0 = không nối hoặc đi thẳng).
struct LineJoin: Equatable {
    var tanStart: Float = 0
    var tanEnd: Float = 0
    static let none = LineJoin()
}

extension Builder {
    /// Độ dài và độ lệch tâm của một dải chạy song song trục đoạn, cách trục `e` m, sau khi cắt vát theo góc nối:
    /// phía ngoài góc kéo dài ra, phía trong góc rút ngắn lại, nên hai đoạn khép kín thành một góc liền mạch.
    static func jspan(_ len: Float, _ e: Float, _ j: LineJoin) -> (Float, Float) {
        let lim = len * 0.45
        let s = max(-lim, min(8, -e * j.tanStart))
        let t = max(-lim, min(8, -e * j.tanEnd))
        return (len + s + t, (t - s) / 2)
    }

    /// Như `tbox` nhưng là dải dọc đoạn (bờ, vỉa, dải cỏ) có tính chỗ nối. `z` là khoảng cách từ trục đoạn.
    static func jbox(_ len: Float, _ j: LineJoin, _ h: Float, _ l: Float, _ t: Tex, tint: UIColor? = nil,
                     tile: Float = 2, y: Float = 0, z: Float = 0) -> SCNNode {
        let (length, cx) = jspan(len, z, j)
        return tbox(length, h, l, t, tint: tint, tile: tile, x: cx, y: y, z: z)
    }

    /// Mảnh đệm đặt tại điểm nối hai đoạn cùng loại: mặt đường / mặt nước phủ kín góc.
    /// `dir` là hướng của đoạn đầu tiên; `round` = true cho mảnh tròn (góc nhẹ), false cho mảnh vuông (góc gắt).
    static func lineJoint(kind: Kind, variant: Int, dir: SIMD2<Float>, round: Bool) -> SCNNode? {
        let root = SCNNode()
        root.eulerAngles.y = atan2(-dir.y, dir.x)
        let lift: Float = 0.008      // cao hơn mặt đoạn vài mm để không nhấp nháy

        switch kind {
        case .road:
            let v = variant % 3
            let width: Float = v == 0 ? 3.2 : (v == 1 ? 2.4 : 2.6)
            let t: Tex = v == 0 ? .asphalt : (v == 1 ? .concrete : .dirt)
            let h: Float = v == 2 ? 0.06 : 0.1
            let rough: CGFloat = v == 0 ? 0.9 : 0.95
            let topM = tex(t, rough: rough, rx: rep(width, 4), ry: rep(width, 4))
            let sideM = tex(t, rough: rough, rx: 1, ry: 0.1)
            root.addChildNode(slab(width, h, topM, sideM, round: round, lift: lift))
        case .villageRoad:
            let v = variant % 3
            let width: Float = 2.2
            let h: Float = v == 0 ? 0.05 : 0.08
            let t: Tex = v == 0 ? .dirt : (v == 1 ? .brick : .concrete)
            let tint: UIColor = v == 0 ? rgb(1.12, 0.84, 0.64) : (v == 1 ? rgb(1.0, 0.80, 0.72) : rgb(0.96, 0.96, 0.93))
            let tile: Float = v == 1 ? 1.5 : 3
            let topM = tex(t, tint: tint, rough: 0.95, rx: rep(width, tile), ry: rep(width, tile))
            let sideM = tex(t, tint: tint, rough: 0.95, rx: 1, ry: 0.1)
            root.addChildNode(slab(width, h, topM, sideM, round: round, lift: lift))
        case .canal:
            let w = canalWater(4.0, 4.0, round: round)
            w.position.y += lift
            root.addChildNode(w)
        case .muongBo:
            let w = flowWater(2.4, 2.4, tint: mangroveWaterTint, period: 12, round: round)
            w.position.y += lift
            root.addChildNode(w)
        default:
            return nil
        }
        return root
    }

    private static func slab(_ width: Float, _ h: Float, _ top: SCNMaterial, _ side: SCNMaterial,
                             round: Bool, lift: Float) -> SCNNode {
        let n: SCNNode
        if round {
            let c = SCNCylinder(radius: CGFloat(width / 2), height: CGFloat(h))
            c.radialSegmentCount = 24
            c.materials = [side, top, side]
            n = SCNNode(geometry: c)
        } else {
            let g = SCNBox(width: CGFloat(width), height: CGFloat(h), length: CGFloat(width), chamferRadius: 0)
            g.materials = [side, side, side, side, top, side]
            n = SCNNode(geometry: g)
        }
        n.position = SCNVector3(0, h / 2 + lift, 0)
        return n
    }
}
