import SceneKit
import SwiftUI
import UIKit

struct ShareSheet: UIViewControllerRepresentable {
    let url: URL

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: [url], applicationActivities: nil)
    }

    func updateUIViewController(_ vc: UIActivityViewController, context: Context) {}
}

struct SceneContainer: UIViewRepresentable {
    let controller: SceneController

    func makeCoordinator() -> Coordinator {
        Coordinator(controller)
    }

    func makeUIView(context: Context) -> SCNView {
        let v = SCNView()
        v.scene = controller.scene
        v.pointOfView = controller.cameraNode
        v.allowsCameraControl = true
        v.antialiasingMode = .multisampling4X
        v.autoenablesDefaultLighting = false
        v.rendersContinuously = true      // để mặt nước chuyển động
        v.preferredFramesPerSecond = 60

        let cc = v.defaultCameraController
        cc.interactionMode = .orbitTurntable
        cc.maximumVerticalAngle = 85
        cc.minimumVerticalAngle = 5
        cc.target = SCNVector3(0, 0, 0)

        let tap = UITapGestureRecognizer(target: context.coordinator,
                                         action: #selector(Coordinator.tapped(_:)))
        v.addGestureRecognizer(tap)
        context.coordinator.view = v
        return v
    }

    func updateUIView(_ uiView: SCNView, context: Context) {}

    final class Coordinator: NSObject {
        let controller: SceneController
        weak var view: SCNView?

        init(_ controller: SceneController) {
            self.controller = controller
        }

        @objc func tapped(_ g: UITapGestureRecognizer) {
            guard let v = view else { return }
            controller.handleTap(at: g.location(in: v), in: v)
        }
    }
}

// MARK: - Giao diện

enum Theme {
    static let accent = Color(red: 0.20, green: 0.78, blue: 0.42)
    static let accent2 = Color(red: 0.12, green: 0.62, blue: 0.72)
    static let amber = Color(red: 1.00, green: 0.72, blue: 0.20)
    static let danger = Color(red: 1.00, green: 0.38, blue: 0.36)
    static let ink = Color(red: 0.04, green: 0.13, blue: 0.20)
    static let gradient = LinearGradient(colors: [accent2, accent],
                                         startPoint: .topLeading, endPoint: .bottomTrailing)
}

enum ToolGroup: String, CaseIterable, Identifiable {
    case buildings = "Công trình"
    case nature = "Cây cối"
    case infra = "Hạ tầng"

    var id: String { rawValue }

    var symbol: String {
        switch self {
        case .buildings: return "building.2.fill"
        case .nature:    return "tree.fill"
        case .infra:     return "water.waves"
        }
    }

    var tools: [Tool] {
        switch self {
        case .buildings: return [.stilt, .tole, .house, .tower]
        case .nature:    return [.coconut, .nipa, .grass, .tree, .pine]
        case .infra:     return [.canal, .road, .bridge, .boat]
        }
    }
}

extension Tool {
    var symbol: String {
        switch self {
        case .select:  return "cursorarrow.click"
        case .stilt:   return "tent.fill"
        case .tole:    return "house.circle.fill"
        case .house:   return "house.fill"
        case .coconut: return "leaf.fill"
        case .nipa:    return "leaf"
        case .grass:   return "camera.macro"
        case .tree:    return "tree.fill"
        case .pine:    return "triangle.fill"
        case .tower:   return "building.2.fill"
        case .canal:   return "water.waves"
        case .road:    return "arrow.triangle.turn.up.right.diamond.fill"
        case .bridge:  return "link"
        case .boat:    return "sailboat.fill"
        case .erase:   return "trash.fill"
        }
    }

    var group: ToolGroup? {
        ToolGroup.allCases.first { $0.tools.contains(self) }
    }
}

struct LogoMark: View {
    var size: CGFloat = 36

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: size * 0.26, style: .continuous)
                .fill(Theme.gradient)
            Image(systemName: "building.2.fill")
                .font(.system(size: size * 0.5, weight: .semibold))
                .foregroundColor(.white)
        }
        .frame(width: size, height: size)
        .shadow(color: Theme.accent.opacity(0.35), radius: size * 0.2, y: size * 0.08)
    }
}

struct GlassBackground: ViewModifier {
    var radius: CGFloat = 18

    func body(content: Content) -> some View {
        content
            .background(.ultraThinMaterial,
                        in: RoundedRectangle(cornerRadius: radius, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: radius, style: .continuous)
                    .stroke(Color.white.opacity(0.14), lineWidth: 0.5)
            )
            .shadow(color: .black.opacity(0.25), radius: 10, y: 4)
    }
}

extension View {
    func glass(radius: CGFloat = 18) -> some View {
        modifier(GlassBackground(radius: radius))
    }
}

struct SplashView: View {
    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(red: 0.07, green: 0.29, blue: 0.36), Theme.ink],
                           startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()
            VStack(spacing: 16) {
                LogoMark(size: 96)
                Text("City Builder")
                    .font(.system(size: 30, weight: .bold, design: .rounded))
                    .foregroundColor(.white)
                Text("Dựng thành phố 3D của riêng bạn")
                    .font(.subheadline)
                    .foregroundColor(.white.opacity(0.7))
            }
        }
    }
}

struct ContentView: View {
    @StateObject private var c = SceneController()
    @State private var confirmClear = false
    @State private var group: ToolGroup = .buildings
    @State private var showSplash = true

    var body: some View {
        ZStack {
            SceneContainer(controller: c)
                .ignoresSafeArea()

            VStack(spacing: 10) {
                topBar
                hintCard
                Spacer()
                if c.tool.isLine, c.roadStart != nil {
                    stopButton
                }
                if c.selectedID != nil {
                    actionBar
                }
                toolDock
            }
            .padding(.horizontal, 12)
            .padding(.bottom, 8)

            if showSplash {
                SplashView()
                    .transition(.opacity)
                    .zIndex(1)
            }
        }
        .preferredColorScheme(.dark)
        .tint(Theme.accent)
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
                withAnimation(.easeOut(duration: 0.4)) { showSplash = false }
            }
        }
        .onChange(of: c.tool) { t in
            if let g = t.group { group = g }
        }
        .sheet(item: $c.shareItem) { item in
            ShareSheet(url: item.url)
        }
        .confirmationDialog("Xóa toàn bộ thành phố?", isPresented: $confirmClear, titleVisibility: .visible) {
            Button("Xóa tất cả", role: .destructive) { c.clearAll() }
        }
    }

    // MARK: Thanh trên

    private var topBar: some View {
        HStack(spacing: 10) {
            HStack(spacing: 10) {
                LogoMark(size: 34)
                VStack(alignment: .leading, spacing: 1) {
                    Text("City Builder")
                        .font(.system(.subheadline, design: .rounded).weight(.bold))
                    Text(c.tool.title)
                        .font(.caption2.weight(.medium))
                        .foregroundColor(Theme.accent)
                }
            }
            .padding(.leading, 6)
            .padding(.trailing, 14)
            .padding(.vertical, 6)
            .glass(radius: 22)

            Spacer()

            circleButton("arrow.uturn.backward") { c.undo() }

            Menu {
                Section("Mẫu có sẵn") {
                    Button { c.addSampleMekong() } label: { Label("Xóm miền Tây", systemImage: "water.waves") }
                    Button { c.addSample() } label: { Label("Khu phố", systemImage: "building.2") }
                }
                Section("Tùy chọn") {
                    Toggle("Căn theo lưới", isOn: $c.snapToGrid)
                    Toggle("Kèm mặt đất khi xuất", isOn: $c.includeGround)
                }
                Section("Xuất file") {
                    Button { c.export(.obj) } label: { Label("Xuất OBJ (cho game)", systemImage: "square.and.arrow.up") }
                    Button { c.export(.usdz) } label: { Label("Xuất USDZ", systemImage: "arkit") }
                    Button { c.export(.scn) } label: { Label("Xuất SCN (SceneKit)", systemImage: "cube") }
                }
                Button(role: .destructive) { confirmClear = true } label: {
                    Label("Xóa tất cả", systemImage: "trash")
                }
            } label: {
                Image(systemName: "ellipsis")
                    .font(.system(size: 16, weight: .bold))
                    .foregroundColor(.white)
                    .frame(width: 42, height: 42)
                    .glass(radius: 21)
            }
        }
    }

    private var hintCard: some View {
        HStack(alignment: .top, spacing: 8) {
            Image(systemName: "info.circle.fill")
                .foregroundColor(Theme.accent)
            Text(c.message)
                .font(.footnote)
                .foregroundColor(.white.opacity(0.92))
                .fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 9)
        .glass(radius: 14)
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func circleButton(_ symbol: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: 16, weight: .bold))
                .foregroundColor(.white)
                .frame(width: 42, height: 42)
                .glass(radius: 21)
        }
    }

    // MARK: Thanh thao tác

    private var stopButton: some View {
        Button { c.stopRoad() } label: {
            Label("Dừng vẽ", systemImage: "stop.fill")
                .font(.subheadline.weight(.bold))
                .foregroundColor(Theme.ink)
                .padding(.horizontal, 20)
                .padding(.vertical, 11)
                .background(Theme.amber, in: Capsule())
                .shadow(color: Theme.amber.opacity(0.4), radius: 10, y: 3)
        }
    }

    private var actionBar: some View {
        HStack(spacing: 6) {
            actionButton("arrow.clockwise", "Xoay") { c.rotateSelected() }
            actionButton("plus.magnifyingglass", "To") { c.scaleSelected(1.2) }
            actionButton("minus.magnifyingglass", "Nhỏ") { c.scaleSelected(1 / 1.2) }
            actionButton("paintpalette.fill", "Màu") { c.recolorSelected() }
            actionButton(c.moveMode ? "mappin.and.ellipse" : "arrow.up.and.down.and.arrow.left.and.right",
                         c.moveMode ? "Chạm đặt" : "Dời",
                         highlighted: c.moveMode) { c.toggleMove() }
            actionButton("trash.fill", "Xóa", tint: Theme.danger) { c.deleteSelected() }
        }
        .padding(6)
        .glass(radius: 20)
    }

    private func actionButton(_ symbol: String, _ title: String,
                              highlighted: Bool = false,
                              tint: Color = .white,
                              action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: 3) {
                Image(systemName: symbol)
                    .font(.system(size: 17, weight: .semibold))
                Text(title)
                    .font(.system(size: 10, weight: .semibold))
                    .lineLimit(1)
            }
            .foregroundColor(highlighted ? Theme.ink : tint)
            .frame(maxWidth: .infinity)
            .frame(height: 48)
            .background(highlighted ? Theme.amber : Color.white.opacity(0.08),
                        in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        }
    }

    // MARK: Dock công cụ

    private var toolDock: some View {
        VStack(spacing: 8) {
            HStack(spacing: 6) {
                dockChip(.select)
                ForEach(ToolGroup.allCases) { g in
                    groupChip(g)
                }
                dockChip(.erase)
            }

            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    ForEach(group.tools) { t in
                        toolTile(t)
                    }
                }
                .padding(.horizontal, 2)
            }
        }
        .padding(10)
        .glass(radius: 24)
    }

    private func dockChip(_ t: Tool) -> some View {
        let on = c.tool == t
        return Button { c.setTool(t) } label: {
            HStack(spacing: 5) {
                Image(systemName: t.symbol)
                    .font(.system(size: 13, weight: .bold))
                if on {
                    Text(t.title).font(.system(size: 12, weight: .bold)).lineLimit(1)
                }
            }
            .foregroundColor(on ? (t == .erase ? .white : Theme.ink) : .white.opacity(0.85))
            .padding(.horizontal, 11)
            .frame(height: 34)
            .background(on ? (t == .erase ? Theme.danger : Theme.accent) : Color.white.opacity(0.09),
                        in: Capsule())
        }
    }

    private func groupChip(_ g: ToolGroup) -> some View {
        let on = group == g
        return Button {
            withAnimation(.easeInOut(duration: 0.18)) { group = g }
        } label: {
            HStack(spacing: 5) {
                Image(systemName: g.symbol)
                    .font(.system(size: 13, weight: .bold))
                if on {
                    Text(g.rawValue).font(.system(size: 12, weight: .bold)).lineLimit(1)
                }
            }
            .foregroundColor(on ? .white : .white.opacity(0.7))
            .padding(.horizontal, 11)
            .frame(height: 34)
            .background(on ? Theme.accent2 : Color.white.opacity(0.09), in: Capsule())
            .overlay(Capsule().stroke(on ? Color.white.opacity(0.25) : .clear, lineWidth: 0.5))
        }
    }

    private func toolTile(_ t: Tool) -> some View {
        let on = c.tool == t
        return Button { c.setTool(t) } label: {
            VStack(spacing: 6) {
                Image(systemName: t.symbol)
                    .font(.system(size: 22, weight: .semibold))
                    .frame(height: 26)
                Text(t.title)
                    .font(.system(size: 11, weight: .semibold))
                    .lineLimit(1)
            }
            .foregroundColor(on ? Theme.ink : .white)
            .frame(width: 74, height: 66)
            .background(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .fill(on ? AnyShapeStyle(Theme.gradient) : AnyShapeStyle(Color.white.opacity(0.08)))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .stroke(on ? Color.white.opacity(0.4) : Color.white.opacity(0.06), lineWidth: 0.5)
            )
        }
    }
}
