import Combine
import SceneKit
import SwiftUI
import simd
import UIKit
import UniformTypeIdentifiers

struct ShareSheet: UIViewControllerRepresentable {
    let url: URL

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: [url], applicationActivities: nil)
    }

    func updateUIViewController(_ vc: UIActivityViewController, context: Context) {}
}

struct SceneContainer: UIViewRepresentable {
    let controller: SceneController

    func makeCoordinator() -> Coordinator {
        Coordinator(controller)
    }

    func makeUIView(context: Context) -> SCNView {
        let v = SCNView()
        v.scene = controller.scene
        v.pointOfView = controller.cameraNode
        v.allowsCameraControl = false      // camera tự làm kiểu bản đồ, xem Coordinator
        v.antialiasingMode = .multisampling4X
        v.autoenablesDefaultLighting = false
        v.rendersContinuously = true      // để mặt nước chuyển động
        v.preferredFramesPerSecond = 60

        let co = context.coordinator
        co.view = v

        let tap = UITapGestureRecognizer(target: co, action: #selector(Coordinator.tapped(_:)))
        let pan = UIPanGestureRecognizer(target: co, action: #selector(Coordinator.pan(_:)))
        pan.minimumNumberOfTouches = 1
        pan.maximumNumberOfTouches = 1
        let tilt = UIPanGestureRecognizer(target: co, action: #selector(Coordinator.tilt(_:)))
        tilt.minimumNumberOfTouches = 2
        tilt.maximumNumberOfTouches = 2
        let pinch = UIPinchGestureRecognizer(target: co, action: #selector(Coordinator.pinch(_:)))
        let rotate = UIRotationGestureRecognizer(target: co, action: #selector(Coordinator.rotate(_:)))
        co.onePan = pan
        for g in [tap, pan, tilt, pinch, rotate] as [UIGestureRecognizer] {
            g.delegate = co
            v.addGestureRecognizer(g)
        }
        return v
    }

    func updateUIView(_ uiView: SCNView, context: Context) {}

    final class Coordinator: NSObject, UIGestureRecognizerDelegate {
        let controller: SceneController
        weak var view: SCNView?
        weak var onePan: UIPanGestureRecognizer?

        private var anchor: SIMD2<Float>?
        private var startDist: Float = 44
        private var startYaw: Float = 0
        private var startPitch: Float = 0.69

        init(_ controller: SceneController) {
            self.controller = controller
        }

        func gestureRecognizer(_ g: UIGestureRecognizer,
                               shouldRecognizeSimultaneouslyWith other: UIGestureRecognizer) -> Bool {
            // chụm / xoay / nghiêng chạy cùng lúc; kéo một ngón đứng riêng
            g !== onePan && other !== onePan
        }

        @objc func tapped(_ g: UITapGestureRecognizer) {
            guard let v = view else { return }
            controller.stopInertia()
            controller.handleTap(at: g.location(in: v), in: v)
        }

        /// Kéo một ngón: điểm đất dưới ngón tay dính theo ngón (như Google Maps).
        @objc func pan(_ g: UIPanGestureRecognizer) {
            guard let v = view else { return }
            if controller.walkMode {
                // chế độ đi dạo: kéo một ngón = nhìn quanh như game
                if g.state == .began {
                    g.setTranslation(.zero, in: v)
                } else if g.state == .changed {
                    let t = g.translation(in: v)
                    g.setTranslation(.zero, in: v)
                    controller.walkLookBy(dx: Float(t.x), dy: Float(t.y))
                }
                return
            }
            // kéo một ngón = xoay hướng nhìn như game: vuốt trái = quay trái, vuốt phải = quay phải,
            // vuốt lên = ngước lên (góc nhìn thấp dần), vuốt xuống = cúi xuống (nhìn từ trên cao hơn).
            // Muốn đi chỗ khác thì dùng cần tròn ở góc dưới bên trái.
            switch g.state {
            case .began:
                controller.stopInertia()
                g.setTranslation(.zero, in: v)
            case .changed:
                let t = g.translation(in: v)
                g.setTranslation(.zero, in: v)
                controller.setCamYaw(controller.camYaw - Float(t.x) * 0.006)
                controller.setCamPitch(controller.camPitch + Float(t.y) * 0.006)
            default:
                break
            }
        }

        /// Chụm hai ngón: zoom, giữ nguyên điểm đất ở giữa hai ngón.
        @objc func pinch(_ g: UIPinchGestureRecognizer) {
            guard !controller.walkMode, let v = view else { return }
            let p = g.location(in: v)
            switch g.state {
            case .began:
                controller.stopInertia()
                startDist = controller.camDist
                anchor = controller.groundRay(p, size: v.bounds.size)
            case .changed:
                controller.setCamDist(startDist / Float(max(g.scale, 0.05)))
                if let a = anchor, let cur = controller.groundRay(p, size: v.bounds.size) {
                    controller.moveTarget(by: a - cur)
                }
            default:
                anchor = nil
            }
        }

        /// Xoay hai ngón: xoay hướng nhìn.
        @objc func rotate(_ g: UIRotationGestureRecognizer) {
            guard !controller.walkMode else { return }
            if g.state == .began {
                controller.stopInertia()
                startYaw = controller.camYaw
            } else if g.state == .changed {
                controller.setCamYaw(startYaw + Float(g.rotation))
            }
        }

        /// Kéo dọc hai ngón: nghiêng góc nhìn (kéo lên = nhìn xa hơn).
        @objc func tilt(_ g: UIPanGestureRecognizer) {
            guard !controller.walkMode, let v = view else { return }
            if g.state == .began {
                startPitch = controller.camPitch
            } else if g.state == .changed {
                let ty = Float(g.translation(in: v).y)
                let dead: Float = 14
                let eff = abs(ty) < dead ? 0 : ty - (ty > 0 ? dead : -dead)
                controller.setCamPitch(startPitch + eff * 0.004)
            }
        }
    }
}

/// Cần điều khiển ảo kiểu game: kéo núm để đi, kéo càng xa càng nhanh, thả tay thì dừng.
struct JoystickView: View {
    var onChange: (SIMD2<Float>) -> Void
    @State private var knob = CGSize.zero
    private let radius: CGFloat = 60

    var body: some View {
        ZStack {
            Circle()
                .fill(Color.white.opacity(0.10))
                .overlay(Circle().stroke(Color.white.opacity(0.35), lineWidth: 1.5))
            Image(systemName: "arrow.up.and.down.and.arrow.left.and.right")
                .font(.system(size: 22, weight: .semibold))
                .foregroundColor(.white.opacity(0.25))
            Circle()
                .fill(LinearGradient(colors: [Color(red: 0.12, green: 0.62, blue: 0.72),
                                              Color(red: 0.20, green: 0.78, blue: 0.42)],
                                     startPoint: .topLeading, endPoint: .bottomTrailing))
                .frame(width: 56, height: 56)
                .shadow(color: .black.opacity(0.35), radius: 6, y: 3)
                .offset(knob)
        }
        .frame(width: radius * 2, height: radius * 2)
        .contentShape(Circle())
        .gesture(
            DragGesture(minimumDistance: 0)
                .onChanged { v in
                    let dx = v.location.x - radius
                    let dy = v.location.y - radius
                    let len = sqrt(dx * dx + dy * dy)
                    let k: CGFloat = len > radius ? radius / len : 1
                    knob = CGSize(width: dx * k, height: dy * k)
                    onChange(SIMD2<Float>(Float(dx * k / radius), Float(-dy * k / radius)))
                }
                .onEnded { _ in
                    knob = .zero
                    onChange(SIMD2<Float>(0, 0))
                }
        )
    }
}

// MARK: - Giao diện

enum Theme {
    static let accent = Color(red: 0.20, green: 0.78, blue: 0.42)
    static let accent2 = Color(red: 0.12, green: 0.62, blue: 0.72)
    static let amber = Color(red: 1.00, green: 0.72, blue: 0.20)
    static let danger = Color(red: 1.00, green: 0.38, blue: 0.36)
    static let ink = Color(red: 0.04, green: 0.13, blue: 0.20)
    static let gradient = LinearGradient(colors: [accent2, accent],
                                         startPoint: .topLeading, endPoint: .bottomTrailing)
}

enum ToolGroup: String, CaseIterable, Identifiable {
    case buildings = "Công trình"
    case nature = "Cây cối"
    case mekong = "Miền Tây"
    case infra = "Hạ tầng"
    case models = "Mô hình"

    var id: String { rawValue }

    var symbol: String {
        switch self {
        case .buildings: return "building.2.fill"
        case .nature:    return "tree.fill"
        case .mekong:    return "sun.haze.fill"
        case .infra:     return "water.waves"
        case .models:    return "shippingbox.fill"
        }
    }

    var tools: [Tool] {
        switch self {
        case .buildings: return [.stilt, .tole, .house, .tower]
        case .nature:    return [.coconut, .nipa, .grass, .tree, .pine, .fruit, .banana, .bamboo, .lotus, .flowers, .hibiscus, .mai, .ban, .duoc, .rungDuoc, .rice, .dragon]
        case .mekong:    return [.nhaCo, .chuaKhmer, .gheBeo, .beCa, .loGach, .rom, .gianBau, .luNuoc, .vit, .trau, .ben, .quan, .datVuon, .boAo, .vuongTom]
        case .infra:     return [.canal, .muongBo, .road, .duongLang, .bridge, .boat]
        case .models:    return [.model]
        }
    }
}

extension Tool {
    var symbol: String {
        switch self {
        case .select:  return "cursorarrow.click"
        case .stilt:   return "tent.fill"
        case .tole:    return "house.circle.fill"
        case .house:   return "house.fill"
        case .coconut: return "leaf.fill"
        case .nipa:    return "leaf"
        case .grass:   return "camera.macro"
        case .tree:    return "tree.fill"
        case .pine:    return "triangle.fill"
        case .tower:   return "building.2.fill"
        case .canal:   return "water.waves"
        case .road:    return "arrow.triangle.turn.up.right.diamond.fill"
        case .bridge:  return "link"
        case .boat:    return "sailboat.fill"
        case .erase:   return "trash.fill"
        case .model:   return "cube.fill"
        case .fruit: return "leaf.fill"
        case .banana: return "leaf.fill"
        case .bamboo: return "leaf.fill"
        case .lotus: return "leaf.fill"
        case .flowers: return "leaf.fill"
        case .hibiscus: return "leaf.fill"
        case .mai: return "leaf.fill"
        case .ban: return "leaf.fill"
        case .rice: return "leaf.fill"
        case .dragon: return "leaf.fill"
        case .nhaCo: return "sailboat.fill"
        case .chuaKhmer: return "sailboat.fill"
        case .gheBeo: return "sailboat.fill"
        case .beCa: return "sailboat.fill"
        case .loGach: return "sailboat.fill"
        case .rom: return "sailboat.fill"
        case .gianBau: return "sailboat.fill"
        case .luNuoc: return "sailboat.fill"
        case .vit: return "sailboat.fill"
        case .trau: return "sailboat.fill"
        case .ben: return "sailboat.fill"
        case .quan: return "sailboat.fill"
        case .datVuon: return "leaf.fill"
        case .boAo: return "drop.fill"
        case .duongLang: return "road.lanes"
        case .duoc: return "leaf.fill"
        case .rungDuoc: return "tree.fill"
        case .vuongTom: return "drop.fill"
        case .muongBo: return "water.waves"
        }
    }

    var group: ToolGroup? {
        ToolGroup.allCases.first { $0.tools.contains(self) }
    }
}

struct LogoMark: View {
    var size: CGFloat = 36

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: size * 0.26, style: .continuous)
                .fill(Theme.gradient)
            Image(systemName: "building.2.fill")
                .font(.system(size: size * 0.5, weight: .semibold))
                .foregroundColor(.white)
        }
        .frame(width: size, height: size)
        .shadow(color: Theme.accent.opacity(0.35), radius: size * 0.2, y: size * 0.08)
    }
}

struct GlassBackground: ViewModifier {
    var radius: CGFloat = 18

    func body(content: Content) -> some View {
        content
            .background(.ultraThinMaterial,
                        in: RoundedRectangle(cornerRadius: radius, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: radius, style: .continuous)
                    .stroke(Color.white.opacity(0.14), lineWidth: 0.5)
            )
            .shadow(color: .black.opacity(0.25), radius: 10, y: 4)
    }
}

extension View {
    func glass(radius: CGFloat = 18) -> some View {
        modifier(GlassBackground(radius: radius))
    }
}

struct SplashView: View {
    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(red: 0.07, green: 0.29, blue: 0.36), Theme.ink],
                           startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()
            VStack(spacing: 16) {
                LogoMark(size: 96)
                Text("City Builder")
                    .font(.system(size: 30, weight: .bold, design: .rounded))
                    .foregroundColor(.white)
                Text("Dựng thành phố 3D của riêng bạn")
                    .font(.subheadline)
                    .foregroundColor(.white.opacity(0.7))
            }
        }
    }
}

struct ContentView: View {
    @StateObject private var c = SceneController()
    @State private var confirmClear = false
    @State private var group: ToolGroup = .buildings
    @State private var showSplash = true
    @State private var showImporter = false
    @State private var showLibrary = false
    @State private var walkHintVisible = false
    @State private var hintHidden = false      // người dùng đã ẩn dòng mô tả; hiện lại khi có nội dung mới

    /// Liệt kê rõ các định dạng để bộ chọn file không báo "không hỗ trợ"; .item/.data làm lưới an toàn.
    private static let importTypes: [UTType] = {
        var t: [UTType] = [.zip, .usdz, .threeDContent, .data, .item]
        for ext in ["obj", "mtl", "dae", "scn", "usd", "usda", "usdc", "glb", "gltf", "vrm", "fbx", "bin", "jpg", "jpeg", "png"] {
            if let u = UTType(filenameExtension: ext) { t.append(u) }
        }
        return t
    }()

    var body: some View {
        ZStack {
            SceneContainer(controller: c)
                .ignoresSafeArea()
                .sheet(isPresented: $showLibrary) {
                    LibraryView(c: c, onImport: {
                        DocPicker.shared.present(types: Self.importTypes) { urls in
                            c.importModels(.success(urls))
                        }
                    })
                }

            // chế độ đi dạo: lớp điều khiển phủ toàn màn hình (nửa trái = cần đi, nửa phải = nhìn quanh)
            if c.walkMode {
                WalkPad(c: c)
                    .ignoresSafeArea()
            }

            VStack(spacing: 10) {
                if c.walkMode {
                    walkTopBar
                } else {
                    topBar
                    if !hintHidden && !c.message.isEmpty {
                        hintCard
                            .transition(.opacity)
                    }
                }
                Spacer()
                if c.walkMode {
                    walkControls
                } else {
                    navControls
                    if c.tool.isLine, c.tool != .bridge {
                        HStack(spacing: 10) {
                            cornerToggle
                            if c.roadStart != nil { stopButton }
                        }
                    }
                    if c.selectedID != nil {
                        actionBar
                    }
                    toolDock
                }
            }
            .padding(.horizontal, 12)
            .padding(.bottom, 8)
            .onReceive(c.$message.dropFirst()) { _ in
                // có hướng dẫn / thông báo mới thì hiện lại để không lỡ nội dung quan trọng
                withAnimation(.easeOut(duration: 0.2)) { hintHidden = false }
            }

            if showSplash {
                SplashView()
                    .transition(.opacity)
                    .zIndex(1)
            }
        }
        .preferredColorScheme(.dark)
        .tint(Theme.accent)
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
                withAnimation(.easeOut(duration: 0.4)) { showSplash = false }
            }
        }
        .onChange(of: c.walkMode) { on in
            guard on else { walkHintVisible = false; return }
            walkHintVisible = true
            DispatchQueue.main.asyncAfter(deadline: .now() + 4) { walkHintVisible = false }
        }
        .onChange(of: c.tool) { t in
            if let g = t.group { group = g }
        }
        .onOpenURL { url in
            // mở file từ ứng dụng Tệp / Chia sẻ → City Builder
            c.importModels(.success([url]))
        }
        .onChange(of: showImporter) { show in
            guard show else { return }
            showImporter = false
            DocPicker.shared.present(types: Self.importTypes) { urls in
                c.importModels(.success(urls))
            }
        }
        .sheet(item: $c.shareItem) { item in
            ShareSheet(url: item.url)
        }
        .confirmationDialog("Xóa toàn bộ thành phố?", isPresented: $confirmClear, titleVisibility: .visible) {
            Button("Xóa tất cả", role: .destructive) { c.clearAll() }
        }
    }

    // MARK: Thanh trên

    private var topBar: some View {
        HStack(spacing: 8) {
            HStack(spacing: 10) {
                LogoMark(size: 34)
                VStack(alignment: .leading, spacing: 1) {
                    Text("City Builder")
                        .font(.system(.subheadline, design: .rounded).weight(.bold))
                    Text(c.tool.title)
                        .font(.caption2.weight(.medium))
                        .foregroundColor(Theme.accent)
                }
            }
            .padding(.leading, 6)
            .padding(.trailing, 14)
            .padding(.vertical, 6)
            .glass(radius: 22)

            Spacer()

            if !c.walkMode {
                circleButton("arrow.uturn.backward") { c.undo() }
                circleButton("scope") { c.resetCamera() }
            }

            weatherMenu(mini: false)

            // Đi dạo kiểu game 3D: joystick để đi, kéo màn hình để nhìn quanh, chạm không đặt / sửa gì
            Button {
                c.toggleWalk()
            } label: {
                Image(systemName: "figure.walk")
                    .font(.system(size: 16, weight: .bold))
                    .foregroundColor(c.walkMode ? Theme.amber : .white)
                    .frame(width: 38, height: 38)
                    .glass(radius: 19)
                    .overlay(Circle().stroke(Theme.amber, lineWidth: c.walkMode ? 2 : 0))
            }

            Menu {
                Section("Mẫu có sẵn") {
                    Button { c.addSampleMekong() } label: { Label("Xóm miền Tây", systemImage: "water.waves") }
                    Button { c.addSampleCaMau() } label: { Label("Vuông tôm rừng đước Cà Mau", systemImage: "drop.fill") }
                    Button { c.addSample() } label: { Label("Khu phố", systemImage: "building.2") }
                }
                Section("Góc nhìn") {
                    Button { c.topDownCamera() } label: { Label("Nhìn từ trên xuống", systemImage: "map") }
                    Button { c.resetCamera() } label: { Label("Về giữa thành phố", systemImage: "scope") }
                }
                Section("Tùy chọn") {
                    Toggle("Căn theo lưới", isOn: $c.snapToGrid)
                    Toggle("Kèm mặt đất khi xuất", isOn: $c.includeGround)
                }
                Section("Xuất file") {
                    Button { c.export(.obj) } label: { Label("Xuất OBJ (cho game)", systemImage: "square.and.arrow.up") }
                    Button { c.export(.usdz) } label: { Label("Xuất USDZ", systemImage: "arkit") }
                    Button { c.export(.scn) } label: { Label("Xuất SCN (SceneKit)", systemImage: "cube") }
                }
                Button(role: .destructive) { confirmClear = true } label: {
                    Label("Xóa tất cả", systemImage: "trash")
                }
            } label: {
                Image(systemName: "ellipsis")
                    .font(.system(size: 16, weight: .bold))
                    .foregroundColor(.white)
                    .frame(width: 38, height: 38)
                    .glass(radius: 19)
            }
        }
    }

    private var hintCard: some View {
        HStack(alignment: .top, spacing: 8) {
            Image(systemName: "info.circle.fill")
                .foregroundColor(Theme.accent)
            Text(c.message)
                .font(.footnote)
                .foregroundColor(.white.opacity(0.92))
                .fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 0)
            Button { hideHint() } label: {
                Image(systemName: "xmark")
                    .font(.system(size: 12, weight: .bold))
                    .foregroundColor(.white.opacity(0.75))
                    .frame(width: 26, height: 26)
                    .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
        }
        .padding(.leading, 12)
        .padding(.trailing, 6)
        .padding(.vertical, 6)
        .glass(radius: 14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .contentShape(Rectangle())
        .onTapGesture { hideHint() }       // chạm vào dòng mô tả cũng ẩn đi
    }

    private func hideHint() {
        withAnimation(.easeOut(duration: 0.2)) { hintHidden = true }
    }

    private func circleButton(_ symbol: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: 16, weight: .bold))
                .foregroundColor(.white)
                .frame(width: 38, height: 38)
                .glass(radius: 19)
        }
    }

    // MARK: Điều khiển đi dạo (kiểu game)

    /// Chế độ xem: ẩn hết giao diện, chỉ còn hai nút nhỏ mờ ở góc (bay / thoát) và gợi ý hiện vài giây đầu.
    private var walkTopBar: some View {
        VStack(spacing: 8) {
            HStack(spacing: 8) {
                Spacer()
                weatherMenu(mini: true)
                if !c.characters.isEmpty {
                    miniButton("person.2.fill", tint: c.walkCharacter == nil ? .white : Theme.amber) { c.cycleWalkCharacter() }
                }
                miniButton("sparkles") { c.walkAction() }
                if c.walkCharacter != nil {
                    miniButton("arrow.triangle.2.circlepath") { c.turnWalkFacing() }
                } else {
                    miniButton("tshirt.fill") { c.cycleOutfit() }
                }
                miniButton(c.runMode ? "hare.fill" : "figure.walk", tint: c.runMode ? Theme.amber : .white) { c.toggleRun() }
                miniButton("xmark", tint: Theme.danger) { c.exitWalk() }
            }
            if !c.walkToast.isEmpty {
                Text(c.walkToast)
                    .font(.footnote.weight(.semibold))
                    .foregroundColor(.white)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 7)
                    .glass(radius: 14)
                    .transition(.opacity)
            }
            if walkHintVisible {
                Text(c.flyMode
                     ? "Đang xem từ trên cao. Chạm nửa trái để điều khiển nhân vật, kéo nửa phải để xoay camera."
                     : "Chạm nửa trái: điều khiển nhân vật đi. Kéo nửa phải: xoay camera.")
                    .font(.footnote)
                    .foregroundColor(.white.opacity(0.92))
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .glass(radius: 14)
                    .transition(.opacity)
                    .onTapGesture { walkHintVisible = false }   // chạm để ẩn
            }
        }
        .animation(.easeOut(duration: 0.25), value: walkHintVisible)
        .animation(.easeOut(duration: 0.2), value: c.walkToast)
    }

    /// Nút thời tiết: nắng, mây, gió, mưa, giông, tuyết, sương mù.
    private func weatherMenu(mini: Bool) -> some View {
        Menu {
            Picker("Thời tiết", selection: $c.weather) {
                ForEach(Weather.allCases) { w in
                    Label(w.title, systemImage: w.symbol).tag(w)
                }
            }
        } label: {
            Image(systemName: c.weather.symbol)
                .font(.system(size: mini ? 15 : 16, weight: .bold))
                .foregroundColor(c.weather == .clear ? .white : Theme.amber)
                .frame(width: 38, height: 38)
                .glass(radius: 19)
                .opacity(mini ? 0.8 : 1)
        }
    }

    private func miniButton(_ symbol: String, tint: Color = .white,
                            action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: 15, weight: .bold))
                .foregroundColor(tint)
                .frame(width: 38, height: 38)
                .glass(radius: 19)
                .opacity(0.8)
        }
    }

    private var walkControls: some View {
        // nút bay lên / hạ xuống (giữ để di chuyển theo chiều cao), chỉ hiện khi đang bay
        HStack(alignment: .bottom) {
            Spacer()
            VStack(spacing: 10) {
                if c.flyMode {
                    liftButton("chevron.up", 1)
                    liftButton("chevron.down", -1)
                }
                walkButton(c.flyMode ? "arrow.down.to.line" : "arrow.up.to.line",
                           c.flyMode ? "Xuống đất" : "Bay lên cao") { c.toggleFly() }
            }
        }
        .padding(.bottom, 14)
    }

    /// Điều hướng khi đang sửa: cần tròn để đi, nút bay lên cao xem toàn cảnh, giữ mũi tên để nâng / hạ camera.
    private var navControls: some View {
        HStack(alignment: .bottom) {
            JoystickView { c.setNavJoy($0) }
            Spacer()
            VStack(spacing: 8) {
                liftButton("chevron.up", 1)
                walkButton(c.overview ? "arrow.down.to.line" : "arrow.up.to.line",
                           c.overview ? "Hạ xuống" : "Trên cao") { c.toggleOverview() }
                liftButton("chevron.down", -1)
            }
        }
        .padding(.horizontal, 4)
        .padding(.bottom, 4)
    }

    private func liftButton(_ symbol: String, _ dir: Float) -> some View {
        Image(systemName: symbol)
            .font(.system(size: 20, weight: .bold))
            .foregroundColor(.white)
            .frame(width: 56, height: 56)
            .glass(radius: 28)
            .opacity(0.85)
            .onLongPressGesture(minimumDuration: 0, maximumDistance: 80, pressing: { down in
                c.setNavLift(down ? dir : 0)
            }, perform: {})
    }

    private func walkButton(_ symbol: String, _ title: String,
                            tint: Color = .white,
                            action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: 3) {
                Image(systemName: symbol)
                    .font(.system(size: 20, weight: .bold))
                Text(title)
                    .font(.system(size: 11, weight: .semibold))
                    .lineLimit(1)
            }
            .foregroundColor(tint)
            .frame(width: 68, height: 62)
            .glass(radius: 18)
        }
    }

    // MARK: Thanh thao tác

    /// Chọn cách nối các đoạn đường / kênh / mương: bo góc hoặc góc vuông.
    private var cornerToggle: some View {
        Button { c.toggleCornerStyle() } label: {
            Label(c.cornerStyle.title, systemImage: c.cornerStyle == .round ? "arrow.turn.up.right" : "square")
                .font(.subheadline.weight(.bold))
                .foregroundColor(.white)
                .padding(.horizontal, 16)
                .padding(.vertical, 11)
                .glass(radius: 22)
        }
    }

    private var stopButton: some View {
        Button { c.stopRoad() } label: {
            Label("Dừng vẽ", systemImage: "stop.fill")
                .font(.subheadline.weight(.bold))
                .foregroundColor(Theme.ink)
                .padding(.horizontal, 20)
                .padding(.vertical, 11)
                .background(Theme.amber, in: Capsule())
                .shadow(color: Theme.amber.opacity(0.4), radius: 10, y: 3)
        }
    }

    private var actionBar: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 6) {
                if let it = c.selectedItem, !it.kind.isLine {
                    // đường / kênh / cầu chỉ dời hoặc xóa được, ẩn nút xoay và đổi cỡ cho khỏi bấm vô ích
                    actionButton("arrow.clockwise", "Xoay") { c.rotateSelected() }
                    actionButton("plus.magnifyingglass", "To") { c.scaleSelected(1.2) }
                    actionButton("minus.magnifyingglass", "Nhỏ") { c.scaleSelected(1 / 1.2) }
                }
                if let it = c.selectedItem, it.kind.variantCount > 1 {
                    actionButton("paintpalette.fill", "Màu") { c.recolorSelected() }
                }
                actionButton("scope", "Tới đây") { c.focusSelected() }
                if let it = c.selectedItem, it.kind == .model {
                    let m = it.motion ?? 0
                    actionButton("wind", Builder.motionTitles[m % Builder.motionTitles.count],
                                 highlighted: m != 0) { c.cycleMotion() }
                    if m == 4 {
                        actionButton("arrow.triangle.turn.up.right.circle", "Hướng đi") { c.flipMotion() }
                    }
                }
                actionButton(c.moveMode ? "mappin.and.ellipse" : "arrow.up.and.down.and.arrow.left.and.right",
                             c.moveMode ? "Chạm đặt" : "Dời",
                             highlighted: c.moveMode) { c.toggleMove() }
                actionButton("trash.fill", "Xóa", tint: Theme.danger) { c.deleteSelected() }
            }
            .padding(6)
        }
        .glass(radius: 20)
    }

    private func actionButton(_ symbol: String, _ title: String,
                              highlighted: Bool = false,
                              tint: Color = .white,
                              action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: 3) {
                Image(systemName: symbol)
                    .font(.system(size: 17, weight: .semibold))
                Text(title)
                    .font(.system(size: 10, weight: .semibold))
                    .lineLimit(1)
            }
            .foregroundColor(highlighted ? Theme.ink : tint)
            .frame(width: 58, height: 48)
            .background(highlighted ? Theme.amber : Color.white.opacity(0.08),
                        in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        }
    }

    // MARK: Dock công cụ

    private var toolDock: some View {
        VStack(spacing: 8) {
            HStack(spacing: 6) {
                dockChip(.select)
                ForEach(ToolGroup.allCases) { g in
                    groupChip(g)
                }
                dockChip(.erase)
            }

            if group == .models {
                modelRow
            } else {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(group.tools) { t in
                            toolTile(t)
                        }
                    }
                    .padding(.horizontal, 2)
                }
            }
        }
        .padding(10)
        .glass(radius: 24)
    }

    // MARK: Thư viện mô hình

    private var modelRow: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                Button { showImporter = true } label: {
                    VStack(spacing: 6) {
                        Image(systemName: "plus.circle.fill")
                            .font(.system(size: 22, weight: .semibold))
                            .frame(height: 26)
                        Text("Nhập")
                            .font(.system(size: 11, weight: .semibold))
                    }
                    .foregroundColor(Theme.amber)
                    .frame(width: 74, height: 66)
                    .background(Theme.amber.opacity(0.14),
                                in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 16, style: .continuous)
                            .stroke(Theme.amber.opacity(0.5), style: StrokeStyle(lineWidth: 1, dash: [4, 3]))
                    )
                }

                Button { showLibrary = true } label: {
                    VStack(spacing: 6) {
                        Image(systemName: "books.vertical.fill")
                            .font(.system(size: 22, weight: .semibold))
                            .frame(height: 26)
                        Text(c.libraryFilterTitle)
                            .font(.system(size: 11, weight: .semibold))
                            .lineLimit(1)
                    }
                    .foregroundColor(Theme.accent2)
                    .padding(.horizontal, 4)
                    .frame(width: 74, height: 66)
                    .background(Theme.accent2.opacity(0.16),
                                in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 16, style: .continuous)
                            .stroke(Theme.accent2.opacity(0.5), lineWidth: 1)
                    )
                }

                if c.models.isEmpty {
                    Text("Chưa có mô hình.\nBấm Nhập để chọn file ZIP, USDZ hoặc OBJ.")
                        .font(.caption)
                        .foregroundColor(.white.opacity(0.7))
                        .fixedSize(horizontal: true, vertical: false)
                        .padding(.horizontal, 6)
                }

                ForEach(c.filteredModels(), id: \.self) { name in
                    modelTile(name)
                }
            }
            .padding(.horizontal, 2)
        }
    }

    private func modelTile(_ name: String) -> some View {
        let on = c.tool == .model && c.currentModel == name
        let title = (name as NSString).deletingPathExtension
        return Button { c.selectModel(name) } label: {
            VStack(spacing: 6) {
                Image(systemName: "cube.fill")
                    .font(.system(size: 22, weight: .semibold))
                    .frame(height: 26)
                Text(title)
                    .font(.system(size: 11, weight: .semibold))
                    .lineLimit(1)
                    .truncationMode(.middle)
            }
            .foregroundColor(on ? Theme.ink : .white)
            .padding(.horizontal, 6)
            .frame(width: 84, height: 66)
            .background(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .fill(on ? AnyShapeStyle(Theme.gradient) : AnyShapeStyle(Color.white.opacity(0.08)))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .stroke(on ? Color.white.opacity(0.4) : Color.white.opacity(0.06), lineWidth: 0.5)
            )
        }
        .contextMenu {
            Button(role: .destructive) { c.deleteModel(name) } label: {
                Label("Xóa khỏi thư viện", systemImage: "trash")
            }
        }
    }

    private func dockChip(_ t: Tool) -> some View {
        let on = c.tool == t
        return Button { c.setTool(t) } label: {
            HStack(spacing: 5) {
                Image(systemName: t.symbol)
                    .font(.system(size: 13, weight: .bold))
                if on {
                    Text(t.title).font(.system(size: 12, weight: .bold)).lineLimit(1)
                }
            }
            .foregroundColor(on ? (t == .erase ? .white : Theme.ink) : .white.opacity(0.85))
            .padding(.horizontal, 11)
            .frame(height: 34)
            .background(on ? (t == .erase ? Theme.danger : Theme.accent) : Color.white.opacity(0.09),
                        in: Capsule())
        }
    }

    private func groupChip(_ g: ToolGroup) -> some View {
        let on = group == g
        return Button {
            withAnimation(.easeInOut(duration: 0.18)) { group = g }
            if g == .models { c.refreshModels() }
        } label: {
            HStack(spacing: 5) {
                Image(systemName: g.symbol)
                    .font(.system(size: 13, weight: .bold))
                if on {
                    Text(g.rawValue).font(.system(size: 12, weight: .bold)).lineLimit(1)
                }
            }
            .foregroundColor(on ? .white : .white.opacity(0.7))
            .padding(.horizontal, 11)
            .frame(height: 34)
            .background(on ? Theme.accent2 : Color.white.opacity(0.09), in: Capsule())
            .overlay(Capsule().stroke(on ? Color.white.opacity(0.25) : .clear, lineWidth: 0.5))
        }
    }

    private func toolTile(_ t: Tool) -> some View {
        let on = c.tool == t
        return Button { c.setTool(t) } label: {
            VStack(spacing: 6) {
                Text(t.icon)
                    .font(.system(size: 24))
                    .frame(height: 26)
                Text(t.title)
                    .font(.system(size: 11, weight: .semibold))
                    .lineLimit(1)
            }
            .foregroundColor(on ? Theme.ink : .white)
            .frame(width: 74, height: 66)
            .background(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .fill(on ? AnyShapeStyle(Theme.gradient) : AnyShapeStyle(Color.white.opacity(0.08)))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .stroke(on ? Color.white.opacity(0.4) : Color.white.opacity(0.06), lineWidth: 0.5)
            )
        }
    }
}
