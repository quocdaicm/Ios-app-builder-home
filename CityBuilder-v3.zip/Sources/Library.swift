import Foundation
import SceneKit
import UIKit
import ZIPFoundation

// MARK: - Dữ liệu thư viện (chuyên mục)

/// Thông tin phân loại mô hình. Lưu ở Documents/library.json, cũng được sao lưu / đồng bộ.
struct LibraryMeta: Codable {
    var categories: [String] = []              // danh sách chuyên mục (theo thứ tự người dùng tạo)
    var assign: [String: String] = [:]         // tên mô hình -> chuyên mục ("" = chưa phân loại)
    var added: [String: Date] = [:]            // ngày thêm (để sắp "mới nhất")
    var removedCategories: [String] = []       // chuyên mục đã xóa (để máy khác biết mà bỏ theo)
    var updated: Date = Date(timeIntervalSince1970: 0)

    /// Gộp với bản của nơi khác. Bên nào cập nhật sau thì thắng khi hai bên khác nhau.
    func merged(with o: LibraryMeta) -> LibraryMeta {
        var r = self
        let otherNewer = o.updated > updated

        let removed = otherNewer ? o.removedCategories : removedCategories
        var cats = categories
        for c in o.categories where !cats.contains(c) { cats.append(c) }
        r.categories = cats.filter { !removed.contains($0) }
        r.removedCategories = removed

        var a = assign
        for (k, v) in o.assign {
            if a[k] == nil || otherNewer { a[k] = v }
        }
        for (k, v) in a where !v.isEmpty && !r.categories.contains(v) { a[k] = "" }
        r.assign = a

        var d = added
        for (k, v) in o.added {
            if let cur = d[k] { d[k] = min(cur, v) } else { d[k] = v }
        }
        r.added = d
        r.updated = max(updated, o.updated)
        return r
    }
}

enum LibraryFilter: Hashable {
    case all
    case uncategorized
    case category(String)
}

enum LibrarySort: String, CaseIterable, Identifiable {
    case name, category, newest

    var id: String { rawValue }

    var title: String {
        switch self {
        case .name:     return "Tên A → Z"
        case .category: return "Theo chuyên mục"
        case .newest:   return "Mới nhất"
        }
    }
}

struct SyncResult {
    var meta: LibraryMeta
    var pulled: Int
    var pushed: Int
}

// MARK: - Chuyên mục, tìm kiếm, sắp xếp

extension SceneController {
    var libraryURL: URL {
        documentsURL.appendingPathComponent("library.json")
    }

    func loadLibrary() {
        if let data = try? Data(contentsOf: libraryURL),
           let m = try? JSONDecoder().decode(LibraryMeta.self, from: data) {
            library = m
        }
        reconcileLibrary()
    }

    func saveLibrary() {
        if let data = try? JSONEncoder().encode(library) {
            try? data.write(to: libraryURL, options: .atomic)
        }
    }

    /// Ghi lại sau khi người dùng thay đổi (đánh dấu thời điểm để đồng bộ biết bản nào mới hơn).
    func touchLibrary() {
        library.updated = Date()
        saveLibrary()
    }

    /// Cho khớp với các mô hình đang có: thêm ngày cho mô hình mới, bỏ thông tin của mô hình đã mất.
    func reconcileLibrary() {
        var m = library
        var changed = false
        let existing = Set(models)
        for name in models where m.added[name] == nil {
            m.added[name] = Date()
            changed = true
        }
        for k in Array(m.assign.keys) where !existing.contains(k) {
            m.assign[k] = nil
            changed = true
        }
        for k in Array(m.added.keys) where !existing.contains(k) {
            m.added[k] = nil
            changed = true
        }
        if changed {
            library = m
            saveLibrary()
        }
    }

    func category(of model: String) -> String {
        library.assign[model] ?? ""
    }

    @discardableResult
    func addCategory(_ raw: String) -> Bool {
        let name = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty, !library.categories.contains(name) else { return false }
        library.categories.append(name)
        library.removedCategories.removeAll { $0 == name }
        touchLibrary()
        return true
    }

    func renameCategory(_ old: String, to raw: String) {
        let name = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty, name != old, !library.categories.contains(name),
              let i = library.categories.firstIndex(of: old) else { return }
        var m = library
        m.categories[i] = name
        for (k, v) in m.assign where v == old { m.assign[k] = name }
        if !m.removedCategories.contains(old) { m.removedCategories.append(old) }
        m.removedCategories.removeAll { $0 == name }
        library = m
        if libraryFilter == .category(old) { libraryFilter = .category(name) }
        touchLibrary()
    }

    func deleteCategory(_ name: String) {
        var m = library
        m.categories.removeAll { $0 == name }
        for (k, v) in m.assign where v == name { m.assign[k] = "" }
        if !m.removedCategories.contains(name) { m.removedCategories.append(name) }
        library = m
        if libraryFilter == .category(name) { libraryFilter = .all }
        touchLibrary()
    }

    func setCategory(_ cat: String, for model: String) {
        library.assign[model] = cat
        touchLibrary()
    }

    /// Sau khi nhập: mô hình mới vào đúng chuyên mục đang chọn.
    func assignImported(before: Set<String>) {
        guard case .category(let c) = libraryFilter else {
            libraryStatus = message
            return
        }
        for n in models where !before.contains(n) { library.assign[n] = c }
        touchLibrary()
        libraryStatus = message + " Đã vào chuyên mục “\(c)”."
    }

    func count(in f: LibraryFilter) -> Int {
        switch f {
        case .all:           return models.count
        case .uncategorized: return models.filter { category(of: $0).isEmpty }.count
        case .category(let c): return models.filter { category(of: $0) == c }.count
        }
    }

    var libraryFilterTitle: String {
        switch libraryFilter {
        case .all:           return "Thư viện"
        case .uncategorized: return "Chưa phân loại"
        case .category(let c): return c
        }
    }

    /// Danh sách đã lọc theo chuyên mục + ô tìm kiếm (theo tên hoặc tên chuyên mục, không phân biệt hoa thường / dấu).
    func filteredModels() -> [String] {
        var list = models
        switch libraryFilter {
        case .all: break
        case .uncategorized: list = list.filter { category(of: $0).isEmpty }
        case .category(let c): list = list.filter { category(of: $0) == c }
        }

        let q = librarySearch.trimmingCharacters(in: .whitespacesAndNewlines)
        if !q.isEmpty {
            let opts: String.CompareOptions = [.caseInsensitive, .diacriticInsensitive]
            list = list.filter {
                $0.range(of: q, options: opts) != nil || category(of: $0).range(of: q, options: opts) != nil
            }
        }

        switch librarySort {
        case .name:
            break   // `models` đã sắp theo tên
        case .category:
            let order = library.categories
            list.sort { a, b in
                let ca = category(of: a)
                let cb = category(of: b)
                if ca != cb {
                    if ca.isEmpty { return false }
                    if cb.isEmpty { return true }
                    return (order.firstIndex(of: ca) ?? 0) < (order.firstIndex(of: cb) ?? 0)
                }
                return a.localizedStandardCompare(b) == .orderedAscending
            }
        case .newest:
            list.sort { (library.added[$0] ?? .distantPast) > (library.added[$1] ?? .distantPast) }
        }
        return list
    }
}

// MARK: - Sao lưu / khôi phục

extension SceneController {
    /// Gói toàn bộ thư viện mô hình + chuyên mục + thành phố đang dựng thành một file .zip để lưu vào Tệp / iCloud / gửi đi.
    func backup() {
        guard !syncBusy else { return }
        syncBusy = true
        message = "Đang tạo bản sao lưu…"
        libraryStatus = message
        saveLibrary()
        let docs = documentsURL
        let modelsDir = Builder.modelsDirectory

        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            let fm = FileManager.default
            let stage = fm.temporaryDirectory.appendingPathComponent("CityBuilderBackup-" + UUID().uuidString, isDirectory: true)
            let f = DateFormatter()
            f.dateFormat = "yyyyMMdd_HHmmss"
            let zip = fm.temporaryDirectory.appendingPathComponent("CityBuilder_SaoLuu_\(f.string(from: Date())).zip")
            var failure: String? = nil
            do {
                try fm.createDirectory(at: stage, withIntermediateDirectories: true)
                try fm.copyItem(at: modelsDir, to: stage.appendingPathComponent("Models"))
                let animDir = ClipLibrary.directory
                if fm.fileExists(atPath: animDir.path) {
                    try? fm.copyItem(at: animDir, to: stage.appendingPathComponent("Animations"))
                }
                for name in ["library.json", "project.json"] {
                    let src = docs.appendingPathComponent(name)
                    if fm.fileExists(atPath: src.path) {
                        try fm.copyItem(at: src, to: stage.appendingPathComponent(name))
                    }
                }
                try? fm.removeItem(at: zip)
                try fm.zipItem(at: stage, to: zip, shouldKeepParent: false, compressionMethod: .deflate)
            } catch {
                failure = error.localizedDescription
            }
            try? fm.removeItem(at: stage)

            let err = failure
            DispatchQueue.main.async {
                guard let self = self else { return }
                self.syncBusy = false
                if let e = err {
                    self.message = "Lỗi sao lưu: \(e)"
                } else {
                    self.message = "Đã tạo bản sao lưu. Chọn nơi lưu (Tệp, iCloud Drive…)."
                    self.shareItem = ShareItem(url: zip)
                }
                self.libraryStatus = self.message
            }
        }
    }

    /// Khôi phục từ file sao lưu: thêm các mô hình còn thiếu, gộp chuyên mục; thành phố thì hỏi trước khi thay.
    func restoreBackup(from url: URL) {
        guard !syncBusy else { return }
        syncBusy = true
        libraryStatus = "Đang khôi phục…"
        let modelsDir = Builder.modelsDirectory

        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            let fm = FileManager.default
            let tmp = fm.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
            var added = 0
            var meta: LibraryMeta? = nil
            var proj: Data? = nil
            var failure: String? = nil
            do {
                try fm.createDirectory(at: tmp, withIntermediateDirectories: true)
                try fm.unzipItem(at: url, to: tmp)
                guard let root = SceneController.findBackupRoot(tmp) else {
                    throw ExportError(text: "File này không phải bản sao lưu của City Builder")
                }
                let srcModels = root.appendingPathComponent("Models", isDirectory: true)
                let entries = (try? fm.contentsOfDirectory(at: srcModels, includingPropertiesForKeys: nil,
                                                            options: [.skipsHiddenFiles])) ?? []
                for e in entries {
                    let dst = modelsDir.appendingPathComponent(e.lastPathComponent)
                    if fm.fileExists(atPath: dst.path) { continue }   // đã có cùng tên thì giữ bản hiện tại
                    try fm.copyItem(at: e, to: dst)
                    added += 1
                }
                // hoạt ảnh nhân vật (nếu bản sao lưu có)
                let srcAnim = root.appendingPathComponent("Animations", isDirectory: true)
                let animDst = ClipLibrary.directory
                for e in (try? fm.contentsOfDirectory(at: srcAnim, includingPropertiesForKeys: nil,
                                                       options: [.skipsHiddenFiles])) ?? [] {
                    let dst = animDst.appendingPathComponent(e.lastPathComponent)
                    if !fm.fileExists(atPath: dst.path) { try? fm.copyItem(at: e, to: dst) }
                }
                if let d = try? Data(contentsOf: root.appendingPathComponent("library.json")) {
                    meta = try? JSONDecoder().decode(LibraryMeta.self, from: d)
                }
                proj = try? Data(contentsOf: root.appendingPathComponent("project.json"))
            } catch {
                failure = error.localizedDescription
            }
            try? fm.removeItem(at: tmp)

            let err = failure
            let metaOut = meta
            let projOut = proj
            let addedCount = added
            DispatchQueue.main.async {
                guard let self = self else { return }
                self.syncBusy = false
                if let e = err {
                    self.libraryStatus = "Lỗi khôi phục: \(e)"
                    return
                }
                if let m = metaOut {
                    self.library = self.library.merged(with: m)
                    self.saveLibrary()
                }
                self.refreshModels()
                self.refreshClips()
                var text = "Đã khôi phục: thêm \(addedCount) mô hình."
                if let p = projOut,
                   let list = try? JSONDecoder().decode([Item].self, from: p), !list.isEmpty {
                    if self.items.isEmpty {
                        self.pendingRestoreProject = p
                        self.applyRestoredProject()
                        text += " Đã khôi phục cả thành phố."
                    } else {
                        self.pendingRestoreProject = p
                        text += " Bản sao lưu có kèm thành phố, hãy chọn có thay thế hay không."
                    }
                }
                self.libraryStatus = text
            }
        }
    }

    /// Thay thành phố đang dựng bằng thành phố trong bản sao lưu.
    func applyRestoredProject() {
        guard let data = pendingRestoreProject else { return }
        pendingRestoreProject = nil
        clearAll()
        try? data.write(to: projectURL, options: .atomic)
        loadProject()
        libraryStatus = "Đã khôi phục thành phố từ bản sao lưu."
    }

    static func findBackupRoot(_ dir: URL) -> URL? {
        let fm = FileManager.default
        func looksRight(_ u: URL) -> Bool {
            fm.fileExists(atPath: u.appendingPathComponent("Models").path)
                || fm.fileExists(atPath: u.appendingPathComponent("library.json").path)
        }
        if looksRight(dir) { return dir }
        let kids = (try? fm.contentsOfDirectory(at: dir, includingPropertiesForKeys: nil,
                                                 options: [.skipsHiddenFiles])) ?? []
        for k in kids where looksRight(k) { return k }
        return nil
    }
}

// MARK: - Đồng bộ qua thư mục (iCloud Drive, Dropbox, OneDrive… bất kỳ nơi nào app Tệp mở được)

extension SceneController {
    /// Lưu thư mục đồng bộ người dùng chọn (nhớ bằng bookmark để lần sau tự mở lại).
    func setSyncFolder(_ url: URL) {
        let ok = url.startAccessingSecurityScopedResource()
        defer { if ok { url.stopAccessingSecurityScopedResource() } }
        do {
            let data = try url.bookmarkData(options: [], includingResourceValuesForKeys: nil, relativeTo: nil)
            UserDefaults.standard.set(data, forKey: "sync.bookmark")
            UserDefaults.standard.set(url.lastPathComponent, forKey: "sync.name")
            syncFolderName = url.lastPathComponent
            libraryStatus = "Đã chọn thư mục “\(url.lastPathComponent)”."
            syncNow()
        } catch {
            libraryStatus = "Không lưu được thư mục: \(error.localizedDescription)"
        }
    }

    func clearSyncFolder() {
        UserDefaults.standard.removeObject(forKey: "sync.bookmark")
        UserDefaults.standard.removeObject(forKey: "sync.name")
        syncFolderName = nil
        libraryStatus = "Đã ngắt đồng bộ. Dữ liệu trong thư mục vẫn còn nguyên."
    }

    private func resolveSyncFolder() -> URL? {
        guard let data = UserDefaults.standard.data(forKey: "sync.bookmark") else { return nil }
        var stale = false
        return try? URL(resolvingBookmarkData: data, options: [], relativeTo: nil, bookmarkDataIsStale: &stale)
    }

    /// Đồng bộ hai chiều: mô hình chỉ có ở một bên thì chép sang bên kia; chuyên mục được gộp.
    /// Việc xóa mô hình không được đồng bộ (để không mất dữ liệu do nhầm).
    func syncNow() {
        guard !syncBusy else { return }
        guard let folder = resolveSyncFolder() else {
            libraryStatus = "Chưa chọn thư mục đồng bộ."
            return
        }
        syncBusy = true
        libraryStatus = "Đang đồng bộ…"
        saveLibrary()
        let local = library
        let modelsDir = Builder.modelsDirectory

        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            let ok = folder.startAccessingSecurityScopedResource()
            defer { if ok { folder.stopAccessingSecurityScopedResource() } }
            let res = SceneController.runSync(folder: folder, modelsDir: modelsDir, local: local)

            DispatchQueue.main.async {
                guard let self = self else { return }
                self.syncBusy = false
                switch res {
                case .failure(let e):
                    self.libraryStatus = "Đồng bộ lỗi: \(e.localizedDescription)"
                case .success(let r):
                    self.library = r.meta
                    self.saveLibrary()
                    self.refreshModels()
                    let f = DateFormatter()
                    f.dateFormat = "HH:mm dd/MM"
                    self.libraryStatus = "Đồng bộ xong lúc \(f.string(from: Date())): tải về \(r.pulled), tải lên \(r.pushed) mô hình."
                }
            }
        }
    }

    static func runSync(folder: URL, modelsDir: URL, local: LibraryMeta) -> Result<SyncResult, Error> {
        let fm = FileManager.default
        do {
            let root = folder.appendingPathComponent("CityBuilder", isDirectory: true)
            let remoteModels = root.appendingPathComponent("Models", isDirectory: true)
            try fm.createDirectory(at: remoteModels, withIntermediateDirectories: true)

            func names(_ dir: URL) -> Set<String> {
                let e = (try? fm.contentsOfDirectory(at: dir, includingPropertiesForKeys: nil,
                                                      options: [.skipsHiddenFiles])) ?? []
                return Set(e.map { $0.lastPathComponent })
            }
            let localNames = names(modelsDir)
            let remoteNames = names(remoteModels)

            var pulled = 0
            var pushed = 0
            for n in remoteNames.subtracting(localNames).sorted() {
                try coordCopy(from: remoteModels.appendingPathComponent(n),
                              to: modelsDir.appendingPathComponent(n))
                pulled += 1
            }
            for n in localNames.subtracting(remoteNames).sorted() {
                try coordCopy(from: modelsDir.appendingPathComponent(n),
                              to: remoteModels.appendingPathComponent(n))
                pushed += 1
            }

            let metaURL = root.appendingPathComponent("library.json")
            var remote: LibraryMeta? = nil
            if let d = coordRead(metaURL) {
                remote = try? JSONDecoder().decode(LibraryMeta.self, from: d)
            }
            let merged = remote.map { local.merged(with: $0) } ?? local
            try coordWrite(try JSONEncoder().encode(merged), to: metaURL)
            return .success(SyncResult(meta: merged, pulled: pulled, pushed: pushed))
        } catch {
            return .failure(error)
        }
    }

    /// Chép có điều phối (NSFileCoordinator) để iCloud tự tải file về trước khi đọc. Chép ra tên tạm rồi mới đổi tên,
    /// nên nếu gián đoạn giữa chừng sẽ không để lại mô hình dở dang.
    static func coordCopy(from src: URL, to dst: URL) throws {
        let fm = FileManager.default
        var coordError: NSError?
        var thrown: Error?
        NSFileCoordinator().coordinate(readingItemAt: src, options: [],
                                       writingItemAt: dst, options: .forReplacing,
                                       error: &coordError) { s, d in
            let part = d.deletingLastPathComponent().appendingPathComponent("." + d.lastPathComponent + ".partial")
            do {
                try? fm.removeItem(at: part)
                try fm.copyItem(at: s, to: part)
                if fm.fileExists(atPath: d.path) { try fm.removeItem(at: d) }
                try fm.moveItem(at: part, to: d)
            } catch {
                try? fm.removeItem(at: part)
                thrown = error
            }
        }
        if let e = coordError { throw e }
        if let e = thrown { throw e }
    }

    static func coordRead(_ url: URL) -> Data? {
        var coordError: NSError?
        var out: Data?
        NSFileCoordinator().coordinate(readingItemAt: url, options: [], error: &coordError) { u in
            out = try? Data(contentsOf: u)
        }
        return out
    }

    static func coordWrite(_ data: Data, to url: URL) throws {
        var coordError: NSError?
        var thrown: Error?
        NSFileCoordinator().coordinate(writingItemAt: url, options: .forReplacing, error: &coordError) { u in
            do { try data.write(to: u, options: .atomic) } catch { thrown = error }
        }
        if let e = coordError { throw e }
        if let e = thrown { throw e }
    }
}
