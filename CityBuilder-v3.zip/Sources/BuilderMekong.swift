import SceneKit
import UIKit
import simd

// MARK: - Công trình và đồ vật miền Tây

extension Builder {
    static let goldMat: SCNMaterial = plain(rgb(0.88, 0.68, 0.18), rough: 0.35, metal: 0.6)

    // MARK: Nhà cổ Nam Bộ

    /// Ba gian hai chái: nền gạch, hàng cột gỗ ở hiên, cửa bàn khoa, mái ngói âm dương rêu phong.
    static func nhaCo(_ variant: Int) -> SCNNode {
        let root = SCNNode()
        let v = variant % 3
        let doorTints: [UIColor] = [rgb(0.62, 0.42, 0.28), rgb(0.30, 0.52, 0.42), rgb(0.60, 0.24, 0.18)]
        let door = doorTints[v]

        root.addChildNode(tbox(10.4, 0.4, 7.0, .brick, tint: rgb(0.80, 0.74, 0.68), tile: 1.6, y: 0.2))
        // tường sau và hai hông
        root.addChildNode(tbox(9.0, 3.4, 0.2, .woodDark, tile: 1.6, y: 2.1, z: -2.5))
        for sx in [Float(-4.4), Float(4.4)] {
            root.addChildNode(tbox(0.2, 3.4, 5.0, .woodDark, tile: 1.6, x: sx, y: 2.1, z: 0))
        }
        // tường trước thụt vào, chia ba gian, mỗi gian một cặp cửa
        let brass = plain(rgb(0.80, 0.65, 0.20), rough: 0.35, metal: 0.7)
        for bx in [Float(-2.9), 0, 2.9] {
            for side in [Float(-1), Float(1)] {
                root.addChildNode(tbox(1.2, 2.7, 0.08, .wood, tint: door, tile: 1.2,
                                       x: bx + side * 0.62, y: 1.85, z: 1.3))
                root.addChildNode(sphere(0.035, brass, x: bx + side * 0.08, y: 1.8, z: 1.38, seg: 6))
            }
            root.addChildNode(tbox(2.9, 0.5, 0.1, .woodDark, tile: 1.2, x: bx, y: 3.45, z: 1.3))
        }
        for cx in [Float(-4.35), -1.45, 1.45, 4.35] {
            root.addChildNode(tcyl(0.12, 3.4, .woodDark, tileY: 2, x: cx, y: 2.1, z: 1.3))
        }
        // hàng cột hiên + đế đá
        for i in 0..<8 {
            let x = -4.2 + Float(i) * 1.2
            root.addChildNode(tcyl(0.13, 3.4, .woodDark, tileY: 2, x: x, y: 2.1, z: 2.9))
            root.addChildNode(cyl(0.2, 0.15, rgb(0.62, 0.60, 0.56), rough: 0.9, x: x, y: 0.475, z: 2.9, seg: 10))
        }
        root.addChildNode(tbox(9.0, 0.3, 0.25, .woodDark, tile: 1.6, y: 3.9, z: 2.9))
        root.addChildNode(tbox(9.0, 0.3, 0.25, .woodDark, tile: 1.6, y: 3.9, z: 1.3))
        // câu đối đỏ và đèn lồng
        let red = rgb(0.75, 0.10, 0.10)
        for cx in [Float(-0.6), 0.6] {
            root.addChildNode(box(0.14, 1.6, 0.03, red, x: cx, y: 2.2, z: 3.05))
        }
        for cx in [Float(-2.4), 2.4] {
            root.addChildNode(link(V3(cx, 3.75, 2.9), V3(cx, 3.5, 2.9), r1: 0.01, r2: 0.01, brass, seg: 4))
            let lamp = sphere(0.17, plain(red, rough: 0.5), x: cx, y: 3.32, z: 2.9, seg: 10)
            lamp.scale = SCNVector3(1, 1.2, 1)
            root.addChildNode(lamp)
        }
        // mái
        let roof = gableRoof(halfSpan: 3.9, rise: 2.0, baseY: 3.95,
                             zBack: -4.9, zFront: 4.9, ovBack: 0.3, ovFront: 0.3,
                             roofTex: .roofTile, roofTint: rgb(0.80, 0.72, 0.66), roofRough: 0.8,
                             thickness: 0.14, tile: 2, gableTex: .woodDark, gableTint: nil)
        roof.eulerAngles.y = Float.pi / 2
        root.addChildNode(roof)
        // đầu đao hai đầu nóc
        let dark = plain(rgb(0.25, 0.20, 0.17), rough: 0.8)
        for sgn in [Float(-1), Float(1)] {
            root.addChildNode(link(V3(sgn * 4.9, 6.05, 0), V3(sgn * 5.4, 6.6, 0), r1: 0.1, r2: 0.03, dark, seg: 6))
        }
        // bậc thềm
        root.addChildNode(tbox(3.2, 0.25, 0.7, .brick, tile: 1, y: 0.125, z: 3.7))
        return root
    }

    // MARK: Chùa Khmer

    static func chuaKhmer(_ variant: Int) -> SCNNode {
        let root = SCNNode()
        let v = variant % 2
        let wall: UIColor = v == 0 ? rgb(1.0, 0.86, 0.45) : rgb(1.0, 0.97, 0.90)
        let roofC: UIColor = v == 0 ? rgb(1.0, 0.55, 0.25) : rgb(0.85, 0.22, 0.16)
        let redWood = rgb(0.72, 0.14, 0.10)

        root.addChildNode(tbox(12, 0.3, 9, .plaster, tint: rgb(0.95, 0.92, 0.85), tile: 2, y: 0.15))
        root.addChildNode(tbox(11, 0.3, 8, .plaster, tint: rgb(0.95, 0.92, 0.85), tile: 2, y: 0.45))
        root.addChildNode(tbox(10, 0.3, 7, .plaster, tint: rgb(0.95, 0.92, 0.85), tile: 2, y: 0.75))
        root.addChildNode(tbox(9.0, 3.4, 5.6, .plaster, tint: wall, tile: 2.4, y: 2.6))
        // hàng cột ở hiên
        for i in 0..<6 {
            let x = -4.0 + Float(i) * 1.6
            root.addChildNode(tcyl(0.16, 3.4, .woodPaint, tint: redWood, tileY: 2, x: x, y: 2.6, z: 3.2))
        }
        // cửa chính và cửa sổ
        root.addChildNode(box(1.6, 2.4, 0.1, rgb(0.50, 0.10, 0.08), x: 0, y: 2.1, z: 2.82))
        root.addChildNode(box(1.9, 0.2, 0.14, goldColor, x: 0, y: 3.4, z: 2.82))
        for sx in [Float(-2.8), 2.8] {
            root.addChildNode(box(0.9, 1.1, 0.1, rgb(0.45, 0.10, 0.08), x: sx, y: 2.4, z: 2.82))
            root.addChildNode(box(1.1, 0.12, 0.14, goldColor, x: sx, y: 3.0, z: 2.82))
        }

        func tier(_ halfSpan: Float, _ rise: Float, _ baseY: Float, _ zExt: Float) {
            let r = gableRoof(halfSpan: halfSpan, rise: rise, baseY: baseY,
                              zBack: -zExt, zFront: zExt, ovBack: 0.3, ovFront: 0.3,
                              roofTex: .roofTile, roofTint: roofC, roofRough: 0.55, thickness: 0.14, tile: 1.6,
                              gableTex: .plaster, gableTint: wall)
            r.eulerAngles.y = Float.pi / 2
            root.addChildNode(r)
            // đầu đao vàng cong lên ở hai đầu nóc
            let ridgeY = baseY + rise + 0.1
            for sgn in [Float(-1), Float(1)] {
                root.addChildNode(link(V3(sgn * (zExt + 0.25), ridgeY - 0.05, 0),
                                       V3(sgn * (zExt + 0.7), ridgeY + 0.6, 0),
                                       r1: 0.12, r2: 0.02, goldMat, seg: 6))
            }
        }
        tier(3.4, 1.5, 4.3, 5.2)
        root.addChildNode(tbox(8.2, 1.4, 4.2, .plaster, tint: wall, tile: 2.4, y: 5.3))
        tier(2.4, 1.3, 5.6, 3.4)
        root.addChildNode(tbox(5.2, 1.2, 2.6, .plaster, tint: wall, tile: 2.4, y: 6.5))
        tier(1.5, 1.1, 6.7, 1.9)
        let spire = SCNCone(topRadius: 0, bottomRadius: 0.14, height: 1.8)
        spire.radialSegmentCount = 8
        spire.materials = [goldMat]
        let sn = SCNNode(geometry: spire)
        sn.position = SCNVector3(0, 8.8, 0)
        root.addChildNode(sn)

        // tháp chuông bên hông
        root.addChildNode(tbox(2.4, 0.5, 2.4, .plaster, tint: rgb(0.95, 0.92, 0.85), tile: 1.5, x: 7.5, y: 0.25, z: -1))
        root.addChildNode(tbox(1.8, 0.5, 1.8, .plaster, tint: rgb(0.95, 0.92, 0.85), tile: 1.5, x: 7.5, y: 0.75, z: -1))
        let bell = SCNCone(topRadius: 0.25, bottomRadius: 0.8, height: 2.0)
        bell.radialSegmentCount = 20
        bell.materials = [tex(.plaster, tint: rgb(1.0, 0.97, 0.9), rx: 2, ry: 1)]
        let bn = SCNNode(geometry: bell)
        bn.position = SCNVector3(7.5, 2.0, -1)
        root.addChildNode(bn)
        let ring = SCNCylinder(radius: 0.32, height: 0.08)
        ring.materials = [goldMat]
        let rn = SCNNode(geometry: ring)
        rn.position = SCNVector3(7.5, 3.05, -1)
        root.addChildNode(rn)
        let top = SCNCone(topRadius: 0, bottomRadius: 0.18, height: 1.6)
        top.radialSegmentCount = 8
        top.materials = [goldMat]
        let tn = SCNNode(geometry: top)
        tn.position = SCNVector3(7.5, 3.9, -1)
        root.addChildNode(tn)
        return root
    }

    private static var goldColor: UIColor { rgb(0.88, 0.68, 0.18) }

    // MARK: Ghe bán hàng chợ nổi (cây bẹo)

    static func gheBeo(_ variant: Int, seed: UInt64) -> SCNNode {
        let root = boat(variant)
        var rng = SeededRNG(seed)
        let v = variant % 3
        let bam = tex(.bamboo, tint: bambooGreen, rx: 1, ry: 6)
        let px: Float = -1.3
        root.addChildNode(link(V3(px, 0.55, 0), V3(px, 5.3, 0), r1: 0.05, r2: 0.03, bam, seg: 6))
        root.addChildNode(link(V3(px, 5.0, -0.7), V3(px, 5.0, 0.7), r1: 0.025, r2: 0.025, bam, seg: 6))
        root.addChildNode(link(V3(px, 3.9, -0.5), V3(px, 3.9, 0.5), r1: 0.025, r2: 0.025, bam, seg: 6))
        root.addChildNode(box(0.02, 0.3, 0.45, rgb(0.9, 0.15, 0.10), x: px, y: 5.2, z: 0.3))

        let palettes: [[UIColor]] = [
            [rgb(0.18, 0.45, 0.22), rgb(0.93, 0.55, 0.12)],     // dưa hấu, bí
            [rgb(0.97, 0.55, 0.08), rgb(0.95, 0.80, 0.20)],     // cam, thơm
            [rgb(0.95, 0.45, 0.10), rgb(0.35, 0.12, 0.40)]      // cà rốt, cà tím
        ]
        let pal = palettes[v]
        let stretch: Float = v == 0 ? 1.0 : (v == 1 ? 1.2 : 1.7)
        let cord = plain(rgb(0.25, 0.22, 0.18), rough: 1)
        for row in 0..<2 {
            let y: Float = row == 0 ? 5.0 : 3.9
            let n = row == 0 ? 4 : 3
            let span: Float = row == 0 ? 1.2 : 0.8
            for i in 0..<n {
                let z = -span / 2 + Float(i) * (span / Float(n - 1))
                let len = rng.f(0.35, 0.7)
                root.addChildNode(link(V3(px, y, z), V3(px, y - len, z), r1: 0.006, r2: 0.006, cord, seg: 4))
                root.addChildNode(fruitBall(0.13, pal[(i + row) % 2], at: V3(px, y - len - 0.12, z), stretch: stretch))
            }
        }
        for _ in 0..<14 {
            let p = V3(rng.f(-0.4, 1.3), 0.74, rng.f(-0.3, 0.3))
            root.addChildNode(fruitBall(0.12, pal[Int.random(in: 0..<2, using: &rng)], at: p, stretch: v == 0 ? 1 : 1.3))
        }
        return root
    }

    // MARK: Bè cá

    static func fishRaft(_ variant: Int) -> SCNNode {
        let root = SCNNode()
        let roofTint: UIColor = variant % 2 == 0 ? rgb(0.55, 0.78, 0.85) : rgb(0.85, 0.45, 0.35)
        let blue = plain(rgb(0.15, 0.32, 0.65), rough: 0.5)
        for px in [Float(-2.2), 0, 2.2] {
            for pz in [Float(-1.4), 1.4] {
                let g = SCNCylinder(radius: 0.3, height: 1.2)
                g.radialSegmentCount = 12
                g.materials = [blue]
                let n = SCNNode(geometry: g)
                n.position = SCNVector3(px, 0.2, pz)
                n.eulerAngles.x = Float.pi / 2
                root.addChildNode(n)
            }
        }
        root.addChildNode(tbox(6.4, 0.15, 4.6, .wood, tile: 1.8, y: 0.6))
        // nhà trên bè
        root.addChildNode(tbox(2.8, 1.9, 2.4, .wood, tint: rgb(0.9, 0.8, 0.65), tile: 1.6, x: -1.3, y: 1.625, z: 0.3))
        let roof = gableRoof(halfSpan: 1.7, rise: 0.7, baseY: 2.6, zBack: -0.9, zFront: 1.5,
                             ovBack: 0.3, ovFront: 0.3, roofTex: .tole, roofTint: roofTint, roofRough: 0.5,
                             thickness: 0.08, tile: 2, gableTex: .wood, gableTint: nil)
        roof.position = SCNVector3(-1.3, 0, 0)
        root.addChildNode(roof)
        root.addChildNode(box(0.7, 1.5, 0.05, rgb(0.35, 0.22, 0.14), x: -1.3, y: 1.4, z: 1.52))
        let w = window(0.7, 0.7)
        w.position = SCNVector3(-2.7, 1.5, 0.3)
        w.eulerAngles.y = -Float.pi / 2
        root.addChildNode(w)
        // lồng nuôi cá (lưới trong mờ) buộc vào bè
        let net = SCNMaterial()
        net.lightingModel = .blinn
        net.diffuse.contents = rgb(0.75, 0.88, 0.95)
        net.transparency = 0.35
        net.isDoubleSided = true
        for cz in [Float(-1.2), 1.2] {
            let g = SCNBox(width: 1.8, height: 1.0, length: 1.8, chamferRadius: 0)
            g.materials = [net]
            let n = SCNNode(geometry: g)
            n.position = SCNVector3(4.2, 0.3, cz)
            n.castsShadow = false
            root.addChildNode(n)
            for cx in [Float(3.3), 5.1] {
                for dz in [Float(-0.9), 0.9] {
                    root.addChildNode(tcyl(0.04, 1.2, .bamboo, tint: bambooGreen, tileY: 1, x: cx, y: 0.5, z: cz + dz, seg: 6))
                }
            }
        }
        root.addChildNode(tbox(1.2, 0.1, 0.7, .wood, tile: 1, x: 3.4, y: 0.62, z: 0))
        return root
    }

    // MARK: Lò gạch

    static func brickKiln(_ variant: Int) -> SCNNode {
        let root = SCNNode()
        let tint: UIColor = variant % 2 == 0 ? rgb(1.0, 0.82, 0.72) : rgb(0.85, 0.70, 0.62)
        root.addChildNode(tcyl(2.3, 2.6, .brick, tint: tint, tileY: 1.6, y: 1.3, seg: 24))
        let dome = SCNSphere(radius: 2.3)
        dome.segmentCount = 24
        dome.materials = [tex(.brick, tint: tint, rx: 4, ry: 2)]
        let dn = SCNNode(geometry: dome)
        dn.scale = SCNVector3(1, 0.45, 1)
        dn.position = SCNVector3(0, 2.6, 0)
        root.addChildNode(dn)
        // ống khói cao
        let chim = SCNCone(topRadius: 0.55, bottomRadius: 1.0, height: 11)
        chim.radialSegmentCount = 20
        chim.materials = [tex(.brick, tint: tint, rx: 4, ry: 8)]
        let cn = SCNNode(geometry: chim)
        cn.position = SCNVector3(0, 8.1, 0)
        root.addChildNode(cn)
        let band = plain(rgb(0.22, 0.20, 0.20), rough: 0.7, metal: 0.4)
        for i in 0..<3 {
            let t = 0.2 + Float(i) * 0.3
            let r = 1.0 - 0.45 * t + 0.04
            root.addChildNode(cyl(r, 0.12, rgb(0.22, 0.20, 0.20), rough: 0.7, metal: 0.4,
                                  y: 2.6 + 11 * t, seg: 20))
        }
        _ = band
        // cửa lò
        for i in 0..<4 {
            let a = Float(i) * Float.pi / 2 + 0.4
            let d = tbox(0.9, 1.3, 0.3, .woodDark, tile: 1, x: cos(a) * 2.3, y: 0.7, z: sin(a) * 2.3)
            d.eulerAngles.y = -a + Float.pi / 2
            root.addChildNode(d)
        }
        // chồng gạch mộc
        for sx in 0..<3 {
            for layer in 0..<4 {
                root.addChildNode(tbox(1.1, 0.4, 0.6, .brick, tint: rgb(1.0, 0.7, 0.55), tile: 0.8,
                                       x: 3.8 + Float(sx) * 1.2, y: 0.2 + Float(layer) * 0.4, z: 1.2))
            }
        }
        return root
    }

    // MARK: Đống rơm

    static func haystack(_ variant: Int, seed: UInt64) -> SCNNode {
        let root = SCNNode()
        var rng = SeededRNG(seed)
        let straw = tex(.thatch, tint: rgb(1.15, 1.0, 0.65), rough: 0.95, rx: 2, ry: 2)
        let strand = plain(rgb(0.86, 0.72, 0.38), rough: 1)
        func pile(_ s: Float, _ x: Float, _ z: Float) {
            let g = SCNCone(topRadius: CGFloat(0.12 * s), bottomRadius: CGFloat(1.25 * s), height: CGFloat(2.6 * s))
            g.radialSegmentCount = 20
            g.materials = [straw]
            let n = SCNNode(geometry: g)
            n.position = SCNVector3(x, 1.3 * s, z)
            root.addChildNode(n)
            let shoulder = sphere(1.0 * s, straw, x: x, y: 0.8 * s, z: z, seg: 16)
            shoulder.scale = SCNVector3(1, 0.9, 1)
            root.addChildNode(shoulder)
            for _ in 0..<45 {
                let a = rng.f(0, 6.28)
                let t = rng.f(0.1, 0.85)
                let r = 1.25 * s * (1 - t)
                let p = V3(x + cos(a) * r, t * 2.6 * s, z + sin(a) * r)
                let out = V3(cos(a) * 0.3 * s, rng.f(-0.2, 0.2) * s, sin(a) * 0.3 * s)
                root.addChildNode(link(p, p + out, r1: 0.012, r2: 0.006, strand, seg: 3))
            }
        }
        pile(1.0, 0, 0)
        if variant % 2 == 1 { pile(0.6, 2.1, 0.8) }
        return root
    }

    // MARK: Giàn bầu / mướp / bí

    static func gourdTrellis(_ variant: Int, seed: UInt64) -> SCNNode {
        let root = SCNNode()
        var rng = SeededRNG(seed)
        let v = variant % 3
        let bam = tex(.bamboo, tint: bambooGreen, rx: 1, ry: 3)
        for px in [Float(-1.6), 1.6] {
            for pz in [Float(-2.5), 0, 2.5] {
                root.addChildNode(link(V3(px, 0, pz), V3(px, 2.3, pz), r1: 0.06, r2: 0.05, bam, seg: 8))
            }
        }
        for px in [Float(-1.6), 0, 1.6] {
            root.addChildNode(link(V3(px, 2.3, -2.6), V3(px, 2.3, 2.6), r1: 0.04, r2: 0.04, bam, seg: 6))
        }
        for i in 0..<9 {
            let z = -2.4 + Float(i) * 0.6
            root.addChildNode(link(V3(-1.7, 2.34, z), V3(1.7, 2.34, z), r1: 0.03, r2: 0.03, bam, seg: 6))
        }
        // dây lá phủ trên giàn
        let leafMat = TextureLibrary.foliageMaterial(.leafBroad, tint: rgb(0.95, 1.08, 0.75))
        var leaves = CardBatch()
        for _ in 0..<110 {
            let p = V3(rng.f(-1.7, 1.7), 2.3, rng.f(-2.5, 2.5))
            let d = simd_normalize(V3(rng.f(-0.8, 0.8), 0.7, rng.f(-0.8, 0.8)))
            leaves.leaf(at: p, dir: d, spin: rng.f(-3, 3), w: 0.3, h: 0.36, fold: 0.15, droop: 0.5)
        }
        for _ in 0..<22 {
            let side: Float = rng.f(0, 1) < 0.5 ? -1 : 1
            let p = V3(side * 1.6, rng.f(1.2, 2.2), rng.f(-2.4, 2.4))
            leaves.leaf(at: p, dir: V3(side * 0.3, 0.3, 0), spin: rng.f(-3, 3), w: 0.26, h: 0.32, fold: 0.15, droop: 0.6)
        }
        if let n = leaves.node(leafMat, sway: 0.05) { root.addChildNode(n) }

        let cord = plain(rgb(0.30, 0.40, 0.18), rough: 0.9)
        let flowerTint: UIColor? = v == 0 ? nil : rgb(1.0, 0.85, 0.20)
        var flowers = CardBatch()
        for _ in 0..<9 {
            flowers.disc(at: V3(rng.f(-1.5, 1.5), 2.2, rng.f(-2.3, 2.3)), normal: V3(0, -1, 0),
                         spin: rng.f(0, 6.28), size: 0.18, dish: 0.2)
        }
        if let n = flowers.node(TextureLibrary.foliageMaterial(.flower5, tint: flowerTint), sway: 0.02) {
            root.addChildNode(n)
        }
        let count = v == 1 ? 12 : (v == 2 ? 5 : 7)
        for _ in 0..<count {
            let x = rng.f(-1.4, 1.4)
            let z = rng.f(-2.3, 2.3)
            switch v {
            case 0:
                root.addChildNode(link(V3(x, 2.3, z), V3(x, 1.95, z), r1: 0.012, r2: 0.012, cord, seg: 4))
                root.addChildNode(fruitBall(0.17, rgb(0.72, 0.82, 0.50), at: V3(x, 1.7, z), stretch: 1.15))
                root.addChildNode(fruitBall(0.10, rgb(0.72, 0.82, 0.50), at: V3(x, 1.95, z)))
            case 1:
                let g = SCNCapsule(capRadius: 0.05, height: 0.75)
                g.materials = [plain(rgb(0.42, 0.62, 0.22), rough: 0.5)]
                let n = SCNNode(geometry: g)
                n.position = SCNVector3(x, 1.85, z)
                root.addChildNode(n)
            default:
                root.addChildNode(link(V3(x, 2.3, z), V3(x, 1.9, z), r1: 0.015, r2: 0.015, cord, seg: 4))
                root.addChildNode(fruitBall(0.22, rgb(0.62, 0.75, 0.55), at: V3(x, 1.6, z), stretch: 1.3))
            }
        }
        // bàn ghế nghỉ dưới giàn
        root.addChildNode(tbox(0.9, 0.06, 0.5, .wood, tile: 1, x: 0, y: 0.45, z: -0.4))
        for lx in [Float(-0.4), 0.4] {
            root.addChildNode(box(0.05, 0.42, 0.05, rgb(0.45, 0.32, 0.20), x: lx, y: 0.21, z: -0.4))
        }
        return root
    }

    // MARK: Lu nước, chum vại

    static func waterJars(_ variant: Int) -> SCNNode {
        let root = SCNNode()
        let glaze = variant % 2 == 1
        let body = glaze ? plain(rgb(0.36, 0.20, 0.10), rough: 0.25, metal: 0.1)
                         : plain(rgb(0.60, 0.33, 0.20), rough: 0.6)
        func jar(_ s: Float, _ x: Float, _ z: Float, lid: Bool) {
            let n = SCNNode()
            let b = sphere(0.45, body, y: 0.52, seg: 18)
            b.scale = SCNVector3(1, 1.1, 1)
            n.addChildNode(b)
            let neck = SCNCone(topRadius: 0.28, bottomRadius: 0.34, height: 0.22)
            neck.radialSegmentCount = 18
            neck.materials = [body]
            let nn = SCNNode(geometry: neck)
            nn.position = SCNVector3(0, 1.0, 0)
            n.addChildNode(nn)
            let rim = SCNTorus(ringRadius: 0.29, pipeRadius: 0.04)
            rim.materials = [body]
            let rn = SCNNode(geometry: rim)
            rn.position = SCNVector3(0, 1.12, 0)
            n.addChildNode(rn)
            if lid {
                n.addChildNode(tcyl(0.31, 0.04, .wood, tileY: 1, y: 1.14, seg: 14))
            } else {
                n.addChildNode(cyl(0.27, 0.02, rgb(0.15, 0.30, 0.35), rough: 0.1, metal: 0.2, y: 1.08, seg: 16))
            }
            n.scale = SCNVector3(s, s, s)
            n.position = SCNVector3(x, 0, z)
            root.addChildNode(n)
        }
        jar(1.0, 0, 0, lid: false)
        jar(0.8, 0.95, 0.25, lid: true)
        jar(0.7, -0.8, 0.45, lid: false)
        return root
    }

    // MARK: Đàn vịt

    private static func duck(_ white: Bool, _ rng: inout SeededRNG) -> SCNNode {
        let n = SCNNode()
        let body = plain(white ? rgb(0.97, 0.96, 0.92) : rgb(0.42, 0.34, 0.25), rough: 0.7)
        let b = sphere(0.22, body, y: 0.2, seg: 12)
        b.scale = SCNVector3(1.4, 0.8, 0.9)
        n.addChildNode(b)
        n.addChildNode(sphere(0.09, body, x: 0.27, y: 0.36, seg: 8))
        n.addChildNode(sphere(0.085, body, x: 0.33, y: 0.46, seg: 8))
        n.addChildNode(box(0.12, 0.03, 0.07, rgb(1.0, 0.62, 0.10), x: 0.43, y: 0.44))
        let eye = plain(rgb(0.02, 0.02, 0.02), rough: 0.3)
        for sz in [Float(-0.05), Float(0.05)] {
            n.addChildNode(sphere(0.012, eye, x: 0.38, y: 0.49, z: sz, seg: 4))
        }
        let tail = sphere(0.07, body, x: -0.33, y: 0.27, seg: 8)
        tail.scale = SCNVector3(1.3, 0.6, 0.8)
        n.addChildNode(tail)
        n.eulerAngles.y = rng.f(0, 6.28)
        return n
    }

    static func duckFlock(_ variant: Int, seed: UInt64) -> SCNNode {
        let root = SCNNode()
        var rng = SeededRNG(seed)
        let v = variant % 3
        for i in 0..<9 {
            let a = rng.f(0, 6.28)
            let d = 1.8 * rng.f(0, 1).squareRoot()
            let white = v == 0 || (v == 2 && i % 2 == 0)
            let d1 = duck(white, &rng)
            d1.position = SCNVector3(cos(a) * d, 0, sin(a) * d)
            root.addChildNode(d1)
        }
        return root
    }

    // MARK: Trâu / bò

    static func buffalo(_ variant: Int) -> SCNNode {
        let root = SCNNode()
        let cow = variant % 2 == 1
        let hide = plain(cow ? rgb(0.70, 0.50, 0.28) : rgb(0.27, 0.25, 0.25), rough: 0.8)
        let dark = plain(cow ? rgb(0.45, 0.30, 0.16) : rgb(0.16, 0.15, 0.15), rough: 0.85)
        let horn = plain(rgb(0.78, 0.74, 0.66), rough: 0.5)
        let body = sphere(0.55, hide, y: 1.05, seg: 14)
        body.scale = SCNVector3(1.7, 0.95, 0.9)
        root.addChildNode(body)
        for lx in [Float(-0.55), Float(0.55)] {
            for lz in [Float(-0.28), Float(0.28)] {
                root.addChildNode(link(V3(lx, 0.78, lz), V3(lx, 0.0, lz), r1: 0.11, r2: 0.08, dark, seg: 8))
            }
        }
        let head = sphere(0.27, hide, x: 1.0, y: 1.1, seg: 12)
        head.scale = SCNVector3(1.25, 0.9, 0.9)
        root.addChildNode(head)
        root.addChildNode(sphere(0.13, dark, x: 1.3, y: 0.98, seg: 8))
        for sz in [Float(-1), Float(1)] {
            if cow {
                root.addChildNode(link(V3(0.95, 1.33, sz * 0.14), V3(0.98, 1.5, sz * 0.3), r1: 0.04, r2: 0.015, horn, seg: 6))
            } else {
                let a = V3(0.92, 1.32, sz * 0.15)
                let b = V3(0.82, 1.5, sz * 0.5)
                let c = V3(0.62, 1.72, sz * 0.62)
                root.addChildNode(link(a, b, r1: 0.05, r2: 0.035, horn, seg: 6))
                root.addChildNode(link(b, c, r1: 0.035, r2: 0.015, horn, seg: 6))
            }
            let ear = sphere(0.07, hide, x: 0.88, y: 1.27, z: sz * 0.3, seg: 6)
            ear.scale = SCNVector3(1, 0.5, 1.3)
            root.addChildNode(ear)
        }
        if cow {
            let hump = sphere(0.25, hide, x: 0.5, y: 1.5, seg: 10)
            root.addChildNode(hump)
        }
        root.addChildNode(link(V3(-0.95, 1.1, 0), V3(-1.15, 0.45, 0), r1: 0.03, r2: 0.02, dark, seg: 5))
        return root
    }

    // MARK: Bến sông

    static func pier(_ variant: Int) -> SCNNode {
        let root = SCNNode()
        let concrete = variant % 2 == 1
        let deckTex: Tex = concrete ? .concrete : .wood
        let postTex: Tex = concrete ? .concrete : .palmBark
        root.addChildNode(tbox(3.2, 0.14, 1.9, deckTex, tile: 1.4, y: 0.7))
        for px in [Float(-1.4), 0, 1.4] {
            for pz in [Float(-0.8), 0.8] {
                root.addChildNode(tcyl(0.1, 1.7, postTex, tileY: 2, x: px, y: 0.3, z: pz, seg: 8))
            }
        }
        for i in 0..<4 {
            root.addChildNode(tbox(0.5, 0.12, 1.5, deckTex, tile: 1, x: 1.85 + Float(i) * 0.5,
                                   y: 0.55 - Float(i) * 0.14))
        }
        let bam = tex(.bamboo, tint: bambooGreen, rx: 1, ry: 3)
        for px in [Float(-1.4), 0, 1.4] {
            root.addChildNode(link(V3(px, 0.7, 0.9), V3(px, 1.5, 0.9), r1: 0.04, r2: 0.04, bam, seg: 6))
        }
        root.addChildNode(link(V3(-1.4, 1.45, 0.9), V3(1.4, 1.45, 0.9), r1: 0.035, r2: 0.035, bam, seg: 6))
        root.addChildNode(tcyl(0.09, 2.2, postTex, tileY: 2, x: -1.8, y: 0.9, z: -0.5, seg: 8))
        return root
    }

    // MARK: Quán nước ven sông (có võng)

    static func riverStall(_ variant: Int) -> SCNNode {
        let root = SCNNode()
        let thatch = variant % 2 == 0
        for px in [Float(-1.6), Float(1.6)] {
            for pz in [Float(-1.3), Float(1.3)] {
                root.addChildNode(tcyl(0.07, 2.4, .bamboo, tint: bambooGreen, tileY: 1.5, x: px, y: 1.2, z: pz, seg: 8))
            }
        }
        let roofTex: Tex = thatch ? .thatch : .tole
        let roofTint: UIColor? = thatch ? nil : rgb(0.70, 0.55, 0.40)
        root.addChildNode(gableRoof(halfSpan: 2.1, rise: 0.9, baseY: 2.4, zBack: -1.5, zFront: 1.5,
                                    ovBack: 0.3, ovFront: 0.3, roofTex: roofTex, roofTint: roofTint,
                                    roofRough: 0.9, thickness: 0.12, tile: 1.4,
                                    gableTex: roofTex, gableTint: roofTint))
        root.addChildNode(tbox(3.8, 0.1, 3.2, .concrete, tile: 1.5, y: 0.05))
        root.addChildNode(tbox(1.0, 0.06, 0.6, .wood, tile: 1, x: 0.6, y: 0.78, z: -0.2))
        for lx in [Float(0.2), Float(1.0)] {
            for lz in [Float(-0.45), Float(0.05)] {
                root.addChildNode(box(0.05, 0.75, 0.05, rgb(0.45, 0.32, 0.20), x: lx, y: 0.4, z: lz))
            }
        }
        let stoolCols: [UIColor] = [rgb(0.85, 0.20, 0.18), rgb(0.20, 0.40, 0.80), rgb(0.25, 0.65, 0.35)]
        let spots: [(Float, Float)] = [(0.6, 0.55), (0.0, -0.4), (1.3, -0.5)]
        for (i, sp) in spots.enumerated() {
            root.addChildNode(cyl(0.17, 0.4, stoolCols[i], rough: 0.5, x: sp.0, y: 0.25, z: sp.1, seg: 10))
        }
        // võng căng giữa hai cột trái
        let cloth = plain(rgb(0.82, 0.30, 0.30), rough: 0.95)
        let a = V3(-1.6, 1.5, -1.3)
        let b = V3(-1.6, 1.5, 1.3)
        let sag: Float = 0.55
        let segs = 8
        for i in 0..<segs {
            let t0 = Float(i) / Float(segs)
            let t1 = Float(i + 1) / Float(segs)
            let p0 = a + (b - a) * t0 - V3(0, sag * 4 * t0 * (1 - t0), 0)
            let p1 = a + (b - a) * t1 - V3(0, sag * 4 * t1 * (1 - t1), 0)
            let d = p1 - p0
            let len = simd_length(d)
            let seg = box(0.5, 0.03, len + 0.02, rgb(0.82, 0.30, 0.30), rough: 0.95)
            seg.position = SCNVector3((p0.x + p1.x) / 2, (p0.y + p1.y) / 2, (p0.z + p1.z) / 2)
            seg.eulerAngles.x = -atan2(d.y, d.z)
            root.addChildNode(seg)
        }
        _ = cloth
        return root
    }
}
