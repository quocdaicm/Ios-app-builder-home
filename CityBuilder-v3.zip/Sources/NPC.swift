import SceneKit
import simd

/// Hành động NPC có thể làm.
enum NPCAction {
    case jump, wave, dance, work
}

/// "Bộ não" của một NPC đặt trong cảnh, chạy mỗi khung hình qua SCNAction:
/// - 1 Đi lang thang: đi tới điểm ngẫu nhiên quanh chỗ đặt, dừng nghỉ, thỉnh thoảng vẫy tay;
/// - 2 Múa, 3 Nhảy, 4 Làm việc, 5 Vẫy tay: đứng tại chỗ làm đi làm lại.
/// Hoạt ảnh lấy từ clip của nhân vật (tên có dance, jump, work, wave…) hoặc từ xương tự dựng.
final class NPCDriver {
    static let radius: Float = 5          // bán kính đi lang thang (theo cỡ nhân vật: nhân với "scale" của vật)
    static let walkSpeed: Float = 1.5     // m/s ở cỡ gốc; khớp tốc độ clip đi bộ nên không trượt chân

    private let avatar: RiggedAvatar
    private let behavior: Int
    private var rng: SeededRNG
    private var pos = SIMD2<Float>(0, 0)          // (x, z) so với điểm đặt
    private var target = SIMD2<Float>(0, 0)
    private var yaw: Float
    private var wait: Float
    private var moving = false
    private var last: Float = 0
    private var idleT: Float = 0

    init(avatar: RiggedAvatar, behavior: Int, seed: UInt64) {
        var r = SeededRNG(seed)
        let y = Float.random(in: 0..<(2 * Float.pi), using: &r)
        let w = Float.random(in: 0...2, using: &r)
        self.avatar = avatar
        self.behavior = behavior
        self.rng = r
        self.yaw = behavior == 1 ? y : 0       // đứng tại chỗ thì hướng theo nút Xoay của vật
        self.wait = w
    }

    func tick(_ t: Float) {
        var dt = t - last
        last = t
        if dt < 0 || dt > 0.25 { dt = 1.0 / 60.0 }
        if behavior == 1 { wander(dt) } else { stay(dt) }
        avatar.root.simdPosition = SIMD3<Float>(pos.x, 0, pos.y)
        avatar.root.eulerAngles.y = yaw
    }

    private func wander(_ dt: Float) {
        var speed: Float = 0
        if moving {
            let d = target - pos
            let dist = simd_length(d)
            if dist < 0.2 {
                moving = false
                wait = Float.random(in: 1.5...4.5, using: &rng)
                if Float.random(in: 0...1, using: &rng) < 0.4 { _ = avatar.play(.wave) }
            } else {
                let want = atan2(d.x, d.y)                       // d.y là trục z
                var diff = want - yaw
                while diff > Float.pi { diff -= 2 * Float.pi }
                while diff < -Float.pi { diff += 2 * Float.pi }
                let maxTurn = 3.5 * dt
                yaw += max(-maxTurn, min(maxTurn, diff))
                if abs(diff) < 0.7 {                             // quay đủ hướng mới bước
                    speed = NPCDriver.walkSpeed
                    let step = min(speed * dt, dist)
                    pos += SIMD2<Float>(sin(yaw), cos(yaw)) * step
                }
            }
        } else {
            wait -= dt
            if wait <= 0 && !avatar.isActing {
                let ang = Float.random(in: 0..<(2 * Float.pi), using: &rng)
                let dist = Float.random(in: 1.5...NPCDriver.radius, using: &rng)
                target = SIMD2<Float>(cos(ang), sin(ang)) * dist
                moving = true
            }
        }
        avatar.animate(speed: speed, dt: dt)
    }

    private func stay(_ dt: Float) {
        if !avatar.isActing {
            idleT -= dt
            if idleT <= 0 {
                let started: Bool
                switch behavior {
                case 2:  started = avatar.play(.dance)
                case 3:  started = avatar.play(.jump)
                case 4:  started = avatar.play(.work)
                default: started = avatar.play(.wave)
                }
                // nhảy và vẫy tay nghỉ một nhịp giữa các lần; múa và làm việc nối liền nhau
                idleT = started ? (behavior == 3 ? 0.4 : (behavior == 5 ? 1.2 : 0)) : 1.0
            }
        }
        avatar.animate(speed: 0, dt: dt)
    }
}
