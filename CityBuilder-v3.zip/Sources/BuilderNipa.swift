import SceneKit
import UIKit
import simd

// MARK: - Dừa nước (Nypa fruticans) vẽ lại theo cây thật
// Đặc điểm: không có thân đứng, lá mọc thẳng từ gốc bùn thành bụi dày; lá kép lông chim dài 4-6m, dựng đứng
// rồi cong ra ngoài ở ngọn; hai hàng lá chét xếp hình chữ V quanh gân giữa, xanh bóng; cuống lá dày màu nâu
// ôliu; dưới gốc có lá khô nâu rủ xuống; thỉnh thoảng có buồng quả tròn nâu trên cuống dài.

extension Builder {
    /// Một tàu lá dừa nước: dải uốn cong trong mặt phẳng XY (X = hướng ra ngoài), gấp hình chữ V quanh gân giữa.
    /// `theta0` = góc nghiêng ban đầu so với phương thẳng đứng, `bend` = mức cong thêm về phía ngọn.
    static func nipaFrond(length L: Float, width: Float, theta0: Float, bend: Float, vAmount: Float,
                          segs: Int = 12) -> SCNGeometry {
        var verts: [SCNVector3] = []
        var norms: [SCNVector3] = []
        var uvs: [CGPoint] = []
        var idx: [Int32] = []
        let hw = width / 2
        var p = SIMD2<Float>(0, 0)
        let ds = L / Float(segs)
        for i in 0...segs {
            let t = Float(i) / Float(segs)
            let th = theta0 + bend * pow(t, 1.7)
            if i > 0 { p += SIMD2<Float>(sin(th), cos(th)) * ds }
            let inward = SIMD2<Float>(-cos(th), sin(th))           // phía lòng máng chữ V
            let lift = hw * vAmount
            let cN = SCNVector3(inward.x, inward.y, 0)
            let phi = atan(vAmount)
            let nl = SCNVector3(inward.x * cos(phi), inward.y * cos(phi), sin(phi))
            let nr = SCNVector3(inward.x * cos(phi), inward.y * cos(phi), -sin(phi))
            verts.append(SCNVector3(p.x + inward.x * lift, p.y + inward.y * lift, -hw))
            verts.append(SCNVector3(p.x, p.y, 0))
            verts.append(SCNVector3(p.x + inward.x * lift, p.y + inward.y * lift, hw))
            norms.append(contentsOf: [nl, cN, nr])
            uvs.append(CGPoint(x: CGFloat(t), y: 0))
            uvs.append(CGPoint(x: CGFloat(t), y: 0.5))
            uvs.append(CGPoint(x: CGFloat(t), y: 1))
        }
        for i in 0..<segs {
            let a = Int32(i * 3)
            idx.append(contentsOf: [a, a + 1, a + 3, a + 1, a + 4, a + 3,
                                    a + 1, a + 2, a + 4, a + 2, a + 5, a + 4])
        }
        return SCNGeometry(sources: [SCNGeometrySource(vertices: verts),
                                     SCNGeometrySource(normals: norms),
                                     SCNGeometrySource(textureCoordinates: uvs)],
                           elements: [SCNGeometryElement(indices: idx, primitiveType: .triangles)])
    }

    /// Điểm trên đường cong tàu lá (cùng công thức với `nipaFrond`) để gắn cuống lá.
    private static func nipaPoint(_ t: Float, length L: Float, theta0: Float, bend: Float) -> SIMD3<Float> {
        var p = SIMD2<Float>(0, 0)
        let n = 24
        let target = Int((t * Float(n)).rounded())
        let ds = L / Float(n)
        if target > 0 {
            for i in 1...target {
                let th = theta0 + bend * pow(Float(i) / Float(n), 1.7)
                p += SIMD2<Float>(sin(th), cos(th)) * ds
            }
        }
        return SIMD3<Float>(p.x, p.y, 0)
    }

    static func nipa(_ variant: Int, seed: UInt64) -> SCNNode {
        let root = SCNNode()
        var rng = SeededRNG(seed)
        let green = TextureLibrary.foliageMaterial(.nipaMask, tint: rgb(1.0, 1.05, 0.92))
        let dry = TextureLibrary.foliageMaterial(.nipaMask, tint: rgb(4.2, 1.05, 0.7))        // lá khô nâu
        let petiole = plain(rgb(0.30, 0.29, 0.13), rough: 0.85)
        let petioleDry = plain(rgb(0.38, 0.26, 0.14), rough: 0.9)

        func addFrond(az: Float, r0: Float, length: Float, theta0: Float, bend: Float, v: Float,
                      mat: SCNMaterial, stem: SCNMaterial, phase: Double) {
            let holder = SCNNode()
            holder.position = SCNVector3(cos(az) * r0, 0, sin(az) * r0)
            holder.eulerAngles.y = -az
            let pivot = SCNNode()
            let geo = nipaFrond(length: length, width: length * 0.34, theta0: theta0, bend: bend, vAmount: v)
            geo.materials = [mat]
            let leaf = SCNNode(geometry: geo)
            leaf.castsShadow = false
            pivot.addChildNode(leaf)
            // cuống lá dày ở gốc (đoạn không có lá chét)
            let a = SIMD3<Float>(0, 0, 0)
            let b = nipaPoint(0.26, length: length, theta0: theta0, bend: bend)
            pivot.addChildNode(link(a, b, r1: 0.075, r2: 0.04, stem, seg: 6))
            holder.addChildNode(pivot)
            root.addChildNode(holder)
            oscillate(pivot, z: 0.035, period: 2.4 + Double(rng.next() % 5) * 0.2, phase: phase)
        }

        // tàu lá xanh: vòng trong dựng đứng và cao, vòng ngoài nghiêng ra và cong nhiều hơn
        let count = 10 + Int(rng.next() % 4)
        for i in 0..<count {
            let inner = i % 3 == 0
            let az = Float(i) * (2 * Float.pi / Float(count)) + rng.f(-0.3, 0.3)
            addFrond(az: az, r0: inner ? rng.f(0.05, 0.18) : rng.f(0.2, 0.45),
                     length: inner ? rng.f(4.6, 5.6) : rng.f(3.6, 4.8),
                     theta0: inner ? rng.f(0.06, 0.2) : rng.f(0.28, 0.55),
                     bend: inner ? rng.f(0.3, 0.6) : rng.f(0.5, 0.95),
                     v: rng.f(0.42, 0.6), mat: green, stem: petiole, phase: Double(i) * 0.31)
        }
        // vài tàu lá khô nâu rủ thấp quanh gốc
        for k in 0..<3 {
            let az = Float(k) * 2.1 + rng.f(0, 1)
            addFrond(az: az, r0: rng.f(0.3, 0.5), length: rng.f(2.2, 3.0), theta0: rng.f(0.85, 1.15),
                     bend: rng.f(0.5, 0.8), v: 0.25, mat: dry, stem: petioleDry, phase: Double(k) * 0.5)
        }

        // gốc bùn + bẹ lá
        let mud = sphere(0.55, plain(rgb(0.20, 0.15, 0.10), rough: 1), y: 0.08, seg: 10)
        mud.scale = SCNVector3(1, 0.3, 1)
        root.addChildNode(mud)
        for k in 0..<6 {
            let az = Float(k) / 6 * 2 * Float.pi + rng.f(-0.3, 0.3)
            root.addChildNode(link(SIMD3<Float>(cos(az) * 0.3, 0, sin(az) * 0.3),
                                   SIMD3<Float>(cos(az) * 0.22, 0.55 + rng.f(0, 0.35), sin(az) * 0.22),
                                   r1: 0.1, r2: 0.07, plain(rgb(0.24, 0.20, 0.10), rough: 1), seg: 6))
        }

        // buồng quả: quả tròn nâu có gai, trên cuống cao trong bụi
        if rng.f(0, 1) < 0.4 {
            let az = rng.f(0, 6.28)
            let top = SIMD3<Float>(cos(az) * 0.6, 2.1, sin(az) * 0.6)
            root.addChildNode(link(SIMD3<Float>(cos(az) * 0.15, 0.2, sin(az) * 0.15), top,
                                   r1: 0.06, r2: 0.045, plain(rgb(0.36, 0.30, 0.16), rough: 0.9), seg: 6))
            let fruitM = plain(rgb(0.32, 0.20, 0.12), rough: 1)
            root.addChildNode(sphere(0.3, fruitM, x: top.x, y: top.y + 0.25, z: top.z, seg: 10))
            for _ in 0..<14 {
                let d = simd_normalize(SIMD3<Float>(rng.f(-1, 1), rng.f(-0.3, 1), rng.f(-1, 1)))
                let c = SIMD3<Float>(top.x, top.y + 0.25, top.z)
                root.addChildNode(link(c + d * 0.28, c + d * 0.42, r1: 0.035, r2: 0.005, fruitM, seg: 4))
            }
        }
        return root
    }
}
