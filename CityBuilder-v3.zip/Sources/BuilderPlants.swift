import SceneKit
import UIKit
import simd

typealias V3 = SIMD3<Float>

// MARK: - Gom nhiều lá / hoa thành MỘT khối hình (cả cây chỉ tốn một lần vẽ)

struct CardBatch {
    var verts: [SCNVector3] = []
    var norms: [SCNVector3] = []
    var uvs: [CGPoint] = []
    var idx: [Int32] = []

    private static func frame(_ dir: V3, spin: Float) -> (up: V3, side: V3, nrm: V3) {
        let up = simd_normalize(dir)
        let ref: V3 = abs(up.y) > 0.95 ? V3(1, 0, 0) : V3(0, 1, 0)
        let s0 = simd_normalize(simd_cross(up, ref))
        let n0 = simd_cross(s0, up)
        let side = simd_normalize(s0 * cos(spin) + n0 * sin(spin))
        let nrm = simd_normalize(simd_cross(side, up))
        return (up, side, nrm)
    }

    private mutating func push(_ p: V3, _ n: V3, _ u: Float, _ v: Float) {
        verts.append(SCNVector3(p.x, p.y, p.z))
        norms.append(SCNVector3(n.x, n.y, n.z))
        uvs.append(CGPoint(x: CGFloat(u), y: CGFloat(v)))
    }

    /// Một phiến lá: gốc tại `p`, mọc theo `dir`, bản rộng `w`, dài `h`.
    /// `fold` gập hai nửa theo gân giữa, `droop` cong ngọn rủ xuống, `rows` số đoạn dọc theo lá.
    mutating func leaf(at p: V3, dir: V3, spin: Float, w: Float, h: Float,
                       fold: Float = 0.15, droop: Float = 0.35, rows: Int = 3) {
        let f = CardBatch.frame(dir, spin: spin)
        var dn = V3(0, -1, 0)
        dn = dn - f.up * simd_dot(dn, f.up)
        let dl = simd_length(dn)
        dn = dl < 0.05 ? f.nrm : dn / dl
        let base = Int32(verts.count)
        let rowsN = max(rows, 2)
        for r in 0..<rowsN {
            let t = Float(r) / Float(rowsN - 1)
            let center = p + f.up * (h * t) + dn * (droop * h * t * t)
            for ci in 0..<3 {
                let col = Float(ci - 1)
                let lift = fold * w * 0.5 * abs(col)
                let pos = center + f.side * (col * w * 0.5) + f.nrm * lift
                let n = simd_normalize(f.nrm - f.side * (col * fold))
                push(pos, n, Float(ci) / 2, 1 - t)
            }
        }
        for r in 0..<(rowsN - 1) {
            for ci in 0..<2 {
                let a = base + Int32(r * 3 + ci)
                idx.append(contentsOf: [a, a + 1, a + 3, a + 1, a + 4, a + 3])
            }
        }
    }

    /// Tấm tròn / vuông nằm theo mặt phẳng vuông góc `normal` (lá sen, bông hoa), rìa hơi vểnh lên (`dish`).
    mutating func disc(at p: V3, normal: V3, spin: Float, size: Float, dish: Float = 0.08) {
        let n = simd_normalize(normal)
        let ref: V3 = abs(n.y) > 0.95 ? V3(1, 0, 0) : V3(0, 1, 0)
        let a0 = simd_normalize(simd_cross(n, ref))
        let b0 = simd_cross(n, a0)
        let ax = a0 * cos(spin) + b0 * sin(spin)
        let bx = simd_cross(n, ax)
        let base = Int32(verts.count)
        for j in 0..<3 {
            for i in 0..<3 {
                let u = Float(i - 1)
                let v = Float(j - 1)
                let edge = (abs(u) + abs(v)) * 0.5
                let pos = p + ax * (u * size * 0.5) + bx * (v * size * 0.5) + n * (dish * size * edge)
                let nn = simd_normalize(n - ax * (u * dish) - bx * (v * dish))
                push(pos, nn, Float(i) / 2, Float(j) / 2)
            }
        }
        for j in 0..<2 {
            for i in 0..<2 {
                let a = base + Int32(j * 3 + i)
                idx.append(contentsOf: [a, a + 1, a + 3, a + 1, a + 4, a + 3])
            }
        }
    }

    /// Tạo node từ cả khối. `sway` > 0 thì lá phất phơ theo gió (mức đung đưa tối đa ở ngọn, tính bằng mét).
    func node(_ material: SCNMaterial, sway: Float = 0) -> SCNNode? {
        guard !verts.isEmpty else { return nil }
        let g = SCNGeometry(sources: [SCNGeometrySource(vertices: verts),
                                      SCNGeometrySource(normals: norms),
                                      SCNGeometrySource(textureCoordinates: uvs)],
                            elements: [SCNGeometryElement(indices: idx, primitiveType: .triangles)])
        g.materials = [material]
        let n = SCNNode(geometry: g)
        n.castsShadow = false
        if sway > 0 {
            let (lo, hi) = n.boundingBox
            let top = max(hi.y - lo.y, 0.001)
            let copy = (material.copy() as? SCNMaterial) ?? material
            var mods = material.shaderModifiers ?? [:]
            mods[SCNShaderModifierEntryPoint.geometry] = Builder.leafShader
            copy.shaderModifiers = mods
            copy.setValue(NSNumber(value: sway), forKey: "amp")
            copy.setValue(NSNumber(value: lo.y), forKey: "lowY")
            copy.setValue(NSNumber(value: top), forKey: "top")
            copy.setValue(NSNumber(value: 1.0), forKey: "gain")
            g.materials = [copy]
        }
        return n
    }
}

// MARK: - Cây, hoa, lúa miền Tây

extension Builder {
    static func barkMat(_ tint: UIColor? = nil) -> SCNMaterial {
        tex(.woodDark, tint: tint ?? rgb(0.85, 0.80, 0.75), rough: 0.95, rx: 1.5, ry: 1)
    }

    /// Rải một nhóm lá quanh đầu cành.
    static func leafSpray(_ b: inout CardBatch, at p: V3, axis: V3, count: Int,
                          w: Float, h: Float, spread: Float, droop: Float,
                          spinRange: Float, _ rng: inout SeededRNG) {
        for _ in 0..<count {
            let rv = V3(rng.f(-1, 1), rng.f(-0.5, 1), rng.f(-1, 1))
            let d = simd_normalize(axis * 0.8 + rv * spread)
            b.leaf(at: p, dir: d, spin: rng.f(-spinRange, spinRange),
                   w: w * rng.f(0.85, 1.15), h: h * rng.f(0.85, 1.15), fold: 0.2, droop: droop)
        }
    }

    static func fruitBall(_ r: Float, _ color: UIColor, at p: V3, stretch: Float = 1) -> SCNNode {
        let n = sphere(r, plain(color, rough: 0.45), x: p.x, y: p.y, z: p.z, seg: 10)
        n.scale = SCNVector3(1, stretch, 1)
        return n
    }

    // MARK: Cây ăn trái: xoài, nhãn, bưởi, cam, mận

    static func fruit(_ variant: Int, seed: UInt64) -> SCNNode {
        let root = SCNNode()
        var rng = SeededRNG(seed)
        let v = variant % 5
        let bark = barkMat()
        let trunkH = rng.f(1.5, 2.1)
        root.addChildNode(link(V3(0, 0, 0), V3(0, trunkH, 0), r1: 0.3, r2: 0.18, bark, seg: 10))
        for i in 0..<4 {
            let a = Float(i) * Float.pi / 2 + rng.f(-0.3, 0.3)
            root.addChildNode(link(V3(cos(a) * 0.5, 0, sin(a) * 0.5), V3(cos(a) * 0.12, 0.6, sin(a) * 0.12),
                                   r1: 0.07, r2: 0.1, bark, seg: 6))
        }

        let leafTex: Tex = (v == 0 || v == 1) ? .leafLance : .leafBroad
        let tints: [UIColor] = [rgb(0.85, 1.0, 0.8), rgb(0.8, 0.95, 0.75), rgb(0.95, 1.05, 0.8),
                                rgb(0.85, 1.05, 0.75), rgb(1.0, 0.95, 0.85)]
        let leafMat = TextureLibrary.foliageMaterial(leafTex, tint: tints[v])
        let lw: [Float] = [0.20, 0.17, 0.34, 0.26, 0.30]
        let lh: [Float] = [0.80, 0.62, 0.52, 0.42, 0.50]

        var batch = CardBatch()
        var tips: [V3] = []
        let branches = 6
        for i in 0..<branches {
            let a = Float(i) * (2 * Float.pi / Float(branches)) + rng.f(-0.3, 0.3)
            let reach = rng.f(1.0, 1.6)
            let from = V3(0, trunkH - rng.f(0, 0.4), 0)
            let mid = V3(cos(a) * reach * 0.6, trunkH + rng.f(0.3, 0.7), sin(a) * reach * 0.6)
            let tip = V3(cos(a) * reach * 1.25, trunkH + rng.f(0.9, 1.6), sin(a) * reach * 1.25)
            root.addChildNode(link(from, mid, r1: 0.13, r2: 0.08, bark, seg: 6))
            root.addChildNode(link(mid, tip, r1: 0.08, r2: 0.04, bark, seg: 6))
            tips.append(tip)
            for _ in 0..<3 {
                let t2 = tip + V3(rng.f(-0.7, 0.7), rng.f(0.1, 0.8), rng.f(-0.7, 0.7))
                root.addChildNode(link(mid * 0.4 + tip * 0.6, t2, r1: 0.04, r2: 0.02, bark, seg: 5))
                tips.append(t2)
            }
        }
        for tp in tips {
            let outward = simd_normalize(V3(tp.x, max(tp.y - trunkH, 0.2), tp.z))
            leafSpray(&batch, at: tp, axis: outward, count: 9, w: lw[v], h: lh[v],
                      spread: 1.0, droop: 0.4, spinRange: 3.1, &rng)
        }
        // lá phủ phần giữa tán cho đỡ trống
        for _ in 0..<40 {
            let p = V3(rng.f(-1.0, 1.0), trunkH + rng.f(0.5, 1.5), rng.f(-1.0, 1.0))
            let d = simd_normalize(V3(rng.f(-1, 1), rng.f(0, 1), rng.f(-1, 1)) + V3(0, 0.2, 0))
            batch.leaf(at: p, dir: d, spin: rng.f(-3, 3), w: lw[v], h: lh[v], fold: 0.2, droop: 0.4)
        }
        if let n = batch.node(leafMat, sway: 0.10) { root.addChildNode(n) }

        // quả
        let count = v == 2 ? 8 : 16
        let stem = plain(rgb(0.35, 0.28, 0.15), rough: 0.9)
        for _ in 0..<count {
            let tp = tips[Int.random(in: 0..<tips.count, using: &rng)]
            let p = tp + V3(rng.f(-0.35, 0.35), -rng.f(0.3, 0.6), rng.f(-0.35, 0.35))
            root.addChildNode(link(p + V3(0, 0.2, 0), p, r1: 0.008, r2: 0.008, stem, seg: 4))
            switch v {
            case 0:
                let col = rng.f(0, 1) < 0.5 ? rgb(0.76, 0.80, 0.22) : rgb(0.92, 0.72, 0.18)
                root.addChildNode(fruitBall(0.11, col, at: p, stretch: 1.45))
            case 1:
                for _ in 0..<7 {
                    let q = p + V3(rng.f(-0.07, 0.07), rng.f(-0.08, 0.05), rng.f(-0.07, 0.07))
                    root.addChildNode(fruitBall(0.045, rgb(0.76, 0.60, 0.38), at: q))
                }
            case 2:
                root.addChildNode(fruitBall(0.20, rgb(0.72, 0.82, 0.30), at: p, stretch: 0.95))
            case 3:
                root.addChildNode(fruitBall(0.09, rgb(0.97, 0.52, 0.08), at: p))
            default:
                root.addChildNode(fruitBall(0.08, rgb(0.82, 0.12, 0.20), at: p, stretch: 1.15))
            }
        }
        return root
    }

    // MARK: Chuối

    static func banana(_ variant: Int, seed: UInt64) -> SCNNode {
        let root = SCNNode()
        var rng = SeededRNG(seed)
        let v = variant % 3
        let stemMat = plain(rgb(0.52, 0.62, 0.30), rough: 0.7)
        let leafMat = TextureLibrary.foliageMaterial(.leafBanana, tint: rgb(1.0, 1.05, 0.95))
        var batch = CardBatch()
        let stems = v == 2 ? 1 : 3
        let bs: Float = v == 2 ? 0.6 : 1.0
        for s in 0..<stems {
            let ang = Float(s) * 2.1 + rng.f(-0.3, 0.3)
            let off: Float = s == 0 ? 0 : rng.f(0.5, 0.9) * bs
            let ox = cos(ang) * off
            let oz = sin(ang) * off
            let h = rng.f(2.6, 3.4) * bs * (s == 0 ? 1 : 0.8)
            let top = V3(ox + rng.f(-0.2, 0.2), h, oz + rng.f(-0.2, 0.2))
            root.addChildNode(link(V3(ox, 0, oz), top, r1: 0.2 * bs, r2: 0.12 * bs, stemMat, seg: 10))
            for k in 0..<8 {
                let a = Float(k) * 0.785 + rng.f(-0.2, 0.2)
                let elev = rng.f(0.45, 1.1)
                let d = V3(cos(a) * cos(elev), sin(elev), sin(a) * cos(elev))
                batch.leaf(at: top, dir: d, spin: rng.f(-0.3, 0.3), w: 0.95 * bs, h: 3.0 * bs,
                           fold: 0.12, droop: 0.75, rows: 6)
            }
            // buồng chuối + bắp chuối
            if v != 2 && s == 0 {
                let p0 = V3(top.x, h - 0.1, top.z)
                let p1 = V3(top.x + 0.25, h - 0.7, top.z + 0.1)
                let p2 = V3(top.x + 0.30, h - 1.5, top.z + 0.12)
                root.addChildNode(link(p0, p1, r1: 0.04, r2: 0.035, stemMat, seg: 6))
                root.addChildNode(link(p1, p2, r1: 0.035, r2: 0.03, stemMat, seg: 6))
                let fruitCol = v == 1 ? rgb(0.95, 0.82, 0.20) : rgb(0.55, 0.72, 0.25)
                let fm = plain(fruitCol, rough: 0.5)
                for hand in 0..<6 {
                    let t = Float(hand) / 6
                    let c = p1 * (1 - t) + p2 * t
                    for f in 0..<7 {
                        let a2 = Float(f) / 7 * 2 * Float.pi
                        let radial = V3(cos(a2), 0, sin(a2))
                        let b0 = c + radial * 0.06
                        let b1 = b0 + radial * 0.10 + V3(0, -0.20, 0)
                        root.addChildNode(link(b0, b1, r1: 0.035, r2: 0.03, fm, seg: 6))
                    }
                }
                let bud = sphere(0.11, plain(rgb(0.45, 0.12, 0.30), rough: 0.5),
                                 x: p2.x, y: p2.y - 0.18, z: p2.z, seg: 10)
                bud.scale = SCNVector3(0.9, 1.7, 0.9)
                root.addChildNode(bud)
            }
        }
        if let n = batch.node(leafMat, sway: 0.18) { root.addChildNode(n) }
        return root
    }

    // MARK: Bụi tre

    static func bambooClump(_ variant: Int, seed: UInt64) -> SCNNode {
        let root = SCNNode()
        var rng = SeededRNG(seed)
        let yellow = variant % 2 == 1
        let culmMat = tex(.bamboo, tint: yellow ? rgb(1.1, 1.0, 0.45) : rgb(0.85, 0.95, 0.55), rx: 1, ry: 4)
        let ringMat = plain(yellow ? rgb(0.75, 0.62, 0.20) : rgb(0.45, 0.58, 0.22), rough: 0.7)
        let leafMat = TextureLibrary.foliageMaterial(.leafLance, tint: yellow ? rgb(1.1, 1.1, 0.7) : rgb(0.9, 1.1, 0.75))
        var batch = CardBatch()
        let culms = 11
        for i in 0..<culms {
            let a = Float(i) * 2.4 + rng.f(-0.3, 0.3)
            let rr = rng.f(0.1, 0.9)
            let bx = cos(a) * rr
            let bz = sin(a) * rr
            let h = rng.f(5.5, 8.0)
            let lean = rng.f(0.4, 1.4)
            let mid = V3(bx + cos(a) * lean * 0.35, h * 0.55, bz + sin(a) * lean * 0.35)
            let top = V3(bx + cos(a) * lean, h, bz + sin(a) * lean)
            let r = rng.f(0.045, 0.07)
            let b0 = V3(bx, 0, bz)
            root.addChildNode(link(b0, mid, r1: r, r2: r * 0.85, culmMat, seg: 8))
            root.addChildNode(link(mid, top, r1: r * 0.85, r2: r * 0.5, culmMat, seg: 8))
            // mắt tre
            for j in 1..<9 {
                let t = Float(j) / 9
                let c: V3 = t < 0.55 ? b0 + (mid - b0) * (t / 0.55) : mid + (top - mid) * ((t - 0.55) / 0.45)
                let rad = r * (1.0 - 0.4 * t)
                root.addChildNode(link(c - V3(0, 0.02, 0), c + V3(0, 0.02, 0),
                                       r1: rad * 1.35, r2: rad * 1.35, ringMat, seg: 8))
            }
            // cụm lá ở phần ngọn
            for k in 0..<4 {
                let t = 0.62 + Float(k) * 0.1
                let p = mid + (top - mid) * ((t - 0.55) / 0.45)
                let axis = simd_normalize(V3(cos(a), 0.5, sin(a)))
                leafSpray(&batch, at: p, axis: axis, count: 7, w: 0.13, h: 0.6,
                          spread: 1.1, droop: 0.5, spinRange: 0.5, &rng)
            }
        }
        if let n = batch.node(leafMat, sway: 0.2) { root.addChildNode(n) }
        return root
    }

    // MARK: Hồ sen

    static func lotusPond(_ variant: Int, seed: UInt64) -> SCNNode {
        let root = SCNNode()
        var rng = SeededRNG(seed)
        let v = variant % 3
        let R: Float = 3.0
        let water = cyl(R, 0.06, rgb(0.10, 0.24, 0.22), rough: 0.15, metal: 0.2, y: 0.03, seg: 36)
        root.addChildNode(water)
        let bank = SCNTube(innerRadius: CGFloat(R - 0.05), outerRadius: CGFloat(R + 0.5), height: 0.16)
        bank.radialSegmentCount = 36
        bank.materials = [tex(.dirt, tint: rgb(0.72, 0.64, 0.56), rx: 6, ry: 0.5)]
        let bn = SCNNode(geometry: bank)
        bn.position = SCNVector3(0, 0.08, 0)
        root.addChildNode(bn)

        let padMat = TextureLibrary.foliageMaterial(.leafLotus, tint: rgb(1.0, 1.05, 0.95))
        var pads = CardBatch()
        let stalkMat = plain(rgb(0.30, 0.45, 0.22), rough: 0.8)
        func spot(_ maxR: Float) -> (Float, Float) {
            let a = rng.f(0, 6.28)
            let rr = maxR * rng.f(0, 1).squareRoot()
            return (cos(a) * rr, sin(a) * rr)
        }
        for _ in 0..<26 {
            let (x, z) = spot(R - 0.45)
            pads.disc(at: V3(x, 0.07, z), normal: V3(0, 1, 0), spin: rng.f(0, 6.28),
                      size: rng.f(0.7, 1.1), dish: 0.05)
        }
        for _ in 0..<9 {
            let (x, z) = spot(R - 0.6)
            let hgt = rng.f(0.7, 1.3)
            root.addChildNode(link(V3(x, 0.05, z), V3(x, hgt, z), r1: 0.014, r2: 0.012, stalkMat, seg: 5))
            let n = V3(rng.f(-0.3, 0.3), 1, rng.f(-0.3, 0.3))
            pads.disc(at: V3(x, hgt, z), normal: n, spin: rng.f(0, 6.28), size: rng.f(0.6, 0.9), dish: 0.22)
        }
        if let n = pads.node(padMat, sway: 0.05) { root.addChildNode(n) }

        if v != 2 {
            let tint: UIColor? = v == 0 ? rgb(1.0, 0.62, 0.78) : nil
            let flowerMat = TextureLibrary.foliageMaterial(.flowerLotus, tint: tint)
            var flowers = CardBatch()
            let budCol = v == 0 ? rgb(0.93, 0.56, 0.72) : rgb(0.96, 0.95, 0.88)
            for _ in 0..<7 {
                let (x, z) = spot(R - 0.7)
                let hgt = rng.f(1.1, 1.8)
                root.addChildNode(link(V3(x, 0.05, z), V3(x, hgt, z), r1: 0.016, r2: 0.013, stalkMat, seg: 5))
                let sp = rng.f(0, 3)
                flowers.leaf(at: V3(x, hgt - 0.02, z), dir: V3(0, 1, 0), spin: sp, w: 0.46, h: 0.5,
                             fold: 0, droop: 0, rows: 2)
                flowers.leaf(at: V3(x, hgt - 0.02, z), dir: V3(0, 1, 0), spin: sp + 1.5708, w: 0.46, h: 0.5,
                             fold: 0, droop: 0, rows: 2)
            }
            for _ in 0..<4 {
                let (x, z) = spot(R - 0.7)
                let hgt = rng.f(1.0, 1.6)
                root.addChildNode(link(V3(x, 0.05, z), V3(x, hgt, z), r1: 0.015, r2: 0.012, stalkMat, seg: 5))
                let bud = sphere(0.075, plain(budCol, rough: 0.5), x: x, y: hgt + 0.1, z: z, seg: 8)
                bud.scale = SCNVector3(0.8, 1.9, 0.8)
                root.addChildNode(bud)
            }
            if let n = flowers.node(flowerMat, sway: 0.04) { root.addChildNode(n) }
        }
        return root
    }

    // MARK: Bồn hoa (cúc)

    static func flowerBed(_ variant: Int, seed: UInt64) -> SCNNode {
        let root = SCNNode()
        var rng = SeededRNG(seed)
        let v = variant % 5
        root.addChildNode(cyl(1.25, 0.2, rgb(0.28, 0.20, 0.12), rough: 1, y: 0.1, seg: 24))
        let edge = SCNTube(innerRadius: 1.22, outerRadius: 1.42, height: 0.3)
        edge.radialSegmentCount = 24
        edge.materials = [tex(.brick, tint: rgb(0.95, 0.85, 0.78), rx: 6, ry: 0.4)]
        let en = SCNNode(geometry: edge)
        en.position = SCNVector3(0, 0.15, 0)
        root.addChildNode(en)

        let leafMat = TextureLibrary.foliageMaterial(.leafBroad, tint: rgb(0.9, 1.05, 0.8))
        var leaves = CardBatch()
        for _ in 0..<70 {
            let a = rng.f(0, 6.28)
            let rr = 1.1 * rng.f(0, 1).squareRoot()
            let d = simd_normalize(V3(rng.f(-0.6, 0.6), 1, rng.f(-0.6, 0.6)))
            leaves.leaf(at: V3(cos(a) * rr, 0.18, sin(a) * rr), dir: d, spin: rng.f(-3, 3),
                        w: 0.2, h: 0.3, fold: 0.2, droop: 0.4)
        }
        if let n = leaves.node(leafMat, sway: 0.03) { root.addChildNode(n) }

        let tints: [UIColor] = [rgb(1.0, 0.62, 0.10), rgb(1.0, 0.88, 0.15), rgb(1.0, 0.55, 0.75),
                                rgb(1.0, 1.0, 1.0), rgb(0.95, 0.20, 0.20)]
        let flowerMat = TextureLibrary.foliageMaterial(.flowerPom, tint: tints[v])
        var flowers = CardBatch()
        for _ in 0..<55 {
            let a = rng.f(0, 6.28)
            let rr = 1.12 * rng.f(0, 1).squareRoot()
            let dome = (1 - rr * rr / 1.3) * 0.3
            let n = V3(rng.f(-0.25, 0.25) + cos(a) * 0.2, 1, rng.f(-0.25, 0.25) + sin(a) * 0.2)
            flowers.disc(at: V3(cos(a) * rr, 0.42 + dome + rng.f(0, 0.1), sin(a) * rr), normal: n,
                         spin: rng.f(0, 6.28), size: rng.f(0.26, 0.34), dish: 0.15)
        }
        if let n = flowers.node(flowerMat, sway: 0.02) { root.addChildNode(n) }
        return root
    }

    // MARK: Bụi dâm bụt (bông bụp)

    static func hibiscus(_ variant: Int, seed: UInt64) -> SCNNode {
        let root = SCNNode()
        var rng = SeededRNG(seed)
        let v = variant % 3
        let bark = plain(rgb(0.36, 0.30, 0.20), rough: 0.9)
        let leafMat = TextureLibrary.foliageMaterial(.leafBroad, tint: rgb(0.8, 1.0, 0.75))
        let tints: [UIColor] = [rgb(1.0, 0.14, 0.14), rgb(1.0, 0.50, 0.70), rgb(1.0, 0.90, 0.18)]
        let flowerMat = TextureLibrary.foliageMaterial(.flower5, tint: tints[v])
        var leaves = CardBatch()
        var flowers = CardBatch()
        var tops: [V3] = []
        for i in 0..<7 {
            let a = Float(i) * 0.9 + rng.f(-0.3, 0.3)
            let h = rng.f(1.2, 1.8)
            let top = V3(cos(a) * rng.f(0.3, 0.8), h, sin(a) * rng.f(0.3, 0.8))
            root.addChildNode(link(V3(0, 0, 0), top, r1: 0.05, r2: 0.025, bark, seg: 6))
            tops.append(top)
        }
        for tp in tops {
            leafSpray(&leaves, at: tp, axis: V3(0, 1, 0), count: 18, w: 0.22, h: 0.34,
                      spread: 1.3, droop: 0.4, spinRange: 3.0, &rng)
            for _ in 0..<5 {
                let q = tp * rng.f(0.5, 0.9)
                leafSpray(&leaves, at: q + V3(0, 0.1, 0), axis: V3(0, 1, 0), count: 6, w: 0.22, h: 0.34,
                          spread: 1.4, droop: 0.4, spinRange: 3.0, &rng)
            }
        }
        for _ in 0..<14 {
            let tp = tops[Int.random(in: 0..<tops.count, using: &rng)]
            let p = tp + V3(rng.f(-0.3, 0.3), rng.f(-0.2, 0.2), rng.f(-0.3, 0.3))
            let n = simd_normalize(V3(p.x, 0.5, p.z))
            flowers.disc(at: p, normal: n, spin: rng.f(0, 6.28), size: rng.f(0.38, 0.5), dish: 0.3)
        }
        if let n = leaves.node(leafMat, sway: 0.06) { root.addChildNode(n) }
        if let n = flowers.node(flowerMat, sway: 0.04) { root.addChildNode(n) }
        return root
    }

    // MARK: Mai vàng

    static func maiVang(_ variant: Int, seed: UInt64) -> SCNNode {
        let root = SCNNode()
        var rng = SeededRNG(seed)
        let bloom = variant % 2 == 0
        let bark = barkMat(rgb(0.75, 0.70, 0.65))
        var tips: [V3] = []

        func grow(_ from: V3, _ dir: V3, _ len: Float, _ r: Float, _ depth: Int) {
            let to = from + simd_normalize(dir) * len
            root.addChildNode(link(from, to, r1: r, r2: r * 0.7, bark, seg: 6))
            if depth == 0 {
                tips.append(to)
                return
            }
            let kids = depth == 3 ? 3 : 2
            for _ in 0..<kids {
                let nd = simd_normalize(dir + V3(rng.f(-0.9, 0.9), rng.f(0.0, 0.6), rng.f(-0.9, 0.9)))
                grow(to, nd, len * rng.f(0.6, 0.8), r * 0.65, depth - 1)
            }
        }
        // thân cong
        let p1 = V3(0.25, 0.9, 0.1)
        let p2 = V3(-0.1, 1.8, 0.05)
        root.addChildNode(link(V3(0, 0, 0), p1, r1: 0.22, r2: 0.16, bark, seg: 8))
        root.addChildNode(link(p1, p2, r1: 0.16, r2: 0.12, bark, seg: 8))
        grow(p2, V3(0.3, 1, 0.1), 0.9, 0.11, 3)
        grow(p1, V3(-1, 0.9, 0.3), 1.0, 0.09, 2)
        grow(p1, V3(0.9, 0.8, -0.4), 1.0, 0.09, 2)

        var flowers = CardBatch()
        var leaves = CardBatch()
        let fMat = TextureLibrary.foliageMaterial(.flower5, tint: rgb(1.0, 0.88, 0.12))
        let lMat = TextureLibrary.foliageMaterial(.leafBroad, tint: rgb(0.85, 1.05, 0.55))
        let bud = plain(rgb(0.78, 0.72, 0.18), rough: 0.6)
        for tp in tips {
            let fcount = bloom ? 9 : 3
            for _ in 0..<fcount {
                let p = tp + V3(rng.f(-0.4, 0.4), rng.f(-0.3, 0.35), rng.f(-0.4, 0.4))
                let n = simd_normalize(V3(p.x, 0.4, p.z))
                flowers.disc(at: p, normal: n, spin: rng.f(0, 6.28), size: rng.f(0.2, 0.3), dish: 0.3)
            }
            if bloom {
                for _ in 0..<2 {
                    root.addChildNode(sphere(0.035, bud, x: tp.x + rng.f(-0.3, 0.3),
                                             y: tp.y + rng.f(-0.2, 0.3), z: tp.z + rng.f(-0.3, 0.3), seg: 6))
                }
            } else {
                leafSpray(&leaves, at: tp, axis: V3(0, 1, 0), count: 10, w: 0.2, h: 0.34,
                          spread: 1.2, droop: 0.4, spinRange: 3.0, &rng)
            }
        }
        if let n = leaves.node(lMat, sway: 0.08) { root.addChildNode(n) }
        if let n = flowers.node(fMat, sway: 0.06) { root.addChildNode(n) }
        return root
    }

    // MARK: Cây bần (rễ thở cọc bần)

    static func ban(_ variant: Int, seed: UInt64) -> SCNNode {
        let root = SCNNode()
        var rng = SeededRNG(seed)
        let bark = barkMat(rgb(0.65, 0.60, 0.55))
        root.addChildNode(cyl(2.9, 0.06, rgb(0.20, 0.15, 0.10), rough: 1, y: 0.03, seg: 24))
        // rễ thở nhọn mọc quanh gốc
        let rootMat = plain(rgb(0.30, 0.22, 0.15), rough: 1)
        for _ in 0..<32 {
            let a = rng.f(0, 6.28)
            let d = rng.f(0.7, 2.6)
            let hgt = rng.f(0.25, 0.7)
            let g = SCNCone(topRadius: 0.008, bottomRadius: 0.035, height: CGFloat(hgt))
            g.radialSegmentCount = 6
            g.materials = [rootMat]
            let n = SCNNode(geometry: g)
            n.position = SCNVector3(cos(a) * d, hgt / 2, sin(a) * d)
            root.addChildNode(n)
        }
        let trunkH = rng.f(3.0, 3.8)
        root.addChildNode(link(V3(0, 0, 0), V3(0.1, trunkH, 0), r1: 0.4, r2: 0.2, bark, seg: 10))
        for i in 0..<5 {
            let a = Float(i) * 1.25
            root.addChildNode(link(V3(cos(a) * 0.65, 0, sin(a) * 0.65), V3(cos(a) * 0.15, 0.9, sin(a) * 0.15),
                                   r1: 0.08, r2: 0.12, bark, seg: 6))
        }
        let leafMat = TextureLibrary.foliageMaterial(.leafBroad, tint: rgb(0.9, 1.08, 0.7))
        var batch = CardBatch()
        var tips: [V3] = []
        for i in 0..<7 {
            let a = Float(i) * 0.9 + rng.f(-0.3, 0.3)
            let reach = rng.f(1.2, 2.0)
            let from = V3(0.1, trunkH - rng.f(0, 0.7), 0)
            let tip = V3(cos(a) * reach, trunkH + rng.f(0.7, 1.7), sin(a) * reach)
            root.addChildNode(link(from, tip, r1: 0.12, r2: 0.04, bark, seg: 6))
            tips.append(tip)
            tips.append(from * 0.3 + tip * 0.7 + V3(rng.f(-0.4, 0.4), 0.3, rng.f(-0.4, 0.4)))
        }
        for tp in tips {
            let outward = simd_normalize(V3(tp.x, max(tp.y - trunkH, 0.3), tp.z))
            leafSpray(&batch, at: tp, axis: outward, count: 10, w: 0.26, h: 0.4,
                      spread: 1.0, droop: 0.25, spinRange: 3.1, &rng)
        }
        if let n = batch.node(leafMat, sway: 0.10) { root.addChildNode(n) }
        for _ in 0..<12 {
            let tp = tips[Int.random(in: 0..<tips.count, using: &rng)]
            root.addChildNode(fruitBall(0.07, rgb(0.55, 0.72, 0.28),
                                        at: tp + V3(rng.f(-0.3, 0.3), -rng.f(0.1, 0.3), rng.f(-0.3, 0.3)),
                                        stretch: 0.8))
        }
        return root
    }

    // MARK: Ruộng lúa

    static func riceField(_ variant: Int, seed: UInt64) -> SCNNode {
        let root = SCNNode()
        var rng = SeededRNG(seed)
        let v = variant % 3
        let half: Float = 4.0
        let soil: UIColor = v == 2 ? rgb(0.26, 0.32, 0.28) : rgb(0.28, 0.22, 0.14)
        root.addChildNode(box(8.4, 0.1, 8.4, soil, rough: v == 2 ? 0.2 : 0.95, y: 0.05))
        for sgn in [Float(-1), Float(1)] {
            root.addChildNode(tbox(8.9, 0.3, 0.5, .dirt, tile: 1.5, y: 0.15, z: sgn * 4.2))
            root.addChildNode(tbox(0.5, 0.3, 8.4, .dirt, tile: 1.5, x: sgn * 4.2, y: 0.15))
        }
        let t: Tex = v == 1 ? .riceGold : .riceGreen
        let tint: UIColor? = v == 2 ? rgb(1.1, 1.2, 0.8) : nil
        let mat = TextureLibrary.foliageMaterial(t, tint: tint)
        let height: Float = v == 0 ? 1.0 : (v == 1 ? 1.15 : 0.4)
        var batch = CardBatch()
        let n = 10
        let step = 2 * half / Float(n)
        for i in 0..<n {
            for j in 0..<n {
                let x = -half + (Float(i) + 0.5) * step + rng.f(-0.18, 0.18)
                let z = -half + (Float(j) + 0.5) * step + rng.f(-0.18, 0.18)
                for k in 0..<2 {
                    let d = V3(rng.f(-0.12, 0.12), 1, rng.f(-0.12, 0.12))
                    batch.leaf(at: V3(x, 0.1, z), dir: d, spin: Float(k) * 1.5708 + rng.f(0, 1.2),
                               w: height * 0.95, h: height, fold: 0, droop: v == 1 ? 0.3 : 0.12)
                }
            }
        }
        if let node = batch.node(mat, sway: 0.07) { root.addChildNode(node) }
        return root
    }

    // MARK: Thanh long

    static func dragonFruit(_ variant: Int, seed: UInt64) -> SCNNode {
        let root = SCNNode()
        var rng = SeededRNG(seed)
        let yellow = variant % 2 == 1
        let green = plain(rgb(0.30, 0.55, 0.22), rough: 0.7)
        let fruitCol: UIColor = yellow ? rgb(0.95, 0.82, 0.20) : rgb(0.88, 0.12, 0.40)
        for px in [Float(-2.2), 0, 2.2] {
            for pz in [Float(-1.4), 1.4] {
                root.addChildNode(tbox(0.2, 1.9, 0.2, .concrete, tile: 1.5, x: px, y: 0.95, z: pz))
                let top = V3(px, 1.9, pz)
                root.addChildNode(link(V3(px + 0.12, 0, pz), top, r1: 0.05, r2: 0.05, green, seg: 3))
                for k in 0..<7 {
                    let a = Float(k) * 0.9 + rng.f(-0.2, 0.2)
                    let c = V3(cos(a), 0, sin(a))
                    let p1 = top + c * 0.45 + V3(0, 0.12, 0)
                    let p2 = top + c * 0.8 + V3(0, -0.25, 0)
                    let p3 = top + c * 0.95 + V3(0, -0.85, 0)
                    root.addChildNode(link(top, p1, r1: 0.05, r2: 0.045, green, seg: 3))
                    root.addChildNode(link(p1, p2, r1: 0.045, r2: 0.04, green, seg: 3))
                    root.addChildNode(link(p2, p3, r1: 0.04, r2: 0.035, green, seg: 3))
                    if k % 2 == 0 {
                        root.addChildNode(fruitBall(0.09, fruitCol, at: p3 + V3(0, -0.08, 0), stretch: 1.25))
                    }
                }
            }
        }
        return root
    }
}
