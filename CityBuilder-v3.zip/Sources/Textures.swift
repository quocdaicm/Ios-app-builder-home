import SceneKit
import UIKit

// MARK: - Thư viện texture chân thực
//
// Mỗi vật liệu có 2 lớp ảnh: màu (albedo) và bản đồ pháp tuyến (normal) để tạo độ nổi.
// Thứ tự ưu tiên:
//   1. Nếu bạn thêm ảnh thật vào thư mục Sources/Textures (ví dụ "wood.jpg", "thatch.jpg"...),
//      app dùng ngay ảnh đó.
//   2. Nếu không có, app tự vẽ texture mô phỏng thật bằng code.
//
// Tên file ảnh thật được hỗ trợ (jpg hoặc png):
//   grass, dirt, asphalt, concrete, wood, woodDark, thatch, tole, brick, roofTile,
//   plaster, palmBark, water

enum Tex: CaseIterable {
    case grass, dirt, asphalt, concrete, wood, woodDark, woodPaint, thatch, tole, brick
    case roofTile, plaster, palmBark, water, bamboo, leafMask, frondMask, nipaMask, grassTuft, needle
    case leafBroad, leafLance, leafBanana, leafLotus      // một phiến lá rõ nét (có gân)
    case flower5, flowerPom, flowerLotus                 // hoa 5 cánh, hoa cúc nhiều cánh, hoa sen
    case riceGreen, riceGold                             // khóm lúa xanh / lúa chín

    var key: String {
        switch self {
        case .grass: return "grass"
        case .dirt: return "dirt"
        case .asphalt: return "asphalt"
        case .concrete: return "concrete"
        case .wood: return "wood"
        case .woodDark: return "woodDark"
        case .woodPaint: return "woodPaint"
        case .thatch: return "thatch"
        case .tole: return "tole"
        case .brick: return "brick"
        case .roofTile: return "roofTile"
        case .plaster: return "plaster"
        case .palmBark: return "palmBark"
        case .water: return "water"
        case .bamboo: return "bamboo"
        case .leafMask: return "leafMask"
        case .frondMask: return "frondMask"
        case .nipaMask: return "nipaMask"
        case .grassTuft: return "grassTuft"
        case .needle: return "needle"
        case .leafBroad: return "leafBroad"
        case .leafLance: return "leafLance"
        case .leafBanana: return "leafBanana"
        case .leafLotus: return "leafLotus"
        case .flower5: return "flower5"
        case .flowerPom: return "flowerPom"
        case .flowerLotus: return "flowerLotus"
        case .riceGreen: return "riceGreen"
        case .riceGold: return "riceGold"
        }
    }
}

enum TextureLibrary {
    private static var albedoCache: [String: UIImage] = [:]
    private static var normalCache: [String: UIImage] = [:]

    // MARK: Truy cập

    private static let lock = NSLock()

    static func albedo(_ t: Tex) -> UIImage {
        lock.lock()
        let cached = albedoCache[t.key]
        lock.unlock()
        if let c = cached { return c }
        let img = UIImage(named: t.key) ?? UIImage(named: t.key + ".jpg") ?? make(t)
        lock.lock()
        albedoCache[t.key] = img
        lock.unlock()
        return img
    }

    static func normal(_ t: Tex) -> UIImage? {
        switch t {
        case .leafMask, .frondMask, .nipaMask, .grassTuft, .needle: return nil
        case .leafBroad, .leafLance, .leafBanana, .leafLotus: return nil
        case .flower5, .flowerPom, .flowerLotus, .riceGreen, .riceGold: return nil
        default: break
        }
        lock.lock()
        let cached = normalCache[t.key]
        lock.unlock()
        if let c = cached { return c }
        let n = normalMap(from: albedo(t), strength: strength(t))
        lock.lock()
        normalCache[t.key] = n
        lock.unlock()
        return n
    }

    /// Vẽ sẵn toàn bộ texture ở luồng nền để lúc mở app không bị khựng.
    static func preload(completion: @escaping () -> Void) {
        DispatchQueue.global(qos: .userInitiated).async {
            for t in Tex.allCases {
                _ = albedo(t)
                _ = normal(t)
            }
            DispatchQueue.main.async(execute: completion)
        }
    }

    private static func strength(_ t: Tex) -> CGFloat {
        switch t {
        case .tole: return 5
        case .thatch: return 4
        case .brick, .roofTile: return 4
        case .wood, .woodDark, .woodPaint, .palmBark, .bamboo: return 3
        case .asphalt, .concrete, .dirt: return 2.5
        case .grass: return 2
        default: return 2
        }
    }

    // MARK: Vật liệu PBR hoàn chỉnh

    private static var matCache: [String: SCNMaterial] = [:]

    /// Vật liệu PBR có texture (được dùng chung giữa các vật thể giống nhau).
    /// `repeatX/Y` = số lần lặp ảnh. `swapUV` = đổi chiều vân (ví dụ cho mái nhà dốc,
    /// để hàng lá chạy dọc theo nóc).
    static func material(_ t: Tex, tint: UIColor? = nil, roughness: CGFloat = 0.85,
                         metalness: CGFloat = 0, repeatX: Float = 1, repeatY: Float = 1,
                         swapUV: Bool = false) -> SCNMaterial {
        let key = "\(t.key)|\(tint?.description ?? "-")|\(roughness)|\(metalness)|\(repeatX)|\(repeatY)|\(swapUV)"
        if let c = matCache[key] { return c }

        let m = SCNMaterial()
        m.lightingModel = .physicallyBased
        m.diffuse.contents = albedo(t)
        m.roughness.contents = roughness
        m.metalness.contents = metalness
        if let n = normal(t) {
            m.normal.contents = n
            m.normal.intensity = 1.0
        }
        var tr = SCNMatrix4MakeScale(repeatX, repeatY, 1)
        if swapUV {
            tr = SCNMatrix4Identity
            tr.m11 = 0
            tr.m22 = 0
            tr.m21 = repeatX
            tr.m12 = repeatY
        }
        for p in [m.diffuse, m.normal] {
            p.wrapS = .repeat
            p.wrapT = .repeat
            p.mipFilter = .linear
            p.contentsTransform = tr
        }
        // nhân màu: giữ vân ảnh, đổi tông màu (để nút "Màu" vẫn hoạt động)
        if let tint = tint { m.multiply.contents = tint }
        matCache[key] = m
        return m
    }

    /// Vật liệu lá: ảnh có kênh alpha, hai mặt, cắt bỏ phần nền trong suốt.
    static func foliageMaterial(_ t: Tex, tint: UIColor? = nil,
                                repeatX: Float = 1, repeatY: Float = 1) -> SCNMaterial {
        let key = "F|\(t.key)|\(tint?.description ?? "-")|\(repeatX)|\(repeatY)"
        if let c = matCache[key] { return c }

        let m = SCNMaterial()
        m.lightingModel = .blinn
        m.diffuse.contents = albedo(t)
        m.specular.contents = UIColor(white: 0.12, alpha: 1)
        m.shininess = 0.15
        m.isDoubleSided = true
        m.diffuse.wrapS = .repeat
        m.diffuse.wrapT = .repeat
        m.diffuse.mipFilter = .linear
        m.diffuse.contentsTransform = SCNMatrix4MakeScale(repeatX, repeatY, 1)
        if let tint = tint { m.multiply.contents = tint }
        // Cắt nền trong suốt (không cần sắp xếp độ sâu, không viền trắng)
        m.shaderModifiers = [.fragment: "if (_output.color.a < 0.5) { discard_fragment(); }\n_output.color.a = 1.0;"]
        matCache[key] = m
        return m
    }

    // MARK: - Sinh ảnh bằng code

    private struct RNG: RandomNumberGenerator {
        var s: UInt64
        mutating func next() -> UInt64 {
            s = s &* 6364136223846793005 &+ 1442695040888963407
            return s
        }
    }

    private static func render(_ size: Int, opaque: Bool = true,
                               _ draw: (CGContext, CGFloat, inout RNG) -> Void) -> UIImage {
        let sz = CGSize(width: size, height: size)
        let fmt = UIGraphicsImageRendererFormat()
        fmt.scale = 1
        fmt.opaque = opaque
        var rng = RNG(s: 0x9E3779B97F4A7C15 &+ UInt64(size))
        return UIGraphicsImageRenderer(size: sz, format: fmt).image { ctx in
            draw(ctx.cgContext, CGFloat(size), &rng)
        }
    }

    private static func col(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat, _ a: CGFloat = 1) -> UIColor {
        UIColor(red: r, green: g, blue: b, alpha: a)
    }

    private static func jitter(_ c: UIColor, _ amt: CGFloat, _ rng: inout RNG) -> UIColor {
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        c.getRed(&r, green: &g, blue: &b, alpha: &a)
        let d = CGFloat.random(in: -amt...amt, using: &rng)
        return UIColor(red: min(max(r + d, 0), 1), green: min(max(g + d, 0), 1),
                       blue: min(max(b + d, 0), 1), alpha: a)
    }

    /// Hạt nhiễu mịn phủ lên toàn ảnh (tạo cảm giác bề mặt thật, không phẳng).
    private static func grain(_ c: CGContext, _ s: CGFloat, count: Int, alpha: CGFloat,
                              _ rng: inout RNG) {
        for _ in 0..<count {
            let x = CGFloat.random(in: 0..<s, using: &rng)
            let y = CGFloat.random(in: 0..<s, using: &rng)
            let w = CGFloat.random(in: 1...3, using: &rng)
            let v = CGFloat.random(in: 0...1, using: &rng)
            c.setFillColor(UIColor(white: v, alpha: alpha).cgColor)
            c.fill(CGRect(x: x, y: y, width: w, height: w))
        }
    }

    /// Vẽ lặp liền mạch: mỗi nét vẽ gần mép được vẽ thêm bản sao phía đối diện.
    private static func tiled(_ s: CGFloat, _ rect: CGRect, _ body: (CGRect) -> Void) {
        for ox in [-s, 0, s] {
            for oy in [-s, 0, s] {
                let r = rect.offsetBy(dx: ox, dy: oy)
                if r.maxX < 0 || r.minX > s || r.maxY < 0 || r.minY > s { continue }
                body(r)
            }
        }
    }

    private static func make(_ t: Tex) -> UIImage {
        switch t {
        case .grass: return makeGrass()
        case .dirt: return makeDirt()
        case .asphalt: return makeAsphalt()
        case .concrete: return makeConcrete()
        case .wood: return makeWood(base: col(0.62, 0.46, 0.29))
        case .woodDark: return makeWood(base: col(0.30, 0.20, 0.12))
        case .woodPaint: return makeWood(base: col(0.88, 0.86, 0.82))
        case .thatch: return makeThatch()
        case .tole: return makeTole()
        case .brick: return makeBrick()
        case .roofTile: return makeRoofTile()
        case .plaster: return makePlaster()
        case .palmBark: return makePalmBark()
        case .water: return makeWater()
        case .bamboo: return makeBamboo()
        case .leafMask: return makeLeafCluster()
        case .frondMask: return makeFrond()
        case .nipaMask: return makeNipa()
        case .grassTuft: return makeGrassTuft()
        case .needle: return makeNeedle()
        case .leafBroad: return makeLeaf(fat: 0.40, shoulder: 0.35, w: 256, h: 288, seed: 11)
        case .leafLance: return makeLeaf(fat: 0.22, shoulder: 0.30, w: 160, h: 320, seed: 12)
        case .leafBanana: return makeBananaLeaf()
        case .leafLotus: return makeLotusLeaf()
        case .flower5: return makeFlower5()
        case .flowerPom: return makeFlowerPom()
        case .flowerLotus: return makeFlowerLotus()
        case .riceGreen: return makeRice(gold: false)
        case .riceGold: return makeRice(gold: true)
        }
    }

    // Cỏ: nền xanh lốm đốm + hàng nghìn ngọn cỏ nhỏ nhiều sắc xanh
    private static func makeGrass() -> UIImage {
        render(512) { c, s, rng in
            c.setFillColor(col(0.30, 0.45, 0.16).cgColor)
            c.fill(CGRect(x: 0, y: 0, width: s, height: s))
            // mảng màu lớn
            for _ in 0..<60 {
                let r = CGFloat.random(in: 30...90, using: &rng)
                let x = CGFloat.random(in: 0..<s, using: &rng)
                let y = CGFloat.random(in: 0..<s, using: &rng)
                let base = Bool.random(using: &rng) ? col(0.36, 0.52, 0.18) : col(0.24, 0.38, 0.13)
                c.setFillColor(base.withAlphaComponent(0.35).cgColor)
                tiled(s, CGRect(x: x - r, y: y - r, width: r * 2, height: r * 2)) { c.fillEllipse(in: $0) }
            }
            // ngọn cỏ
            let greens = [col(0.20, 0.36, 0.10), col(0.33, 0.52, 0.17), col(0.45, 0.62, 0.22),
                          col(0.52, 0.55, 0.20), col(0.16, 0.30, 0.10)]
            for _ in 0..<9000 {
                let x = CGFloat.random(in: 0..<s, using: &rng)
                let y = CGFloat.random(in: 0..<s, using: &rng)
                let h = CGFloat.random(in: 5...14, using: &rng)
                let lean = CGFloat.random(in: -4...4, using: &rng)
                c.setStrokeColor(greens.randomElement(using: &rng)!.cgColor)
                c.setLineWidth(CGFloat.random(in: 0.8...1.8, using: &rng))
                c.move(to: CGPoint(x: x, y: y))
                c.addLine(to: CGPoint(x: x + lean, y: y - h))
                c.strokePath()
            }
        }
    }

    // Đất: nâu, sỏi nhỏ, vệt khô
    private static func makeDirt() -> UIImage {
        render(512) { c, s, rng in
            c.setFillColor(col(0.45, 0.33, 0.21).cgColor)
            c.fill(CGRect(x: 0, y: 0, width: s, height: s))
            for _ in 0..<120 {
                let r = CGFloat.random(in: 15...70, using: &rng)
                let x = CGFloat.random(in: 0..<s, using: &rng)
                let y = CGFloat.random(in: 0..<s, using: &rng)
                c.setFillColor(jitter(col(0.46, 0.33, 0.20), 0.08, &rng).withAlphaComponent(0.4).cgColor)
                tiled(s, CGRect(x: x - r, y: y - r, width: r * 2, height: r * 1.4)) { c.fillEllipse(in: $0) }
            }
            for _ in 0..<1400 {
                let x = CGFloat.random(in: 0..<s, using: &rng)
                let y = CGFloat.random(in: 0..<s, using: &rng)
                let r = CGFloat.random(in: 1.5...5, using: &rng)
                c.setFillColor(jitter(col(0.55, 0.47, 0.36), 0.12, &rng).cgColor)
                c.fillEllipse(in: CGRect(x: x, y: y, width: r, height: r * 0.8))
            }
            grain(c, s, count: 9000, alpha: 0.10, &rng)
        }
    }

    // Nhựa đường: xám than, hạt đá, vết rạn
    private static func makeAsphalt() -> UIImage {
        render(512) { c, s, rng in
            c.setFillColor(col(0.20, 0.20, 0.21).cgColor)
            c.fill(CGRect(x: 0, y: 0, width: s, height: s))
            for _ in 0..<40 {
                let r = CGFloat.random(in: 30...100, using: &rng)
                let x = CGFloat.random(in: 0..<s, using: &rng)
                let y = CGFloat.random(in: 0..<s, using: &rng)
                c.setFillColor(UIColor(white: CGFloat.random(in: 0.15...0.28, using: &rng), alpha: 0.35).cgColor)
                tiled(s, CGRect(x: x - r, y: y - r, width: r * 2, height: r * 2)) { c.fillEllipse(in: $0) }
            }
            grain(c, s, count: 26000, alpha: 0.22, &rng)
            // vết nứt
            c.setStrokeColor(UIColor(white: 0.08, alpha: 0.8).cgColor)
            c.setLineWidth(1.2)
            for _ in 0..<4 {
                var p = CGPoint(x: CGFloat.random(in: 0..<s, using: &rng), y: CGFloat.random(in: 0..<s, using: &rng))
                c.move(to: p)
                for _ in 0..<12 {
                    p.x += CGFloat.random(in: -14...14, using: &rng)
                    p.y += CGFloat.random(in: 4...16, using: &rng)
                    c.addLine(to: p)
                }
                c.strokePath()
            }
        }
    }

    // Bê tông: xám sáng, lỗ khí, ố loang
    private static func makeConcrete() -> UIImage {
        render(512) { c, s, rng in
            c.setFillColor(col(0.66, 0.65, 0.62).cgColor)
            c.fill(CGRect(x: 0, y: 0, width: s, height: s))
            for _ in 0..<70 {
                let r = CGFloat.random(in: 25...90, using: &rng)
                let x = CGFloat.random(in: 0..<s, using: &rng)
                let y = CGFloat.random(in: 0..<s, using: &rng)
                let v = CGFloat.random(in: 0.5...0.78, using: &rng)
                c.setFillColor(UIColor(white: v, alpha: 0.3).cgColor)
                tiled(s, CGRect(x: x - r, y: y - r, width: r * 2, height: r * 2)) { c.fillEllipse(in: $0) }
            }
            grain(c, s, count: 18000, alpha: 0.18, &rng)
            for _ in 0..<160 {
                let x = CGFloat.random(in: 0..<s, using: &rng)
                let y = CGFloat.random(in: 0..<s, using: &rng)
                let r = CGFloat.random(in: 1...3, using: &rng)
                c.setFillColor(UIColor(white: 0.32, alpha: 0.7).cgColor)
                c.fillEllipse(in: CGRect(x: x, y: y, width: r, height: r))
            }
            // khe co giãn
            c.setStrokeColor(UIColor(white: 0.35, alpha: 0.9).cgColor)
            c.setLineWidth(2)
            c.move(to: CGPoint(x: 0, y: s / 2)); c.addLine(to: CGPoint(x: s, y: s / 2))
            c.move(to: CGPoint(x: s / 2, y: 0)); c.addLine(to: CGPoint(x: s / 2, y: s))
            c.strokePath()
        }
    }

    // Ván gỗ: các tấm ván dọc, thớ gỗ, mắt gỗ, khe giữa các tấm
    private static func makeWood(base: UIColor) -> UIImage {
        render(512) { c, s, rng in
            let boards = 6
            let bw = s / CGFloat(boards)
            for b in 0..<boards {
                let x0 = CGFloat(b) * bw
                c.setFillColor(jitter(base, 0.07, &rng).cgColor)
                c.fill(CGRect(x: x0, y: 0, width: bw, height: s))
                // thớ gỗ
                for _ in 0..<110 {
                    let x = x0 + CGFloat.random(in: 2..<(bw - 2), using: &rng)
                    let w = CGFloat.random(in: 0.5...1.6, using: &rng)
                    let v = CGFloat.random(in: -0.10...0.07, using: &rng)
                    var r: CGFloat = 0, g: CGFloat = 0, bl: CGFloat = 0, a: CGFloat = 0
                    base.getRed(&r, green: &g, blue: &bl, alpha: &a)
                    c.setStrokeColor(UIColor(red: r + v, green: g + v, blue: bl + v, alpha: 0.6).cgColor)
                    c.setLineWidth(w)
                    c.move(to: CGPoint(x: x, y: 0))
                    c.addCurve(to: CGPoint(x: x + CGFloat.random(in: -3...3, using: &rng), y: s),
                               control1: CGPoint(x: x + CGFloat.random(in: -4...4, using: &rng), y: s * 0.33),
                               control2: CGPoint(x: x + CGFloat.random(in: -4...4, using: &rng), y: s * 0.66))
                    c.strokePath()
                }
                // mắt gỗ
                if Int.random(in: 0..<3, using: &rng) == 0 {
                    let kx = x0 + CGFloat.random(in: 12..<(bw - 12), using: &rng)
                    let ky = CGFloat.random(in: 40..<(s - 40), using: &rng)
                    for ring in 0..<4 {
                        let rr = CGFloat(ring) * 2.5 + 3
                        c.setStrokeColor(col(0.20, 0.12, 0.06, 0.55).cgColor)
                        c.setLineWidth(1)
                        c.strokeEllipse(in: CGRect(x: kx - rr, y: ky - rr * 1.6, width: rr * 2, height: rr * 3.2))
                    }
                }
                // khe giữa ván
                c.setFillColor(col(0.05, 0.03, 0.02, 0.85).cgColor)
                c.fill(CGRect(x: x0, y: 0, width: 2, height: s))
            }
            // đinh / mối nối ngang
            c.setFillColor(col(0.05, 0.03, 0.02, 0.6).cgColor)
            c.fill(CGRect(x: 0, y: s * 0.5, width: s, height: 1.5))
            grain(c, s, count: 5000, alpha: 0.07, &rng)
        }
    }

    // Mái lá dừa nước: nhiều lớp lá xếp so le, sợi lá, màu rơm vàng nâu
    private static func makeThatch() -> UIImage {
        render(512) { c, s, rng in
            c.setFillColor(col(0.46, 0.36, 0.18).cgColor)
            c.fill(CGRect(x: 0, y: 0, width: s, height: s))
            let rows = 12
            let rh = s / CGFloat(rows)
            let palette = [col(0.66, 0.54, 0.28), col(0.58, 0.46, 0.22), col(0.72, 0.60, 0.33),
                           col(0.50, 0.40, 0.19), col(0.62, 0.50, 0.26), col(0.42, 0.34, 0.16)]
            for r in 0..<rows {
                let y0 = CGFloat(r) * rh
                // dải lá rủ xuống, đầu nhọn
                var x: CGFloat = -10
                while x < s + 10 {
                    let w = CGFloat.random(in: 14...30, using: &rng)
                    let c0 = palette.randomElement(using: &rng)!
                    c.setFillColor(c0.cgColor)
                    c.move(to: CGPoint(x: x, y: y0))
                    c.addLine(to: CGPoint(x: x + w, y: y0))
                    c.addLine(to: CGPoint(x: x + w * 0.5 + CGFloat.random(in: -3...3, using: &rng), y: y0 + rh * 1.6))
                    c.closePath()
                    c.fillPath()
                    // sợi lá
                    c.setStrokeColor(UIColor(white: 0, alpha: 0.18).cgColor)
                    c.setLineWidth(0.8)
                    for i in 0..<4 {
                        let fx = x + w * (0.2 + 0.2 * CGFloat(i))
                        c.move(to: CGPoint(x: fx, y: y0))
                        c.addLine(to: CGPoint(x: x + w * 0.5, y: y0 + rh * 1.5))
                    }
                    c.strokePath()
                    x += w * CGFloat.random(in: 0.6...0.9, using: &rng)
                }
                // bóng đổ dưới mỗi hàng lá
                c.setFillColor(UIColor(white: 0, alpha: 0.28).cgColor)
                c.fill(CGRect(x: 0, y: y0 + rh * 1.0, width: s, height: 3))
            }
            grain(c, s, count: 9000, alpha: 0.10, &rng)
        }
    }

    // Tôn múi: sóng dọc, gỉ sét loang, đinh vít
    private static func makeTole() -> UIImage {
        render(512) { c, s, rng in
            let ribs = 12
            let rw = s / CGFloat(ribs)
            for i in 0..<ribs {
                let x0 = CGFloat(i) * rw
                let grad = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(),
                                      colors: [col(0.45, 0.48, 0.50).cgColor, col(0.82, 0.85, 0.87).cgColor,
                                               col(0.50, 0.53, 0.55).cgColor] as CFArray,
                                      locations: [0, 0.5, 1])!
                c.saveGState()
                c.clip(to: CGRect(x: x0, y: 0, width: rw, height: s))
                c.drawLinearGradient(grad, start: CGPoint(x: x0, y: 0), end: CGPoint(x: x0 + rw, y: 0), options: [])
                c.restoreGState()
            }
            // gỉ sét
            for _ in 0..<70 {
                let x = CGFloat.random(in: 0..<s, using: &rng)
                let y = CGFloat.random(in: 0..<s, using: &rng)
                let r = CGFloat.random(in: 6...34, using: &rng)
                c.setFillColor(col(0.48, 0.24, 0.10, CGFloat.random(in: 0.10...0.35, using: &rng)).cgColor)
                c.fillEllipse(in: CGRect(x: x, y: y, width: r * 0.6, height: r * 1.8))
            }
            // vệt nước chảy
            for _ in 0..<40 {
                let x = CGFloat.random(in: 0..<s, using: &rng)
                let y = CGFloat.random(in: 0..<(s * 0.7), using: &rng)
                c.setStrokeColor(col(0.40, 0.22, 0.12, 0.28).cgColor)
                c.setLineWidth(CGFloat.random(in: 1...3, using: &rng))
                c.move(to: CGPoint(x: x, y: y))
                c.addLine(to: CGPoint(x: x + CGFloat.random(in: -2...2, using: &rng),
                                      y: y + CGFloat.random(in: 40...180, using: &rng)))
                c.strokePath()
            }
            // đinh vít
            for row in [CGFloat(40), s - 40] {
                for i in 0..<ribs where i % 2 == 0 {
                    let x = CGFloat(i) * rw + rw / 2
                    c.setFillColor(UIColor(white: 0.25, alpha: 1).cgColor)
                    c.fillEllipse(in: CGRect(x: x - 3, y: row - 3, width: 6, height: 6))
                }
            }
            grain(c, s, count: 8000, alpha: 0.09, &rng)
        }
    }

    // Gạch đỏ: hàng gạch xây so le, vữa xám
    private static func makeBrick() -> UIImage {
        render(512) { c, s, rng in
            c.setFillColor(col(0.62, 0.60, 0.55).cgColor)   // vữa
            c.fill(CGRect(x: 0, y: 0, width: s, height: s))
            let rows = 16
            let bh = s / CGFloat(rows)
            let bw = s / 6
            for r in 0..<rows {
                let off: CGFloat = r % 2 == 0 ? 0 : -bw / 2
                for i in 0...6 {
                    let x = CGFloat(i) * bw + off
                    let color = jitter(col(0.60, 0.27, 0.19), 0.07, &rng)
                    c.setFillColor(color.cgColor)
                    c.fill(CGRect(x: x + 2, y: CGFloat(r) * bh + 2, width: bw - 4, height: bh - 4))
                    // rêu / ố
                    if Int.random(in: 0..<6, using: &rng) == 0 {
                        c.setFillColor(col(0.25, 0.32, 0.18, 0.28).cgColor)
                        c.fill(CGRect(x: x + 2, y: CGFloat(r) * bh + bh * 0.5, width: bw - 4, height: bh * 0.5 - 2))
                    }
                }
            }
            grain(c, s, count: 14000, alpha: 0.12, &rng)
        }
    }

    // Ngói đỏ: hàng ngói âm dương bo tròn
    private static func makeRoofTile() -> UIImage {
        render(512) { c, s, rng in
            c.setFillColor(col(0.25, 0.10, 0.07).cgColor)
            c.fill(CGRect(x: 0, y: 0, width: s, height: s))
            let cols = 12
            let rows = 10
            let tw = s / CGFloat(cols)
            let th = s / CGFloat(rows)
            for r in 0..<rows {
                for i in 0..<cols {
                    let off: CGFloat = r % 2 == 0 ? 0 : tw / 2
                    let x = CGFloat(i) * tw + off - tw / 2
                    let y = CGFloat(r) * th
                    let base = jitter(col(0.66, 0.28, 0.16), 0.07, &rng)
                    let grad = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(),
                                          colors: [base.withAlphaComponent(1).cgColor,
                                                   jitter(base, 0.10, &rng).cgColor,
                                                   base.withAlphaComponent(1).cgColor] as CFArray,
                                          locations: [0, 0.5, 1])!
                    c.saveGState()
                    let rect = CGRect(x: x + 1, y: y, width: tw - 2, height: th * 1.35)
                    c.addPath(UIBezierPath(roundedRect: rect, byRoundingCorners: [.bottomLeft, .bottomRight],
                                           cornerRadii: CGSize(width: tw / 2, height: th * 0.5)).cgPath)
                    c.clip()
                    c.drawLinearGradient(grad, start: CGPoint(x: x, y: y), end: CGPoint(x: x + tw, y: y), options: [])
                    c.restoreGState()
                    // bóng dưới mép ngói
                    c.setFillColor(UIColor(white: 0, alpha: 0.28).cgColor)
                    c.fill(CGRect(x: x + 2, y: y + th * 1.0, width: tw - 4, height: 2.5))
                    if Int.random(in: 0..<8, using: &rng) == 0 {
                        c.setFillColor(col(0.20, 0.30, 0.15, 0.25).cgColor)   // rêu
                        c.fill(CGRect(x: x + 2, y: y + th * 0.4, width: tw - 4, height: th * 0.6))
                    }
                }
            }
            grain(c, s, count: 9000, alpha: 0.10, &rng)
        }
    }

    // Vữa tô tường: màu kem, hơi lốm đốm, vết ố
    private static func makePlaster() -> UIImage {
        render(512) { c, s, rng in
            c.setFillColor(col(0.88, 0.86, 0.80).cgColor)
            c.fill(CGRect(x: 0, y: 0, width: s, height: s))
            for _ in 0..<80 {
                let r = CGFloat.random(in: 20...80, using: &rng)
                let x = CGFloat.random(in: 0..<s, using: &rng)
                let y = CGFloat.random(in: 0..<s, using: &rng)
                c.setFillColor(UIColor(white: CGFloat.random(in: 0.6...0.95, using: &rng), alpha: 0.18).cgColor)
                tiled(s, CGRect(x: x - r, y: y - r, width: r * 2, height: r * 2)) { c.fillEllipse(in: $0) }
            }
            // vệt nước mưa
            for _ in 0..<26 {
                let x = CGFloat.random(in: 0..<s, using: &rng)
                c.setStrokeColor(col(0.45, 0.42, 0.34, 0.12).cgColor)
                c.setLineWidth(CGFloat.random(in: 2...8, using: &rng))
                c.move(to: CGPoint(x: x, y: 0))
                c.addLine(to: CGPoint(x: x + CGFloat.random(in: -6...6, using: &rng),
                                      y: CGFloat.random(in: 80...s, using: &rng)))
                c.strokePath()
            }
            grain(c, s, count: 22000, alpha: 0.12, &rng)
        }
    }

    // Vỏ thân dừa: các vòng ngang đậm, sợi dọc xám nâu
    private static func makePalmBark() -> UIImage {
        render(512) { c, s, rng in
            c.setFillColor(col(0.46, 0.38, 0.30).cgColor)
            c.fill(CGRect(x: 0, y: 0, width: s, height: s))
            // sợi dọc
            for _ in 0..<420 {
                let x = CGFloat.random(in: 0..<s, using: &rng)
                let v = CGFloat.random(in: -0.12...0.10, using: &rng)
                c.setStrokeColor(UIColor(red: 0.46 + v, green: 0.38 + v, blue: 0.30 + v, alpha: 0.7).cgColor)
                c.setLineWidth(CGFloat.random(in: 0.6...2, using: &rng))
                c.move(to: CGPoint(x: x, y: 0))
                c.addLine(to: CGPoint(x: x + CGFloat.random(in: -2...2, using: &rng), y: s))
                c.strokePath()
            }
            // vòng ngang (sẹo cuống lá)
            let rings = 22
            for i in 0..<rings {
                let y = CGFloat(i) * s / CGFloat(rings) + CGFloat.random(in: -2...2, using: &rng)
                c.setStrokeColor(col(0.18, 0.13, 0.09, 0.75).cgColor)
                c.setLineWidth(CGFloat.random(in: 2.5...4.5, using: &rng))
                c.move(to: CGPoint(x: 0, y: y))
                var x: CGFloat = 0
                while x < s {
                    x += 16
                    c.addLine(to: CGPoint(x: x, y: y + CGFloat.random(in: -2...2, using: &rng)))
                }
                c.strokePath()
                c.setStrokeColor(col(0.66, 0.58, 0.46, 0.45).cgColor)
                c.setLineWidth(1.2)
                c.move(to: CGPoint(x: 0, y: y + 4))
                c.addLine(to: CGPoint(x: s, y: y + 4))
                c.strokePath()
            }
            grain(c, s, count: 9000, alpha: 0.10, &rng)
        }
    }

    // Nước kênh: xanh đục phù sa, gợn sóng mềm
    private static func makeWater() -> UIImage {
        render(512) { c, s, rng in
            let grad = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(),
                                  colors: [col(0.28, 0.38, 0.30).cgColor, col(0.34, 0.46, 0.38).cgColor] as CFArray,
                                  locations: [0, 1])!
            c.drawLinearGradient(grad, start: .zero, end: CGPoint(x: s, y: s), options: [])
            for _ in 0..<260 {
                let x = CGFloat.random(in: 0..<s, using: &rng)
                let y = CGFloat.random(in: 0..<s, using: &rng)
                let w = CGFloat.random(in: 20...90, using: &rng)
                c.setStrokeColor(UIColor(white: 1, alpha: CGFloat.random(in: 0.04...0.16, using: &rng)).cgColor)
                c.setLineWidth(CGFloat.random(in: 1...2.5, using: &rng))
                tiled(s, CGRect(x: x, y: y - 4, width: w, height: 8)) { r in
                    c.move(to: CGPoint(x: r.minX, y: r.midY))
                    c.addQuadCurve(to: CGPoint(x: r.maxX, y: r.midY), control: CGPoint(x: r.midX, y: r.midY - 4))
                    c.strokePath()
                }
            }
            grain(c, s, count: 6000, alpha: 0.05, &rng)
        }
    }

    // Tre: đốt tre, sợi dọc vàng xanh
    private static func makeBamboo() -> UIImage {
        render(256) { c, s, rng in
            c.setFillColor(col(0.70, 0.60, 0.30).cgColor)
            c.fill(CGRect(x: 0, y: 0, width: s, height: s))
            for _ in 0..<160 {
                let x = CGFloat.random(in: 0..<s, using: &rng)
                let v = CGFloat.random(in: -0.10...0.08, using: &rng)
                c.setStrokeColor(UIColor(red: 0.70 + v, green: 0.60 + v, blue: 0.30 + v, alpha: 0.7).cgColor)
                c.setLineWidth(CGFloat.random(in: 0.6...1.8, using: &rng))
                c.move(to: CGPoint(x: x, y: 0))
                c.addLine(to: CGPoint(x: x, y: s))
                c.strokePath()
            }
            for y in [s * 0.18, s * 0.62] {
                c.setFillColor(col(0.38, 0.30, 0.12, 0.85).cgColor)
                c.fill(CGRect(x: 0, y: y, width: s, height: 5))
            }
            grain(c, s, count: 2000, alpha: 0.08, &rng)
        }
    }

    // MARK: Ảnh lá có kênh alpha (nền trong suốt)

    /// Một tàu lá dừa (lá kép lông chim): gân giữa + hàng lá chét hai bên, đầu nhọn.
    /// Trục lá nằm ngang, gốc ở bên trái.
    private static func makeFrond() -> UIImage {
        let w = 512, h = 256
        let fmt = UIGraphicsImageRendererFormat()
        fmt.scale = 1
        fmt.opaque = false
        var rng = RNG(s: 77)
        return UIGraphicsImageRenderer(size: CGSize(width: w, height: h), format: fmt).image { ctx in
            let c = ctx.cgContext
            let W = CGFloat(w), H = CGFloat(h)
            let midY = H / 2
            // gân giữa
            c.setStrokeColor(col(0.45, 0.38, 0.18).cgColor)
            c.setLineWidth(5)
            c.move(to: CGPoint(x: 0, y: midY))
            c.addLine(to: CGPoint(x: W * 0.97, y: midY))
            c.strokePath()

            let count = 54
            for i in 0..<count {
                let t = CGFloat(i) / CGFloat(count)
                let x = 14 + t * (W - 40)
                // lá chét dài ở giữa, ngắn dần về hai đầu
                let tc: CGFloat = min(max(t, 0.05), 0.95)
                let shape: CGFloat = 0.35 + 0.65 * sin(tc * CGFloat.pi)
                let rnd: CGFloat = CGFloat.random(in: 0.88...1.05, using: &rng)
                let len: CGFloat = H * 0.46 * shape * rnd
                let sweep = 30 + 40 * t   // lá chét xuôi về phía đầu tàu lá
                for dir in [CGFloat(-1), CGFloat(1)] {
                    let tip = CGPoint(x: x + sweep, y: midY + dir * len)
                    let ctrl = CGPoint(x: x + sweep * 0.3, y: midY + dir * len * 0.55)
                    let green = jitter(col(0.16, 0.42, 0.14), 0.07, &rng)
                    c.setFillColor(green.cgColor)
                    c.move(to: CGPoint(x: x - 2.5, y: midY))
                    c.addQuadCurve(to: tip, control: ctrl)
                    c.addQuadCurve(to: CGPoint(x: x + 2.5, y: midY),
                                   control: CGPoint(x: ctrl.x + 7, y: ctrl.y))
                    c.closePath()
                    c.fillPath()
                    // gân lá chét sáng hơn
                    c.setStrokeColor(col(0.36, 0.60, 0.24, 0.8).cgColor)
                    c.setLineWidth(1)
                    c.move(to: CGPoint(x: x, y: midY))
                    c.addQuadCurve(to: tip, control: CGPoint(x: ctrl.x + 3, y: ctrl.y))
                    c.strokePath()
                }
            }
        }
    }

    /// Mảng lá phủ kín (lặp liền mạch) dùng cho tán cây: nhiều lá nhỏ chồng nhau,
    /// có sáng/tối, có khe hở nhỏ trong suốt giữa các lá.
    private static func makeLeafCluster() -> UIImage {
        let w = 512
        let fmt = UIGraphicsImageRendererFormat()
        fmt.scale = 1
        fmt.opaque = false
        var rng = RNG(s: 123)
        return UIGraphicsImageRenderer(size: CGSize(width: w, height: w), format: fmt).image { ctx in
            let c = ctx.cgContext
            let S = CGFloat(w)
            // nền tối để khe giữa lá không lộ lỗ trống quá nhiều
            c.setFillColor(col(0.07, 0.19, 0.06).cgColor)
            c.fill(CGRect(x: 0, y: 0, width: S, height: S))
            for layer in 0..<4 {
                let lum = 0.55 + 0.17 * CGFloat(layer)
                for _ in 0..<(330 + layer * 60) {
                    let px = CGFloat.random(in: 0..<S, using: &rng)
                    let py = CGFloat.random(in: 0..<S, using: &rng)
                    let size = CGFloat.random(in: 22...44, using: &rng)
                    let rot = CGFloat.random(in: 0..<(2 * CGFloat.pi), using: &rng)
                    let gr: CGFloat = 0.17 * lum + 0.04
                    let gg: CGFloat = 0.42 * lum + 0.04
                    let gb: CGFloat = 0.11 * lum
                    let g = jitter(col(gr, gg, gb), 0.05, &rng)
                    for ox in [-S, 0, S] {
                        for oy in [-S, 0, S] {
                            let cx = px + ox, cy = py + oy
                            if cx < -size || cx > S + size || cy < -size || cy > S + size { continue }
                            c.saveGState()
                            c.translateBy(x: cx, y: cy)
                            c.rotate(by: rot)
                            c.setFillColor(g.cgColor)
                            c.addEllipse(in: CGRect(x: -size / 2, y: -size / 4, width: size, height: size / 2))
                            c.fillPath()
                            c.setStrokeColor(UIColor(white: 1, alpha: 0.14).cgColor)
                            c.setLineWidth(0.8)
                            c.move(to: CGPoint(x: -size / 2, y: 0))
                            c.addLine(to: CGPoint(x: size / 2, y: 0))
                            c.strokePath()
                            c.restoreGState()
                        }
                    }
                }
            }
        }
    }

    // MARK: - Lá, hoa, lúa thật (ảnh có kênh alpha, mỗi phiến lá hiện rõ gân)

    private static func card(_ w: Int, _ h: Int, seed: UInt64,
                             _ draw: (CGContext, CGFloat, CGFloat, inout RNG) -> Void) -> UIImage {
        let fmt = UIGraphicsImageRendererFormat()
        fmt.scale = 1
        fmt.opaque = false
        var rng = RNG(s: seed)
        return UIGraphicsImageRenderer(size: CGSize(width: w, height: h), format: fmt).image { ctx in
            draw(ctx.cgContext, CGFloat(w), CGFloat(h), &rng)
        }
    }

    private static func rnd(_ lo: CGFloat, _ hi: CGFloat, _ rng: inout RNG) -> CGFloat {
        CGFloat.random(in: lo...hi, using: &rng)
    }

    /// Hình phiến lá: gốc ở đáy giữa ảnh, ngọn ở đỉnh ảnh.
    private static func leafOutline(_ W: CGFloat, _ H: CGFloat, fat: CGFloat, shoulder: CGFloat) -> CGPath {
        let p = CGMutablePath()
        let cx = W / 2
        let base = CGPoint(x: cx, y: H - 3)
        let tip = CGPoint(x: cx, y: 3)
        let c1y = H * (1 - shoulder * 0.6)
        let c2y = H * (1 - shoulder) * 0.55
        p.move(to: base)
        p.addCurve(to: tip,
                   control1: CGPoint(x: cx - W * fat * 1.25, y: c1y),
                   control2: CGPoint(x: cx - W * fat * 0.9, y: c2y))
        p.addCurve(to: base,
                   control1: CGPoint(x: cx + W * fat * 0.9, y: c2y),
                   control2: CGPoint(x: cx + W * fat * 1.25, y: c1y))
        p.closeSubpath()
        return p
    }

    private static func gradient(_ a: UIColor, _ b: UIColor) -> CGGradient? {
        CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(),
                   colors: [a.cgColor, b.cgColor] as CFArray, locations: [0, 1])
    }

    /// Tô thân lá (đậm ở gốc, sáng ở ngọn), gân giữa và gân bên.
    private static func paintLeaf(_ c: CGContext, _ W: CGFloat, _ H: CGFloat, path: CGPath,
                                  dark: UIColor, light: UIColor, veins: Int) {
        c.saveGState()
        c.addPath(path)
        c.clip()
        if let g = gradient(dark, light) {
            c.drawLinearGradient(g, start: CGPoint(x: 0, y: H), end: CGPoint(x: 0, y: 0), options: [])
        }
        // nửa phải hơi tối hơn: lá có chiều sâu như gập theo gân giữa
        c.setFillColor(UIColor(white: 0, alpha: 0.13).cgColor)
        c.fill(CGRect(x: W / 2, y: 0, width: W / 2, height: H))
        // gân bên
        c.setLineCap(.round)
        c.setLineWidth(max(1.2, W / 140))
        for i in 1...veins {
            let t = CGFloat(i) / CGFloat(veins + 1)
            let y0 = H - 8 - t * (H - 40)
            for dir in [CGFloat(-1), CGFloat(1)] {
                let reach = W * 0.46 * (1 - t * 0.5)
                let tipPt = CGPoint(x: W / 2 + dir * reach, y: y0 - H * 0.15)
                let ctrl = CGPoint(x: W / 2 + dir * reach * 0.45, y: y0 - H * 0.02)
                c.setStrokeColor(UIColor(red: 0.86, green: 0.95, blue: 0.62, alpha: 0.38).cgColor)
                c.move(to: CGPoint(x: W / 2, y: y0))
                c.addQuadCurve(to: tipPt, control: ctrl)
                c.strokePath()
            }
        }
        // gân giữa
        c.setStrokeColor(UIColor(red: 0.84, green: 0.93, blue: 0.55, alpha: 0.95).cgColor)
        c.setLineWidth(max(2.5, W / 55))
        c.move(to: CGPoint(x: W / 2, y: H - 2))
        c.addLine(to: CGPoint(x: W / 2, y: H * 0.07))
        c.strokePath()
        c.restoreGState()
        // viền sáng mảnh
        c.addPath(path)
        c.setStrokeColor(UIColor(white: 1, alpha: 0.12).cgColor)
        c.setLineWidth(1.2)
        c.strokePath()
    }

    /// Lá đơn: xoài, nhãn, bưởi, cam, dâm bụt, bần... (khác nhau ở độ bè và độ thon).
    private static func makeLeaf(fat: CGFloat, shoulder: CGFloat, w: Int, h: Int, seed: UInt64) -> UIImage {
        card(w, h, seed: seed) { c, W, H, _ in
            let path = leafOutline(W, H, fat: fat, shoulder: shoulder)
            paintLeaf(c, W, H, path: path,
                      dark: col(0.10, 0.30, 0.07), light: col(0.30, 0.58, 0.16), veins: 9)
        }
    }

    /// Lá chuối: bản to dài, gân song song, rách thành vệt ở mép.
    private static func makeBananaLeaf() -> UIImage {
        card(192, 512, seed: 21) { c, W, H, rng in
            let cx = W / 2
            let p = CGMutablePath()
            p.move(to: CGPoint(x: cx, y: H - 2))
            p.addCurve(to: CGPoint(x: cx - W * 0.46, y: H * 0.55),
                       control1: CGPoint(x: cx - W * 0.15, y: H * 0.93),
                       control2: CGPoint(x: cx - W * 0.46, y: H * 0.82))
            p.addCurve(to: CGPoint(x: cx, y: 4),
                       control1: CGPoint(x: cx - W * 0.47, y: H * 0.25),
                       control2: CGPoint(x: cx - W * 0.28, y: H * 0.05))
            p.addCurve(to: CGPoint(x: cx + W * 0.46, y: H * 0.55),
                       control1: CGPoint(x: cx + W * 0.28, y: H * 0.05),
                       control2: CGPoint(x: cx + W * 0.47, y: H * 0.25))
            p.addCurve(to: CGPoint(x: cx, y: H - 2),
                       control1: CGPoint(x: cx + W * 0.46, y: H * 0.82),
                       control2: CGPoint(x: cx + W * 0.15, y: H * 0.93))
            p.closeSubpath()
            c.saveGState()
            c.addPath(p)
            c.clip()
            if let g = gradient(col(0.12, 0.36, 0.08), col(0.36, 0.64, 0.20)) {
                c.drawLinearGradient(g, start: CGPoint(x: 0, y: H), end: CGPoint(x: 0, y: 0), options: [])
            }
            c.setFillColor(UIColor(white: 0, alpha: 0.12).cgColor)
            c.fill(CGRect(x: cx, y: 0, width: W / 2, height: H))
            // gân song song chạy xiên từ gân giữa ra mép
            c.setLineWidth(1.4)
            var y = H - 10
            while y > 12 {
                for dir in [CGFloat(-1), CGFloat(1)] {
                    c.setStrokeColor(UIColor(red: 0.80, green: 0.92, blue: 0.55, alpha: 0.30).cgColor)
                    c.move(to: CGPoint(x: cx, y: y))
                    c.addLine(to: CGPoint(x: cx + dir * W * 0.5, y: y - H * 0.07))
                    c.strokePath()
                }
                y -= 7
            }
            // gân giữa to, sáng
            c.setStrokeColor(UIColor(red: 0.80, green: 0.90, blue: 0.50, alpha: 1).cgColor)
            c.setLineWidth(5)
            c.move(to: CGPoint(x: cx, y: H - 2))
            c.addLine(to: CGPoint(x: cx, y: 8))
            c.strokePath()
            // vệt rách ở mép (xóa thành trong suốt)
            c.setBlendMode(.clear)
            c.setLineWidth(3.5)
            c.setLineCap(.round)
            for _ in 0..<9 {
                let dir: CGFloat = rnd(0, 1, &rng) < 0.5 ? -1 : 1
                let yy = rnd(H * 0.12, H * 0.8, &rng)
                let len = rnd(W * 0.18, W * 0.34, &rng)
                c.move(to: CGPoint(x: cx + dir * W * 0.5, y: yy))
                c.addLine(to: CGPoint(x: cx + dir * (W * 0.5 - len), y: yy - len * 0.16))
                c.strokePath()
            }
            c.restoreGState()
        }
    }

    /// Lá sen: tròn, gân tỏa từ giữa, có khuyết một góc.
    private static func makeLotusLeaf() -> UIImage {
        card(384, 384, seed: 31) { c, W, H, rng in
            let ctr = CGPoint(x: W / 2, y: H / 2)
            let r = W * 0.48
            c.saveGState()
            c.addEllipse(in: CGRect(x: ctr.x - r, y: ctr.y - r, width: r * 2, height: r * 2))
            c.clip()
            if let g = gradient(col(0.36, 0.62, 0.36), col(0.14, 0.40, 0.20)) {
                c.drawRadialGradient(g, startCenter: ctr, startRadius: 0, endCenter: ctr, endRadius: r, options: [])
            }
            c.setLineCap(.round)
            for i in 0..<20 {
                let a = CGFloat(i) / 20 * 2 * CGFloat.pi
                c.setStrokeColor(UIColor(red: 0.78, green: 0.92, blue: 0.70, alpha: 0.42).cgColor)
                c.setLineWidth(i % 2 == 0 ? 2.4 : 1.4)
                c.move(to: ctr)
                c.addLine(to: CGPoint(x: ctr.x + cos(a) * r, y: ctr.y + sin(a) * r))
                c.strokePath()
            }
            // vài giọt nước đọng
            for _ in 0..<6 {
                let a = rnd(0, 2 * CGFloat.pi, &rng)
                let d = rnd(r * 0.15, r * 0.8, &rng)
                let s = rnd(5, 9, &rng)
                c.setFillColor(UIColor(white: 1, alpha: 0.55).cgColor)
                c.fillEllipse(in: CGRect(x: ctr.x + cos(a) * d, y: ctr.y + sin(a) * d, width: s, height: s))
            }
            // khuyết một góc
            c.setBlendMode(.clear)
            c.move(to: ctr)
            c.addLine(to: CGPoint(x: ctr.x + cos(-1.35) * r * 1.2, y: ctr.y + sin(-1.35) * r * 1.2))
            c.addLine(to: CGPoint(x: ctr.x + cos(-1.78) * r * 1.2, y: ctr.y + sin(-1.78) * r * 1.2))
            c.closePath()
            c.fillPath()
            c.restoreGState()
        }
    }

    /// Hoa 5 cánh (dâm bụt, mai): vẽ gần trắng, có bóng đậm dần về nhụy; màu thật do `tint` nhân lên.
    private static func makeFlower5() -> UIImage {
        card(256, 256, seed: 41) { c, W, H, _ in
            let ctr = CGPoint(x: W / 2, y: H / 2)
            let r = W * 0.46
            for i in 0..<5 {
                c.saveGState()
                c.translateBy(x: ctr.x, y: ctr.y)
                c.rotate(by: CGFloat(i) * 2 * CGFloat.pi / 5 + 0.3)
                let petal = CGMutablePath()
                petal.move(to: .zero)
                petal.addCurve(to: CGPoint(x: 0, y: -r),
                               control1: CGPoint(x: -r * 0.95, y: -r * 0.35),
                               control2: CGPoint(x: -r * 0.75, y: -r * 1.0))
                petal.addCurve(to: .zero,
                               control1: CGPoint(x: r * 0.75, y: -r * 1.0),
                               control2: CGPoint(x: r * 0.95, y: -r * 0.35))
                c.addPath(petal)
                c.clip()
                if let g = gradient(col(0.62, 0.58, 0.58), col(1.0, 0.98, 0.98)) {
                    c.drawLinearGradient(g, start: .zero, end: CGPoint(x: 0, y: -r), options: [])
                }
                c.setStrokeColor(UIColor(white: 0.55, alpha: 0.35).cgColor)
                c.setLineWidth(1.2)
                for k in -2...2 {
                    c.move(to: .zero)
                    c.addLine(to: CGPoint(x: CGFloat(k) * r * 0.22, y: -r * 0.9))
                    c.strokePath()
                }
                c.restoreGState()
            }
            // nhụy
            c.setStrokeColor(col(0.95, 0.92, 0.65).cgColor)
            c.setLineWidth(5)
            c.move(to: ctr)
            c.addLine(to: CGPoint(x: ctr.x + 6, y: ctr.y - r * 0.5))
            c.strokePath()
            c.setFillColor(col(1.0, 0.95, 0.70).cgColor)
            c.fillEllipse(in: CGRect(x: ctr.x - 4, y: ctr.y - r * 0.58, width: 20, height: 12))
        }
    }

    /// Hoa cúc: nhiều vòng cánh nhỏ.
    private static func makeFlowerPom() -> UIImage {
        card(256, 256, seed: 51) { c, W, H, _ in
            let ctr = CGPoint(x: W / 2, y: H / 2)
            let rings: [(Int, CGFloat, CGFloat)] = [(26, 0.47, 0.50), (20, 0.36, 0.72), (14, 0.25, 0.88), (9, 0.14, 1.0)]
            for (count, rad, shade) in rings {
                for i in 0..<count {
                    let a = CGFloat(i) / CGFloat(count) * 2 * CGFloat.pi + rad
                    c.saveGState()
                    c.translateBy(x: ctr.x, y: ctr.y)
                    c.rotate(by: a)
                    let len = W * rad
                    let wid = W * 0.045 + rad * 14
                    c.setFillColor(UIColor(white: shade, alpha: 1).cgColor)
                    c.fillEllipse(in: CGRect(x: -wid / 2, y: -len, width: wid, height: len))
                    c.setStrokeColor(UIColor(white: shade * 0.7, alpha: 0.5).cgColor)
                    c.setLineWidth(0.8)
                    c.strokeEllipse(in: CGRect(x: -wid / 2, y: -len, width: wid, height: len))
                    c.restoreGState()
                }
            }
            c.setFillColor(col(0.98, 0.92, 0.62).cgColor)
            c.fillEllipse(in: CGRect(x: ctr.x - 10, y: ctr.y - 10, width: 20, height: 20))
        }
    }

    /// Hoa sen nhìn ngang: các cánh nhọn xòe từ đáy; màu hồng do `tint`.
    private static func makeFlowerLotus() -> UIImage {
        card(256, 320, seed: 61) { c, W, H, _ in
            let base = CGPoint(x: W / 2, y: H - 14)
            let layers: [(Int, CGFloat, CGFloat, CGFloat)] = [
                (7, 1.00, 0.70, 0.84),      // lớp sau: cao, mờ hơn
                (5, 0.84, 0.46, 0.92),
                (3, 0.62, 0.20, 1.00)       // lớp trước: ngắn, sáng
            ]
            for (count, lenK, spread, shade) in layers {
                for i in 0..<count {
                    let f = count == 1 ? 0 : CGFloat(i) / CGFloat(count - 1) - 0.5
                    let ang = f * spread * 2.6
                    c.saveGState()
                    c.translateBy(x: base.x, y: base.y)
                    c.rotate(by: ang)
                    let len = (H - 30) * lenK
                    let wid = W * 0.20
                    let p = CGMutablePath()
                    p.move(to: .zero)
                    p.addCurve(to: CGPoint(x: 0, y: -len),
                               control1: CGPoint(x: -wid * 1.5, y: -len * 0.35),
                               control2: CGPoint(x: -wid * 0.7, y: -len * 0.85))
                    p.addCurve(to: .zero,
                               control1: CGPoint(x: wid * 0.7, y: -len * 0.85),
                               control2: CGPoint(x: wid * 1.5, y: -len * 0.35))
                    c.addPath(p)
                    c.clip()
                    if let g = gradient(col(0.80, 0.82, 0.60), col(1.0 * shade, 0.97 * shade, 0.99 * shade)) {
                        c.drawLinearGradient(g, start: .zero, end: CGPoint(x: 0, y: -len), options: [])
                    }
                    c.setStrokeColor(UIColor(white: 0.5, alpha: 0.30).cgColor)
                    c.setLineWidth(1.1)
                    for k in -1...1 {
                        c.move(to: .zero)
                        c.addQuadCurve(to: CGPoint(x: CGFloat(k) * wid * 0.35, y: -len * 0.95),
                                       control: CGPoint(x: CGFloat(k) * wid * 0.7, y: -len * 0.5))
                        c.strokePath()
                    }
                    c.restoreGState()
                }
            }
            // đài sen vàng
            c.setFillColor(col(0.95, 0.85, 0.30).cgColor)
            c.fillEllipse(in: CGRect(x: base.x - 16, y: base.y - 46, width: 32, height: 26))
        }
    }

    /// Khóm lúa: nhiều lá lúa cong, lúa chín thêm các bông rủ.
    private static func makeRice(gold: Bool) -> UIImage {
        card(256, 256, seed: gold ? 72 : 71) { c, W, H, rng in
            let bladeCol = gold ? col(0.62, 0.60, 0.20) : col(0.24, 0.58, 0.14)
            for _ in 0..<18 {
                let x0 = W / 2 + rnd(-W * 0.10, W * 0.10, &rng)
                let y0 = H - 2
                let lean = rnd(-1, 1, &rng)
                let len = H * rnd(0.55, 0.95, &rng)
                let tip = CGPoint(x: x0 + lean * W * 0.40, y: y0 - len)
                let ctrl = CGPoint(x: x0 + lean * W * 0.04, y: y0 - len * 0.72)
                c.setFillColor(jitter(bladeCol, 0.07, &rng).cgColor)
                c.move(to: CGPoint(x: x0 - 3.2, y: y0))
                c.addQuadCurve(to: tip, control: CGPoint(x: ctrl.x - 2.5, y: ctrl.y))
                c.addQuadCurve(to: CGPoint(x: x0 + 3.2, y: y0), control: CGPoint(x: ctrl.x + 2.5, y: ctrl.y))
                c.closePath()
                c.fillPath()
            }
            if gold {
                // bông lúa chín rủ xuống
                for i in 0..<7 {
                    let sx = W / 2 + rnd(-W * 0.16, W * 0.16, &rng)
                    let sy = H * rnd(0.30, 0.50, &rng)
                    let dirX: CGFloat = i % 2 == 0 ? 1 : -1
                    let reach = rnd(W * 0.18, W * 0.32, &rng)
                    let start = CGPoint(x: sx, y: sy)
                    let ctrl = CGPoint(x: sx + dirX * reach * 0.4, y: sy - H * 0.16)
                    let end = CGPoint(x: sx + dirX * reach, y: sy + H * 0.06)
                    c.setStrokeColor(col(0.70, 0.62, 0.22).cgColor)
                    c.setLineWidth(1.6)
                    c.move(to: start)
                    c.addQuadCurve(to: end, control: ctrl)
                    c.strokePath()
                    var t: CGFloat = 0.30
                    while t <= 1.0 {
                        let u = 1 - t
                        let px = u * u * start.x + 2 * u * t * ctrl.x + t * t * end.x
                        let py = u * u * start.y + 2 * u * t * ctrl.y + t * t * end.y
                        c.setFillColor(jitter(col(0.94, 0.76, 0.24), 0.05, &rng).cgColor)
                        c.fillEllipse(in: CGRect(x: px - 4, y: py - 2.5, width: 8, height: 5))
                        c.fillEllipse(in: CGRect(x: px - 2 + dirX * 2, y: py + 1, width: 7, height: 4))
                        t += 0.07
                    }
                }
            }
        }
    }

    /// Một tàu lá dừa nước: gân giữa + lá chét hẹp, dài, mọc đều. Trục nằm ngang, gốc bên trái.
    private static func makeNipa() -> UIImage {
        let w = 512, h = 160
        let fmt = UIGraphicsImageRendererFormat()
        fmt.scale = 1
        fmt.opaque = false
        var rng = RNG(s: 311)
        return UIGraphicsImageRenderer(size: CGSize(width: w, height: h), format: fmt).image { ctx in
            let c = ctx.cgContext
            let W = CGFloat(w), H = CGFloat(h)
            let midY = H / 2
            c.setStrokeColor(col(0.40, 0.36, 0.16).cgColor)
            c.setLineWidth(5)
            c.move(to: CGPoint(x: 0, y: midY))
            c.addLine(to: CGPoint(x: W * 0.98, y: midY))
            c.strokePath()
            let count = 58
            for i in 0..<count {
                let t = CGFloat(i) / CGFloat(count)
                let x = 30 + t * (W - 50)
                let tc: CGFloat = min(max(t, 0.08), 0.96)
                let shape: CGFloat = 0.50 + 0.50 * sin(tc * CGFloat.pi)
                let rnd: CGFloat = CGFloat.random(in: 0.9...1.05, using: &rng)
                let len: CGFloat = H * 0.47 * shape * rnd
                let sweep: CGFloat = 26
                for dir in [CGFloat(-1), CGFloat(1)] {
                    let tip = CGPoint(x: x + sweep, y: midY + dir * len)
                    let green = jitter(col(0.14, 0.40, 0.16), 0.06, &rng)
                    c.setFillColor(green.cgColor)
                    c.move(to: CGPoint(x: x - 2, y: midY))
                    c.addQuadCurve(to: tip, control: CGPoint(x: x + sweep * 0.2, y: midY + dir * len * 0.6))
                    c.addQuadCurve(to: CGPoint(x: x + 2, y: midY),
                                   control: CGPoint(x: x + sweep * 0.2 + 6, y: midY + dir * len * 0.6))
                    c.closePath()
                    c.fillPath()
                }
            }
        }
    }

    /// Bụi cỏ (có kênh alpha): nhiều lá cỏ cong xòe từ gốc ở đáy ảnh.
    private static func makeGrassTuft() -> UIImage {
        let w = 256
        let fmt = UIGraphicsImageRendererFormat()
        fmt.scale = 1
        fmt.opaque = false
        var rng = RNG(s: 909)
        return UIGraphicsImageRenderer(size: CGSize(width: w, height: w), format: fmt).image { ctx in
            let c = ctx.cgContext
            let S = CGFloat(w)
            for _ in 0..<70 {
                let bx = S / 2 + CGFloat.random(in: -S * 0.22...S * 0.22, using: &rng)
                let h = CGFloat.random(in: S * 0.35...S * 0.95, using: &rng)
                let lean = CGFloat.random(in: -S * 0.30...S * 0.30, using: &rng)
                let wd = CGFloat.random(in: 3...7, using: &rng)
                let g = jitter(col(0.30, 0.52, 0.16), 0.10, &rng)
                let top = CGPoint(x: bx + lean, y: S - h)
                c.setFillColor(g.cgColor)
                c.move(to: CGPoint(x: bx - wd / 2, y: S))
                c.addQuadCurve(to: top, control: CGPoint(x: bx - wd / 2 + lean * 0.1, y: S - h * 0.6))
                c.addQuadCurve(to: CGPoint(x: bx + wd / 2, y: S),
                               control: CGPoint(x: bx + wd / 2 + lean * 0.35, y: S - h * 0.55))
                c.closePath()
                c.fillPath()
            }
        }
    }

    /// Lá kim thông: nền xanh thẫm phủ kín, nhiều cụm kim mảnh tỏa ra từ cành (lặp liền mạch).
    private static func makeNeedle() -> UIImage {
        render(256) { c, s, rng in
            c.setFillColor(col(0.05, 0.16, 0.08).cgColor)
            c.fill(CGRect(x: 0, y: 0, width: s, height: s))
            c.setLineCap(.round)
            for _ in 0..<2600 {
                let x = CGFloat.random(in: 0..<s, using: &rng)
                let y = CGFloat.random(in: 0..<s, using: &rng)
                let ang = CGFloat.random(in: 0..<(2 * CGFloat.pi), using: &rng)
                let len = CGFloat.random(in: 9...20, using: &rng)
                let g = jitter(col(0.12, 0.34, 0.16), 0.08, &rng)
                c.setStrokeColor(g.cgColor)
                c.setLineWidth(CGFloat.random(in: 0.7...1.3, using: &rng))
                for ox in [-s, 0, s] {
                    for oy in [-s, 0, s] {
                        let px = x + ox, py = y + oy
                        if px < -len || px > s + len || py < -len || py > s + len { continue }
                        c.move(to: CGPoint(x: px, y: py))
                        c.addLine(to: CGPoint(x: px + cos(ang) * len, y: py + sin(ang) * len))
                        c.strokePath()
                    }
                }
            }
        }
    }

    // MARK: - Tạo bản đồ pháp tuyến từ ảnh (độ sáng → độ cao)

    private static func toByte(_ v: Float) -> UInt8 {
        let x: Float = (v * 0.5 + 0.5) * 255
        let c: Float = x < 0 ? 0 : (x > 255 ? 255 : x)
        return UInt8(c)
    }

    static func normalMap(from image: UIImage, strength: CGFloat) -> UIImage {
        guard let cg = image.cgImage else { return image }
        let w = cg.width, h = cg.height
        var gray = [Float](repeating: 0, count: w * h)
        var raw = [UInt8](repeating: 0, count: w * h * 4)
        let cs = CGColorSpaceCreateDeviceRGB()
        var drawn = false
        raw.withUnsafeMutableBytes { buf in
            guard let ctx = CGContext(data: buf.baseAddress, width: w, height: h, bitsPerComponent: 8,
                                      bytesPerRow: w * 4, space: cs,
                                      bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return }
            ctx.draw(cg, in: CGRect(x: 0, y: 0, width: w, height: h))
            drawn = true
        }
        if !drawn { return image }
        for i in 0..<(w * h) {
            let r = Float(raw[i * 4]), g = Float(raw[i * 4 + 1]), b = Float(raw[i * 4 + 2])
            gray[i] = (0.299 * r + 0.587 * g + 0.114 * b) / 255
        }
        var out = [UInt8](repeating: 255, count: w * h * 4)
        let k = Float(strength)
        for y in 0..<h {
            for x in 0..<w {
                let xl = gray[y * w + (x + w - 1) % w], xr = gray[y * w + (x + 1) % w]
                let yu = gray[((y + h - 1) % h) * w + x], yd = gray[((y + 1) % h) * w + x]
                var nx = (xl - xr) * k
                var ny = (yu - yd) * k
                var nz: Float = 1
                let len = (nx * nx + ny * ny + nz * nz).squareRoot()
                nx /= len; ny /= len; nz /= len
                let o = (y * w + x) * 4
                out[o] = toByte(nx)
                out[o + 1] = toByte(ny)
                out[o + 2] = toByte(nz)
                out[o + 3] = 255
            }
        }
        guard let provider = CGDataProvider(data: Data(out) as CFData),
              let res = CGImage(width: w, height: h, bitsPerComponent: 8, bitsPerPixel: 32,
                                bytesPerRow: w * 4, space: cs,
                                bitmapInfo: CGBitmapInfo(rawValue: CGImageAlphaInfo.premultipliedLast.rawValue),
                                provider: provider, decode: nil, shouldInterpolate: true,
                                intent: .defaultIntent) else { return image }
        return UIImage(cgImage: res)
    }
}
