import SceneKit
import UIKit

// MARK: - Thư viện texture chân thực
//
// Mỗi vật liệu có 2 lớp ảnh: màu (albedo) và bản đồ pháp tuyến (normal) để tạo độ nổi.
// Thứ tự ưu tiên:
//   1. Nếu bạn thêm ảnh thật vào thư mục Sources/Textures (ví dụ "wood.jpg", "thatch.jpg"...),
//      app dùng ngay ảnh đó.
//   2. Nếu không có, app tự vẽ texture mô phỏng thật bằng code.
//
// Tên file ảnh thật được hỗ trợ (jpg hoặc png):
//   grass, dirt, asphalt, concrete, wood, woodDark, thatch, tole, brick, roofTile,
//   plaster, palmBark, water

enum Tex: CaseIterable {
    case grass, dirt, asphalt, concrete, wood, woodDark, woodPaint, thatch, tole, brick
    case roofTile, plaster, palmBark, water, bamboo, leafMask, frondMask, nipaMask, grassTuft, needle

    var key: String {
        switch self {
        case .grass: return "grass"
        case .dirt: return "dirt"
        case .asphalt: return "asphalt"
        case .concrete: return "concrete"
        case .wood: return "wood"
        case .woodDark: return "woodDark"
        case .woodPaint: return "woodPaint"
        case .thatch: return "thatch"
        case .tole: return "tole"
        case .brick: return "brick"
        case .roofTile: return "roofTile"
        case .plaster: return "plaster"
        case .palmBark: return "palmBark"
        case .water: return "water"
        case .bamboo: return "bamboo"
        case .leafMask: return "leafMask"
        case .frondMask: return "frondMask"
        case .nipaMask: return "nipaMask"
        case .grassTuft: return "grassTuft"
        case .needle: return "needle"
        }
    }
}

enum TextureLibrary {
    private static var albedoCache: [String: UIImage] = [:]
    private static var normalCache: [String: UIImage] = [:]

    // MARK: Truy cập

    private static let lock = NSLock()

    static func albedo(_ t: Tex) -> UIImage {
        lock.lock()
        let cached = albedoCache[t.key]
        lock.unlock()
        if let c = cached { return c }
        let img = UIImage(named: t.key) ?? UIImage(named: t.key + ".jpg") ?? make(t)
        lock.lock()
        albedoCache[t.key] = img
        lock.unlock()
        return img
    }

    static func normal(_ t: Tex) -> UIImage? {
        switch t {
        case .leafMask, .frondMask, .nipaMask, .grassTuft, .needle: return nil
        default: break
        }
        lock.lock()
        let cached = normalCache[t.key]
        lock.unlock()
        if let c = cached { return c }
        let n = normalMap(from: albedo(t), strength: strength(t))
        lock.lock()
        normalCache[t.key] = n
        lock.unlock()
        return n
    }

    /// Vẽ sẵn toàn bộ texture ở luồng nền để lúc mở app không bị khựng.
    static func preload(completion: @escaping () -> Void) {
        DispatchQueue.global(qos: .userInitiated).async {
            for t in Tex.allCases {
                _ = albedo(t)
                _ = normal(t)
            }
            DispatchQueue.main.async(execute: completion)
        }
    }

    private static func strength(_ t: Tex) -> CGFloat {
        switch t {
        case .tole: return 5
        case .thatch: return 4
        case .brick, .roofTile: return 4
        case .wood, .woodDark, .woodPaint, .palmBark, .bamboo: return 3
        case .asphalt, .concrete, .dirt: return 2.5
        case .grass: return 2
        default: return 2
        }
    }

    // MARK: Vật liệu PBR hoàn chỉnh

    private static var matCache: [String: SCNMaterial] = [:]

    /// Vật liệu PBR có texture (được dùng chung giữa các vật thể giống nhau).
    /// `repeatX/Y` = số lần lặp ảnh. `swapUV` = đổi chiều vân (ví dụ cho mái nhà dốc,
    /// để hàng lá chạy dọc theo nóc).
    static func material(_ t: Tex, tint: UIColor? = nil, roughness: CGFloat = 0.85,
                         metalness: CGFloat = 0, repeatX: Float = 1, repeatY: Float = 1,
                         swapUV: Bool = false) -> SCNMaterial {
        let key = "\(t.key)|\(tint?.description ?? "-")|\(roughness)|\(metalness)|\(repeatX)|\(repeatY)|\(swapUV)"
        if let c = matCache[key] { return c }

        let m = SCNMaterial()
        m.lightingModel = .physicallyBased
        m.diffuse.contents = albedo(t)
        m.roughness.contents = roughness
        m.metalness.contents = metalness
        if let n = normal(t) {
            m.normal.contents = n
            m.normal.intensity = 1.0
        }
        var tr = SCNMatrix4MakeScale(repeatX, repeatY, 1)
        if swapUV {
            tr = SCNMatrix4Identity
            tr.m11 = 0
            tr.m22 = 0
            tr.m21 = repeatX
            tr.m12 = repeatY
        }
        for p in [m.diffuse, m.normal] {
            p.wrapS = .repeat
            p.wrapT = .repeat
            p.mipFilter = .linear
            p.contentsTransform = tr
        }
        // nhân màu: giữ vân ảnh, đổi tông màu (để nút "Màu" vẫn hoạt động)
        if let tint = tint { m.multiply.contents = tint }
        matCache[key] = m
        return m
    }

    /// Vật liệu lá: ảnh có kênh alpha, hai mặt, cắt bỏ phần nền trong suốt.
    static func foliageMaterial(_ t: Tex, tint: UIColor? = nil,
                                repeatX: Float = 1, repeatY: Float = 1) -> SCNMaterial {
        let key = "F|\(t.key)|\(tint?.description ?? "-")|\(repeatX)|\(repeatY)"
        if let c = matCache[key] { return c }

        let m = SCNMaterial()
        m.lightingModel = .blinn
        m.diffuse.contents = albedo(t)
        m.specular.contents = UIColor(white: 0.12, alpha: 1)
        m.shininess = 0.15
        m.isDoubleSided = true
        m.diffuse.wrapS = .repeat
        m.diffuse.wrapT = .repeat
        m.diffuse.mipFilter = .linear
        m.diffuse.contentsTransform = SCNMatrix4MakeScale(repeatX, repeatY, 1)
        if let tint = tint { m.multiply.contents = tint }
        // Cắt nền trong suốt (không cần sắp xếp độ sâu, không viền trắng)
        m.shaderModifiers = [.fragment: "if (_output.color.a < 0.5) { discard_fragment(); }\n_output.color.a = 1.0;"]
        matCache[key] = m
        return m
    }

    // MARK: - Sinh ảnh bằng code

    private struct RNG: RandomNumberGenerator {
        var s: UInt64
        mutating func next() -> UInt64 {
            s = s &* 6364136223846793005 &+ 1442695040888963407
            return s
        }
    }

    private static func render(_ size: Int, opaque: Bool = true,
                               _ draw: (CGContext, CGFloat, inout RNG) -> Void) -> UIImage {
        let sz = CGSize(width: size, height: size)
        let fmt = UIGraphicsImageRendererFormat()
        fmt.scale = 1
        fmt.opaque = opaque
        var rng = RNG(s: 0x9E3779B97F4A7C15 &+ UInt64(size))
        return UIGraphicsImageRenderer(size: sz, format: fmt).image { ctx in
            draw(ctx.cgContext, CGFloat(size), &rng)
        }
    }

    private static func col(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat, _ a: CGFloat = 1) -> UIColor {
        UIColor(red: r, green: g, blue: b, alpha: a)
    }

    private static func jitter(_ c: UIColor, _ amt: CGFloat, _ rng: inout RNG) -> UIColor {
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        c.getRed(&r, green: &g, blue: &b, alpha: &a)
        let d = CGFloat.random(in: -amt...amt, using: &rng)
        return UIColor(red: min(max(r + d, 0), 1), green: min(max(g + d, 0), 1),
                       blue: min(max(b + d, 0), 1), alpha: a)
    }

    /// Hạt nhiễu mịn phủ lên toàn ảnh (tạo cảm giác bề mặt thật, không phẳng).
    private static func grain(_ c: CGContext, _ s: CGFloat, count: Int, alpha: CGFloat,
                              _ rng: inout RNG) {
        for _ in 0..<count {
            let x = CGFloat.random(in: 0..<s, using: &rng)
            let y = CGFloat.random(in: 0..<s, using: &rng)
            let w = CGFloat.random(in: 1...3, using: &rng)
            let v = CGFloat.random(in: 0...1, using: &rng)
            c.setFillColor(UIColor(white: v, alpha: alpha).cgColor)
            c.fill(CGRect(x: x, y: y, width: w, height: w))
        }
    }

    /// Vẽ lặp liền mạch: mỗi nét vẽ gần mép được vẽ thêm bản sao phía đối diện.
    private static func tiled(_ s: CGFloat, _ rect: CGRect, _ body: (CGRect) -> Void) {
        for ox in [-s, 0, s] {
            for oy in [-s, 0, s] {
                let r = rect.offsetBy(dx: ox, dy: oy)
                if r.maxX < 0 || r.minX > s || r.maxY < 0 || r.minY > s { continue }
                body(r)
            }
        }
    }

    private static func make(_ t: Tex) -> UIImage {
        switch t {
        case .grass: return makeGrass()
        case .dirt: return makeDirt()
        case .asphalt: return makeAsphalt()
        case .concrete: return makeConcrete()
        case .wood: return makeWood(base: col(0.62, 0.46, 0.29))
        case .woodDark: return makeWood(base: col(0.30, 0.20, 0.12))
        case .woodPaint: return makeWood(base: col(0.88, 0.86, 0.82))
        case .thatch: return makeThatch()
        case .tole: return makeTole()
        case .brick: return makeBrick()
        case .roofTile: return makeRoofTile()
        case .plaster: return makePlaster()
        case .palmBark: return makePalmBark()
        case .water: return makeWater()
        case .bamboo: return makeBamboo()
        case .leafMask: return makeLeafCluster()
        case .frondMask: return makeFrond()
        case .nipaMask: return makeNipa()
        case .grassTuft: return makeGrassTuft()
        case .needle: return makeNeedle()
        }
    }

    // Cỏ: nền xanh lốm đốm + hàng nghìn ngọn cỏ nhỏ nhiều sắc xanh
    private static func makeGrass() -> UIImage {
        render(512) { c, s, rng in
            c.setFillColor(col(0.30, 0.45, 0.16).cgColor)
            c.fill(CGRect(x: 0, y: 0, width: s, height: s))
            // mảng màu lớn
            for _ in 0..<60 {
                let r = CGFloat.random(in: 30...90, using: &rng)
                let x = CGFloat.random(in: 0..<s, using: &rng)
                let y = CGFloat.random(in: 0..<s, using: &rng)
                let base = Bool.random(using: &rng) ? col(0.36, 0.52, 0.18) : col(0.24, 0.38, 0.13)
                c.setFillColor(base.withAlphaComponent(0.35).cgColor)
                tiled(s, CGRect(x: x - r, y: y - r, width: r * 2, height: r * 2)) { c.fillEllipse(in: $0) }
            }
            // ngọn cỏ
            let greens = [col(0.20, 0.36, 0.10), col(0.33, 0.52, 0.17), col(0.45, 0.62, 0.22),
                          col(0.52, 0.55, 0.20), col(0.16, 0.30, 0.10)]
            for _ in 0..<9000 {
                let x = CGFloat.random(in: 0..<s, using: &rng)
                let y = CGFloat.random(in: 0..<s, using: &rng)
                let h = CGFloat.random(in: 5...14, using: &rng)
                let lean = CGFloat.random(in: -4...4, using: &rng)
                c.setStrokeColor(greens.randomElement(using: &rng)!.cgColor)
                c.setLineWidth(CGFloat.random(in: 0.8...1.8, using: &rng))
                c.move(to: CGPoint(x: x, y: y))
                c.addLine(to: CGPoint(x: x + lean, y: y - h))
                c.strokePath()
            }
        }
    }

    // Đất: nâu, sỏi nhỏ, vệt khô
    private static func makeDirt() -> UIImage {
        render(512) { c, s, rng in
            c.setFillColor(col(0.45, 0.33, 0.21).cgColor)
            c.fill(CGRect(x: 0, y: 0, width: s, height: s))
            for _ in 0..<120 {
                let r = CGFloat.random(in: 15...70, using: &rng)
                let x = CGFloat.random(in: 0..<s, using: &rng)
                let y = CGFloat.random(in: 0..<s, using: &rng)
                c.setFillColor(jitter(col(0.46, 0.33, 0.20), 0.08, &rng).withAlphaComponent(0.4).cgColor)
                tiled(s, CGRect(x: x - r, y: y - r, width: r * 2, height: r * 1.4)) { c.fillEllipse(in: $0) }
            }
            for _ in 0..<1400 {
                let x = CGFloat.random(in: 0..<s, using: &rng)
                let y = CGFloat.random(in: 0..<s, using: &rng)
                let r = CGFloat.random(in: 1.5...5, using: &rng)
                c.setFillColor(jitter(col(0.55, 0.47, 0.36), 0.12, &rng).cgColor)
                c.fillEllipse(in: CGRect(x: x, y: y, width: r, height: r * 0.8))
            }
            grain(c, s, count: 9000, alpha: 0.10, &rng)
        }
    }

    // Nhựa đường: xám than, hạt đá, vết rạn
    private static func makeAsphalt() -> UIImage {
        render(512) { c, s, rng in
            c.setFillColor(col(0.20, 0.20, 0.21).cgColor)
            c.fill(CGRect(x: 0, y: 0, width: s, height: s))
            for _ in 0..<40 {
                let r = CGFloat.random(in: 30...100, using: &rng)
                let x = CGFloat.random(in: 0..<s, using: &rng)
                let y = CGFloat.random(in: 0..<s, using: &rng)
                c.setFillColor(UIColor(white: CGFloat.random(in: 0.15...0.28, using: &rng), alpha: 0.35).cgColor)
                tiled(s, CGRect(x: x - r, y: y - r, width: r * 2, height: r * 2)) { c.fillEllipse(in: $0) }
            }
            grain(c, s, count: 26000, alpha: 0.22, &rng)
            // vết nứt
            c.setStrokeColor(UIColor(white: 0.08, alpha: 0.8).cgColor)
            c.setLineWidth(1.2)
            for _ in 0..<4 {
                var p = CGPoint(x: CGFloat.random(in: 0..<s, using: &rng), y: CGFloat.random(in: 0..<s, using: &rng))
                c.move(to: p)
                for _ in 0..<12 {
                    p.x += CGFloat.random(in: -14...14, using: &rng)
                    p.y += CGFloat.random(in: 4...16, using: &rng)
                    c.addLine(to: p)
                }
                c.strokePath()
            }
        }
    }

    // Bê tông: xám sáng, lỗ khí, ố loang
    private static func makeConcrete() -> UIImage {
        render(512) { c, s, rng in
            c.setFillColor(col(0.66, 0.65, 0.62).cgColor)
            c.fill(CGRect(x: 0, y: 0, width: s, height: s))
            for _ in 0..<70 {
                let r = CGFloat.random(in: 25...90, using: &rng)
                let x = CGFloat.random(in: 0..<s, using: &rng)
                let y = CGFloat.random(in: 0..<s, using: &rng)
                let v = CGFloat.random(in: 0.5...0.78, using: &rng)
                c.setFillColor(UIColor(white: v, alpha: 0.3).cgColor)
                tiled(s, CGRect(x: x - r, y: y - r, width: r * 2, height: r * 2)) { c.fillEllipse(in: $0) }
            }
            grain(c, s, count: 18000, alpha: 0.18, &rng)
            for _ in 0..<160 {
                let x = CGFloat.random(in: 0..<s, using: &rng)
                let y = CGFloat.random(in: 0..<s, using: &rng)
                let r = CGFloat.random(in: 1...3, using: &rng)
                c.setFillColor(UIColor(white: 0.32, alpha: 0.7).cgColor)
                c.fillEllipse(in: CGRect(x: x, y: y, width: r, height: r))
            }
            // khe co giãn
            c.setStrokeColor(UIColor(white: 0.35, alpha: 0.9).cgColor)
            c.setLineWidth(2)
            c.move(to: CGPoint(x: 0, y: s / 2)); c.addLine(to: CGPoint(x: s, y: s / 2))
            c.move(to: CGPoint(x: s / 2, y: 0)); c.addLine(to: CGPoint(x: s / 2, y: s))
            c.strokePath()
        }
    }

    // Ván gỗ: các tấm ván dọc, thớ gỗ, mắt gỗ, khe giữa các tấm
    private static func makeWood(base: UIColor) -> UIImage {
        render(512) { c, s, rng in
            let boards = 6
            let bw = s / CGFloat(boards)
            for b in 0..<boards {
                let x0 = CGFloat(b) * bw
                c.setFillColor(jitter(base, 0.07, &rng).cgColor)
                c.fill(CGRect(x: x0, y: 0, width: bw, height: s))
                // thớ gỗ
                for _ in 0..<110 {
                    let x = x0 + CGFloat.random(in: 2..<(bw - 2), using: &rng)
                    let w = CGFloat.random(in: 0.5...1.6, using: &rng)
                    let v = CGFloat.random(in: -0.10...0.07, using: &rng)
                    var r: CGFloat = 0, g: CGFloat = 0, bl: CGFloat = 0, a: CGFloat = 0
                    base.getRed(&r, green: &g, blue: &bl, alpha: &a)
                    c.setStrokeColor(UIColor(red: r + v, green: g + v, blue: bl + v, alpha: 0.6).cgColor)
                    c.setLineWidth(w)
                    c.move(to: CGPoint(x: x, y: 0))
                    c.addCurve(to: CGPoint(x: x + CGFloat.random(in: -3...3, using: &rng), y: s),
                               control1: CGPoint(x: x + CGFloat.random(in: -4...4, using: &rng), y: s * 0.33),
                               control2: CGPoint(x: x + CGFloat.random(in: -4...4, using: &rng), y: s * 0.66))
                    c.strokePath()
                }
                // mắt gỗ
                if Int.random(in: 0..<3, using: &rng) == 0 {
                    let kx = x0 + CGFloat.random(in: 12..<(bw - 12), using: &rng)
                    let ky = CGFloat.random(in: 40..<(s - 40), using: &rng)
                    for ring in 0..<4 {
                        let rr = CGFloat(ring) * 2.5 + 3
                        c.setStrokeColor(col(0.20, 0.12, 0.06, 0.55).cgColor)
                        c.setLineWidth(1)
                        c.strokeEllipse(in: CGRect(x: kx - rr, y: ky - rr * 1.6, width: rr * 2, height: rr * 3.2))
                    }
                }
                // khe giữa ván
                c.setFillColor(col(0.05, 0.03, 0.02, 0.85).cgColor)
                c.fill(CGRect(x: x0, y: 0, width: 2, height: s))
            }
            // đinh / mối nối ngang
            c.setFillColor(col(0.05, 0.03, 0.02, 0.6).cgColor)
            c.fill(CGRect(x: 0, y: s * 0.5, width: s, height: 1.5))
            grain(c, s, count: 5000, alpha: 0.07, &rng)
        }
    }

    // Mái lá dừa nước: nhiều lớp lá xếp so le, sợi lá, màu rơm vàng nâu
    private static func makeThatch() -> UIImage {
        render(512) { c, s, rng in
            c.setFillColor(col(0.46, 0.36, 0.18).cgColor)
            c.fill(CGRect(x: 0, y: 0, width: s, height: s))
            let rows = 12
            let rh = s / CGFloat(rows)
            let palette = [col(0.66, 0.54, 0.28), col(0.58, 0.46, 0.22), col(0.72, 0.60, 0.33),
                           col(0.50, 0.40, 0.19), col(0.62, 0.50, 0.26), col(0.42, 0.34, 0.16)]
            for r in 0..<rows {
                let y0 = CGFloat(r) * rh
                // dải lá rủ xuống, đầu nhọn
                var x: CGFloat = -10
                while x < s + 10 {
                    let w = CGFloat.random(in: 14...30, using: &rng)
                    let c0 = palette.randomElement(using: &rng)!
                    c.setFillColor(c0.cgColor)
                    c.move(to: CGPoint(x: x, y: y0))
                    c.addLine(to: CGPoint(x: x + w, y: y0))
                    c.addLine(to: CGPoint(x: x + w * 0.5 + CGFloat.random(in: -3...3, using: &rng), y: y0 + rh * 1.6))
                    c.closePath()
                    c.fillPath()
                    // sợi lá
                    c.setStrokeColor(UIColor(white: 0, alpha: 0.18).cgColor)
                    c.setLineWidth(0.8)
                    for i in 0..<4 {
                        let fx = x + w * (0.2 + 0.2 * CGFloat(i))
                        c.move(to: CGPoint(x: fx, y: y0))
                        c.addLine(to: CGPoint(x: x + w * 0.5, y: y0 + rh * 1.5))
                    }
                    c.strokePath()
                    x += w * CGFloat.random(in: 0.6...0.9, using: &rng)
                }
                // bóng đổ dưới mỗi hàng lá
                c.setFillColor(UIColor(white: 0, alpha: 0.28).cgColor)
                c.fill(CGRect(x: 0, y: y0 + rh * 1.0, width: s, height: 3))
            }
            grain(c, s, count: 9000, alpha: 0.10, &rng)
        }
    }

    // Tôn múi: sóng dọc, gỉ sét loang, đinh vít
    private static func makeTole() -> UIImage {
        render(512) { c, s, rng in
            let ribs = 12
            let rw = s / CGFloat(ribs)
            for i in 0..<ribs {
                let x0 = CGFloat(i) * rw
                let grad = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(),
                                      colors: [col(0.45, 0.48, 0.50).cgColor, col(0.82, 0.85, 0.87).cgColor,
                                               col(0.50, 0.53, 0.55).cgColor] as CFArray,
                                      locations: [0, 0.5, 1])!
                c.saveGState()
                c.clip(to: CGRect(x: x0, y: 0, width: rw, height: s))
                c.drawLinearGradient(grad, start: CGPoint(x: x0, y: 0), end: CGPoint(x: x0 + rw, y: 0), options: [])
                c.restoreGState()
            }
            // gỉ sét
            for _ in 0..<70 {
                let x = CGFloat.random(in: 0..<s, using: &rng)
                let y = CGFloat.random(in: 0..<s, using: &rng)
                let r = CGFloat.random(in: 6...34, using: &rng)
                c.setFillColor(col(0.48, 0.24, 0.10, CGFloat.random(in: 0.10...0.35, using: &rng)).cgColor)
                c.fillEllipse(in: CGRect(x: x, y: y, width: r * 0.6, height: r * 1.8))
            }
            // vệt nước chảy
            for _ in 0..<40 {
                let x = CGFloat.random(in: 0..<s, using: &rng)
                let y = CGFloat.random(in: 0..<(s * 0.7), using: &rng)
                c.setStrokeColor(col(0.40, 0.22, 0.12, 0.28).cgColor)
                c.setLineWidth(CGFloat.random(in: 1...3, using: &rng))
                c.move(to: CGPoint(x: x, y: y))
                c.addLine(to: CGPoint(x: x + CGFloat.random(in: -2...2, using: &rng),
                                      y: y + CGFloat.random(in: 40...180, using: &rng)))
                c.strokePath()
            }
            // đinh vít
            for row in [CGFloat(40), s - 40] {
                for i in 0..<ribs where i % 2 == 0 {
                    let x = CGFloat(i) * rw + rw / 2
                    c.setFillColor(UIColor(white: 0.25, alpha: 1).cgColor)
                    c.fillEllipse(in: CGRect(x: x - 3, y: row - 3, width: 6, height: 6))
                }
            }
            grain(c, s, count: 8000, alpha: 0.09, &rng)
        }
    }

    // Gạch đỏ: hàng gạch xây so le, vữa xám
    private static func makeBrick() -> UIImage {
        render(512) { c, s, rng in
            c.setFillColor(col(0.62, 0.60, 0.55).cgColor)   // vữa
            c.fill(CGRect(x: 0, y: 0, width: s, height: s))
            let rows = 16
            let bh = s / CGFloat(rows)
            let bw = s / 6
            for r in 0..<rows {
                let off: CGFloat = r % 2 == 0 ? 0 : -bw / 2
                for i in 0...6 {
                    let x = CGFloat(i) * bw + off
                    let color = jitter(col(0.60, 0.27, 0.19), 0.07, &rng)
                    c.setFillColor(color.cgColor)
                    c.fill(CGRect(x: x + 2, y: CGFloat(r) * bh + 2, width: bw - 4, height: bh - 4))
                    // rêu / ố
                    if Int.random(in: 0..<6, using: &rng) == 0 {
                        c.setFillColor(col(0.25, 0.32, 0.18, 0.28).cgColor)
                        c.fill(CGRect(x: x + 2, y: CGFloat(r) * bh + bh * 0.5, width: bw - 4, height: bh * 0.5 - 2))
                    }
                }
            }
            grain(c, s, count: 14000, alpha: 0.12, &rng)
        }
    }

    // Ngói đỏ: hàng ngói âm dương bo tròn
    private static func makeRoofTile() -> UIImage {
        render(512) { c, s, rng in
            c.setFillColor(col(0.25, 0.10, 0.07).cgColor)
            c.fill(CGRect(x: 0, y: 0, width: s, height: s))
            let cols = 12
            let rows = 10
            let tw = s / CGFloat(cols)
            let th = s / CGFloat(rows)
            for r in 0..<rows {
                for i in 0..<cols {
                    let off: CGFloat = r % 2 == 0 ? 0 : tw / 2
                    let x = CGFloat(i) * tw + off - tw / 2
                    let y = CGFloat(r) * th
                    let base = jitter(col(0.66, 0.28, 0.16), 0.07, &rng)
                    let grad = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(),
                                          colors: [base.withAlphaComponent(1).cgColor,
                                                   jitter(base, 0.10, &rng).cgColor,
                                                   base.withAlphaComponent(1).cgColor] as CFArray,
                                          locations: [0, 0.5, 1])!
                    c.saveGState()
                    let rect = CGRect(x: x + 1, y: y, width: tw - 2, height: th * 1.35)
                    c.addPath(UIBezierPath(roundedRect: rect, byRoundingCorners: [.bottomLeft, .bottomRight],
                                           cornerRadii: CGSize(width: tw / 2, height: th * 0.5)).cgPath)
                    c.clip()
                    c.drawLinearGradient(grad, start: CGPoint(x: x, y: y), end: CGPoint(x: x + tw, y: y), options: [])
                    c.restoreGState()
                    // bóng dưới mép ngói
                    c.setFillColor(UIColor(white: 0, alpha: 0.28).cgColor)
                    c.fill(CGRect(x: x + 2, y: y + th * 1.0, width: tw - 4, height: 2.5))
                    if Int.random(in: 0..<8, using: &rng) == 0 {
                        c.setFillColor(col(0.20, 0.30, 0.15, 0.25).cgColor)   // rêu
                        c.fill(CGRect(x: x + 2, y: y + th * 0.4, width: tw - 4, height: th * 0.6))
                    }
                }
            }
            grain(c, s, count: 9000, alpha: 0.10, &rng)
        }
    }

    // Vữa tô tường: màu kem, hơi lốm đốm, vết ố
    private static func makePlaster() -> UIImage {
        render(512) { c, s, rng in
            c.setFillColor(col(0.88, 0.86, 0.80).cgColor)
            c.fill(CGRect(x: 0, y: 0, width: s, height: s))
            for _ in 0..<80 {
                let r = CGFloat.random(in: 20...80, using: &rng)
                let x = CGFloat.random(in: 0..<s, using: &rng)
                let y = CGFloat.random(in: 0..<s, using: &rng)
                c.setFillColor(UIColor(white: CGFloat.random(in: 0.6...0.95, using: &rng), alpha: 0.18).cgColor)
                tiled(s, CGRect(x: x - r, y: y - r, width: r * 2, height: r * 2)) { c.fillEllipse(in: $0) }
            }
            // vệt nước mưa
            for _ in 0..<26 {
                let x = CGFloat.random(in: 0..<s, using: &rng)
                c.setStrokeColor(col(0.45, 0.42, 0.34, 0.12).cgColor)
                c.setLineWidth(CGFloat.random(in: 2...8, using: &rng))
                c.move(to: CGPoint(x: x, y: 0))
                c.addLine(to: CGPoint(x: x + CGFloat.random(in: -6...6, using: &rng),
                                      y: CGFloat.random(in: 80...s, using: &rng)))
                c.strokePath()
            }
            grain(c, s, count: 22000, alpha: 0.12, &rng)
        }
    }

    // Vỏ thân dừa: các vòng ngang đậm, sợi dọc xám nâu
    private static func makePalmBark() -> UIImage {
        render(512) { c, s, rng in
            c.setFillColor(col(0.46, 0.38, 0.30).cgColor)
            c.fill(CGRect(x: 0, y: 0, width: s, height: s))
            // sợi dọc
            for _ in 0..<420 {
                let x = CGFloat.random(in: 0..<s, using: &rng)
                let v = CGFloat.random(in: -0.12...0.10, using: &rng)
                c.setStrokeColor(UIColor(red: 0.46 + v, green: 0.38 + v, blue: 0.30 + v, alpha: 0.7).cgColor)
                c.setLineWidth(CGFloat.random(in: 0.6...2, using: &rng))
                c.move(to: CGPoint(x: x, y: 0))
                c.addLine(to: CGPoint(x: x + CGFloat.random(in: -2...2, using: &rng), y: s))
                c.strokePath()
            }
            // vòng ngang (sẹo cuống lá)
            let rings = 22
            for i in 0..<rings {
                let y = CGFloat(i) * s / CGFloat(rings) + CGFloat.random(in: -2...2, using: &rng)
                c.setStrokeColor(col(0.18, 0.13, 0.09, 0.75).cgColor)
                c.setLineWidth(CGFloat.random(in: 2.5...4.5, using: &rng))
                c.move(to: CGPoint(x: 0, y: y))
                var x: CGFloat = 0
                while x < s {
                    x += 16
                    c.addLine(to: CGPoint(x: x, y: y + CGFloat.random(in: -2...2, using: &rng)))
                }
                c.strokePath()
                c.setStrokeColor(col(0.66, 0.58, 0.46, 0.45).cgColor)
                c.setLineWidth(1.2)
                c.move(to: CGPoint(x: 0, y: y + 4))
                c.addLine(to: CGPoint(x: s, y: y + 4))
                c.strokePath()
            }
            grain(c, s, count: 9000, alpha: 0.10, &rng)
        }
    }

    // Nước kênh: xanh đục phù sa, gợn sóng mềm
    private static func makeWater() -> UIImage {
        render(512) { c, s, rng in
            let grad = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(),
                                  colors: [col(0.28, 0.38, 0.30).cgColor, col(0.34, 0.46, 0.38).cgColor] as CFArray,
                                  locations: [0, 1])!
            c.drawLinearGradient(grad, start: .zero, end: CGPoint(x: s, y: s), options: [])
            for _ in 0..<260 {
                let x = CGFloat.random(in: 0..<s, using: &rng)
                let y = CGFloat.random(in: 0..<s, using: &rng)
                let w = CGFloat.random(in: 20...90, using: &rng)
                c.setStrokeColor(UIColor(white: 1, alpha: CGFloat.random(in: 0.04...0.16, using: &rng)).cgColor)
                c.setLineWidth(CGFloat.random(in: 1...2.5, using: &rng))
                tiled(s, CGRect(x: x, y: y - 4, width: w, height: 8)) { r in
                    c.move(to: CGPoint(x: r.minX, y: r.midY))
                    c.addQuadCurve(to: CGPoint(x: r.maxX, y: r.midY), control: CGPoint(x: r.midX, y: r.midY - 4))
                    c.strokePath()
                }
            }
            grain(c, s, count: 6000, alpha: 0.05, &rng)
        }
    }

    // Tre: đốt tre, sợi dọc vàng xanh
    private static func makeBamboo() -> UIImage {
        render(256) { c, s, rng in
            c.setFillColor(col(0.70, 0.60, 0.30).cgColor)
            c.fill(CGRect(x: 0, y: 0, width: s, height: s))
            for _ in 0..<160 {
                let x = CGFloat.random(in: 0..<s, using: &rng)
                let v = CGFloat.random(in: -0.10...0.08, using: &rng)
                c.setStrokeColor(UIColor(red: 0.70 + v, green: 0.60 + v, blue: 0.30 + v, alpha: 0.7).cgColor)
                c.setLineWidth(CGFloat.random(in: 0.6...1.8, using: &rng))
                c.move(to: CGPoint(x: x, y: 0))
                c.addLine(to: CGPoint(x: x, y: s))
                c.strokePath()
            }
            for y in [s * 0.18, s * 0.62] {
                c.setFillColor(col(0.38, 0.30, 0.12, 0.85).cgColor)
                c.fill(CGRect(x: 0, y: y, width: s, height: 5))
            }
            grain(c, s, count: 2000, alpha: 0.08, &rng)
        }
    }

    // MARK: Ảnh lá có kênh alpha (nền trong suốt)

    /// Một tàu lá dừa (lá kép lông chim): gân giữa + hàng lá chét hai bên, đầu nhọn.
    /// Trục lá nằm ngang, gốc ở bên trái.
    private static func makeFrond() -> UIImage {
        let w = 512, h = 256
        let fmt = UIGraphicsImageRendererFormat()
        fmt.scale = 1
        fmt.opaque = false
        var rng = RNG(s: 77)
        return UIGraphicsImageRenderer(size: CGSize(width: w, height: h), format: fmt).image { ctx in
            let c = ctx.cgContext
            let W = CGFloat(w), H = CGFloat(h)
            let midY = H / 2
            // gân giữa
            c.setStrokeColor(col(0.45, 0.38, 0.18).cgColor)
            c.setLineWidth(5)
            c.move(to: CGPoint(x: 0, y: midY))
            c.addLine(to: CGPoint(x: W * 0.97, y: midY))
            c.strokePath()

            let count = 54
            for i in 0..<count {
                let t = CGFloat(i) / CGFloat(count)
                let x = 14 + t * (W - 40)
                // lá chét dài ở giữa, ngắn dần về hai đầu
                let tc: CGFloat = min(max(t, 0.05), 0.95)
                let shape: CGFloat = 0.35 + 0.65 * sin(tc * CGFloat.pi)
                let rnd: CGFloat = CGFloat.random(in: 0.88...1.05, using: &rng)
                let len: CGFloat = H * 0.46 * shape * rnd
                let sweep = 30 + 40 * t   // lá chét xuôi về phía đầu tàu lá
                for dir in [CGFloat(-1), CGFloat(1)] {
                    let tip = CGPoint(x: x + sweep, y: midY + dir * len)
                    let ctrl = CGPoint(x: x + sweep * 0.3, y: midY + dir * len * 0.55)
                    let green = jitter(col(0.16, 0.42, 0.14), 0.07, &rng)
                    c.setFillColor(green.cgColor)
                    c.move(to: CGPoint(x: x - 2.5, y: midY))
                    c.addQuadCurve(to: tip, control: ctrl)
                    c.addQuadCurve(to: CGPoint(x: x + 2.5, y: midY),
                                   control: CGPoint(x: ctrl.x + 7, y: ctrl.y))
                    c.closePath()
                    c.fillPath()
                    // gân lá chét sáng hơn
                    c.setStrokeColor(col(0.36, 0.60, 0.24, 0.8).cgColor)
                    c.setLineWidth(1)
                    c.move(to: CGPoint(x: x, y: midY))
                    c.addQuadCurve(to: tip, control: CGPoint(x: ctrl.x + 3, y: ctrl.y))
                    c.strokePath()
                }
            }
        }
    }

    /// Mảng lá phủ kín (lặp liền mạch) dùng cho tán cây: nhiều lá nhỏ chồng nhau,
    /// có sáng/tối, có khe hở nhỏ trong suốt giữa các lá.
    private static func makeLeafCluster() -> UIImage {
        let w = 512
        let fmt = UIGraphicsImageRendererFormat()
        fmt.scale = 1
        fmt.opaque = false
        var rng = RNG(s: 123)
        return UIGraphicsImageRenderer(size: CGSize(width: w, height: w), format: fmt).image { ctx in
            let c = ctx.cgContext
            let S = CGFloat(w)
            // nền tối để khe giữa lá không lộ lỗ trống quá nhiều
            c.setFillColor(col(0.07, 0.19, 0.06).cgColor)
            c.fill(CGRect(x: 0, y: 0, width: S, height: S))
            for layer in 0..<4 {
                let lum = 0.55 + 0.17 * CGFloat(layer)
                for _ in 0..<(330 + layer * 60) {
                    let px = CGFloat.random(in: 0..<S, using: &rng)
                    let py = CGFloat.random(in: 0..<S, using: &rng)
                    let size = CGFloat.random(in: 22...44, using: &rng)
                    let rot = CGFloat.random(in: 0..<(2 * CGFloat.pi), using: &rng)
                    let gr: CGFloat = 0.17 * lum + 0.04
                    let gg: CGFloat = 0.42 * lum + 0.04
                    let gb: CGFloat = 0.11 * lum
                    let g = jitter(col(gr, gg, gb), 0.05, &rng)
                    for ox in [-S, 0, S] {
                        for oy in [-S, 0, S] {
                            let cx = px + ox, cy = py + oy
                            if cx < -size || cx > S + size || cy < -size || cy > S + size { continue }
                            c.saveGState()
                            c.translateBy(x: cx, y: cy)
                            c.rotate(by: rot)
                            c.setFillColor(g.cgColor)
                            c.addEllipse(in: CGRect(x: -size / 2, y: -size / 4, width: size, height: size / 2))
                            c.fillPath()
                            c.setStrokeColor(UIColor(white: 1, alpha: 0.14).cgColor)
                            c.setLineWidth(0.8)
                            c.move(to: CGPoint(x: -size / 2, y: 0))
                            c.addLine(to: CGPoint(x: size / 2, y: 0))
                            c.strokePath()
                            c.restoreGState()
                        }
                    }
                }
            }
        }
    }

    /// Một tàu lá dừa nước: gân giữa + lá chét hẹp, dài, mọc đều. Trục nằm ngang, gốc bên trái.
    private static func makeNipa() -> UIImage {
        let w = 512, h = 160
        let fmt = UIGraphicsImageRendererFormat()
        fmt.scale = 1
        fmt.opaque = false
        var rng = RNG(s: 311)
        return UIGraphicsImageRenderer(size: CGSize(width: w, height: h), format: fmt).image { ctx in
            let c = ctx.cgContext
            let W = CGFloat(w), H = CGFloat(h)
            let midY = H / 2
            c.setStrokeColor(col(0.40, 0.36, 0.16).cgColor)
            c.setLineWidth(5)
            c.move(to: CGPoint(x: 0, y: midY))
            c.addLine(to: CGPoint(x: W * 0.98, y: midY))
            c.strokePath()
            let count = 58
            for i in 0..<count {
                let t = CGFloat(i) / CGFloat(count)
                let x = 30 + t * (W - 50)
                let tc: CGFloat = min(max(t, 0.08), 0.96)
                let shape: CGFloat = 0.50 + 0.50 * sin(tc * CGFloat.pi)
                let rnd: CGFloat = CGFloat.random(in: 0.9...1.05, using: &rng)
                let len: CGFloat = H * 0.47 * shape * rnd
                let sweep: CGFloat = 26
                for dir in [CGFloat(-1), CGFloat(1)] {
                    let tip = CGPoint(x: x + sweep, y: midY + dir * len)
                    let green = jitter(col(0.14, 0.40, 0.16), 0.06, &rng)
                    c.setFillColor(green.cgColor)
                    c.move(to: CGPoint(x: x - 2, y: midY))
                    c.addQuadCurve(to: tip, control: CGPoint(x: x + sweep * 0.2, y: midY + dir * len * 0.6))
                    c.addQuadCurve(to: CGPoint(x: x + 2, y: midY),
                                   control: CGPoint(x: x + sweep * 0.2 + 6, y: midY + dir * len * 0.6))
                    c.closePath()
                    c.fillPath()
                }
            }
        }
    }

    /// Bụi cỏ (có kênh alpha): nhiều lá cỏ cong xòe từ gốc ở đáy ảnh.
    private static func makeGrassTuft() -> UIImage {
        let w = 256
        let fmt = UIGraphicsImageRendererFormat()
        fmt.scale = 1
        fmt.opaque = false
        var rng = RNG(s: 909)
        return UIGraphicsImageRenderer(size: CGSize(width: w, height: w), format: fmt).image { ctx in
            let c = ctx.cgContext
            let S = CGFloat(w)
            for _ in 0..<70 {
                let bx = S / 2 + CGFloat.random(in: -S * 0.22...S * 0.22, using: &rng)
                let h = CGFloat.random(in: S * 0.35...S * 0.95, using: &rng)
                let lean = CGFloat.random(in: -S * 0.30...S * 0.30, using: &rng)
                let wd = CGFloat.random(in: 3...7, using: &rng)
                let g = jitter(col(0.30, 0.52, 0.16), 0.10, &rng)
                let top = CGPoint(x: bx + lean, y: S - h)
                c.setFillColor(g.cgColor)
                c.move(to: CGPoint(x: bx - wd / 2, y: S))
                c.addQuadCurve(to: top, control: CGPoint(x: bx - wd / 2 + lean * 0.1, y: S - h * 0.6))
                c.addQuadCurve(to: CGPoint(x: bx + wd / 2, y: S),
                               control: CGPoint(x: bx + wd / 2 + lean * 0.35, y: S - h * 0.55))
                c.closePath()
                c.fillPath()
            }
        }
    }

    /// Lá kim thông: nền xanh thẫm phủ kín, nhiều cụm kim mảnh tỏa ra từ cành (lặp liền mạch).
    private static func makeNeedle() -> UIImage {
        render(256) { c, s, rng in
            c.setFillColor(col(0.05, 0.16, 0.08).cgColor)
            c.fill(CGRect(x: 0, y: 0, width: s, height: s))
            c.setLineCap(.round)
            for _ in 0..<2600 {
                let x = CGFloat.random(in: 0..<s, using: &rng)
                let y = CGFloat.random(in: 0..<s, using: &rng)
                let ang = CGFloat.random(in: 0..<(2 * CGFloat.pi), using: &rng)
                let len = CGFloat.random(in: 9...20, using: &rng)
                let g = jitter(col(0.12, 0.34, 0.16), 0.08, &rng)
                c.setStrokeColor(g.cgColor)
                c.setLineWidth(CGFloat.random(in: 0.7...1.3, using: &rng))
                for ox in [-s, 0, s] {
                    for oy in [-s, 0, s] {
                        let px = x + ox, py = y + oy
                        if px < -len || px > s + len || py < -len || py > s + len { continue }
                        c.move(to: CGPoint(x: px, y: py))
                        c.addLine(to: CGPoint(x: px + cos(ang) * len, y: py + sin(ang) * len))
                        c.strokePath()
                    }
                }
            }
        }
    }

    // MARK: - Tạo bản đồ pháp tuyến từ ảnh (độ sáng → độ cao)

    private static func toByte(_ v: Float) -> UInt8 {
        let x: Float = (v * 0.5 + 0.5) * 255
        let c: Float = x < 0 ? 0 : (x > 255 ? 255 : x)
        return UInt8(c)
    }

    static func normalMap(from image: UIImage, strength: CGFloat) -> UIImage {
        guard let cg = image.cgImage else { return image }
        let w = cg.width, h = cg.height
        var gray = [Float](repeating: 0, count: w * h)
        var raw = [UInt8](repeating: 0, count: w * h * 4)
        let cs = CGColorSpaceCreateDeviceRGB()
        var drawn = false
        raw.withUnsafeMutableBytes { buf in
            guard let ctx = CGContext(data: buf.baseAddress, width: w, height: h, bitsPerComponent: 8,
                                      bytesPerRow: w * 4, space: cs,
                                      bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return }
            ctx.draw(cg, in: CGRect(x: 0, y: 0, width: w, height: h))
            drawn = true
        }
        if !drawn { return image }
        for i in 0..<(w * h) {
            let r = Float(raw[i * 4]), g = Float(raw[i * 4 + 1]), b = Float(raw[i * 4 + 2])
            gray[i] = (0.299 * r + 0.587 * g + 0.114 * b) / 255
        }
        var out = [UInt8](repeating: 255, count: w * h * 4)
        let k = Float(strength)
        for y in 0..<h {
            for x in 0..<w {
                let xl = gray[y * w + (x + w - 1) % w], xr = gray[y * w + (x + 1) % w]
                let yu = gray[((y + h - 1) % h) * w + x], yd = gray[((y + 1) % h) * w + x]
                var nx = (xl - xr) * k
                var ny = (yu - yd) * k
                var nz: Float = 1
                let len = (nx * nx + ny * ny + nz * nz).squareRoot()
                nx /= len; ny /= len; nz /= len
                let o = (y * w + x) * 4
                out[o] = toByte(nx)
                out[o + 1] = toByte(ny)
                out[o + 2] = toByte(nz)
                out[o + 3] = 255
            }
        }
        guard let provider = CGDataProvider(data: Data(out) as CFData),
              let res = CGImage(width: w, height: h, bitsPerComponent: 8, bitsPerPixel: 32,
                                bytesPerRow: w * 4, space: cs,
                                bitmapInfo: CGBitmapInfo(rawValue: CGImageAlphaInfo.premultipliedLast.rawValue),
                                provider: provider, decode: nil, shouldInterpolate: true,
                                intent: .defaultIntent) else { return image }
        return UIImage(cgImage: res)
    }
}
