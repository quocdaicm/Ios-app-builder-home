import SwiftUI

@main
struct CityBuilderApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
