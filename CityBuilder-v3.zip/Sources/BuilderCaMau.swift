import SceneKit
import UIKit

// MARK: - Nhà miền Tây kiểu Cà Mau: nhà sàn mái lá dừa nước và nhà tôn
// Mẫu theo nhà ven kênh rạch Cà Mau: nhà ba gian hai mái, hướng ra mé nước, chân cao bằng cột đước / cột
// bê tông, vách và mái lá dừa nước (hoặc tôn), hiên rộng, bậc thang xuống bến, chum nước.
// Mặt trước của nhà quay về +Z (hướng ra kênh).

extension Builder {
    static func stilt(_ variant: Int) -> SCNNode { laCaMau(variant) }
    static func tole(_ variant: Int) -> SCNNode { tonCaMau(variant) }

    // MARK: Nhà sàn mái lá

    static func laCaMau(_ variant: Int) -> SCNNode {
        let root = SCNNode()
        let v = variant % 3
        let duoc = rgb(0.62, 0.38, 0.28)                               // cột đước đỏ sẫm
        let floorTop: Float = v == 2 ? 1.25 : 1.6
        let wallH: Float = 1.95
        let wallTex: Tex = v == 1 ? .wood : .thatch                     // vách ván tràm hoặc vách lá dừa
        let wallTint: UIColor? = v == 1 ? rgb(0.70, 0.64, 0.56) : (v == 2 ? rgb(0.85, 0.78, 0.66) : nil)
        let roofTint: UIColor? = v == 2 ? rgb(0.66, 0.60, 0.52) : nil   // lá cũ thì sẫm màu

        // cột đước chân cao + dầm
        var postZ: [Float] = [-1.6, 1.6, 3.0]
        if v == 2 { postZ.append(-3.3) }
        for px in [Float(-1.9), 0, 1.9] {
            for pz in postZ where !(v == 2 && pz == -3.3 && px == 0) {
                root.addChildNode(tcyl(0.12, floorTop, .woodDark, tint: duoc, tileY: 2.4,
                                       x: px, y: floorTop / 2, z: pz, seg: 10))
            }
            root.addChildNode(tbox(0.15, 0.16, 5.6, .woodDark, tint: duoc, tile: 1.5,
                                   x: px, y: floorTop - 0.14, z: 0.6))
        }
        // giằng chéo bằng tre
        let bambooMat = tex(.bamboo, tint: rgb(0.9, 0.85, 0.6), rx: 1, ry: 2)
        for sx in [Float(-1.9), 1.9] {
            root.addChildNode(link(SIMD3<Float>(sx, 0.1, -1.6), SIMD3<Float>(sx, floorTop - 0.2, 1.6),
                                   r1: 0.04, r2: 0.04, bambooMat, seg: 6))
        }
        // sàn ván
        root.addChildNode(tbox(4.7, 0.14, 5.6, .wood, tint: rgb(0.80, 0.72, 0.60), tile: 1.8,
                               y: floorTop - 0.02, z: 0.6))

        // vách + nóc
        root.addChildNode(tbox(4.2, wallH, 3.6, wallTex, tint: wallTint, tile: 1.4, y: floorTop + wallH / 2))
        root.addChildNode(gableRoof(halfSpan: 2.8, rise: 2.15, baseY: floorTop + wallH,
                                    zBack: -1.8, zFront: 1.8, ovBack: 0.55, ovFront: 1.5,
                                    roofTex: .thatch, roofTint: roofTint, roofRough: 0.95, roofMetal: 0,
                                    thickness: 0.32, tile: 1.6, gableTex: wallTex, gableTint: wallTint))
        // cột hiên chống mái đua
        for sx in [Float(-2.1), 2.1] {
            root.addChildNode(tcyl(0.09, wallH + 0.1, .woodDark, tint: duoc, tileY: 2.4,
                                   x: sx, y: floorTop + wallH / 2, z: 3.1, seg: 8))
        }

        // cửa không cánh (khung tối) + mành tre cuốn một nửa
        root.addChildNode(box(1.0, 1.75, 0.06, rgb(0.10, 0.08, 0.06), rough: 1, x: 0, y: floorTop + 0.9, z: 1.82))
        root.addChildNode(tbox(1.15, 0.08, 0.1, .woodDark, tint: duoc, tile: 1, x: 0, y: floorTop + 1.8, z: 1.84))
        root.addChildNode(tbox(1.0, 0.55, 0.03, .bamboo, tint: rgb(0.92, 0.80, 0.55), tile: 0.8,
                               x: 0, y: floorTop + 1.5, z: 1.88))
        for sx in [Float(-1.45), Float(1.45)] {
            let w = window(0.7, 0.75, frame: .woodDark, frameTint: nil, shutters: false)
            w.position = SCNVector3(sx, floorTop + 1.2, 1.8)
            root.addChildNode(w)
        }
        let sw = window(0.7, 0.75, frame: .woodDark, frameTint: nil, shutters: false)
        sw.position = SCNVector3(2.1, floorTop + 1.2, 0)
        sw.eulerAngles.y = Float.pi / 2
        root.addChildNode(sw)

        // lan can hiên
        func railRun(x: Float, z: Float, length: Float, alongX: Bool) {
            root.addChildNode(tbox(alongX ? length : 0.07, 0.07, alongX ? 0.07 : length, .woodDark, tile: 1,
                                   x: x, y: floorTop + 0.95, z: z))
            let n = max(Int(length / 0.4), 1)
            for i in 0...n {
                let o = -length / 2 + length * Float(i) / Float(n)
                root.addChildNode(tbox(0.05, 0.9, 0.05, .woodDark, tile: 1,
                                       x: alongX ? x + o : x, y: floorTop + 0.5, z: alongX ? z : z + o))
            }
        }
        railRun(x: -1.5, z: 3.3, length: 1.7, alongX: true)
        railRun(x: 1.5, z: 3.3, length: 1.7, alongX: true)
        railRun(x: -2.3, z: 2.55, length: 1.5, alongX: false)
        railRun(x: 2.3, z: 2.55, length: 1.5, alongX: false)

        // thang gỗ xuống bến + sàn nước ra sát mé kênh
        let stepH = (floorTop - 0.1) / 4
        for i in 0..<4 {
            root.addChildNode(tbox(0.9, 0.08, 0.34, .wood, tile: 1, y: 0.25 + Float(i) * stepH, z: 4.85 - Float(i) * 0.4))
        }
        for sx in [Float(-0.5), Float(0.5)] {
            root.addChildNode(link(SIMD3<Float>(sx, 0.1, 5.15), SIMD3<Float>(sx, floorTop - 0.05, 3.45),
                                   r1: 0.045, r2: 0.045, plain(rgb(0.36, 0.24, 0.16), rough: 0.9), seg: 6))
        }
        root.addChildNode(tbox(2.4, 0.09, 1.7, .wood, tint: rgb(0.70, 0.62, 0.50), tile: 1, y: 0.32, z: 6.1))
        for (px, pz) in [(Float(-1.1), Float(5.4)), (1.1, 5.4), (-1.1, 6.8), (1.1, 6.8)] {
            root.addChildNode(tcyl(0.07, 0.7, .woodDark, tint: duoc, tileY: 1, x: px, y: 0.25, z: pz, seg: 8))
        }

        // chum nước dưới gầm hiên
        let clay = plain(rgb(0.55, 0.30, 0.18), rough: 0.6)
        let jar = sphere(0.36, clay, x: -1.7, y: 0.38, z: 4.1, seg: 14)
        jar.scale = SCNVector3(1, 1.1, 1)
        root.addChildNode(jar)

        // nhà lá cũ: chái bếp lợp lá phía sau + sào phơi quần áo ở hiên
        if v == 2 {
            root.addChildNode(tbox(4.0, 0.14, 1.4, .wood, tint: rgb(0.80, 0.72, 0.60), tile: 1.8, y: floorTop - 0.02, z: -2.9))
            root.addChildNode(tbox(3.8, 1.5, 0.1, .thatch, tint: wallTint, tile: 1.2, y: floorTop + 0.75, z: -3.55))
            for sx in [Float(-1.9), 1.9] {
                root.addChildNode(tbox(0.1, 1.5, 1.7, .thatch, tint: wallTint, tile: 1.2, x: sx, y: floorTop + 0.75, z: -2.7))
            }
            let lean = SCNBox(width: 4.6, height: 0.26, length: 2.1, chamferRadius: 0)
            lean.materials = [tex(.thatch, tint: roofTint, rough: 0.95, rx: 3, ry: 1.2)]
            let ln = SCNNode(geometry: lean)
            ln.position = SCNVector3(0, floorTop + 1.78, -2.95)
            ln.eulerAngles.x = -0.2
            root.addChildNode(ln)
            root.addChildNode(link(SIMD3<Float>(-2.1, floorTop + 1.85, 3.1), SIMD3<Float>(2.1, floorTop + 1.85, 3.1),
                                   r1: 0.03, r2: 0.03, bambooMat, seg: 6))
            let cloth: [UIColor] = [rgb(0.85, 0.35, 0.30), rgb(0.95, 0.92, 0.85), rgb(0.30, 0.50, 0.75)]
            for (i, c) in cloth.enumerated() {
                root.addChildNode(box(0.38, 0.65, 0.02, c, rough: 1, x: -1.3 + Float(i) * 1.1, y: floorTop + 1.5, z: 3.1))
            }
        }
        return root
    }

    // MARK: Nhà tôn

    static func tonCaMau(_ variant: Int) -> SCNNode {
        let root = SCNNode()
        let v = variant % 3
        let wallTints: [UIColor] = [rgb(0.62, 0.80, 1.0), rgb(0.92, 0.92, 0.88), rgb(0.70, 0.92, 0.72)]
        let roofTints: [UIColor] = [rgb(0.95, 0.62, 0.55), rgb(0.88, 0.88, 0.88), rgb(0.62, 0.78, 1.0)]
        let wallTint = wallTints[v], roofTint = roofTints[v]
        let floorTop: Float = v == 1 ? 0.55 : (v == 0 ? 1.3 : 1.4)
        let wallH: Float = 2.0

        if v == 1 {
            // nhà trệt nền xi măng cao
            root.addChildNode(tbox(4.8, floorTop, 5.4, .concrete, tile: 2.4, y: floorTop / 2, z: 0.6))
        } else {
            // nhà sàn: cột bê tông vuông (v0) hoặc cột tràm (v2)
            for px in [Float(-1.9), 0, 1.9] {
                for pz in [Float(-1.6), 1.6, 3.0] {
                    if v == 0 {
                        root.addChildNode(tbox(0.2, floorTop, 0.2, .concrete, tile: 1.2, x: px, y: floorTop / 2, z: pz))
                    } else {
                        root.addChildNode(tcyl(0.1, floorTop, .woodDark, tint: rgb(0.72, 0.62, 0.50), tileY: 2.4,
                                               x: px, y: floorTop / 2, z: pz, seg: 8))
                    }
                }
            }
            root.addChildNode(tbox(4.7, 0.16, 5.6, v == 0 ? .concrete : .wood, tile: 2, y: floorTop - 0.04, z: 0.6))
        }

        // vách tôn múi (phần chân gỉ sét sẫm hơn)
        root.addChildNode(tbox(4.2, wallH, 3.6, .tole, tint: wallTint, rough: 0.5, metal: 0.5, tile: 2,
                               y: floorTop + wallH / 2))
        root.addChildNode(tbox(4.22, 0.4, 3.62, .tole, tint: rgb(0.62, 0.42, 0.30), rough: 0.7, metal: 0.4, tile: 2,
                               y: floorTop + 0.2))
        // mái tôn hai dốc thoải, mái hiên đua ra trước
        root.addChildNode(gableRoof(halfSpan: 2.7, rise: 1.0, baseY: floorTop + wallH,
                                    zBack: -1.8, zFront: 1.8, ovBack: 0.5, ovFront: 1.7,
                                    roofTex: .tole, roofTint: roofTint, roofRough: 0.45, roofMetal: 0.7,
                                    thickness: 0.06, tile: 2, gableTex: .tole, gableTint: wallTint))
        // cột hiên
        for sx in [Float(-2.1), 2.1] {
            if v == 0 {
                root.addChildNode(tbox(0.14, wallH + 0.05, 0.14, .concrete, tile: 1, x: sx, y: floorTop + wallH / 2, z: 3.3))
            } else {
                root.addChildNode(tcyl(0.08, wallH + 0.05, .woodDark, tileY: 2, x: sx, y: floorTop + wallH / 2, z: 3.3, seg: 8))
            }
        }
        // cửa + cửa sổ tôn
        let d = door(0.9, 1.75)
        d.position = SCNVector3(0, floorTop, 1.8)
        root.addChildNode(d)
        for sx in [Float(-1.4), Float(1.4)] {
            let w = window(0.75, 0.75, shutters: true)
            w.position = SCNVector3(sx, floorTop + 1.3, 1.8)
            root.addChildNode(w)
        }
        // bậc tam cấp bê tông
        for k in 0..<3 {
            let h = floorTop * Float(k + 1) / 3
            root.addChildNode(tbox(1.7, h, 0.4, .concrete, tile: 1.2, x: 0, y: h / 2, z: 4.5 - Float(k) * 0.4))
        }
        if v == 0 {
            // bồn nước nhựa trên giàn
            for (lx, lz) in [(Float(-0.3), Float(-0.3)), (0.3, -0.3), (-0.3, 0.3), (0.3, 0.3)] {
                root.addChildNode(cyl(0.05, 1.5, rgb(0.35, 0.35, 0.37), rough: 0.5, metal: 0.8,
                                      x: -3.1 + lx, y: 0.75, z: -1.0 + lz, seg: 6))
            }
            root.addChildNode(box(0.9, 0.08, 0.9, rgb(0.35, 0.35, 0.37), rough: 0.5, metal: 0.8, x: -3.1, y: 1.52, z: -1.0))
            root.addChildNode(cyl(0.42, 1.05, rgb(0.20, 0.45, 0.75), rough: 0.4, x: -3.1, y: 2.1, z: -1.0, seg: 20))
        } else if v == 1 {
            // cột ăng-ten + chum nước
            root.addChildNode(cyl(0.03, 3.2, rgb(0.5, 0.5, 0.5), rough: 0.4, metal: 0.9,
                                  x: 1.3, y: floorTop + wallH + 1.6, z: -0.5, seg: 6))
            root.addChildNode(box(1.0, 0.04, 0.04, rgb(0.5, 0.5, 0.5), rough: 0.4, metal: 0.9,
                                  x: 1.3, y: floorTop + wallH + 3.0, z: -0.5))
            let clay = plain(rgb(0.55, 0.30, 0.18), rough: 0.6)
            let jar = sphere(0.36, clay, x: 2.7, y: floorTop + 0.38, z: 3.9, seg: 14)
            jar.scale = SCNVector3(1, 1.1, 1)
            root.addChildNode(jar)
        } else {
            // chái tôn lụp xụp phía sau
            root.addChildNode(tbox(3.6, 1.5, 1.2, .tole, tint: rgb(0.80, 0.70, 0.62), rough: 0.7, metal: 0.4, tile: 2,
                                   y: floorTop + 0.75, z: -2.4))
            let lean = SCNBox(width: 4.2, height: 0.06, length: 1.9, chamferRadius: 0)
            lean.materials = [tex(.tole, tint: rgb(0.85, 0.75, 0.68), rough: 0.5, metal: 0.6, rx: 2, ry: 1)]
            let ln = SCNNode(geometry: lean)
            ln.position = SCNVector3(0, floorTop + 1.65, -2.5)
            ln.eulerAngles.x = -0.18
            root.addChildNode(ln)
        }
        return root
    }
}
