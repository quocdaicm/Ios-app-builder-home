import SceneKit
import UIKit
import simd

// MARK: - Rừng đước, vuông tôm và mương nước Cà Mau
//
// Dựng lại theo ảnh thật rừng đước Cà Mau (Rhizophora apiculata):
// - Thân: thẳng, thon, vỏ xám be nứt dọc có mắt vỏ; ngọn mới có tán lá.
// - Rễ chống: nhiều rễ nâu sẫm cong như vòm, có rễ phụ chẻ nhánh, chân loe cắm xuống bùn.
// - Lá: bầu dục dày bóng, mọc đối chéo chữ thập từng cặp ở đầu cành, lá non vàng xanh ở chồi ngọn.
// - Trái (cây con): hình thoi dài 25 - 40 cm, đỏ nâu, cổ xanh vàng, rủ thành từng chùm; rụng cắm thẳng vào bùn.
// - Bùn: xám be, mảng nâu sẫm ướt, gợn lồi lõm, lỗ cua, lá mục, vũng nước đọng.
// - Nước lợ: xanh ô liu đục, có bóng thân cây và ánh phù sa.
// Ảnh vỏ / lá / bùn / nước / trái nằm trong Assets.xcassets (barkDuoc, leafDuoc, mudWet, waterBrack, fruitDuoc).
// Cả cây chỉ gom thành 5 khối hình (thân + cành, rễ, trái, lá già, lá non) nên rất nhẹ.

// MARK: - Gom ống / trái thành MỘT khối hình

struct MeshBatch {
    var verts: [SCNVector3] = []
    var norms: [SCNVector3] = []
    var uvs: [CGPoint] = []
    var idx: [Int32] = []

    private mutating func push(_ p: V3, _ n: V3, _ u: Float, _ v: Float) {
        verts.append(SCNVector3(p.x, p.y, p.z))
        norms.append(SCNVector3(n.x, n.y, n.z))
        uvs.append(CGPoint(x: CGFloat(u), y: CGFloat(v)))
    }

    /// Nối các vòng tròn thành ống: `idx` theo thứ tự (a, b, d), (a, d, c) cho mặt ngoài.
    private mutating func stitch(base: Int32, rings: Int, sides: Int) {
        for i in 0..<(rings - 1) {
            for s in 0..<sides {
                let a = base + Int32(i * (sides + 1) + s)
                let b = a + 1
                let c = a + Int32(sides + 1)
                let d = c + 1
                idx.append(contentsOf: [a, b, d, a, d, c])
            }
        }
    }

    /// Ống cong thon dần đi qua các điểm `pts` (bán kính `radii` tại từng điểm).
    /// `uRep` = số lần ảnh lặp quanh chu vi, `vPerMeter` = số lần ảnh lặp trên mỗi mét chiều dài.
    mutating func tube(_ pts: [V3], radii: [Float], sides: Int, uRep: Float = 1, vPerMeter: Float = 1) {
        let n = pts.count
        guard n >= 2, radii.count == n, sides >= 3 else { return }
        var tang: [V3] = []
        for i in 0..<n {
            let d = pts[min(i + 1, n - 1)] - pts[max(i - 1, 0)]
            let l = simd_length(d)
            tang.append(l < 1e-5 ? V3(0, 1, 0) : d / l)
        }
        let ref: V3 = abs(tang[0].y) > 0.9 ? V3(1, 0, 0) : V3(0, 1, 0)
        var nrm = simd_normalize(simd_cross(tang[0], ref))
        let base = Int32(verts.count)
        var along: Float = 0
        for i in 0..<n {
            if i > 0 {
                along += simd_length(pts[i] - pts[i - 1])
                var m = nrm - tang[i] * simd_dot(nrm, tang[i])
                if simd_length(m) < 1e-4 {
                    let alt: V3 = abs(tang[i].x) < 0.9 ? V3(1, 0, 0) : V3(0, 0, 1)
                    m = simd_cross(tang[i], alt)
                }
                nrm = simd_normalize(m)
            }
            let bin = simd_cross(tang[i], nrm)
            for s in 0...sides {
                let a = Float(s) / Float(sides) * 2 * Float.pi
                let dir = nrm * cos(a) + bin * sin(a)
                push(pts[i] + dir * radii[i], dir, Float(s) / Float(sides) * uRep, along * vPerMeter)
            }
        }
        stitch(base: base, rings: n, sides: sides)
    }

    /// Trái đước: hình thoi dài thon từ cổ trái `top` (xanh vàng) tới đầu nhọn `tip` (nâu sẫm).
    mutating func propagule(top: V3, tip: V3, radius: Float, sides: Int = 7) {
        let d = tip - top
        let len = simd_length(d)
        guard len > 0.01 else { return }
        let ax = d / len
        let ref: V3 = abs(ax.y) > 0.9 ? V3(1, 0, 0) : V3(0, 1, 0)
        let nrm = simd_normalize(simd_cross(ax, ref))
        let bin = simd_cross(ax, nrm)
        let ts: [Float] = [0, 0.05, 0.12, 0.25, 0.42, 0.62, 0.80, 0.93, 1.0]
        let rs: [Float] = [0.45, 0.80, 0.60, 0.85, 1.0, 0.95, 0.75, 0.42, 0.05]
        let base = Int32(verts.count)
        for i in 0..<ts.count {
            let c = top + ax * (len * ts[i])
            for s in 0...sides {
                let a = Float(s) / Float(sides) * 2 * Float.pi
                let dir = nrm * cos(a) + bin * sin(a)
                push(c + dir * (radius * rs[i]), dir, Float(s) / Float(sides), ts[i])
            }
        }
        stitch(base: base, rings: ts.count, sides: sides)
    }

    func node(_ material: SCNMaterial, shadow: Bool = true) -> SCNNode? {
        guard !verts.isEmpty else { return nil }
        let g = SCNGeometry(sources: [SCNGeometrySource(vertices: verts),
                                      SCNGeometrySource(normals: norms),
                                      SCNGeometrySource(textureCoordinates: uvs)],
                            elements: [SCNGeometryElement(indices: idx, primitiveType: .triangles)])
        g.materials = [material]
        let n = SCNNode(geometry: g)
        n.castsShadow = shadow
        return n
    }
}

extension Builder {

    // MARK: Vật liệu dùng chung cho đước

    fileprivate static var duocMats: [String: SCNMaterial] = [:]

    /// Nước lợ: màu nhân gần như trắng để giữ nguyên màu ảnh.
    static let mangroveWaterTint: UIColor = UIColor(red: 0.95, green: 1.0, blue: 0.90, alpha: 1)

    /// Vỏ thân / cành (xám be) hoặc rễ chống (nâu sẫm); hai mặt cho chắc.
    static func duocWoodMat(root: Bool) -> SCNMaterial {
        let key = root ? "root" : "wood"
        if let m = duocMats[key] { return m }
        let base = tex(.barkDuoc, tint: root ? rgb(0.55, 0.46, 0.40) : rgb(1.0, 0.96, 0.90),
                       rough: root ? 0.80 : 0.90, rx: 1, ry: 1)
        let m = (base.copy() as? SCNMaterial) ?? base
        m.isDoubleSided = true
        duocMats[key] = m
        return m
    }

    /// Lá đước bóng. kind: 0 lá già xanh đậm, 1 lá non vàng xanh, 2 lá mục nâu.
    static func duocLeafMat(_ kind: Int) -> SCNMaterial {
        let key = "leaf\(kind)"
        if let m = duocMats[key] { return m }
        let tints: [UIColor] = [rgb(0.62, 0.84, 0.56), rgb(1.0, 1.0, 0.80), rgb(0.95, 0.50, 0.35)]
        let m = SCNMaterial()
        m.lightingModel = .blinn
        m.diffuse.contents = TextureLibrary.albedo(.leafDuoc)
        m.specular.contents = UIColor(white: kind == 2 ? 0.1 : 0.42, alpha: 1)
        m.shininess = kind == 2 ? 0.15 : 0.35
        m.isDoubleSided = true
        m.diffuse.wrapS = .clamp
        m.diffuse.wrapT = .clamp
        m.diffuse.mipFilter = .linear
        m.multiply.contents = tints[min(max(kind, 0), 2)]
        m.shaderModifiers = [.fragment: "if (_output.color.a < 0.5) { discard_fragment(); }\n_output.color.a = 1.0;"]
        duocMats[key] = m
        return m
    }

    static func duocFruitMat() -> SCNMaterial {
        let key = "fruit"
        if let m = duocMats[key] { return m }
        let m = tex(.fruitDuoc, rough: 0.45)
        duocMats[key] = m
        return m
    }

    static func duocMudMat() -> SCNMaterial {
        let key = "mud"
        if let m = duocMats[key] { return m }
        let base = tex(.mudWet, rough: 0.50, rx: 1, ry: 1)
        let m = (base.copy() as? SCNMaterial) ?? base
        m.isDoubleSided = true
        duocMats[key] = m
        return m
    }

    static func duocPuddleMat() -> SCNMaterial {
        let key = "puddle"
        if let m = duocMats[key] { return m }
        let m = SCNMaterial()
        m.lightingModel = .physicallyBased
        m.diffuse.contents = TextureLibrary.albedo(.waterBrack)
        m.multiply.contents = mangroveWaterTint
        m.roughness.contents = 0.05
        m.metalness.contents = 0.0
        duocMats[key] = m
        return m
    }

    // MARK: Nền bùn và mặt nước dùng chung

    static func mudMat(rx: Float = 3, ry: Float = 3) -> SCNMaterial {
        tex(.mudWet, rough: 0.50, rx: rx, ry: ry)
    }

    /// Nền bùn sình tròn: mặt gồ ghề nhẹ, vành thoải xuống đất, lõm xuống ở chỗ có vũng nước.
    /// Mặt bùn trung bình ở độ cao 0.09 (cây đặt ở đó); `pools` = (x, z, bán kính) các vũng nước.
    static func mudDisc(radius r: Float, height h: Float = 0.1, y: Float = 0.04, seed: UInt64 = 7,
                        pools: [(Float, Float, Float)] = []) -> SCNNode {
        var rng = SeededRNG(seed &+ 977)
        var ph: [Float] = []
        for _ in 0..<4 { ph.append(rng.f(0, 6.28)) }
        let top = y + h / 2
        func height(_ x: Float, _ z: Float) -> Float {
            let d = (x * x + z * z).squareRoot() / r
            let w0: Float = x * 1.3 + ph[0]
            let w1: Float = z * 1.1 + ph[1]
            let w2: Float = x * 2.9 + z * 2.3 + ph[2]
            let w3: Float = z * 4.1 - x * 1.7 + ph[3]
            var v: Float = 0.016 * sin(w0) * cos(w1)
            v += 0.010 * sin(w2)
            v += 0.006 * sin(w3)
            for p in pools {
                let dd = ((x - p.0) * (x - p.0) + (z - p.1) * (z - p.1)).squareRoot()
                let lim = p.2 * 1.3
                if dd < lim {
                    let t = 1 - dd / lim
                    v -= 0.05 * t * t * (3 - 2 * t)
                }
            }
            let rim = max(0, (d - 0.80) / 0.20)
            return top + v * (1 - rim) - rim * rim * (top - 0.005)
        }
        let rings = 16
        let sectors = 44
        var verts: [SCNVector3] = []
        var norms: [SCNVector3] = []
        var uvs: [CGPoint] = []
        var idx: [Int32] = []
        let e: Float = 0.06
        for ri in 0...rings {
            let rr = r * Float(ri) / Float(rings)
            for si in 0...sectors {
                let a = Float(si) / Float(sectors) * 2 * Float.pi
                let x = cos(a) * rr
                let z = sin(a) * rr
                let dx = height(x + e, z) - height(x - e, z)
                let dz = height(x, z + e) - height(x, z - e)
                let nn = simd_normalize(V3(-dx / (2 * e), 1, -dz / (2 * e)))
                verts.append(SCNVector3(x, height(x, z), z))
                norms.append(SCNVector3(nn.x, nn.y, nn.z))
                uvs.append(CGPoint(x: CGFloat(x / 2.6), y: CGFloat(z / 2.6)))
            }
        }
        for ri in 0..<rings {
            for si in 0..<sectors {
                let a = Int32(ri * (sectors + 1) + si)
                let b = a + 1
                let c = a + Int32(sectors + 1)
                let d = c + 1
                idx.append(contentsOf: [a, b, c, b, d, c])
            }
        }
        let g = SCNGeometry(sources: [SCNGeometrySource(vertices: verts),
                                      SCNGeometrySource(normals: norms),
                                      SCNGeometrySource(textureCoordinates: uvs)],
                            elements: [SCNGeometryElement(indices: idx, primitiveType: .triangles)])
        g.materials = [duocMudMat()]
        let n = SCNNode(geometry: g)
        n.castsShadow = false
        return n
    }

    /// Vũng nước đọng trên bùn: mặt nước hơi thấp hơn mặt bùn trung bình, rìa tự nhiên do bùn lồi lõm.
    static func duocPuddle(x: Float, z: Float, radius pr: Float) -> SCNNode {
        let g = SCNCylinder(radius: CGFloat(pr * 1.12), height: 0.012)
        g.radialSegmentCount = 28
        let m = duocPuddleMat()
        g.materials = [m, m, m]
        let n = SCNNode(geometry: g)
        n.position = SCNVector3(x, 0.078, z)
        n.castsShadow = false
        return n
    }

    /// Mặt nước lợ đục có hiệu ứng chảy nhẹ. Nút gốc nằm sẵn ở độ cao 0.12.
    static func flowWater(_ w: Float, _ l: Float, tint: UIColor, period: Double = 14, round: Bool = false) -> SCNNode {
        let wm = SCNMaterial()
        wm.lightingModel = .physicallyBased
        wm.diffuse.contents = TextureLibrary.albedo(.waterBrack)
        wm.multiply.contents = tint
        wm.roughness.contents = 0.06
        wm.metalness.contents = 0.0
        if let nm = TextureLibrary.normal(.waterBrack) {
            wm.normal.contents = nm
            wm.normal.intensity = 0.8
        }
        let rx = max((w / 4).rounded(), 1)
        let ry = max((l / 4).rounded(), 1)
        for p in [wm.diffuse, wm.normal] {
            p.wrapS = .repeat
            p.wrapT = .repeat
            p.mipFilter = .linear
            p.contentsTransform = SCNMatrix4MakeScale(rx, ry, 1)
        }
        let g: SCNGeometry = round
            ? SCNCylinder(radius: CGFloat(w / 2), height: 0.05)
            : SCNBox(width: CGFloat(w), height: 0.05, length: CGFloat(l), chamferRadius: 0)
        g.materials = [wm]
        let n = SCNNode(geometry: g)
        n.position = SCNVector3(0, 0.12, 0)
        n.castsShadow = false
        let flow = SCNAction.customAction(duration: period) { _, t in
            let u = Float(t / period)
            var a = SCNMatrix4MakeScale(rx, ry, 1)
            a.m41 = -u
            var b = SCNMatrix4MakeScale(rx, ry, 1)
            b.m41 = -2 * u
            b.m42 = 0.08 * sin(2 * Float.pi * u)
            wm.diffuse.contentsTransform = a
            wm.normal.contentsTransform = b
        }
        n.runAction(SCNAction.repeatForever(flow))
        return n
    }

    // MARK: Chùm lá ở đầu cành

    /// Một chồi: cành nhỏ, các cặp lá mọc đối chéo chữ thập (mỗi cặp xoay 90° so với cặp trước),
    /// cặp cuối và chồi ngọn là lá non vàng xanh. `leaf` = chiều dài lá (m).
    static func duocShoot(_ twig: inout MeshBatch, _ oldL: inout CardBatch, _ youngL: inout CardBatch,
                          at p: V3, dir d0: V3, pairs: Int, leaf: Float, _ rng: inout SeededRNG) {
        let d = simd_normalize(d0)
        let ref: V3 = abs(d.y) > 0.9 ? V3(1, 0, 0) : V3(0, 1, 0)
        let s0 = simd_normalize(simd_cross(d, ref))
        let s1 = simd_cross(d, s0)
        let gap = 0.045 + leaf * 0.17
        var last = p
        for k in 0..<pairs {
            let pos = p + d * (gap * Float(k))
            last = pos
            let ang = Float(k) * Float.pi / 2 + rng.f(-0.25, 0.25)
            let side = s0 * cos(ang) + s1 * sin(ang)
            for sg: Float in [-1, 1] {
                var ld: V3 = d * 0.30
                ld += side * (0.95 * sg)
                ld += V3(0, 0.25, 0)
                ld = simd_normalize(ld)
                let sz = leaf * rng.f(0.85, 1.12)
                let isYoung = k == pairs - 1 || rng.f(0, 1) < 0.14
                if isYoung {
                    youngL.leaf(at: pos, dir: ld, spin: rng.f(-0.4, 0.4), w: sz * 0.5, h: sz,
                                fold: 0.12, droop: 0.22, rows: 3)
                } else {
                    oldL.leaf(at: pos, dir: ld, spin: rng.f(-0.4, 0.4), w: sz * 0.5, h: sz,
                              fold: 0.12, droop: 0.28, rows: 3)
                }
            }
        }
        // chồi ngọn: hai lá non chụm lên
        let tipP = last + d * gap
        for sg: Float in [-1, 1] {
            var ld: V3 = d * 0.9
            ld += s0 * (0.35 * sg)
            ld += V3(0, 0.2, 0)
            ld = simd_normalize(ld)
            youngL.leaf(at: tipP, dir: ld, spin: rng.f(-0.3, 0.3), w: leaf * 0.19, h: leaf * 0.75,
                        fold: 0.10, droop: 0.12, rows: 3)
        }
        twig.tube([p - d * 0.02, tipP], radii: [0.009, 0.005], sides: 4, uRep: 1, vPerMeter: 12)
    }

    // MARK: Một cây đước (dùng chung cho cây lẻ, rừng, vuông tôm, bờ mương)

    /// Gốc cây ở (0, 0, 0). `roots` là số rễ chống chính (mỗi rễ có thể chẻ thêm rễ phụ),
    /// `segs` số đoạn mỗi rễ (nhiều đoạn thì cong mượt hơn nhưng nặng hơn).
    static func duocNode(height h: Float, roots: Int, segs: Int, fruits: Int, seed: UInt64) -> SCNNode {
        let n = SCNNode()
        var rng = SeededRNG(seed)
        var wood = MeshBatch()
        var rootB = MeshBatch()
        var fruitB = MeshBatch()
        var oldLeaf = CardBatch()
        var youngLeaf = CardBatch()

        let lx = rng.f(-0.14, 0.14)
        let lz = rng.f(-0.14, 0.14)
        let ph = rng.f(0, 6.28)
        let baseY = max(0.45, h * 0.13)
        let r0 = 0.016 * h + 0.03
        let y0 = baseY * 0.5

        // trục thân thẳng, hơi cong và nghiêng
        func axis(_ t: Float) -> V3 {
            let wob = 0.05 * sin(t * 4.2 + ph) * min(h, 6) / 6
            return V3(lx * t + wob, y0 + (h - y0) * t, lz * t + wob * 0.7)
        }
        func trunkR(_ t: Float) -> Float {
            let flare: Float = t < 0.1 ? 1 + (0.1 - t) * 3 : 1
            return r0 * (1 - 0.66 * powf(t, 0.85)) * flare
        }

        // thân
        var tp: [V3] = []
        var tr: [Float] = []
        let ringN = 9
        for k in 0...ringN {
            let t = Float(k) / Float(ringN)
            tp.append(axis(t))
            tr.append(trunkR(t))
        }
        tp.append(axis(1) + V3(0, 0.25, 0))
        tr.append(0.004)
        wood.tube(tp, radii: tr, sides: 8, uRep: 2, vPerMeter: 2.4)

        // rễ chống: đường cong bậc ba từ thân xuống bùn, chân loe; một phần chẻ rễ phụ
        let rootN = max(Int((Float(max(roots, 3)) * 1.5).rounded()), 4)
        let segN = max(segs, 2) * 2 + 2
        func bez(_ p0: V3, _ p1: V3, _ p2: V3, _ p3: V3, _ t: Float) -> V3 {
            let u: Float = 1 - t
            let w0: Float = u * u * u
            let w1: Float = 3 * u * u * t
            let w2: Float = 3 * u * t * t
            let w3: Float = t * t * t
            var r: V3 = p0 * w0
            r += p1 * w1
            r += p2 * w2
            r += p3 * w3
            return r
        }
        func addRoot(_ p0: V3, _ p1: V3, _ p2: V3, _ p3: V3, _ rA: Float, _ rB: Float) {
            var pts: [V3] = []
            var rad: [Float] = []
            for k in 0..<segN {
                let t = Float(k) / Float(segN - 1)
                pts.append(bez(p0, p1, p2, p3, t))
                var r = rA + (rB - rA) * t
                if k == segN - 2 { r *= 1.18 } else if k == segN - 1 { r *= 1.45 }
                rad.append(r)
            }
            rootB.tube(pts, radii: rad, sides: 5, uRep: 1, vPerMeter: 4.5)
        }
        for i in 0..<rootN {
            let a = Float(i) / Float(rootN) * 2 * Float.pi + rng.f(-0.3, 0.3)
            let dir = V3(cos(a), 0, sin(a))
            let side = V3(-sin(a), 0, cos(a))
            let sy = baseY * rng.f(0.85, 1.0) + rng.f(0, 0.16 * h)
            let tt = min(max((sy - y0) / (h - y0), 0), 1)
            let c = axis(tt)
            let off: Float = trunkR(tt) * 0.8
            let p0 = V3(c.x + dir.x * off, sy, c.z + dir.z * off)
            let reach: Float = rng.f(0.5, 0.2 * h + 0.6) + 0.15 * (sy - baseY)
            let wig: Float = rng.f(-0.25, 0.25) * reach
            var p1: V3 = p0 + dir * (reach * 0.40)
            p1 += side * wig
            p1 += V3(0, 0.10 + 0.05 * h, 0)
            var p2: V3 = V3(c.x, sy * 0.30, c.z)
            p2 += dir * (reach * 0.92)
            p2 += side * (wig * 0.5)
            var p3: V3 = V3(c.x, -0.04, c.z)
            p3 += dir * reach
            p3 += side * (wig * 0.6)
            let rA: Float = 0.030 + 0.003 * h
            addRoot(p0, p1, p2, p3, rA, rA * 0.5)
            if rng.f(0, 1) < 0.55 {
                let q0 = bez(p0, p1, p2, p3, 0.42)
                let sgn: Float = rng.f(0, 1) < 0.5 ? -1 : 1
                let a2: Float = a + rng.f(0.4, 0.9) * sgn
                let d2 = V3(cos(a2), 0, sin(a2))
                let reach2: Float = reach * rng.f(0.35, 0.6)
                var q3: V3 = V3(q0.x, -0.04, q0.z)
                q3 += d2 * reach2
                var q1: V3 = q0 + d2 * (reach2 * 0.3)
                q1 += V3(0, 0.05, 0)
                let q2y: Float = max(q0.y * 0.35, 0.1)
                let q2 = V3(q3.x - d2.x * reach2 * 0.1, q2y, q3.z - d2.z * reach2 * 0.1)
                addRoot(q0, q1, q2, q3, rA * 0.62, rA * 0.28)
            }
        }

        // cành thưa, ngắn, tán thu hẹp ở ngọn; lá dày ở đầu cành
        var shoots: [V3] = []
        let nBr = h > 4 ? 14 : 9
        let leafL = 0.19 + 0.011 * h
        let pairsMain = h > 4 ? 5 : 4
        for i in 0..<nBr {
            let k = (Float(i) + rng.f(0.1, 0.9)) / Float(nBr)
            let fy = h * (0.38 + 0.58 * k)
            let tt = min(max((fy - y0) / (h - y0), 0), 1)
            let c = axis(tt)
            let a = Float(i) * 2.399963 + rng.f(-0.3, 0.3)
            let dir = V3(cos(a), 0, sin(a))
            let L: Float = rng.f(0.5, 0.16 * h + 0.6) * (1.25 - 0.55 * k)
            let from: V3 = c + dir * (trunkR(tt) * 0.6)
            var p1: V3 = from + dir * (L * 0.35)
            p1 += V3(0, L * 0.22, 0)
            var p2: V3 = from + dir * (L * 0.72)
            p2 += V3(0, L * 0.34, 0)
            var tip: V3 = from + dir * L
            tip += V3(0, L * 0.38 + rng.f(0, 0.2), 0)
            let b0: Float = 0.022 + 0.0035 * h
            wood.tube([from, p1, p2, tip], radii: [b0, b0 * 0.8, b0 * 0.55, b0 * 0.35],
                      sides: 5, uRep: 1, vPerMeter: 5)
            let grow = simd_normalize((tip - p2) + V3(0, 0.25, 0))
            duocShoot(&wood, &oldLeaf, &youngLeaf, at: tip, dir: grow, pairs: pairsMain, leaf: leafL, &rng)
            shoots.append(tip)
            for _ in 0..<3 {
                let jx: Float = rng.f(-0.5, 0.5)
                let jy: Float = rng.f(0, 0.5)
                let jz: Float = rng.f(-0.5, 0.5)
                let sd = simd_normalize(dir * 0.6 + V3(jx, jy, jz))
                let sp: V3 = p2 + (tip - p2) * rng.f(0.2, 0.7)
                let st: V3 = sp + sd * rng.f(0.25, 0.45)
                wood.tube([sp, st], radii: [0.012, 0.007], sides: 4, uRep: 1, vPerMeter: 8)
                duocShoot(&wood, &oldLeaf, &youngLeaf, at: st, dir: sd, pairs: 3, leaf: leafL * 0.95, &rng)
                shoots.append(st)
            }
        }
        // chồi đầu ngọn thân
        let crown = axis(1) + V3(0, 0.25, 0)
        duocShoot(&wood, &oldLeaf, &youngLeaf, at: crown, dir: V3(0, 1, 0), pairs: pairsMain, leaf: leafL, &rng)
        for j in 0..<3 {
            let a = Float(j) * 2.09 + rng.f(0, 1)
            let sd = simd_normalize(V3(cos(a) * 0.7, 0.8, sin(a) * 0.7))
            let sp: V3 = axis(0.93)
            let st: V3 = sp + sd * rng.f(0.3, 0.5)
            wood.tube([sp, st], radii: [0.014, 0.007], sides: 4, uRep: 1, vPerMeter: 8)
            duocShoot(&wood, &oldLeaf, &youngLeaf, at: st, dir: sd, pairs: 3, leaf: leafL * 0.9, &rng)
            shoots.append(st)
        }

        // trái đước: rủ xuống từ gốc chùm lá, thường thành từng chùm
        let nf = fruits + fruits / 2
        if !shoots.isEmpty {
            for _ in 0..<nf {
                let sp = shoots[Int.random(in: 0..<shoots.count, using: &rng)]
                let ox: Float = rng.f(-0.12, 0.12)
                let oy: Float = rng.f(0.02, 0.10)
                let oz: Float = rng.f(-0.12, 0.12)
                let top: V3 = sp + V3(ox, -oy, oz)
                let len: Float = (0.24 + 0.022 * h) * rng.f(0.8, 1.15)
                let th: Float = rng.f(0, 0.28)
                let pa: Float = rng.f(0, 6.28)
                let hang = V3(sin(th) * cos(pa), -cos(th), sin(th) * sin(pa))
                let tip: V3 = top + hang * len
                fruitB.propagule(top: top, tip: tip, radius: 0.0125 + 0.0007 * h)
            }
        }

        if let w = wood.node(duocWoodMat(root: false)) { n.addChildNode(w) }
        if let r = rootB.node(duocWoodMat(root: true), shadow: false) { n.addChildNode(r) }
        if let f = fruitB.node(duocFruitMat(), shadow: false) { n.addChildNode(f) }
        if let l = oldLeaf.node(duocLeafMat(0), sway: 0.07) { n.addChildNode(l) }
        if let l = youngLeaf.node(duocLeafMat(1), sway: 0.09) { n.addChildNode(l) }
        return n
    }

    /// Cây đước con: trái đã rụng cắm thẳng xuống bùn (đầu nhọn chôn trong bùn), nhú vài cặp lá non.
    /// Mặt bùn trung bình ở độ cao 0.09.
    static func duocSaplings(_ count: Int, radius: Float, rng: inout SeededRNG) -> SCNNode {
        let n = SCNNode()
        var stick = MeshBatch()
        var twig = MeshBatch()
        var young = CardBatch()
        var old = CardBatch()
        for _ in 0..<count {
            let a = rng.f(0, 2 * Float.pi)
            let d = rng.f(0.8, max(radius, 0.9))
            let x = cos(a) * d
            let z = sin(a) * d
            let hgt = rng.f(0.25, 0.5)
            let lean = V3(rng.f(-0.12, 0.12), 0, rng.f(-0.12, 0.12))
            let topP = V3(x, 0.09 + hgt, z) + lean
            stick.propagule(top: topP, tip: V3(x, 0.06, z), radius: 0.013)
            duocShoot(&twig, &old, &young, at: topP, dir: simd_normalize(V3(lean.x, 1, lean.z)),
                      pairs: 2, leaf: 0.11, &rng)
        }
        if let s = stick.node(duocFruitMat(), shadow: false) { n.addChildNode(s) }
        if let t = twig.node(duocWoodMat(root: false), shadow: false) { n.addChildNode(t) }
        if let l = old.node(duocLeafMat(0), sway: 0.05) { n.addChildNode(l) }
        if let l = young.node(duocLeafMat(1), sway: 0.05) { n.addChildNode(l) }
        return n
    }

    /// Lá mục và trái đã rụng nằm trên bùn.
    static func duocLitter(leaves: Int, fallen: Int, radius: Float, rng: inout SeededRNG) -> SCNNode {
        let n = SCNNode()
        var dead = CardBatch()
        var fruitB = MeshBatch()
        for _ in 0..<leaves {
            let a = rng.f(0, 2 * Float.pi)
            let d = radius * rng.f(0, 1).squareRoot()
            let p = V3(cos(a) * d, 0.095, sin(a) * d)
            let ta = rng.f(0, 2 * Float.pi)
            dead.leaf(at: p, dir: V3(cos(ta), 0.04, sin(ta)), spin: rng.f(-0.15, 0.15),
                      w: 0.07, h: 0.14 * rng.f(0.8, 1.3), fold: 0.05, droop: 0.05, rows: 2)
        }
        for _ in 0..<fallen {
            let a = rng.f(0, 2 * Float.pi)
            let d = radius * rng.f(0.1, 1).squareRoot()
            let ta = rng.f(0, 2 * Float.pi)
            let len = rng.f(0.26, 0.38)
            let p = V3(cos(a) * d, 0.105, sin(a) * d)
            fruitB.propagule(top: p, tip: p + V3(cos(ta), 0, sin(ta)) * len, radius: 0.014)
        }
        if let l = dead.node(duocLeafMat(2)) { n.addChildNode(l) }
        if let f = fruitB.node(duocFruitMat(), shadow: false) { n.addChildNode(f) }
        return n
    }

    // MARK: Cây đước (cây lẻ)

    static func duoc(_ variant: Int, seed: UInt64) -> SCNNode {
        let root = SCNNode()
        var rng = SeededRNG(seed)
        let old = variant % 2 == 0                       // 0: đước già, 1: đước non
        let R: Float = old ? 3.2 : 2.3
        let pools: [(Float, Float, Float)] = old ? [(1.5, -1.1, 0.55)] : []
        root.addChildNode(mudDisc(radius: R, seed: seed, pools: pools))
        for p in pools { root.addChildNode(duocPuddle(x: p.0, z: p.1, radius: p.2)) }
        let h: Float = old ? rng.f(6.0, 7.5) : rng.f(2.8, 3.6)
        let tree = duocNode(height: h, roots: old ? 11 : 7, segs: 4, fruits: old ? 8 : 3, seed: seed &+ 11)
        tree.position = SCNVector3(0, 0.09, 0)
        root.addChildNode(tree)
        root.addChildNode(duocSaplings(old ? 6 : 3, radius: R - 0.4, rng: &rng))
        root.addChildNode(duocLitter(leaves: old ? 26 : 14, fallen: old ? 5 : 2, radius: R - 0.3, rng: &rng))
        return root
    }

    // MARK: Rừng đước (cụm nhiều cây trên bùn)

    static func rungDuoc(_ variant: Int, seed: UInt64) -> SCNNode {
        let root = SCNNode()
        var rng = SeededRNG(seed)
        let old = variant % 2 == 0                       // 0: rừng già cao, 1: rừng non dày
        let R: Float = 5.6
        let pools: [(Float, Float, Float)] = [(-2.2, 3.0, 1.1), (3.0, -2.4, 1.4), (0.6, 0.4, 0.8)]
        root.addChildNode(mudDisc(radius: R, seed: seed, pools: pools))
        for p in pools { root.addChildNode(duocPuddle(x: p.0, z: p.1, radius: p.2)) }

        // rải cây, cách nhau tối thiểu
        let target = old ? 7 : 12
        let minD: Float = old ? 2.0 : 1.25
        var pts: [SIMD2<Float>] = []
        var tries = 0
        while pts.count < target && tries < 300 {
            tries += 1
            let a = rng.f(0, 2 * Float.pi)
            let d = R * 0.72 * rng.f(0, 1).squareRoot()
            let p = SIMD2<Float>(cos(a) * d, sin(a) * d)
            var ok = true
            for q in pts where simd_length(p - q) < minD {
                ok = false
                break
            }
            if ok { pts.append(p) }
        }
        for (i, p) in pts.enumerated() {
            let h: Float = old ? rng.f(5.0, 7.2) : rng.f(2.4, 3.6)
            let t = duocNode(height: h, roots: old ? 7 : 5, segs: 3, fruits: old ? 4 : 1,
                             seed: seed &+ UInt64(i + 1) &* 7919)
            t.position = SCNVector3(p.x, 0.09, p.y)
            t.eulerAngles.y = rng.f(0, 2 * Float.pi)
            root.addChildNode(t)
        }
        root.addChildNode(duocSaplings(old ? 10 : 14, radius: R * 0.85, rng: &rng))
        root.addChildNode(duocLitter(leaves: old ? 70 : 90, fallen: old ? 10 : 8, radius: R * 0.9, rng: &rng))
        return root
    }

    // MARK: Chòi canh và vó tôm

    /// Chòi canh tôm: sàn tre trên bốn cột đước, mái lá hai dốc, lối vào ở phía -Z.
    static func choiTom() -> SCNNode {
        let r = SCNNode()
        let duocCol = rgb(0.62, 0.40, 0.30)
        let floorY: Float = 0.95
        let thatchTint = rgb(0.85, 0.78, 0.62)
        for sx: Float in [-0.95, 0.95] {
            for sz: Float in [-0.95, 0.95] {
                r.addChildNode(tcyl(0.07, 3.0, .woodDark, tint: duocCol, tileY: 2.4, x: sx, y: 1.55, z: sz, seg: 8))
            }
        }
        let brace = plain(rgb(0.80, 0.72, 0.45), rough: 0.7)
        r.addChildNode(link(V3(-0.95, 0.15, 0.95), V3(0.95, 0.9, 0.95), r1: 0.03, r2: 0.03, brace, seg: 5))
        r.addChildNode(link(V3(0.95, 0.15, 0.95), V3(-0.95, 0.9, 0.95), r1: 0.03, r2: 0.03, brace, seg: 5))
        // sàn
        r.addChildNode(tbox(2.3, 0.1, 2.3, .wood, tint: rgb(0.78, 0.68, 0.55), tile: 1.6, y: floorY))
        // vách lá thấp: hai bên và phía sau (phía -Z để trống làm lối vào)
        for sx: Float in [-1.0, 1.0] {
            r.addChildNode(tbox(0.05, 0.55, 2.0, .thatch, tint: thatchTint, tile: 1, x: sx, y: floorY + 0.32))
        }
        r.addChildNode(tbox(2.0, 0.55, 0.05, .thatch, tint: thatchTint, tile: 1, y: floorY + 0.32, z: 1.0))
        // mái lá hai dốc
        for sgn: Float in [-1, 1] {
            let slope = tbox(2.9, 0.14, 1.65, .thatch, tint: thatchTint, rough: 0.95, tile: 1.6,
                             y: 2.775, z: sgn * 0.65)
            slope.eulerAngles.x = sgn * 0.52
            r.addChildNode(slope)
        }
        r.addChildNode(tbox(2.95, 0.1, 0.2, .thatch, tint: thatchTint, tile: 1, y: 3.17))
        return r
    }

    /// Vó tôm trên cầu tre: gốc ở (0,0,0), vươn về phía -Z ra mặt nước.
    static func voTom() -> SCNNode {
        let r = SCNNode()
        let bambooMat = tex(.bamboo, tint: rgb(0.92, 0.85, 0.6), rx: 1, ry: 2)
        // sàn cầu tre ba cây ghép
        for sx: Float in [-0.12, 0, 0.12] {
            let p = tcyl(0.05, 1.6, .bamboo, tint: rgb(0.92, 0.85, 0.6), tileY: 1, x: sx, y: 0.62, z: -0.8, seg: 8)
            p.eulerAngles.x = Float.pi / 2
            r.addChildNode(p)
        }
        for sx: Float in [-0.12, 0.12] {
            r.addChildNode(cyl(0.05, 0.6, rgb(0.46, 0.34, 0.22), rough: 0.9, x: sx, y: 0.3, z: -1.4, seg: 6))
        }
        // trụ và cần vó
        r.addChildNode(tcyl(0.06, 2.6, .bamboo, tint: rgb(0.92, 0.85, 0.6), tileY: 1, y: 1.3, z: -1.6, seg: 8))
        r.addChildNode(link(V3(0, 2.5, -1.6), V3(0, 1.0, -4.0), r1: 0.05, r2: 0.03, bambooMat, seg: 6))
        // lưới vó
        let net = box(2.0, 0.03, 2.0, rgb(0.28, 0.34, 0.30), rough: 1, x: 0, y: 0.5, z: -4.3)
        net.eulerAngles.x = 0.35
        r.addChildNode(net)
        r.addChildNode(link(V3(-1.0, 0.45, -3.4), V3(1.0, 0.7, -5.2), r1: 0.025, r2: 0.025, bambooMat, seg: 5))
        r.addChildNode(link(V3(1.0, 0.45, -3.4), V3(-1.0, 0.7, -5.2), r1: 0.025, r2: 0.025, bambooMat, seg: 5))
        return r
    }

    // MARK: Vuông tôm (tôm - rừng)

    /// Kích thước 16 x 12 m. variant: 0 rừng bao (lỏi rừng giữa vuông), 1 dạng líp, 2 vuông quảng canh nhiều mặt nước.
    static func vuongTom(_ variant: Int, seed: UInt64) -> SCNNode {
        let root = SCNNode()
        var rng = SeededRNG(seed)
        let v = variant % 3
        let hx: Float = 8.0
        let hz: Float = 6.0
        let dk: Float = 1.3                              // bề rộng đê bao
        let wx = hx - dk
        let wz = hz - dk
        let dirt = rgb(0.60, 0.50, 0.40)
        let islet = rgb(0.34, 0.28, 0.22)

        // đáy vuông + nước lợ đục
        root.addChildNode(tbox(2 * wx + 0.4, 0.1, 2 * wz + 0.4, .mudWet, tint: rgb(0.62, 0.60, 0.56), tile: 3, y: 0.02))
        root.addChildNode(flowWater(2 * wx, 2 * wz, tint: mangroveWaterTint, period: 16))

        // đê bao đất phủ cỏ
        for sz: Float in [-1, 1] {
            root.addChildNode(tbox(2 * hx, 0.55, dk, .dirt, tint: dirt, tile: 2, y: 0.275, z: sz * (hz - dk / 2)))
            root.addChildNode(tbox(2 * hx, 0.05, dk * 0.7, .grass, tile: 2, y: 0.57, z: sz * (hz - dk / 2)))
        }
        for sx: Float in [-1, 1] {
            root.addChildNode(tbox(dk, 0.55, 2 * wz, .dirt, tint: dirt, tile: 2, x: sx * (hx - dk / 2), y: 0.275))
            root.addChildNode(tbox(dk * 0.7, 0.05, 2 * wz, .grass, tile: 2, x: sx * (hx - dk / 2), y: 0.57))
        }

        // phần rừng trong vuông
        if v == 0 {
            // rừng bao: lỏi rừng đước giữa vuông, mương nước chạy vòng quanh
            root.addChildNode(tbox(8.6, 0.34, 5.0, .mudWet, tint: nil, rough: 0.5, tile: 2, y: 0.17))
            let xs: [Float] = [-3.1, -1.05, 1.05, 3.1]
            let zs: [Float] = [-1.1, 1.1]
            var idx = 0
            for ox in xs {
                for oz in zs {
                    let t = duocNode(height: rng.f(5.0, 6.8), roots: 6, segs: 3, fruits: 3,
                                     seed: seed &+ UInt64(idx + 1) &* 104729)
                    t.position = SCNVector3(ox + rng.f(-0.35, 0.35), 0.34, oz + rng.f(-0.4, 0.4))
                    t.eulerAngles.y = rng.f(0, 2 * Float.pi)
                    root.addChildNode(t)
                    idx += 1
                }
            }
            let sap = duocSaplings(8, radius: 2.4, rng: &rng)
            sap.position = SCNVector3(0, 0.25, 0)
            root.addChildNode(sap)
        } else if v == 1 {
            // dạng líp: hai líp rừng xen kẽ ba dải mương
            let g: Float = (2 * wz - 4.8) / 3
            let lipZ: [Float] = [-wz + g + 1.2, -wz + g + 2.4 + g + 1.2]
            for (li, lz) in lipZ.enumerated() {
                root.addChildNode(tbox(8.6, 0.34, 2.4, .mudWet, tint: nil, rough: 0.5, tile: 2, y: 0.17, z: lz))
                for k in 0..<5 {
                    let ox = -3.6 + Float(k) * 1.8 + rng.f(-0.25, 0.25)
                    let t = duocNode(height: rng.f(4.0, 5.6), roots: 6, segs: 3, fruits: 2,
                                     seed: seed &+ UInt64(li * 5 + k + 1) &* 104729)
                    t.position = SCNVector3(ox, 0.34, lz + rng.f(-0.3, 0.3))
                    t.eulerAngles.y = rng.f(0, 2 * Float.pi)
                    root.addChildNode(t)
                }
            }
        }

        // đước non trồng trên đê sau
        let backZ = -(hz - dk / 2)
        let dikeTrees: [Float] = [-5.5, -1.5, 2.5]
        for (i, tx) in dikeTrees.enumerated() {
            let t = duocNode(height: rng.f(3.0, 3.8), roots: 5, segs: 3, fruits: 1,
                             seed: seed &+ UInt64(i + 40) &* 7919)
            t.position = SCNVector3(tx, 0.59, backZ)
            t.eulerAngles.y = rng.f(0, 2 * Float.pi)
            root.addChildNode(t)
        }

        // cống bọng lấy nước giữa đê trước, thông ra mương dẫn bên ngoài
        let frontZ = hz - dk / 2
        root.addChildNode(tbox(2.4, 0.8, 1.5, .concrete, tile: 1.2, y: 0.4, z: frontZ))
        for sx: Float in [-0.55, 0.55] {
            let pipe = cyl(0.3, 1.7, rgb(0.05, 0.05, 0.05), rough: 0.9, x: sx, y: 0.38, z: frontZ, seg: 16)
            pipe.eulerAngles.x = Float.pi / 2
            root.addChildNode(pipe)
        }
        for sx: Float in [-1.1, 1.1] {
            root.addChildNode(tbox(0.12, 1.3, 0.12, .woodDark, tile: 1, x: sx, y: 0.65, z: hz - dk - 0.1))
        }
        root.addChildNode(tbox(2.2, 0.5, 0.06, .wood, tint: rgb(0.70, 0.60, 0.48), tile: 1, y: 0.55, z: hz - dk - 0.1))
        let outZ = hz + 1.75
        root.addChildNode(tbox(2.4, 0.1, 3.5, .mudWet, tint: rgb(0.62, 0.60, 0.56), tile: 3, y: 0.02, z: outZ))
        let outWater = flowWater(2.0, 3.5, tint: mangroveWaterTint, period: 12)
        outWater.position = SCNVector3(0, 0.12, outZ)
        root.addChildNode(outWater)
        for sx: Float in [-1.45, 1.45] {
            root.addChildNode(tbox(0.7, 0.4, 3.5, .dirt, tint: dirt, tile: 2, x: sx, y: 0.2, z: outZ))
        }

        // chòi canh ở góc sau bên phải, có cầu tre nối từ đê
        let hut = choiTom()
        hut.position = SCNVector3(5.6, 0.07, -2.6)
        root.addChildNode(hut)
        for sx: Float in [-0.12, 0, 0.12] {
            let p = tcyl(0.05, 1.1, .bamboo, tint: rgb(0.92, 0.85, 0.6), tileY: 1, x: 5.6 + sx, y: 0.88, z: -4.2, seg: 8)
            p.eulerAngles.x = Float.pi / 2
            root.addChildNode(p)
        }
        for sx: Float in [-0.15, 0.15] {
            root.addChildNode(cyl(0.05, 0.85, rgb(0.46, 0.34, 0.22), rough: 0.9, x: 5.6 + sx, y: 0.45, z: -4.2, seg: 6))
        }

        // vó tôm ở góc trước bên trái (dạng líp và vuông quảng canh)
        if v != 0 {
            let vo = voTom()
            vo.position = SCNVector3(-5.4, 0, hz - dk)
            root.addChildNode(vo)
        }

        // xuồng nhỏ
        let boatSpots: [(Float, Float)] = [(-1.5, 3.6), (-2.0, 0.0), (1.5, -1.0)]
        let bs = boatSpots[v]
        let b = boat(0)
        b.position = SCNVector3(bs.0, 0, bs.1)
        b.eulerAngles.y = rng.f(-0.3, 0.3)
        b.scale = SCNVector3(0.8, 0.8, 0.8)
        bobWrap(b, seed: seed &+ 3)
        root.addChildNode(b)

        // bèo tây trôi trên mặt nước
        let beoSpots: [[(Float, Float)]] = [
            [(-5.6, 0.5), (5.8, -1.0), (-3.0, 3.7), (3.2, -3.7), (0.5, 3.6), (-5.8, -3.5)],
            [(-6.2, 0.0), (6.2, 1.0), (0.5, -0.1), (-3.5, -0.2), (3.8, 0.3)],
            [(-5.0, -3.5), (-2.0, 2.0), (3.0, -3.8), (4.0, 2.5), (-5.5, 0.5), (0.0, 0.0)]
        ]
        let beo = plain(rgb(0.34, 0.60, 0.24), rough: 0.6)
        for (bx, bz) in beoSpots[v] {
            let s = sphere(rng.f(0.35, 0.6), beo, x: bx, y: 0.14, z: bz, seg: 10)
            s.scale = SCNVector3(1.3, 0.12, 1.0)
            root.addChildNode(s)
        }
        return root
    }

    // MARK: Mương nước (nối giữa 2 điểm)

    /// Mương rộng 2.4 m. variant: 0 bờ đất cỏ, 1 kè cừ tràm, 2 bờ có đước con giữ đất.
    static func muong(from a: SIMD2<Float>, to b: SIMD2<Float>, variant: Int, seed: UInt64, join: LineJoin = .none) -> SCNNode {
        let (root, len) = lineRoot(from: a, to: b)
        var rng = SeededRNG(seed)
        let v = variant % 3
        let hw: Float = 1.2

        root.addChildNode(tbox(len, 0.1, 2 * hw + 0.3, .mudWet, tint: rgb(0.62, 0.60, 0.56), tile: 3, y: 0.02))
        root.addChildNode(flowWater(len, 2 * hw, tint: mangroveWaterTint, period: 12))

        let bankTint: UIColor = v == 0 ? rgb(0.66, 0.58, 0.46) : rgb(0.50, 0.42, 0.34)
        let topTex: Tex = v == 0 ? .grass : .dirt
        let topTint: UIColor? = v == 0 ? nil : bankTint
        for sign: Float in [-1, 1] {
            let bank = jbox(len, join, 0.5, 1.2, v == 0 ? .dirt : .mudWet, tint: v == 0 ? bankTint : rgb(0.80, 0.77, 0.72),
                            tile: 2, y: 0.12, z: sign * (hw + 0.45))
            bank.eulerAngles.x = sign * 0.38
            root.addChildNode(bank)
            root.addChildNode(jbox(len, join, 0.09, 0.8, topTex, tint: topTint, tile: 2, y: 0.34, z: sign * (hw + 0.85)))
        }

        if v == 1 {
            // kè cừ tràm: hàng cọc tràm đóng sát mép nước, giằng tre phía trên
            let poles = SCNNode()
            let pm = tex(.woodDark, tint: rgb(0.74, 0.62, 0.50), rough: 0.95, rx: 1, ry: 1)
            let count = max(Int(len / 0.5), 1)
            for sign: Float in [-1, 1] {
                for i in 0...count {
                    let x = -len / 2 + len * Float(i) / Float(count)
                    let hgt = 0.75 + rng.f(-0.08, 0.08)
                    let g = SCNCylinder(radius: 0.045, height: CGFloat(hgt))
                    g.radialSegmentCount = 6
                    g.materials = [pm]
                    let pn = SCNNode(geometry: g)
                    pn.position = SCNVector3(x, hgt / 2 - 0.05, sign * (hw + 0.08))
                    poles.addChildNode(pn)
                }
                poles.addChildNode(tbox(len, 0.05, 0.07, .bamboo, tile: 1, y: 0.62, z: sign * (hw + 0.17)))
            }
            root.addChildNode(poles.flattenedClone())
        } else if v == 2 {
            // đước con trồng xen kẽ hai bờ để giữ đất
            var k = 0
            var x = -len / 2 + 1.6
            while x < len / 2 - 1.0 {
                let sign: Float = k % 2 == 0 ? 1 : -1
                let t = duocNode(height: rng.f(2.4, 3.4), roots: 5, segs: 3, fruits: 1,
                                 seed: seed &+ UInt64(k + 1) &* 6271)
                t.position = SCNVector3(x + rng.f(-0.4, 0.4), 0.38, sign * (hw + 0.95))
                t.eulerAngles.y = rng.f(0, 2 * Float.pi)
                root.addChildNode(t)
                k += 1
                x += rng.f(3.4, 4.6)
            }
        }
        return root
    }
}
