import SceneKit
import UIKit
import simd

// MARK: - Rừng đước, vuông tôm và mương nước Cà Mau
//
// Tham khảo mô hình tôm - rừng ở Cà Mau (Năm Căn, Ngọc Hiển):
// - Cây đước (Rhizophora apiculata): thân thẳng cao 10 - 20 m, nhiều rễ chống cong chống xuống bùn,
//   lá dày thuôn bóng, trái hình trụ dài rủ xuống rồi cắm thẳng vào bùn thành cây con.
// - Vuông tôm: đê bao đất quanh vuông, mương nước bao quanh tán rừng ("rừng bao", lỏi giữa)
//   hoặc rừng trồng trên các líp xen kẽ mương ("dạng líp"); tỉ lệ khoảng 60% rừng, 40% mặt nước.
//   Có cống bọng lấy nước theo con nước, chòi canh, vó tôm, xuồng.
// - Mương nước: bờ đất cỏ, kè cừ tràm, hoặc bờ có đước con giữ đất.

extension Builder {

    // MARK: Nền bùn và mặt nước dùng chung

    static func mudMat(rx: Float = 3, ry: Float = 3) -> SCNMaterial {
        tex(.dirt, tint: rgb(0.40, 0.33, 0.27), rough: 0.35, rx: rx, ry: ry)
    }

    /// Nền bùn sình tròn (đất phù sa ngập mặn).
    static func mudDisc(radius r: Float, height h: Float = 0.1, y: Float = 0.04) -> SCNNode {
        let g = SCNCylinder(radius: CGFloat(r), height: CGFloat(h))
        g.radialSegmentCount = 36
        let m = mudMat(rx: max(r, 1), ry: max(r, 1))
        g.materials = [m, m, m]
        let n = SCNNode(geometry: g)
        n.position = SCNVector3(0, y, 0)
        return n
    }

    /// Mặt nước lợ đục có hiệu ứng chảy nhẹ. Nút gốc nằm sẵn ở độ cao 0.12.
    static func flowWater(_ w: Float, _ l: Float, tint: UIColor, period: Double = 14) -> SCNNode {
        let wm = SCNMaterial()
        wm.lightingModel = .physicallyBased
        wm.diffuse.contents = TextureLibrary.albedo(.water)
        wm.multiply.contents = tint
        wm.roughness.contents = 0.12
        wm.metalness.contents = 0.1
        if let nm = TextureLibrary.normal(.water) {
            wm.normal.contents = nm
            wm.normal.intensity = 1.0
        }
        let rx = max((w / 4).rounded(), 1)
        let ry = max((l / 4).rounded(), 1)
        for p in [wm.diffuse, wm.normal] {
            p.wrapS = .repeat
            p.wrapT = .repeat
            p.mipFilter = .linear
            p.contentsTransform = SCNMatrix4MakeScale(rx, ry, 1)
        }
        let g = SCNBox(width: CGFloat(w), height: 0.05, length: CGFloat(l), chamferRadius: 0)
        g.materials = [wm]
        let n = SCNNode(geometry: g)
        n.position = SCNVector3(0, 0.12, 0)
        n.castsShadow = false
        let flow = SCNAction.customAction(duration: period) { _, t in
            let u = Float(t / period)
            var a = SCNMatrix4MakeScale(rx, ry, 1)
            a.m41 = -u
            var b = SCNMatrix4MakeScale(rx, ry, 1)
            b.m41 = -2 * u
            b.m42 = 0.08 * sin(2 * Float.pi * u)
            wm.diffuse.contentsTransform = a
            wm.normal.contentsTransform = b
        }
        n.runAction(SCNAction.repeatForever(flow))
        return n
    }

    // MARK: Một cây đước (dùng chung cho cây lẻ, rừng, vuông tôm, bờ mương)

    /// Gốc cây ở (0, 0, 0). `roots` là số rễ chống, `segs` số đoạn mỗi rễ (nhiều đoạn thì cong mượt hơn nhưng nặng hơn).
    static func duocNode(height h: Float, roots: Int, segs: Int, fruits: Int, seed: UInt64) -> SCNNode {
        let n = SCNNode()
        var rng = SeededRNG(seed)
        let bark = barkMat(rgb(0.80, 0.66, 0.58))
        let rootMat = plain(rgb(0.50, 0.30, 0.22), rough: 0.9)
        let lx = rng.f(-0.18, 0.18)
        let lz = rng.f(-0.18, 0.18)
        let baseY = max(0.5, h * 0.12)
        let top = V3(lx, h, lz)

        // thân thẳng, hơi nghiêng
        n.addChildNode(link(V3(0, baseY, 0), top, r1: 0.035 * h + 0.05, r2: 0.014 * h + 0.03, bark, seg: 8))

        // rễ chống: đường cong bậc hai từ thân xuống bùn, đặc trưng của đước
        let rootCount = max(roots, 3)
        let segCount = max(segs, 2)
        func rad(_ t: Float) -> Float { 0.065 - 0.032 * t }
        for i in 0..<rootCount {
            let a = Float(i) / Float(rootCount) * 2 * Float.pi + rng.f(-0.35, 0.35)
            let startH = rng.f(baseY + 0.1, baseY + 0.22 * h + 0.3)
            let reach = rng.f(0.5, 0.18 * h + 0.5)
            let dx = cos(a)
            let dz = sin(a)
            let p0 = V3(dx * 0.05, startH, dz * 0.05)
            let p1 = V3(dx * reach * 0.85, startH + 0.25 + 0.04 * h, dz * reach * 0.85)
            let p2 = V3(dx * reach, 0, dz * reach)
            var prev = p0
            for s in 1...segCount {
                let t = Float(s) / Float(segCount)
                let t0 = Float(s - 1) / Float(segCount)
                let u = 1 - t
                let w0 = u * u
                let w1 = 2 * u * t
                let w2 = t * t
                let pt = p0 * w0 + p1 * w1 + p2 * w2
                n.addChildNode(link(prev, pt, r1: rad(t0), r2: rad(t), rootMat, seg: 5))
                prev = pt
            }
        }

        // cành và tán lá dày bóng
        let leafMat = TextureLibrary.foliageMaterial(.leafBroad, tint: rgb(0.70, 0.92, 0.58))
        var batch = CardBatch()
        var tips: [V3] = []
        let branchCount = h > 4 ? 7 : 5
        for i in 0..<branchCount {
            let a = Float(i) * 2 * Float.pi / Float(branchCount) + rng.f(-0.4, 0.4)
            let fy = h * rng.f(0.55, 0.9)
            let k = fy / h
            let from = V3(lx * k, fy, lz * k)
            let reach = rng.f(0.5, 0.2 * h + 0.3)
            let tip = V3(from.x + cos(a) * reach, fy + rng.f(0.4, 0.4 + 0.12 * h), from.z + sin(a) * reach)
            n.addChildNode(link(from, tip, r1: 0.05 + 0.01 * h, r2: 0.025, bark, seg: 5))
            tips.append(tip)
        }
        tips.append(V3(lx, h + 0.4, lz))
        let center = V3(lx, h * 0.6, lz)
        for tp in tips {
            var axis = tp - center
            if simd_length(axis) < 0.1 { axis = V3(0, 1, 0) }
            axis = simd_normalize(axis)
            leafSpray(&batch, at: tp, axis: axis, count: 14,
                      w: 0.22 + 0.02 * h, h: 0.4 + 0.03 * h,
                      spread: 1.0, droop: 0.2, spinRange: 3.1, &rng)
        }
        if let ln = batch.node(leafMat, sway: 0.08) { n.addChildNode(ln) }

        // trái đước: hình trụ dài rủ xuống
        let fruitMat = plain(rgb(0.46, 0.55, 0.24), rough: 0.5)
        for _ in 0..<fruits {
            let tp = tips[Int.random(in: 0..<tips.count, using: &rng)]
            let g = SCNCone(topRadius: 0.02, bottomRadius: 0.011, height: 0.34)
            g.radialSegmentCount = 6
            g.materials = [fruitMat]
            let f = SCNNode(geometry: g)
            f.position = SCNVector3(tp.x + rng.f(-0.3, 0.3), tp.y - rng.f(0.15, 0.4), tp.z + rng.f(-0.3, 0.3))
            n.addChildNode(f)
        }
        return n
    }

    /// Cây đước con: trái đã rụng cắm thẳng xuống bùn, nhú vài lá. Đáy ở độ cao 0.09 (mặt nền bùn).
    static func duocSaplings(_ count: Int, radius: Float, rng: inout SeededRNG) -> SCNNode {
        let n = SCNNode()
        let stickMat = plain(rgb(0.46, 0.55, 0.24), rough: 0.5)
        let leafMat = TextureLibrary.foliageMaterial(.leafBroad, tint: rgb(0.70, 0.95, 0.55))
        var batch = CardBatch()
        for _ in 0..<count {
            let a = rng.f(0, 2 * Float.pi)
            let d = rng.f(0.8, max(radius, 0.9))
            let x = cos(a) * d
            let z = sin(a) * d
            let hgt = rng.f(0.25, 0.5)
            let g = SCNCylinder(radius: 0.012, height: CGFloat(hgt))
            g.radialSegmentCount = 5
            g.materials = [stickMat]
            let s = SCNNode(geometry: g)
            s.position = SCNVector3(x, 0.09 + hgt / 2, z)
            n.addChildNode(s)
            leafSpray(&batch, at: V3(x, 0.09 + hgt, z), axis: V3(0, 1, 0), count: 3,
                      w: 0.09, h: 0.18, spread: 0.8, droop: 0.2, spinRange: 3.0, &rng)
        }
        if let ln = batch.node(leafMat, sway: 0.05) { n.addChildNode(ln) }
        return n
    }

    // MARK: Cây đước (cây lẻ)

    static func duoc(_ variant: Int, seed: UInt64) -> SCNNode {
        let root = SCNNode()
        var rng = SeededRNG(seed)
        let old = variant % 2 == 0                       // 0: đước già, 1: đước non
        root.addChildNode(mudDisc(radius: old ? 2.6 : 1.8))
        let h: Float = old ? rng.f(6.0, 7.5) : rng.f(2.8, 3.6)
        let tree = duocNode(height: h, roots: old ? 11 : 6, segs: 4, fruits: old ? 8 : 3, seed: seed &+ 11)
        tree.position = SCNVector3(0, 0.09, 0)
        root.addChildNode(tree)
        root.addChildNode(duocSaplings(old ? 6 : 3, radius: old ? 2.3 : 1.5, rng: &rng))
        return root
    }

    // MARK: Rừng đước (cụm nhiều cây trên bùn)

    static func rungDuoc(_ variant: Int, seed: UInt64) -> SCNNode {
        let root = SCNNode()
        var rng = SeededRNG(seed)
        let old = variant % 2 == 0                       // 0: rừng già cao, 1: rừng non dày
        let R: Float = 5.2
        root.addChildNode(mudDisc(radius: R))

        // vũng nước đọng trên bùn
        let pool = plain(rgb(0.30, 0.40, 0.36), rough: 0.06, metal: 0.1)
        let pools: [(Float, Float, Float)] = [(-2.2, 3.0, 1.1), (3.0, -2.4, 1.4), (0.6, 0.4, 0.8)]
        for (px, pz, pr) in pools {
            let g = SCNCylinder(radius: CGFloat(pr), height: 0.02)
            g.radialSegmentCount = 24
            g.materials = [pool, pool, pool]
            let pn = SCNNode(geometry: g)
            pn.position = SCNVector3(px, 0.095, pz)
            pn.castsShadow = false
            root.addChildNode(pn)
        }

        // rải cây, cách nhau tối thiểu
        let target = old ? 7 : 11
        let minD: Float = old ? 2.0 : 1.35
        var pts: [SIMD2<Float>] = []
        var tries = 0
        while pts.count < target && tries < 300 {
            tries += 1
            let a = rng.f(0, 2 * Float.pi)
            let d = R * 0.78 * rng.f(0, 1).squareRoot()
            let p = SIMD2<Float>(cos(a) * d, sin(a) * d)
            var ok = true
            for q in pts where simd_length(p - q) < minD {
                ok = false
                break
            }
            if ok { pts.append(p) }
        }
        for (i, p) in pts.enumerated() {
            let h: Float = old ? rng.f(5.0, 7.2) : rng.f(2.4, 3.6)
            let t = duocNode(height: h, roots: old ? 7 : 5, segs: 3, fruits: old ? 4 : 1,
                             seed: seed &+ UInt64(i + 1) &* 7919)
            t.position = SCNVector3(p.x, 0.09, p.y)
            t.eulerAngles.y = rng.f(0, 2 * Float.pi)
            root.addChildNode(t)
        }
        root.addChildNode(duocSaplings(old ? 10 : 14, radius: R * 0.85, rng: &rng))
        return root
    }

    // MARK: Chòi canh và vó tôm

    /// Chòi canh tôm: sàn tre trên bốn cột đước, mái lá hai dốc, lối vào ở phía -Z.
    static func choiTom() -> SCNNode {
        let r = SCNNode()
        let duocCol = rgb(0.62, 0.40, 0.30)
        let floorY: Float = 0.95
        let thatchTint = rgb(0.85, 0.78, 0.62)
        for sx: Float in [-0.95, 0.95] {
            for sz: Float in [-0.95, 0.95] {
                r.addChildNode(tcyl(0.07, 3.0, .woodDark, tint: duocCol, tileY: 2.4, x: sx, y: 1.55, z: sz, seg: 8))
            }
        }
        let brace = plain(rgb(0.80, 0.72, 0.45), rough: 0.7)
        r.addChildNode(link(V3(-0.95, 0.15, 0.95), V3(0.95, 0.9, 0.95), r1: 0.03, r2: 0.03, brace, seg: 5))
        r.addChildNode(link(V3(0.95, 0.15, 0.95), V3(-0.95, 0.9, 0.95), r1: 0.03, r2: 0.03, brace, seg: 5))
        // sàn
        r.addChildNode(tbox(2.3, 0.1, 2.3, .wood, tint: rgb(0.78, 0.68, 0.55), tile: 1.6, y: floorY))
        // vách lá thấp: hai bên và phía sau (phía -Z để trống làm lối vào)
        for sx: Float in [-1.0, 1.0] {
            r.addChildNode(tbox(0.05, 0.55, 2.0, .thatch, tint: thatchTint, tile: 1, x: sx, y: floorY + 0.32))
        }
        r.addChildNode(tbox(2.0, 0.55, 0.05, .thatch, tint: thatchTint, tile: 1, y: floorY + 0.32, z: 1.0))
        // mái lá hai dốc
        for sgn: Float in [-1, 1] {
            let slope = tbox(2.9, 0.14, 1.65, .thatch, tint: thatchTint, rough: 0.95, tile: 1.6,
                             y: 2.775, z: sgn * 0.65)
            slope.eulerAngles.x = sgn * 0.52
            r.addChildNode(slope)
        }
        r.addChildNode(tbox(2.95, 0.1, 0.2, .thatch, tint: thatchTint, tile: 1, y: 3.17))
        return r
    }

    /// Vó tôm trên cầu tre: gốc ở (0,0,0), vươn về phía -Z ra mặt nước.
    static func voTom() -> SCNNode {
        let r = SCNNode()
        let bambooMat = tex(.bamboo, tint: rgb(0.92, 0.85, 0.6), rx: 1, ry: 2)
        // sàn cầu tre ba cây ghép
        for sx: Float in [-0.12, 0, 0.12] {
            let p = tcyl(0.05, 1.6, .bamboo, tint: rgb(0.92, 0.85, 0.6), tileY: 1, x: sx, y: 0.62, z: -0.8, seg: 8)
            p.eulerAngles.x = Float.pi / 2
            r.addChildNode(p)
        }
        for sx: Float in [-0.12, 0.12] {
            r.addChildNode(cyl(0.05, 0.6, rgb(0.46, 0.34, 0.22), rough: 0.9, x: sx, y: 0.3, z: -1.4, seg: 6))
        }
        // trụ và cần vó
        r.addChildNode(tcyl(0.06, 2.6, .bamboo, tint: rgb(0.92, 0.85, 0.6), tileY: 1, y: 1.3, z: -1.6, seg: 8))
        r.addChildNode(link(V3(0, 2.5, -1.6), V3(0, 1.0, -4.0), r1: 0.05, r2: 0.03, bambooMat, seg: 6))
        // lưới vó
        let net = box(2.0, 0.03, 2.0, rgb(0.28, 0.34, 0.30), rough: 1, x: 0, y: 0.5, z: -4.3)
        net.eulerAngles.x = 0.35
        r.addChildNode(net)
        r.addChildNode(link(V3(-1.0, 0.45, -3.4), V3(1.0, 0.7, -5.2), r1: 0.025, r2: 0.025, bambooMat, seg: 5))
        r.addChildNode(link(V3(1.0, 0.45, -3.4), V3(-1.0, 0.7, -5.2), r1: 0.025, r2: 0.025, bambooMat, seg: 5))
        return r
    }

    // MARK: Vuông tôm (tôm - rừng)

    /// Kích thước 16 x 12 m. variant: 0 rừng bao (lỏi rừng giữa vuông), 1 dạng líp, 2 vuông quảng canh nhiều mặt nước.
    static func vuongTom(_ variant: Int, seed: UInt64) -> SCNNode {
        let root = SCNNode()
        var rng = SeededRNG(seed)
        let v = variant % 3
        let hx: Float = 8.0
        let hz: Float = 6.0
        let dk: Float = 1.3                              // bề rộng đê bao
        let wx = hx - dk
        let wz = hz - dk
        let dirt = rgb(0.60, 0.50, 0.40)
        let islet = rgb(0.34, 0.28, 0.22)

        // đáy vuông + nước lợ đục
        root.addChildNode(tbox(2 * wx + 0.4, 0.1, 2 * wz + 0.4, .dirt, tint: rgb(0.42, 0.36, 0.30), tile: 3, y: 0.02))
        root.addChildNode(flowWater(2 * wx, 2 * wz, tint: rgb(0.66, 0.74, 0.60), period: 16))

        // đê bao đất phủ cỏ
        for sz: Float in [-1, 1] {
            root.addChildNode(tbox(2 * hx, 0.55, dk, .dirt, tint: dirt, tile: 2, y: 0.275, z: sz * (hz - dk / 2)))
            root.addChildNode(tbox(2 * hx, 0.05, dk * 0.7, .grass, tile: 2, y: 0.57, z: sz * (hz - dk / 2)))
        }
        for sx: Float in [-1, 1] {
            root.addChildNode(tbox(dk, 0.55, 2 * wz, .dirt, tint: dirt, tile: 2, x: sx * (hx - dk / 2), y: 0.275))
            root.addChildNode(tbox(dk * 0.7, 0.05, 2 * wz, .grass, tile: 2, x: sx * (hx - dk / 2), y: 0.57))
        }

        // phần rừng trong vuông
        if v == 0 {
            // rừng bao: lỏi rừng đước giữa vuông, mương nước chạy vòng quanh
            root.addChildNode(tbox(8.6, 0.34, 5.0, .dirt, tint: islet, rough: 0.4, tile: 2, y: 0.17))
            let xs: [Float] = [-3.1, -1.05, 1.05, 3.1]
            let zs: [Float] = [-1.1, 1.1]
            var idx = 0
            for ox in xs {
                for oz in zs {
                    let t = duocNode(height: rng.f(5.0, 6.8), roots: 6, segs: 3, fruits: 3,
                                     seed: seed &+ UInt64(idx + 1) &* 104729)
                    t.position = SCNVector3(ox + rng.f(-0.35, 0.35), 0.34, oz + rng.f(-0.4, 0.4))
                    t.eulerAngles.y = rng.f(0, 2 * Float.pi)
                    root.addChildNode(t)
                    idx += 1
                }
            }
            let sap = duocSaplings(8, radius: 2.4, rng: &rng)
            sap.position = SCNVector3(0, 0.25, 0)
            root.addChildNode(sap)
        } else if v == 1 {
            // dạng líp: hai líp rừng xen kẽ ba dải mương
            let g: Float = (2 * wz - 4.8) / 3
            let lipZ: [Float] = [-wz + g + 1.2, -wz + g + 2.4 + g + 1.2]
            for (li, lz) in lipZ.enumerated() {
                root.addChildNode(tbox(8.6, 0.34, 2.4, .dirt, tint: islet, rough: 0.4, tile: 2, y: 0.17, z: lz))
                for k in 0..<5 {
                    let ox = -3.6 + Float(k) * 1.8 + rng.f(-0.25, 0.25)
                    let t = duocNode(height: rng.f(4.0, 5.6), roots: 6, segs: 3, fruits: 2,
                                     seed: seed &+ UInt64(li * 5 + k + 1) &* 104729)
                    t.position = SCNVector3(ox, 0.34, lz + rng.f(-0.3, 0.3))
                    t.eulerAngles.y = rng.f(0, 2 * Float.pi)
                    root.addChildNode(t)
                }
            }
        }

        // đước non trồng trên đê sau
        let backZ = -(hz - dk / 2)
        let dikeTrees: [Float] = [-5.5, -1.5, 2.5]
        for (i, tx) in dikeTrees.enumerated() {
            let t = duocNode(height: rng.f(3.0, 3.8), roots: 5, segs: 3, fruits: 1,
                             seed: seed &+ UInt64(i + 40) &* 7919)
            t.position = SCNVector3(tx, 0.59, backZ)
            t.eulerAngles.y = rng.f(0, 2 * Float.pi)
            root.addChildNode(t)
        }

        // cống bọng lấy nước giữa đê trước, thông ra mương dẫn bên ngoài
        let frontZ = hz - dk / 2
        root.addChildNode(tbox(2.4, 0.8, 1.5, .concrete, tile: 1.2, y: 0.4, z: frontZ))
        for sx: Float in [-0.55, 0.55] {
            let pipe = cyl(0.3, 1.7, rgb(0.05, 0.05, 0.05), rough: 0.9, x: sx, y: 0.38, z: frontZ, seg: 16)
            pipe.eulerAngles.x = Float.pi / 2
            root.addChildNode(pipe)
        }
        for sx: Float in [-1.1, 1.1] {
            root.addChildNode(tbox(0.12, 1.3, 0.12, .woodDark, tile: 1, x: sx, y: 0.65, z: hz - dk - 0.1))
        }
        root.addChildNode(tbox(2.2, 0.5, 0.06, .wood, tint: rgb(0.70, 0.60, 0.48), tile: 1, y: 0.55, z: hz - dk - 0.1))
        let outZ = hz + 1.75
        root.addChildNode(tbox(2.4, 0.1, 3.5, .dirt, tint: rgb(0.42, 0.36, 0.30), tile: 3, y: 0.02, z: outZ))
        let outWater = flowWater(2.0, 3.5, tint: rgb(0.66, 0.74, 0.60), period: 12)
        outWater.position = SCNVector3(0, 0.12, outZ)
        root.addChildNode(outWater)
        for sx: Float in [-1.45, 1.45] {
            root.addChildNode(tbox(0.7, 0.4, 3.5, .dirt, tint: dirt, tile: 2, x: sx, y: 0.2, z: outZ))
        }

        // chòi canh ở góc sau bên phải, có cầu tre nối từ đê
        let hut = choiTom()
        hut.position = SCNVector3(5.6, 0.07, -2.6)
        root.addChildNode(hut)
        for sx: Float in [-0.12, 0, 0.12] {
            let p = tcyl(0.05, 1.1, .bamboo, tint: rgb(0.92, 0.85, 0.6), tileY: 1, x: 5.6 + sx, y: 0.88, z: -4.2, seg: 8)
            p.eulerAngles.x = Float.pi / 2
            root.addChildNode(p)
        }
        for sx: Float in [-0.15, 0.15] {
            root.addChildNode(cyl(0.05, 0.85, rgb(0.46, 0.34, 0.22), rough: 0.9, x: 5.6 + sx, y: 0.45, z: -4.2, seg: 6))
        }

        // vó tôm ở góc trước bên trái (dạng líp và vuông quảng canh)
        if v != 0 {
            let vo = voTom()
            vo.position = SCNVector3(-5.4, 0, hz - dk)
            root.addChildNode(vo)
        }

        // xuồng nhỏ
        let boatSpots: [(Float, Float)] = [(-1.5, 3.6), (-2.0, 0.0), (1.5, -1.0)]
        let bs = boatSpots[v]
        let b = boat(0)
        b.position = SCNVector3(bs.0, 0, bs.1)
        b.eulerAngles.y = rng.f(-0.3, 0.3)
        b.scale = SCNVector3(0.8, 0.8, 0.8)
        bobWrap(b, seed: seed &+ 3)
        root.addChildNode(b)

        // bèo tây trôi trên mặt nước
        let beoSpots: [[(Float, Float)]] = [
            [(-5.6, 0.5), (5.8, -1.0), (-3.0, 3.7), (3.2, -3.7), (0.5, 3.6), (-5.8, -3.5)],
            [(-6.2, 0.0), (6.2, 1.0), (0.5, -0.1), (-3.5, -0.2), (3.8, 0.3)],
            [(-5.0, -3.5), (-2.0, 2.0), (3.0, -3.8), (4.0, 2.5), (-5.5, 0.5), (0.0, 0.0)]
        ]
        let beo = plain(rgb(0.34, 0.60, 0.24), rough: 0.6)
        for (bx, bz) in beoSpots[v] {
            let s = sphere(rng.f(0.35, 0.6), beo, x: bx, y: 0.14, z: bz, seg: 10)
            s.scale = SCNVector3(1.3, 0.12, 1.0)
            root.addChildNode(s)
        }
        return root
    }

    // MARK: Mương nước (nối giữa 2 điểm)

    /// Mương rộng 2.4 m. variant: 0 bờ đất cỏ, 1 kè cừ tràm, 2 bờ có đước con giữ đất.
    static func muong(from a: SIMD2<Float>, to b: SIMD2<Float>, variant: Int, seed: UInt64) -> SCNNode {
        let (root, len) = lineRoot(from: a, to: b)
        var rng = SeededRNG(seed)
        let v = variant % 3
        let hw: Float = 1.2

        root.addChildNode(tbox(len, 0.1, 2 * hw + 0.3, .dirt, tint: rgb(0.42, 0.36, 0.30), tile: 3, y: 0.02))
        root.addChildNode(flowWater(len, 2 * hw, tint: rgb(0.66, 0.74, 0.60), period: 12))

        let bankTint: UIColor = v == 0 ? rgb(0.66, 0.58, 0.46) : rgb(0.50, 0.42, 0.34)
        let topTex: Tex = v == 0 ? .grass : .dirt
        let topTint: UIColor? = v == 0 ? nil : bankTint
        for sign: Float in [-1, 1] {
            let bank = tbox(len, 0.5, 1.2, .dirt, tint: bankTint, tile: 2, y: 0.12, z: sign * (hw + 0.45))
            bank.eulerAngles.x = sign * 0.38
            root.addChildNode(bank)
            root.addChildNode(tbox(len, 0.09, 0.8, topTex, tint: topTint, tile: 2, y: 0.34, z: sign * (hw + 0.85)))
        }

        if v == 1 {
            // kè cừ tràm: hàng cọc tràm đóng sát mép nước, giằng tre phía trên
            let poles = SCNNode()
            let pm = tex(.woodDark, tint: rgb(0.74, 0.62, 0.50), rough: 0.95, rx: 1, ry: 1)
            let count = max(Int(len / 0.5), 1)
            for sign: Float in [-1, 1] {
                for i in 0...count {
                    let x = -len / 2 + len * Float(i) / Float(count)
                    let hgt = 0.75 + rng.f(-0.08, 0.08)
                    let g = SCNCylinder(radius: 0.045, height: CGFloat(hgt))
                    g.radialSegmentCount = 6
                    g.materials = [pm]
                    let pn = SCNNode(geometry: g)
                    pn.position = SCNVector3(x, hgt / 2 - 0.05, sign * (hw + 0.08))
                    poles.addChildNode(pn)
                }
                poles.addChildNode(tbox(len, 0.05, 0.07, .bamboo, tile: 1, y: 0.62, z: sign * (hw + 0.17)))
            }
            root.addChildNode(poles.flattenedClone())
        } else if v == 2 {
            // đước con trồng xen kẽ hai bờ để giữ đất
            var k = 0
            var x = -len / 2 + 1.6
            while x < len / 2 - 1.0 {
                let sign: Float = k % 2 == 0 ? 1 : -1
                let t = duocNode(height: rng.f(2.4, 3.4), roots: 5, segs: 3, fruits: 1,
                                 seed: seed &+ UInt64(k + 1) &* 6271)
                t.position = SCNVector3(x + rng.f(-0.4, 0.4), 0.38, sign * (hw + 0.95))
                t.eulerAngles.y = rng.f(0, 2 * Float.pi)
                root.addChildNode(t)
                k += 1
                x += rng.f(3.4, 4.6)
            }
        }
        return root
    }
}
