import UIKit
import UniformTypeIdentifiers

/// Bộ chọn file của UIKit. Ổn định hơn `.fileImporter` của SwiftUI (nút Mở không bấm được
/// khi view có nhiều lớp trình bày). Dùng asCopy: file được chép sẵn vào vùng của app.
final class DocPicker: NSObject, UIDocumentPickerDelegate {
    static let shared = DocPicker()
    private var completion: (([URL]) -> Void)?

    /// asCopy = false dùng cho chọn thư mục (đồng bộ): app được cấp quyền truy cập thư mục đó.
    func present(types: [UTType], asCopy: Bool = true, multiple: Bool = true,
                 completion: @escaping ([URL]) -> Void) {
        guard let top = Self.topViewController() else { return }
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: types, asCopy: asCopy)
        picker.allowsMultipleSelection = multiple
        picker.delegate = self
        self.completion = completion
        top.present(picker, animated: true)
    }

    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        let done = completion
        completion = nil
        done?(urls)
    }

    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        completion = nil
    }

    private static func topViewController() -> UIViewController? {
        let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
        let scene = scenes.first(where: { $0.activationState == .foregroundActive }) ?? scenes.first
        let window = scene?.windows.first(where: { $0.isKeyWindow }) ?? scene?.windows.first
        var vc = window?.rootViewController
        while let next = vc?.presentedViewController { vc = next }
        return vc
    }
}
