import SceneKit
import UIKit
import simd

/// Đọc file GLB / GLTF (không cần thư viện ngoài): hình học, vật liệu PBR, texture, cây node.
/// Chưa hỗ trợ: nén Draco / Meshopt, xương, hoạt ảnh.
struct GLTFFailure: LocalizedError {
    let text: String
    var errorDescription: String? { text }
}

enum GLTFLoader {
    static func loadScene(at url: URL) throws -> SCNScene {
        let reader = try GLTFReader(url: url)
        return try reader.buildScene()
    }
}

private final class GLTFReader {
    let baseURL: URL
    let glbBin: Data?
    let accessors: [[String: Any]]
    let bufferViews: [[String: Any]]
    let bufferList: [[String: Any]]
    let nodeList: [[String: Any]]
    let meshList: [[String: Any]]
    let materialList: [[String: Any]]
    let textureList: [[String: Any]]
    let imageList: [[String: Any]]
    let sceneList: [[String: Any]]
    let sceneIndex: Int

    var bufferCache: [Int: Data] = [:]
    var imageCache: [Int: UIImage] = [:]
    var materialCache: [Int: SCNMaterial] = [:]

    // MARK: Đọc số nhị phân

    static func u32(_ d: Data, _ o: Int) -> UInt32 {
        UInt32(d[o]) | (UInt32(d[o + 1]) << 8) | (UInt32(d[o + 2]) << 16) | (UInt32(d[o + 3]) << 24)
    }

    static func u16(_ d: Data, _ o: Int) -> UInt16 {
        UInt16(d[o]) | (UInt16(d[o + 1]) << 8)
    }

    // MARK: Khởi tạo

    init(url: URL) throws {
        baseURL = url.deletingLastPathComponent()
        let data = try Data(contentsOf: url)
        var jsonData = data
        var bin: Data? = nil

        if url.pathExtension.lowercased() == "glb" {
            let s = data.startIndex
            guard data.count >= 20, GLTFReader.u32(data, s) == 0x46546C67 else {
                throw GLTFFailure(text: "không phải file GLB hợp lệ")
            }
            var off = 12
            var j: Data? = nil
            while off + 8 <= data.count {
                let len = Int(GLTFReader.u32(data, s + off))
                let type = GLTFReader.u32(data, s + off + 4)
                let start = off + 8
                if start + len > data.count { break }
                let chunk = data.subdata(in: (s + start)..<(s + start + len))
                if type == 0x4E4F534A { j = chunk }
                else if type == 0x004E4942, bin == nil { bin = chunk }
                off = start + ((len + 3) & ~3)
            }
            guard let jj = j else { throw GLTFFailure(text: "GLB thiếu phần JSON") }
            jsonData = jj
        }

        guard let obj = try JSONSerialization.jsonObject(with: jsonData) as? [String: Any] else {
            throw GLTFFailure(text: "JSON của file không đọc được")
        }

        let required = (obj["extensionsRequired"] as? [String]) ?? []
        for e in required where e.lowercased().contains("draco") || e.lowercased().contains("meshopt") {
            throw GLTFFailure(text: "mô hình bị nén (\(e)), hãy xuất lại không nén")
        }

        glbBin = bin
        accessors = obj["accessors"] as? [[String: Any]] ?? []
        bufferViews = obj["bufferViews"] as? [[String: Any]] ?? []
        bufferList = obj["buffers"] as? [[String: Any]] ?? []
        nodeList = obj["nodes"] as? [[String: Any]] ?? []
        meshList = obj["meshes"] as? [[String: Any]] ?? []
        materialList = obj["materials"] as? [[String: Any]] ?? []
        textureList = obj["textures"] as? [[String: Any]] ?? []
        imageList = obj["images"] as? [[String: Any]] ?? []
        sceneList = obj["scenes"] as? [[String: Any]] ?? []
        sceneIndex = obj["scene"] as? Int ?? 0
    }

    // MARK: Buffer / accessor

    func loadURI(_ uri: String) -> Data? {
        if uri.hasPrefix("data:") {
            guard let comma = uri.firstIndex(of: ",") else { return nil }
            let payload = String(uri[uri.index(after: comma)...])
            return Data(base64Encoded: payload, options: .ignoreUnknownCharacters)
        }
        let name = uri.removingPercentEncoding ?? uri
        return try? Data(contentsOf: baseURL.appendingPathComponent(name))
    }

    func buffer(_ i: Int) -> Data? {
        if let b = bufferCache[i] { return b }
        guard i >= 0, i < bufferList.count else { return nil }
        var result: Data? = nil
        if let uri = bufferList[i]["uri"] as? String {
            result = loadURI(uri)
        } else if i == 0 {
            result = glbBin
        }
        if let r = result { bufferCache[i] = r }
        return result
    }

    func viewInfo(_ i: Int) -> (data: Data, base: Int, stride: Int)? {
        guard i >= 0, i < bufferViews.count,
              let b = bufferViews[i]["buffer"] as? Int,
              let data = buffer(b) else { return nil }
        let base = bufferViews[i]["byteOffset"] as? Int ?? 0
        let stride = bufferViews[i]["byteStride"] as? Int ?? 0
        return (data, base, stride)
    }

    func value(_ d: Data, _ o: Int, _ ct: Int, _ norm: Bool) -> Float {
        switch ct {
        case 5126:
            return Float(bitPattern: GLTFReader.u32(d, o))
        case 5125:
            return Float(GLTFReader.u32(d, o))
        case 5123:
            let v = Float(GLTFReader.u16(d, o))
            return norm ? v / 65535 : v
        case 5122:
            let v = Float(Int16(bitPattern: GLTFReader.u16(d, o)))
            return norm ? max(v / 32767, -1) : v
        case 5121:
            let v = Float(d[o])
            return norm ? v / 255 : v
        case 5120:
            let v = Float(Int8(bitPattern: d[o]))
            return norm ? max(v / 127, -1) : v
        default:
            return 0
        }
    }

    /// Đọc accessor thành mảng Float phẳng.
    func readFloats(_ idx: Int) -> (values: [Float], comps: Int, count: Int)? {
        guard idx >= 0, idx < accessors.count else { return nil }
        let a = accessors[idx]
        guard let ct = a["componentType"] as? Int,
              let count = a["count"] as? Int,
              let type = a["type"] as? String else { return nil }
        let table: [String: Int] = ["SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4,
                                    "MAT2": 4, "MAT3": 9, "MAT4": 16]
        guard let comps = table[type], count >= 0 else { return nil }
        let normalized = a["normalized"] as? Bool ?? false
        let compSize = (ct == 5120 || ct == 5121) ? 1 : ((ct == 5122 || ct == 5123) ? 2 : 4)

        var out = [Float](repeating: 0, count: count * comps)
        if let bvIdx = a["bufferView"] as? Int {
            guard let v = viewInfo(bvIdx) else { return nil }
            let accOff = a["byteOffset"] as? Int ?? 0
            let elemSize = compSize * comps
            let step = v.stride > 0 ? v.stride : elemSize
            for i in 0..<count {
                let rowStart = v.base + accOff + i * step
                if rowStart + elemSize > v.data.count { return nil }
                for c in 0..<comps {
                    let o = v.data.startIndex + rowStart + c * compSize
                    out[i * comps + c] = value(v.data, o, ct, normalized)
                }
            }
        }
        return (out, comps, count)
    }

    // MARK: Hình ảnh / vật liệu

    func image(forTexture t: Int) -> UIImage? {
        guard t >= 0, t < textureList.count, let s = textureList[t]["source"] as? Int else { return nil }
        if let c = imageCache[s] { return c }
        guard s >= 0, s < imageList.count else { return nil }
        var data: Data? = nil
        if let uri = imageList[s]["uri"] as? String {
            data = loadURI(uri)
        } else if let bv = imageList[s]["bufferView"] as? Int, let v = viewInfo(bv) {
            let len = bufferViews[bv]["byteLength"] as? Int ?? 0
            let st = v.data.startIndex + v.base
            if len > 0, st + len <= v.data.endIndex {
                data = v.data.subdata(in: st..<(st + len))
            }
        }
        guard let d = data, let img = UIImage(data: d) else { return nil }
        imageCache[s] = img
        return img
    }

    func material(_ index: Int?) -> SCNMaterial {
        let key = index ?? -1
        if let m = materialCache[key] { return m }
        let m = SCNMaterial()
        m.lightingModel = .physicallyBased
        m.diffuse.contents = UIColor(white: 0.8, alpha: 1)
        m.metalness.contents = 0.0
        m.roughness.contents = 0.8
        m.isDoubleSided = false

        if let i = index, i >= 0, i < materialList.count {
            let md = materialList[i]
            m.isDoubleSided = md["doubleSided"] as? Bool ?? false

            if let pbr = md["pbrMetallicRoughness"] as? [String: Any] {
                if let f = pbr["baseColorFactor"] as? [Double], f.count == 4 {
                    m.diffuse.contents = UIColor(red: CGFloat(f[0]), green: CGFloat(f[1]),
                                                 blue: CGFloat(f[2]), alpha: CGFloat(f[3]))
                }
                if let t = pbr["baseColorTexture"] as? [String: Any],
                   let ti = t["index"] as? Int, let img = image(forTexture: ti) {
                    m.diffuse.contents = img
                    m.diffuse.wrapS = .repeat
                    m.diffuse.wrapT = .repeat
                }
                // Cảnh chưa có phản xạ môi trường: kim loại cao sẽ đen sì, nên giới hạn lại.
                let metal = pbr["metallicFactor"] as? Double ?? 0.0
                let rough = pbr["roughnessFactor"] as? Double ?? 0.8
                m.metalness.contents = min(metal, 0.3)
                m.roughness.contents = max(rough, 0.35)
            }
            if let nt = md["normalTexture"] as? [String: Any],
               let ti = nt["index"] as? Int, let img = image(forTexture: ti) {
                m.normal.contents = img
                m.normal.wrapS = .repeat
                m.normal.wrapT = .repeat
            }
            if let e = md["emissiveFactor"] as? [Double], e.count == 3, e.contains(where: { $0 > 0 }) {
                m.emission.contents = UIColor(red: CGFloat(e[0]), green: CGFloat(e[1]),
                                              blue: CGFloat(e[2]), alpha: 1)
            }
            if let et = md["emissiveTexture"] as? [String: Any],
               let ti = et["index"] as? Int, let img = image(forTexture: ti) {
                m.emission.contents = img
            }
        }
        materialCache[key] = m
        return m
    }

    // MARK: Hình học

    func computeNormals(_ v: [SCNVector3], _ idx: [UInt32]) -> [SCNVector3] {
        var acc = [SIMD3<Float>](repeating: SIMD3<Float>(0, 0, 0), count: v.count)
        var t = 0
        while t + 2 < idx.count {
            let a = Int(idx[t]), b = Int(idx[t + 1]), c = Int(idx[t + 2])
            let pa = SIMD3<Float>(v[a].x, v[a].y, v[a].z)
            let pb = SIMD3<Float>(v[b].x, v[b].y, v[b].z)
            let pc = SIMD3<Float>(v[c].x, v[c].y, v[c].z)
            let n = simd_cross(pb - pa, pc - pa)
            acc[a] += n
            acc[b] += n
            acc[c] += n
            t += 3
        }
        return acc.map { n in
            let l = simd_length(n)
            let u = l > 0 ? n / l : SIMD3<Float>(0, 1, 0)
            return SCNVector3(u.x, u.y, u.z)
        }
    }

    func geometry(for prim: [String: Any]) -> SCNGeometry? {
        let mode = prim["mode"] as? Int ?? 4
        guard mode == 4 else { return nil }   // chỉ nhận tam giác
        guard let attrs = prim["attributes"] as? [String: Int],
              let posIdx = attrs["POSITION"],
              let pos = readFloats(posIdx), pos.comps == 3, pos.count > 0 else { return nil }
        let n = pos.count

        var verts: [SCNVector3] = []
        verts.reserveCapacity(n)
        for i in 0..<n {
            verts.append(SCNVector3(pos.values[i * 3], pos.values[i * 3 + 1], pos.values[i * 3 + 2]))
        }

        var idx: [UInt32]
        if let ii = prim["indices"] as? Int, let ir = readFloats(ii) {
            idx = ir.values.map { UInt32(max($0, 0)) }
        } else {
            idx = (0..<n).map { UInt32($0) }
        }
        idx = Array(idx.prefix(idx.count - idx.count % 3))
        guard idx.count >= 3 else { return nil }
        if let mx = idx.max(), Int(mx) >= n { return nil }

        var sources: [SCNGeometrySource] = [SCNGeometrySource(vertices: verts)]

        if let ni = attrs["NORMAL"], let nr = readFloats(ni), nr.comps == 3, nr.count == n {
            var ns: [SCNVector3] = []
            ns.reserveCapacity(n)
            for i in 0..<n {
                ns.append(SCNVector3(nr.values[i * 3], nr.values[i * 3 + 1], nr.values[i * 3 + 2]))
            }
            sources.append(SCNGeometrySource(normals: ns))
        } else {
            sources.append(SCNGeometrySource(normals: computeNormals(verts, idx)))
        }

        if let ti = attrs["TEXCOORD_0"], let tc = readFloats(ti), tc.comps == 2, tc.count == n {
            var ts: [CGPoint] = []
            ts.reserveCapacity(n)
            for i in 0..<n {
                // glTF gốc ảnh ở góc trên-trái, SceneKit ở góc dưới-trái → lật trục v
                ts.append(CGPoint(x: CGFloat(tc.values[i * 2]), y: CGFloat(1 - tc.values[i * 2 + 1])))
            }
            sources.append(SCNGeometrySource(textureCoordinates: ts))
        }

        let data = idx.withUnsafeBufferPointer { Data(buffer: $0) }
        let element = SCNGeometryElement(data: data, primitiveType: .triangles,
                                         primitiveCount: idx.count / 3, bytesPerIndex: 4)
        let g = SCNGeometry(sources: sources, elements: [element])
        g.materials = [material(prim["material"] as? Int)]
        return g
    }

    // MARK: Cây node

    func node(_ i: Int, depth: Int) -> SCNNode? {
        guard i >= 0, i < nodeList.count, depth < 64 else { return nil }
        let d = nodeList[i]
        let n = SCNNode()
        n.name = d["name"] as? String

        if let m = d["matrix"] as? [Double], m.count == 16 {
            let f = m.map { Float($0) }
            n.simdTransform = simd_float4x4(columns: (
                SIMD4<Float>(f[0], f[1], f[2], f[3]),
                SIMD4<Float>(f[4], f[5], f[6], f[7]),
                SIMD4<Float>(f[8], f[9], f[10], f[11]),
                SIMD4<Float>(f[12], f[13], f[14], f[15])))
        } else {
            if let t = d["translation"] as? [Double], t.count == 3 {
                n.simdPosition = SIMD3<Float>(Float(t[0]), Float(t[1]), Float(t[2]))
            }
            if let r = d["rotation"] as? [Double], r.count == 4 {
                n.simdOrientation = simd_quatf(ix: Float(r[0]), iy: Float(r[1]),
                                               iz: Float(r[2]), r: Float(r[3]))
            }
            if let s = d["scale"] as? [Double], s.count == 3 {
                n.simdScale = SIMD3<Float>(Float(s[0]), Float(s[1]), Float(s[2]))
            }
        }

        if let mi = d["mesh"] as? Int, mi >= 0, mi < meshList.count,
           let prims = meshList[mi]["primitives"] as? [[String: Any]] {
            for p in prims {
                if let g = geometry(for: p) {
                    n.addChildNode(SCNNode(geometry: g))
                }
            }
        }
        if let kids = d["children"] as? [Int] {
            for k in kids {
                if let c = node(k, depth: depth + 1) { n.addChildNode(c) }
            }
        }
        return n
    }

    func buildScene() throws -> SCNScene {
        let scene = SCNScene()
        var roots: [Int] = []
        if sceneIndex >= 0, sceneIndex < sceneList.count,
           let r = sceneList[sceneIndex]["nodes"] as? [Int] {
            roots = r
        } else if let first = sceneList.first, let r = first["nodes"] as? [Int] {
            roots = r
        } else {
            var isChild = Set<Int>()
            for nd in nodeList { for k in (nd["children"] as? [Int] ?? []) { isChild.insert(k) } }
            roots = (0..<nodeList.count).filter { !isChild.contains($0) }
        }
        for r in roots {
            if let n = node(r, depth: 0) { scene.rootNode.addChildNode(n) }
        }
        if scene.rootNode.childNodes.isEmpty {
            throw GLTFFailure(text: "không có hình học để hiển thị")
        }
        return scene
    }
}
