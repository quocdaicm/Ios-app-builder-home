import SceneKit
import SceneKit.ModelIO
import ModelIO
import SwiftUI
import UIKit

enum Tool: String, CaseIterable, Identifiable {
    case select, stilt, tole, house, coconut, nipa, grass, tree, pine, tower
    case canal, road, bridge, boat, erase

    var id: String { rawValue }

    var icon: String {
        switch self {
        case .select:  return "👆"
        case .stilt:   return "🛖"
        case .tole:    return "🏡"
        case .house:   return "🏠"
        case .coconut: return "🌴"
        case .nipa:    return "🌿"
        case .grass:   return "🌾"
        case .tree:    return "🌳"
        case .pine:    return "🌲"
        case .tower:   return "🏢"
        case .canal:   return "🌊"
        case .road:    return "🛣️"
        case .bridge:  return "🌉"
        case .boat:    return "🛶"
        case .erase:   return "🗑️"
        }
    }

    var title: String {
        switch self {
        case .select:  return "Chọn"
        case .stilt:   return "Nhà sàn"
        case .tole:    return "Nhà tôn"
        case .house:   return "Nhà ngói"
        case .coconut: return "Dừa"
        case .nipa:    return "Dừa nước"
        case .grass:   return "Cỏ"
        case .tree:    return "Cây"
        case .pine:    return "Thông"
        case .tower:   return "Tòa nhà"
        case .canal:   return "Kênh"
        case .road:    return "Đường"
        case .bridge:  return "Cầu khỉ"
        case .boat:    return "Xuồng"
        case .erase:   return "Xóa"
        }
    }

    var hint: String {
        switch self {
        case .select:  return "Chạm vào vật thể để chọn, rồi xoay / đổi cỡ / đổi kiểu / dời."
        case .stilt:   return "Chạm lên nền để đặt nhà sàn mái lá."
        case .tole:    return "Chạm lên nền để đặt nhà tôn vách ván."
        case .house:   return "Chạm lên nền để đặt nhà ngói."
        case .coconut: return "Chạm lên nền để trồng dừa."
        case .nipa:    return "Chạm ven kênh để trồng dừa nước."
        case .grass:   return "Chạm lên nền để thêm bụi cỏ. Bấm “Màu” để đổi cỏ xanh / cỏ khô / cỏ đậm."
        case .tree:    return "Chạm lên nền để trồng cây."
        case .pine:    return "Chạm lên nền để trồng cây thông."
        case .tower:   return "Chạm lên nền để đặt tòa nhà cao tầng."
        case .canal:   return "Chạm điểm đầu, rồi chạm các điểm tiếp theo để đào kênh. Chọn kênh rồi bấm “Màu” để đổi bờ đất / kè gạch."
        case .road:    return "Chạm điểm đầu, rồi chạm các điểm tiếp theo. Chọn đường rồi bấm “Màu” để đổi nhựa / bê tông / đất."
        case .bridge:  return "Chạm hai điểm hai bên bờ kênh để bắc cầu khỉ."
        case .boat:    return "Chạm lên mặt kênh để thả xuồng. Dùng Chọn → Xoay để quay đầu."
        case .erase:   return "Chạm vào vật thể để xóa."
        }
    }

    var kind: Kind? {
        switch self {
        case .stilt:   return .stilt
        case .tole:    return .tole
        case .house:   return .house
        case .coconut: return .coconut
        case .nipa:    return .nipa
        case .grass:   return .grass
        case .tree:    return .tree
        case .pine:    return .pine
        case .tower:   return .tower
        case .canal:   return .canal
        case .road:    return .road
        case .bridge:  return .bridge
        case .boat:    return .boat
        default:       return nil
        }
    }

    var isLine: Bool { kind?.isLine ?? false }
}

enum ExportFormat {
    case obj, usdz, scn

    var ext: String {
        switch self {
        case .obj:  return "obj"
        case .usdz: return "usdz"
        case .scn:  return "scn"
        }
    }
}

struct ShareItem: Identifiable {
    let id = UUID()
    let url: URL
}

struct ExportError: LocalizedError {
    let text: String
    var errorDescription: String? { text }
}

final class SceneController: ObservableObject {
    let scene = SCNScene()
    let world = SCNNode()          // chỉ chứa các vật thể người dùng đặt (dùng để xuất file)
    let cameraNode = SCNNode()
    private let ring = SCNNode()   // vòng chọn
    private let marker = SCNNode() // cột đánh dấu điểm đầu của đường / kênh / cầu
    private var nodes: [UUID: SCNNode] = [:]
    private var undoStack: [UUID] = []

    @Published var items: [Item] = []
    @Published var tool: Tool = .stilt
    @Published var selectedID: UUID? = nil
    @Published var roadStart: SIMD2<Float>? = nil
    @Published var moveMode = false
    @Published var snapToGrid = true
    @Published var includeGround = true
    @Published var message = Tool.stilt.hint
    @Published var shareItem: ShareItem? = nil

    init() {
        scene.rootNode.addChildNode(world)
        buildSky()
        buildGround()
        buildLights()
        buildCamera()
        buildOverlays()
        message = "Đang chuẩn bị hình ảnh…"
        TextureLibrary.preload { [weak self] in
            guard let self = self else { return }
            self.loadProject()
            self.message = self.tool.hint
        }
    }

    // MARK: - Dựng cảnh

    /// Màu chân trời, dùng chung cho nền trời và sương mù để hòa vào nhau.
    private static let horizon = UIColor(red: 0.80, green: 0.88, blue: 0.94, alpha: 1)

    private func buildSky() {
        let sky = Self.skyImage()
        scene.background.contents = sky
        scene.lightingEnvironment.contents = sky      // phản chiếu bầu trời lên kính, kim loại, nước
        scene.lightingEnvironment.intensity = 1.1
        scene.fogColor = Self.horizon
        scene.fogStartDistance = 110
        scene.fogEndDistance = 420
        scene.fogDensityExponent = 1.2
    }

    /// Ảnh bầu trời toàn cảnh (equirectangular): xanh đậm ở đỉnh, trắng ở chân trời, mây, mặt trời.
    static func skyImage() -> UIImage {
        let size = CGSize(width: 1024, height: 512)
        let fmt = UIGraphicsImageRendererFormat()
        fmt.scale = 1
        fmt.opaque = true
        return UIGraphicsImageRenderer(size: size, format: fmt).image { ctx in
            let c = ctx.cgContext
            let cs = CGColorSpaceCreateDeviceRGB()
            let colors = [
                UIColor(red: 0.20, green: 0.45, blue: 0.82, alpha: 1).cgColor,
                UIColor(red: 0.52, green: 0.73, blue: 0.93, alpha: 1).cgColor,
                horizon.cgColor,
                UIColor(red: 0.62, green: 0.70, blue: 0.55, alpha: 1).cgColor,
                UIColor(red: 0.30, green: 0.40, blue: 0.24, alpha: 1).cgColor
            ] as CFArray
            let grad = CGGradient(colorsSpace: cs, colors: colors, locations: [0, 0.30, 0.50, 0.56, 1])!
            c.drawLinearGradient(grad, start: .zero, end: CGPoint(x: 0, y: size.height), options: [])

            // mây
            var s: UInt64 = 424242
            func rnd() -> CGFloat {
                s = s &* 6364136223846793005 &+ 1442695040888963407
                return CGFloat((s >> 33) % 10000) / 10000
            }
            for _ in 0..<26 {
                let cx = rnd() * size.width
                let cy = size.height * (0.12 + rnd() * 0.30)
                let n = 8 + Int(rnd() * 8)
                for _ in 0..<n {
                    let rx = 30 + rnd() * 60
                    let ry = 8 + rnd() * 16
                    c.setFillColor(UIColor(white: 1, alpha: 0.10 + rnd() * 0.12).cgColor)
                    c.fillEllipse(in: CGRect(x: cx + (rnd() - 0.5) * 140 - rx, y: cy + (rnd() - 0.5) * 24 - ry,
                                             width: rx * 2, height: ry * 2))
                }
            }
            // mặt trời
            let sun = CGPoint(x: size.width * 0.62, y: size.height * 0.22)
            let sg = CGGradient(colorsSpace: cs,
                                colors: [UIColor(white: 1, alpha: 1).cgColor,
                                         UIColor(red: 1, green: 0.95, blue: 0.8, alpha: 0.5).cgColor,
                                         UIColor(red: 1, green: 0.95, blue: 0.8, alpha: 0).cgColor] as CFArray,
                                locations: [0, 0.25, 1])!
            c.drawRadialGradient(sg, startCenter: sun, startRadius: 0, endCenter: sun, endRadius: 90, options: [])
        }
    }

    private func buildGround() {
        // nền cỏ thật (PBR + vân nổi), lặp mỗi ô 4m
        let plane = SCNPlane(width: 600, height: 600)
        let m = TextureLibrary.material(.grass, roughness: 1, repeatX: 150, repeatY: 150)
        plane.materials = [m]
        let n = SCNNode(geometry: plane)
        n.eulerAngles.x = -Float.pi / 2
        n.name = "ground"
        scene.rootNode.addChildNode(n)

        // lưới mờ giúp canh vị trí
        let grid = SCNPlane(width: 160, height: 160)
        let gm = SCNMaterial()
        gm.diffuse.contents = Self.gridImage()
        gm.diffuse.wrapS = .repeat
        gm.diffuse.wrapT = .repeat
        gm.diffuse.contentsTransform = SCNMatrix4MakeScale(16, 16, 1)
        gm.lightingModel = .constant
        gm.writesToDepthBuffer = false
        gm.isDoubleSided = true
        grid.materials = [gm]
        let gn = SCNNode(geometry: grid)
        gn.eulerAngles.x = -Float.pi / 2
        gn.position = SCNVector3(0, 0.012, 0)
        gn.castsShadow = false
        gn.renderingOrder = -1
        scene.rootNode.addChildNode(gn)
    }

    static func gridImage() -> UIImage {
        let size = CGSize(width: 500, height: 500)
        let fmt = UIGraphicsImageRendererFormat()
        fmt.scale = 1
        fmt.opaque = false
        return UIGraphicsImageRenderer(size: size, format: fmt).image { _ in
            UIColor(white: 1, alpha: 0.16).setStroke()
            let path = UIBezierPath()
            for i in 0...10 {
                let p = CGFloat(i) * 50
                path.move(to: CGPoint(x: p, y: 0))
                path.addLine(to: CGPoint(x: p, y: 500))
                path.move(to: CGPoint(x: 0, y: p))
                path.addLine(to: CGPoint(x: 500, y: p))
            }
            path.lineWidth = 2
            path.stroke()
        }
    }

    private func buildLights() {
        let ambient = SCNNode()
        let a = SCNLight()
        a.type = .ambient
        a.intensity = 180          // phần lớn ánh sáng nền đã đến từ bầu trời (IBL)
        a.color = UIColor(red: 0.85, green: 0.92, blue: 1.0, alpha: 1)
        ambient.light = a
        scene.rootNode.addChildNode(ambient)

        let sun = SCNNode()
        let l = SCNLight()
        l.type = .directional
        l.intensity = 1900
        l.color = UIColor(red: 1.0, green: 0.95, blue: 0.86, alpha: 1)
        l.temperature = 5800
        l.castsShadow = true
        l.shadowMode = .deferred
        l.shadowRadius = 5
        l.shadowSampleCount = 8
        l.shadowMapSize = CGSize(width: 2048, height: 2048)
        l.shadowColor = UIColor(white: 0, alpha: 0.45)
        l.automaticallyAdjustsShadowProjection = true
        l.maximumShadowDistance = 140
        l.shadowCascadeCount = 3
        sun.light = l
        sun.eulerAngles = SCNVector3(-Float.pi / 3.2, Float.pi / 4, 0)
        scene.rootNode.addChildNode(sun)
    }

    private func buildCamera() {
        let cam = SCNCamera()
        cam.fieldOfView = 55
        cam.zNear = 0.5
        cam.zFar = 1200
        cam.wantsHDR = true
        cam.wantsExposureAdaptation = false
        cam.exposureOffset = -0.3
        cam.bloomIntensity = 0.25
        cam.bloomThreshold = 1.0
        cam.bloomBlurRadius = 8
        cam.saturation = 1.1
        cam.contrast = 0.12
        cam.vignettingIntensity = 0.25
        cam.vignettingPower = 1.0
        cameraNode.camera = cam
        cameraNode.position = SCNVector3(0, 28, 34)
        cameraNode.look(at: SCNVector3(0, 0, 0))
        scene.rootNode.addChildNode(cameraNode)
    }

    private func buildOverlays() {
        let torus = SCNTorus(ringRadius: 3, pipeRadius: 0.07)
        let rm = SCNMaterial()
        rm.diffuse.contents = UIColor.yellow
        rm.emission.contents = UIColor.yellow
        rm.lightingModel = .constant
        torus.materials = [rm]
        ring.geometry = torus
        ring.castsShadow = false
        ring.isHidden = true
        scene.rootNode.addChildNode(ring)

        let cyl = SCNCylinder(radius: 0.45, height: 1.5)
        let mm = SCNMaterial()
        mm.diffuse.contents = UIColor.red
        mm.lightingModel = .constant
        cyl.materials = [mm]
        marker.geometry = cyl
        marker.castsShadow = false
        marker.isHidden = true
        scene.rootNode.addChildNode(marker)
    }

    private func refreshOverlays() {
        if let id = selectedID, let it = items.first(where: { $0.id == id }) {
            ring.isHidden = false
            if it.kind.isLine {
                ring.position = SCNVector3((it.x + it.x2) / 2, 0.45, (it.z + it.z2) / 2)
                ring.scale = SCNVector3(1, 1, 1)
            } else {
                ring.position = SCNVector3(it.x, 0.15, it.z)
                ring.scale = SCNVector3(it.scale, 1, it.scale)
            }
        } else {
            ring.isHidden = true
        }
        if let s = roadStart {
            marker.isHidden = false
            marker.position = SCNVector3(s.x, 0.75, s.y)
        } else {
            marker.isHidden = true
        }
    }

    // MARK: - Chạm màn hình

    func setTool(_ t: Tool) {
        tool = t
        roadStart = nil
        moveMode = false
        if t != .select { selectedID = nil }
        message = t.hint
        refreshOverlays()
    }

    func handleTap(at point: CGPoint, in view: SCNView) {
        switch tool {
        case .select:
            if moveMode, let id = selectedID, let g = groundPoint(point, in: view) {
                move(id, to: g)
                moveMode = false
                message = "Đã dời."
                return
            }
            selectedID = pickID(point, in: view)
            moveMode = false
            message = selectedID == nil ? Tool.select.hint : "Đã chọn. Dùng thanh nút bên dưới."
            refreshOverlays()
        case .erase:
            if let id = pickID(point, in: view) { remove(id) }
        case .road, .canal, .bridge:
            guard let kind = tool.kind, let g = groundPoint(point, in: view) else { return }
            if let s = roadStart {
                if s != g { addLine(kind, from: s, to: g) }
                if kind == .bridge {
                    roadStart = nil
                    message = Tool.bridge.hint
                } else {
                    roadStart = g          // nối tiếp đoạn sau
                    message = "Chạm điểm tiếp theo, hoặc bấm “Dừng”."
                }
            } else {
                roadStart = g
                message = "Chạm điểm cuối."
            }
            refreshOverlays()
        default:
            if let kind = tool.kind, let g = groundPoint(point, in: view) {
                add(kind, at: g)
            }
        }
    }

    func stopRoad() {
        roadStart = nil
        message = tool.hint
        refreshOverlays()
    }

    /// Chiếu tia từ ngón tay xuống mặt phẳng y = 0.
    func groundPoint(_ p: CGPoint, in view: SCNView) -> SIMD2<Float>? {
        let a = view.unprojectPoint(SCNVector3(Float(p.x), Float(p.y), 0))
        let b = view.unprojectPoint(SCNVector3(Float(p.x), Float(p.y), 1))
        let dy = b.y - a.y
        guard abs(dy) > 0.0001 else { return nil }
        let t = -a.y / dy
        guard t > 0 else { return nil }
        var x = a.x + (b.x - a.x) * t
        var z = a.z + (b.z - a.z) * t
        guard abs(x) < 80, abs(z) < 80 else { return nil }
        if snapToGrid {
            x = x.rounded()
            z = z.rounded()
        }
        return SIMD2<Float>(x, z)
    }

    func pickID(_ p: CGPoint, in view: SCNView) -> UUID? {
        let options: [SCNHitTestOption: Any] = [
            .searchMode: SCNHitTestSearchMode.all.rawValue
        ]
        for hit in view.hitTest(p, options: options) {
            var n: SCNNode? = hit.node
            while let cur = n {
                if let name = cur.name, let id = UUID(uuidString: name), nodes[id] != nil {
                    return id
                }
                n = cur.parent
            }
        }
        return nil
    }

    // MARK: - Thêm / sửa / xóa

    private func insert(_ it: Item) {
        let n = Builder.node(for: it)
        world.addChildNode(n)
        nodes[it.id] = n
        items.append(it)
    }

    func add(_ kind: Kind, at p: SIMD2<Float>) {
        // Chống đặt chồng khi bấm đúp (đúp chạm cũng là thao tác đặt lại camera)
        if items.contains(where: { $0.kind == kind && abs($0.x - p.x) < 0.5 && abs($0.z - p.y) < 0.5 }) {
            return
        }
        var it = Item(kind: kind, x: p.x, z: p.y)
        it.colorIndex = Int.random(in: 0..<kind.variantCount)
        insert(it)
        undoStack.append(it.id)
        autosave()
    }

    func addLine(_ kind: Kind, from a: SIMD2<Float>, to b: SIMD2<Float>) {
        var it = Item(kind: kind, x: a.x, z: a.y)
        it.x2 = b.x
        it.z2 = b.y
        insert(it)
        undoStack.append(it.id)
        autosave()
    }

    func remove(_ id: UUID) {
        nodes[id]?.removeFromParentNode()
        nodes[id] = nil
        items.removeAll { $0.id == id }
        if selectedID == id { selectedID = nil }
        refreshOverlays()
        autosave()
    }

    func undo() {
        while let last = undoStack.popLast() {
            if nodes[last] != nil {
                remove(last)
                return
            }
        }
    }

    func clearAll() {
        for (_, n) in nodes { n.removeFromParentNode() }
        nodes.removeAll()
        items.removeAll()
        undoStack.removeAll()
        selectedID = nil
        roadStart = nil
        refreshOverlays()
        autosave()
    }

    private func update(_ id: UUID, _ change: (inout Item) -> Void) {
        guard let i = items.firstIndex(where: { $0.id == id }) else { return }
        change(&items[i])
        let it = items[i]
        nodes[id]?.removeFromParentNode()
        let n = Builder.node(for: it)
        world.addChildNode(n)
        nodes[id] = n
        refreshOverlays()
        autosave()
    }

    func move(_ id: UUID, to p: SIMD2<Float>) {
        update(id) { it in
            if it.kind.isLine {
                let dx = p.x - (it.x + it.x2) / 2
                let dz = p.y - (it.z + it.z2) / 2
                it.x += dx
                it.x2 += dx
                it.z += dz
                it.z2 += dz
            } else {
                it.x = p.x
                it.z = p.y
            }
        }
    }

    func rotateSelected() {
        guard let id = selectedID else { return }
        update(id) { it in
            if !it.kind.isLine { it.rot += Float.pi / 4 }
        }
    }

    func scaleSelected(_ factor: Float) {
        guard let id = selectedID else { return }
        update(id) { it in
            if !it.kind.isLine { it.scale = min(max(it.scale * factor, 0.4), 4) }
        }
    }

    func recolorSelected() {
        guard let id = selectedID else { return }
        update(id) { it in
            it.colorIndex = (it.colorIndex + 1) % max(it.kind.variantCount, 1)
        }
    }

    func deleteSelected() {
        if let id = selectedID { remove(id) }
    }

    func toggleMove() {
        moveMode.toggle()
        message = moveMode ? "Chạm lên nền nơi muốn đặt vật thể." : "Đã hủy dời."
    }

    // MARK: - Cảnh mẫu

    private func samplePlace(_ kind: Kind, _ x: Float, _ z: Float, rot: Float = 0, variant: Int? = nil) {
        var it = Item(kind: kind, x: x, z: z)
        it.rot = rot
        it.colorIndex = variant ?? Int.random(in: 0..<kind.variantCount)
        insert(it)
    }

    private func sampleLine(_ kind: Kind, _ a: SIMD2<Float>, _ b: SIMD2<Float>, variant: Int) {
        var it = Item(kind: kind, x: a.x, z: a.y)
        it.x2 = b.x
        it.z2 = b.y
        it.colorIndex = variant
        insert(it)
    }

    /// Khu phố đô thị mẫu
    func addSample() {
        clearAll()
        sampleLine(.road, SIMD2<Float>(-30, 0), SIMD2<Float>(30, 0), variant: 0)
        sampleLine(.road, SIMD2<Float>(0, -30), SIMD2<Float>(0, 30), variant: 0)

        for x in stride(from: -24 as Float, through: 24, by: 8) where abs(x) > 6 {
            samplePlace(.house, x, -5)
            samplePlace(.house, x, 5, rot: Float.pi)
        }
        for z in stride(from: -24 as Float, through: 24, by: 8) where abs(z) > 6 {
            samplePlace(.house, -5, z, rot: Float.pi / 2)
            samplePlace(.house, 5, z, rot: -Float.pi / 2)
        }
        for sx: Float in [-1, 1] {
            for sz: Float in [-1, 1] {
                samplePlace(.tower, sx * 16, sz * 16)
                samplePlace(.tree, sx * 12, sz * 10)
                samplePlace(.pine, sx * 20, sz * 10)
                samplePlace(.pine, sx * 22, sz * 20)
                samplePlace(.grass, sx * 9, sz * 14)
                samplePlace(.grass, sx * 26, sz * 6)
            }
        }
        autosave()
        message = "Đã tạo khu phố mẫu. Thử bấm Menu → Xuất OBJ."
    }

    /// Xóm ven kênh miền Tây mẫu
    func addSampleMekong() {
        clearAll()
        sampleLine(.canal, SIMD2<Float>(-40, 0), SIMD2<Float>(0, 0), variant: 0)   // bờ đất
        sampleLine(.canal, SIMD2<Float>(0, 0), SIMD2<Float>(40, 0), variant: 1)    // kè gạch
        sampleLine(.road, SIMD2<Float>(-40, -16), SIMD2<Float>(40, -16), variant: 1) // đường bê tông
        sampleLine(.road, SIMD2<Float>(0, -16), SIMD2<Float>(0, -4), variant: 2)     // đường đất ra cầu
        sampleLine(.bridge, SIMD2<Float>(0, -4), SIMD2<Float>(0, 4), variant: 0)

        var i = 0
        for x in stride(from: -36 as Float, through: 36, by: 9) where x != 0 {
            samplePlace(.stilt, x, -9.5, variant: i % 3)                 // bờ bắc, quay mặt ra kênh
            samplePlace(.coconut, x + 4.5, -7.5)
            samplePlace(.tole, x, 8, rot: Float.pi, variant: i % 5)      // bờ nam
            samplePlace(.coconut, x + 4.5, 7.5)
            samplePlace(.grass, x + 2, -4.2)
            samplePlace(.grass, x - 2, 4.4)
            i += 1
        }
        for x: Float in [-31, -13, 4, 22, 31] {
            samplePlace(.nipa, x, -4.0)
            samplePlace(.nipa, x + 3, 4.0)
        }
        for x: Float in [-24, -8, 10, 28] {
            samplePlace(.grass, x, -13.5)
            samplePlace(.grass, x + 4, 13)
        }
        samplePlace(.boat, -14, 0.3, variant: 0)
        samplePlace(.boat, 14, -0.3, rot: 0.05, variant: 1)
        samplePlace(.boat, 26, 0, variant: 2)
        autosave()
        message = "Đã tạo xóm ven kênh miền Tây mẫu."
    }

    // MARK: - Lưu / mở dự án (tự động)

    private var documentsURL: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }

    private var projectURL: URL {
        documentsURL.appendingPathComponent("project.json")
    }

    private func autosave() {
        if let data = try? JSONEncoder().encode(items) {
            try? data.write(to: projectURL, options: .atomic)
        }
    }

    private func loadProject() {
        guard let data = try? Data(contentsOf: projectURL),
              let loaded = try? JSONDecoder().decode([Item].self, from: data) else { return }
        for it in loaded { insert(it) }
    }

    // MARK: - Xuất file 3D

    func export(_ format: ExportFormat) {
        guard !items.isEmpty else {
            message = "Chưa có gì để xuất. Hãy đặt vài vật thể trước."
            return
        }

        let exp = SCNScene()
        exp.rootNode.addChildNode(world.clone())
        if includeGround {
            let g = SCNPlane(width: 160, height: 160)
            g.materials = [TextureLibrary.material(.grass, roughness: 1, repeatX: 40, repeatY: 40)]
            let gn = SCNNode(geometry: g)
            gn.eulerAngles.x = -Float.pi / 2
            gn.name = "ground"
            exp.rootNode.addChildNode(gn)
        }

        let f = DateFormatter()
        f.dateFormat = "yyyyMMdd_HHmmss"
        let url = documentsURL.appendingPathComponent("ThanhPho_\(f.string(from: Date())).\(format.ext)")

        do {
            switch format {
            case .obj:
                let asset = MDLAsset(scnScene: exp)
                try asset.export(to: url)
            case .usdz, .scn:
                let ok = exp.write(to: url, options: nil, delegate: nil, progressHandler: nil)
                if !ok { throw ExportError(text: "Không ghi được file \(format.ext)") }
            }
            shareItem = ShareItem(url: url)
            message = "Đã xuất \(url.lastPathComponent). Lưu vào Tệp hoặc gửi đi."
        } catch {
            message = "Lỗi xuất file: \(error.localizedDescription)"
        }
    }
}
