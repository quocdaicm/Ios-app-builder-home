import SceneKit
import SceneKit.ModelIO
import ModelIO
import SwiftUI
import UIKit
import ZIPFoundation

enum Tool: String, CaseIterable, Identifiable {
    case select, stilt, tole, house, coconut, nipa, grass, tree, pine, tower
    case canal, road, bridge, boat, erase
    case model
    // cây cối và hoa lá thật
    case fruit, banana, bamboo, lotus, flowers, hibiscus, mai, ban, rice, dragon
    // miền Tây
    case nhaCo, chuaKhmer, gheBeo, beCa, loGach, rom, gianBau, luNuoc, vit, trau, ben, quan

    var id: String { rawValue }

    var icon: String {
        switch self {
        case .select:  return "👆"
        case .stilt:   return "🛖"
        case .tole:    return "🏡"
        case .house:   return "🏠"
        case .coconut: return "🌴"
        case .nipa:    return "🌿"
        case .grass:   return "🌾"
        case .tree:    return "🌳"
        case .pine:    return "🌲"
        case .tower:   return "🏢"
        case .canal:   return "🌊"
        case .road:    return "🛣️"
        case .bridge:  return "🌉"
        case .boat:    return "🛶"
        case .erase:   return "🗑️"
        case .model:   return "🧊"
        case .fruit: return "🥭"
        case .banana: return "🍌"
        case .bamboo: return "🎋"
        case .lotus: return "🌸"
        case .flowers: return "🌼"
        case .hibiscus: return "🌺"
        case .mai: return "🏵️"
        case .ban: return "🌱"
        case .rice: return "🌾"
        case .dragon: return "🌵"
        case .nhaCo: return "🏛️"
        case .chuaKhmer: return "🛕"
        case .gheBeo: return "⛵"
        case .beCa: return "🐟"
        case .loGach: return "🏭"
        case .rom: return "🍂"
        case .gianBau: return "🥒"
        case .luNuoc: return "🏺"
        case .vit: return "🦆"
        case .trau: return "🐃"
        case .ben: return "⚓"
        case .quan: return "☕"
        }
    }

    var title: String {
        switch self {
        case .select:  return "Chọn"
        case .stilt:   return "Nhà sàn"
        case .tole:    return "Nhà tôn"
        case .house:   return "Nhà ngói"
        case .coconut: return "Dừa"
        case .nipa:    return "Dừa nước"
        case .grass:   return "Cỏ"
        case .tree:    return "Cây"
        case .pine:    return "Thông"
        case .tower:   return "Tòa nhà"
        case .canal:   return "Kênh"
        case .road:    return "Đường"
        case .bridge:  return "Cầu khỉ"
        case .boat:    return "Xuồng"
        case .erase:   return "Xóa"
        case .model:   return "Mô hình"
        case .fruit: return "Cây ăn trái"
        case .banana: return "Chuối"
        case .bamboo: return "Tre"
        case .lotus: return "Hồ sen"
        case .flowers: return "Bồn hoa"
        case .hibiscus: return "Dâm bụt"
        case .mai: return "Mai vàng"
        case .ban: return "Cây bần"
        case .rice: return "Ruộng lúa"
        case .dragon: return "Thanh long"
        case .nhaCo: return "Nhà cổ"
        case .chuaKhmer: return "Chùa Khmer"
        case .gheBeo: return "Ghe chợ nổi"
        case .beCa: return "Bè cá"
        case .loGach: return "Lò gạch"
        case .rom: return "Đống rơm"
        case .gianBau: return "Giàn bầu"
        case .luNuoc: return "Lu nước"
        case .vit: return "Đàn vịt"
        case .trau: return "Trâu bò"
        case .ben: return "Bến sông"
        case .quan: return "Quán võng"
        }
    }

    var hint: String {
        switch self {
        case .select:  return "Chạm vào vật thể để chọn, rồi xoay / đổi cỡ / đổi kiểu / dời."
        case .stilt:   return "Chạm lên nền để đặt nhà sàn mái lá."
        case .tole:    return "Chạm lên nền để đặt nhà tôn vách ván."
        case .house:   return "Chạm lên nền để đặt nhà ngói."
        case .coconut: return "Chạm lên nền để trồng dừa."
        case .nipa:    return "Chạm ven kênh để trồng dừa nước."
        case .grass:   return "Chạm lên nền để thêm bụi cỏ. Bấm “Màu” để đổi cỏ xanh / cỏ khô / cỏ đậm."
        case .tree:    return "Chạm lên nền để trồng cây."
        case .pine:    return "Chạm lên nền để trồng cây thông."
        case .tower:   return "Chạm lên nền để đặt tòa nhà cao tầng."
        case .canal:   return "Chạm điểm đầu, rồi chạm các điểm tiếp theo để đào kênh. Chọn kênh rồi bấm “Màu” để đổi bờ đất / kè gạch."
        case .road:    return "Chạm điểm đầu, rồi chạm các điểm tiếp theo. Chọn đường rồi bấm “Màu” để đổi nhựa / bê tông / đất."
        case .bridge:  return "Chạm hai điểm hai bên bờ kênh để bắc cầu khỉ."
        case .boat:    return "Chạm lên mặt kênh để thả xuồng. Dùng Chọn → Xoay để quay đầu."
        case .erase:   return "Chạm vào vật thể để xóa."
        case .model:   return "Chọn một mô hình trong danh sách rồi chạm lên nền để đặt."
        case .fruit: return "Chạm lên nền để trồng cây ăn trái. Bấm “Màu” để đổi xoài / nhãn / bưởi / cam / mận."
        case .banana: return "Chạm lên nền để trồng bụi chuối. Bấm “Màu” để đổi buồng xanh / buồng chín / chuối con."
        case .bamboo: return "Chạm lên nền để trồng bụi tre. Bấm “Màu” để đổi tre xanh / trúc vàng."
        case .lotus: return "Chạm lên nền để đặt hồ sen. Bấm “Màu” để đổi sen hồng / sen trắng / chỉ có lá."
        case .flowers: return "Chạm lên nền để đặt bồn hoa cúc. Bấm “Màu” để đổi màu hoa."
        case .hibiscus: return "Chạm lên nền để trồng bụi dâm bụt. Bấm “Màu” để đổi hoa đỏ / hồng / vàng."
        case .mai: return "Chạm lên nền để trồng mai vàng. Bấm “Màu” để đổi nở rộ / có lá."
        case .ban: return "Chạm ven kênh để trồng cây bần, có rễ thở cọc bần quanh gốc."
        case .rice: return "Chạm lên nền để đặt thửa ruộng. Bấm “Màu” để đổi lúa xanh / lúa chín / mạ non."
        case .dragon: return "Chạm lên nền để đặt vườn thanh long. Bấm “Màu” để đổi ruột đỏ / ruột vàng."
        case .nhaCo: return "Chạm lên nền để đặt nhà cổ Nam Bộ. Bấm “Màu” để đổi màu cửa."
        case .chuaKhmer: return "Chạm lên nền để đặt chùa Khmer mái tầng. Bấm “Màu” để đổi vàng / trắng đỏ."
        case .gheBeo: return "Chạm lên mặt kênh để thả ghe bán hàng có cây bẹo. Bấm “Màu” để đổi loại hàng."
        case .beCa: return "Chạm lên mặt kênh để đặt bè nuôi cá có nhà và lồng cá."
        case .loGach: return "Chạm lên nền để đặt lò gạch ống khói cao."
        case .rom: return "Chạm lên nền để đặt đống rơm. Bấm “Màu” để thêm đống nhỏ bên cạnh."
        case .gianBau: return "Chạm lên nền để đặt giàn bầu bí. Bấm “Màu” để đổi bầu / mướp / bí."
        case .luNuoc: return "Chạm lên nền để đặt lu chum. Bấm “Màu” để đổi đất nung / men nâu."
        case .vit: return "Chạm lên nền hoặc mặt nước để thả đàn vịt. Bấm “Màu” để đổi vịt trắng / nâu / lẫn."
        case .trau: return "Chạm lên nền để dắt trâu ra đồng. Bấm “Màu” để đổi trâu / bò vàng."
        case .ben: return "Chạm ven kênh để làm bến đò. Bấm “Màu” để đổi gỗ / bê tông."
        case .quan: return "Chạm lên nền để đặt quán nước có võng. Bấm “Màu” để đổi mái lá / mái tôn."
        }
    }

    var kind: Kind? {
        switch self {
        case .stilt:   return .stilt
        case .tole:    return .tole
        case .house:   return .house
        case .coconut: return .coconut
        case .nipa:    return .nipa
        case .grass:   return .grass
        case .tree:    return .tree
        case .pine:    return .pine
        case .tower:   return .tower
        case .canal:   return .canal
        case .road:    return .road
        case .bridge:  return .bridge
        case .boat:    return .boat
        case .model:   return .model
        case .fruit: return .fruit
        case .banana: return .banana
        case .bamboo: return .bamboo
        case .lotus: return .lotus
        case .flowers: return .flowers
        case .hibiscus: return .hibiscus
        case .mai: return .mai
        case .ban: return .ban
        case .rice: return .rice
        case .dragon: return .dragonFruit
        case .nhaCo: return .nhaCo
        case .chuaKhmer: return .chuaKhmer
        case .gheBeo: return .gheBeo
        case .beCa: return .fishRaft
        case .loGach: return .brickKiln
        case .rom: return .haystack
        case .gianBau: return .gourdTrellis
        case .luNuoc: return .waterJars
        case .vit: return .duckFlock
        case .trau: return .buffalo
        case .ben: return .pier
        case .quan: return .riverStall
        default:       return nil
        }
    }

    var isLine: Bool { kind?.isLine ?? false }
}

enum ExportFormat {
    case obj, usdz, scn

    var ext: String {
        switch self {
        case .obj:  return "obj"
        case .usdz: return "usdz"
        case .scn:  return "scn"
        }
    }
}

struct ShareItem: Identifiable {
    let id = UUID()
    let url: URL
}

struct ExportError: LocalizedError {
    let text: String
    var errorDescription: String? { text }
}

final class SceneController: ObservableObject {
    let scene = SCNScene()
    let world = SCNNode()          // chỉ chứa các vật thể người dùng đặt (dùng để xuất file)
    let cameraNode = SCNNode()
    private let ring = SCNNode()   // vòng chọn
    private let marker = SCNNode() // cột đánh dấu điểm đầu của đường / kênh / cầu
    private var nodes: [UUID: SCNNode] = [:]
    private var undoStack: [UUID] = []

    @Published var items: [Item] = []
    @Published var tool: Tool = .stilt
    @Published var selectedID: UUID? = nil
    @Published var roadStart: SIMD2<Float>? = nil
    @Published var moveMode = false
    @Published var viewOnly = false          // chế độ xem: chạm không đặt / chọn / xóa
    @Published var walkMode = false          // chế độ đi dạo kiểu game (joystick + nhìn quanh)
    @Published var flyMode = false           // trong đi dạo: bay tự do thay vì đi trên mặt đất
    @Published var runMode = false           // trong đi dạo: chạy nhanh
    @Published var snapToGrid = true
    @Published var includeGround = true
    @Published var message = Tool.stilt.hint
    @Published var shareItem: ShareItem? = nil
    @Published var models: [String] = []          // mô hình đã nhập (tên file)
    @Published var currentModel: String? = nil
    @Published var library = LibraryMeta()           // chuyên mục của thư viện mô hình
    @Published var librarySearch = ""
    @Published var libraryFilter: LibraryFilter = .all
    @Published var librarySort: LibrarySort = .name
    @Published var libraryStatus = ""                // trạng thái sao lưu / đồng bộ hiện trong màn Thư viện
    @Published var syncBusy = false
    @Published var syncFolderName: String? = UserDefaults.standard.string(forKey: "sync.name")
    @Published var pendingRestoreProject: Data? = nil

    init() {
        scene.rootNode.addChildNode(world)
        buildSky()
        buildGround()
        buildLights()
        buildCamera()
        buildOverlays()
        message = "Đang chuẩn bị hình ảnh…"
        TextureLibrary.preload { [weak self] in
            guard let self = self else { return }
            self.installBuiltinModels()
            self.loadLibrary()
            self.refreshModels()
            self.loadProject()
            self.message = self.tool.hint
        }
    }

    // MARK: - Dựng cảnh

    /// Màu chân trời, dùng chung cho nền trời và sương mù để hòa vào nhau.
    private static let horizon = UIColor(red: 0.80, green: 0.88, blue: 0.94, alpha: 1)

    private func buildSky() {
        let sky = Self.skyImage()
        scene.background.contents = sky
        scene.lightingEnvironment.contents = sky      // phản chiếu bầu trời lên kính, kim loại, nước
        scene.lightingEnvironment.intensity = 1.1
        scene.fogColor = Self.horizon
        scene.fogStartDistance = 110
        scene.fogEndDistance = 420
        scene.fogDensityExponent = 1.2
    }

    /// Ảnh bầu trời toàn cảnh (equirectangular): xanh đậm ở đỉnh, trắng ở chân trời, mây, mặt trời.
    static func skyImage() -> UIImage {
        let size = CGSize(width: 1024, height: 512)
        let fmt = UIGraphicsImageRendererFormat()
        fmt.scale = 1
        fmt.opaque = true
        return UIGraphicsImageRenderer(size: size, format: fmt).image { ctx in
            let c = ctx.cgContext
            let cs = CGColorSpaceCreateDeviceRGB()
            let colors = [
                UIColor(red: 0.20, green: 0.45, blue: 0.82, alpha: 1).cgColor,
                UIColor(red: 0.52, green: 0.73, blue: 0.93, alpha: 1).cgColor,
                horizon.cgColor,
                UIColor(red: 0.62, green: 0.70, blue: 0.55, alpha: 1).cgColor,
                UIColor(red: 0.30, green: 0.40, blue: 0.24, alpha: 1).cgColor
            ] as CFArray
            let grad = CGGradient(colorsSpace: cs, colors: colors, locations: [0, 0.30, 0.50, 0.56, 1])!
            c.drawLinearGradient(grad, start: .zero, end: CGPoint(x: 0, y: size.height), options: [])

            // mây
            var s: UInt64 = 424242
            func rnd() -> CGFloat {
                s = s &* 6364136223846793005 &+ 1442695040888963407
                return CGFloat((s >> 33) % 10000) / 10000
            }
            for _ in 0..<26 {
                let cx = rnd() * size.width
                let cy = size.height * (0.12 + rnd() * 0.30)
                let n = 8 + Int(rnd() * 8)
                for _ in 0..<n {
                    let rx = 30 + rnd() * 60
                    let ry = 8 + rnd() * 16
                    c.setFillColor(UIColor(white: 1, alpha: 0.10 + rnd() * 0.12).cgColor)
                    c.fillEllipse(in: CGRect(x: cx + (rnd() - 0.5) * 140 - rx, y: cy + (rnd() - 0.5) * 24 - ry,
                                             width: rx * 2, height: ry * 2))
                }
            }
            // mặt trời
            let sun = CGPoint(x: size.width * 0.62, y: size.height * 0.22)
            let sg = CGGradient(colorsSpace: cs,
                                colors: [UIColor(white: 1, alpha: 1).cgColor,
                                         UIColor(red: 1, green: 0.95, blue: 0.8, alpha: 0.5).cgColor,
                                         UIColor(red: 1, green: 0.95, blue: 0.8, alpha: 0).cgColor] as CFArray,
                                locations: [0, 0.25, 1])!
            c.drawRadialGradient(sg, startCenter: sun, startRadius: 0, endCenter: sun, endRadius: 90, options: [])
        }
    }

    private func buildGround() {
        // nền cỏ thật (PBR + vân nổi), lặp mỗi ô 4m
        let plane = SCNPlane(width: 1600, height: 1600)
        let m = TextureLibrary.material(.grass, roughness: 1, repeatX: 400, repeatY: 400)
        plane.materials = [m]
        let n = SCNNode(geometry: plane)
        n.eulerAngles.x = -Float.pi / 2
        n.name = "ground"
        scene.rootNode.addChildNode(n)

        // lưới mờ giúp canh vị trí
        let grid = SCNPlane(width: 580, height: 580)
        let gm = SCNMaterial()
        gm.diffuse.contents = Self.gridImage()
        gm.diffuse.wrapS = .repeat
        gm.diffuse.wrapT = .repeat
        gm.diffuse.contentsTransform = SCNMatrix4MakeScale(58, 58, 1)
        gm.lightingModel = .constant
        gm.writesToDepthBuffer = false
        gm.isDoubleSided = true
        grid.materials = [gm]
        let gn = SCNNode(geometry: grid)
        gn.eulerAngles.x = -Float.pi / 2
        gn.position = SCNVector3(0, 0.012, 0)
        gn.castsShadow = false
        gn.renderingOrder = -1
        scene.rootNode.addChildNode(gn)
    }

    static func gridImage() -> UIImage {
        let size = CGSize(width: 500, height: 500)
        let fmt = UIGraphicsImageRendererFormat()
        fmt.scale = 1
        fmt.opaque = false
        return UIGraphicsImageRenderer(size: size, format: fmt).image { _ in
            UIColor(white: 1, alpha: 0.16).setStroke()
            let path = UIBezierPath()
            for i in 0...10 {
                let p = CGFloat(i) * 50
                path.move(to: CGPoint(x: p, y: 0))
                path.addLine(to: CGPoint(x: p, y: 500))
                path.move(to: CGPoint(x: 0, y: p))
                path.addLine(to: CGPoint(x: 500, y: p))
            }
            path.lineWidth = 2
            path.stroke()
        }
    }

    private func buildLights() {
        let ambient = SCNNode()
        let a = SCNLight()
        a.type = .ambient
        a.intensity = 180          // phần lớn ánh sáng nền đã đến từ bầu trời (IBL)
        a.color = UIColor(red: 0.85, green: 0.92, blue: 1.0, alpha: 1)
        ambient.light = a
        scene.rootNode.addChildNode(ambient)

        let sun = SCNNode()
        let l = SCNLight()
        l.type = .directional
        l.intensity = 1900
        l.color = UIColor(red: 1.0, green: 0.95, blue: 0.86, alpha: 1)
        l.temperature = 5800
        l.castsShadow = true
        l.shadowMode = .deferred
        l.shadowRadius = 5
        l.shadowSampleCount = 8
        l.shadowMapSize = CGSize(width: 2048, height: 2048)
        l.shadowColor = UIColor(white: 0, alpha: 0.45)
        l.automaticallyAdjustsShadowProjection = true
        l.maximumShadowDistance = 140
        l.shadowCascadeCount = 3
        sun.light = l
        sun.eulerAngles = SCNVector3(-Float.pi / 3.2, Float.pi / 4, 0)
        scene.rootNode.addChildNode(sun)
    }

    private func buildCamera() {
        let cam = SCNCamera()
        cam.fieldOfView = 55
        cam.zNear = 0.5
        cam.wantsHDR = true
        cam.wantsExposureAdaptation = false
        cam.exposureOffset = -0.3
        cam.bloomIntensity = 0.25
        cam.bloomThreshold = 1.0
        cam.bloomBlurRadius = 8
        cam.saturation = 1.1
        cam.contrast = 0.12
        cam.vignettingIntensity = 0.25
        cam.vignettingPower = 1.0
        cam.zFar = 2500
        cameraNode.camera = cam
        scene.rootNode.addChildNode(cameraNode)
        applyCamera()
    }

    // MARK: - Camera tự do (kéo, zoom, xoay, nghiêng như bản đồ)

    var camTarget = SIMD2<Float>(0, 0)      // điểm trên mặt đất camera đang nhìn vào
    var camDist: Float = 44
    var camYaw: Float = 0
    var camPitch: Float = 0.69              // rad, 0 = ngang, ~1.5 = nhìn thẳng xuống
    private var inertiaTimer: Timer?
    static let camLimit: Float = 290        // giới hạn kéo đi xa (mét)

    func cameraPosition() -> SIMD3<Float> {
        let cp = cos(camPitch)
        return SIMD3<Float>(camTarget.x + sin(camYaw) * cp * camDist,
                            sin(camPitch) * camDist,
                            camTarget.y + cos(camYaw) * cp * camDist)
    }

    func applyCamera() {
        if walkMode {
            let pos = SIMD3<Float>(walkPos.x, walkHeight, walkPos.y)
            cameraNode.simdPosition = pos
            cameraNode.simdLook(at: pos + walkDirection())
            scene.fogStartDistance = 110
            scene.fogEndDistance = 420
            return
        }
        cameraNode.simdPosition = cameraPosition()
        cameraNode.simdLook(at: SIMD3<Float>(camTarget.x, 0, camTarget.y))
        // sương mù dãn ra khi zoom xa để không che mất khu đang xem
        scene.fogStartDistance = CGFloat(max(110, camDist * 1.6))
        scene.fogEndDistance = CGFloat(max(420, camDist * 5))
    }

    func moveTarget(by d: SIMD2<Float>) {
        let L = Self.camLimit
        camTarget.x = min(max(camTarget.x + d.x, -L), L)
        camTarget.y = min(max(camTarget.y + d.y, -L), L)
        applyCamera()
    }

    func setCamDist(_ d: Float) {
        camDist = min(max(d, 4), 400)
        applyCamera()
    }

    func setCamYaw(_ y: Float) {
        camYaw = y
        applyCamera()
    }

    func setCamPitch(_ p: Float) {
        camPitch = min(max(p, 0.12), 1.5)
        applyCamera()
    }

    /// Điểm trên mặt đất (y = 0) dưới ngón tay, tính thẳng từ trạng thái camera (không trễ khung hình).
    func groundRay(_ p: CGPoint, size: CGSize) -> SIMD2<Float>? {
        guard size.width > 1, size.height > 1 else { return nil }
        let pos = cameraPosition()
        let tgt = SIMD3<Float>(camTarget.x, 0, camTarget.y)
        let fwd = simd_normalize(tgt - pos)
        let right = simd_normalize(simd_cross(fwd, SIMD3<Float>(0, 1, 0)))
        let up = simd_cross(right, fwd)
        let fov = Float(cameraNode.camera?.fieldOfView ?? 55)
        let th = tan(fov * Float.pi / 360)
        let aspect = Float(size.width / size.height)
        let nx = Float(p.x / size.width) * 2 - 1
        let ny = 1 - Float(p.y / size.height) * 2
        let dir = simd_normalize(fwd + right * (nx * th * aspect) + up * (ny * th))
        guard dir.y < -0.03 else { return nil }
        let hit = pos + dir * (-pos.y / dir.y)
        guard abs(hit.x) < 3000, abs(hit.z) < 3000 else { return nil }
        return SIMD2<Float>(hit.x, hit.z)
    }

    func stopInertia() {
        inertiaTimer?.invalidate()
        inertiaTimer = nil
    }

    /// Lướt tiếp sau khi thả tay, chậm dần.
    func fling(_ delta: SIMD2<Float>) {
        stopInertia()
        var v = delta
        let maxLen = camDist * 0.08
        if simd_length(v) > maxLen { v = v / simd_length(v) * maxLen }
        inertiaTimer = Timer.scheduledTimer(withTimeInterval: 1.0 / 60, repeats: true) { [weak self] t in
            guard let self = self else { t.invalidate(); return }
            self.moveTarget(by: v)
            v *= 0.93
            if simd_length(v) < 0.004 {
                t.invalidate()
                self.inertiaTimer = nil
            }
        }
    }

    // MARK: - Chế độ đi dạo kiểu game 3D
    // Cần joystick bên trái = đi / lùi / đi ngang. Kéo một ngón ở phần còn lại của màn hình = nhìn quanh.
    // Đi bộ: camera cao ngang mắt người. Bay: đẩy cần tới thì bay theo hướng đang nhìn.

    var walkPos = SIMD2<Float>(0, 0)
    var walkHeight: Float = 1.7
    var walkYaw: Float = 0
    var walkLook: Float = 0                 // rad, > 0 = ngước lên
    var joy = SIMD2<Float>(0, 0)            // x = sang phải, y = tiến lên (-1...1)
    var lift: Float = 0                     // -1...1: bay lên / xuống bằng nút (khi đang bay)
    private var lookVel = SIMD2<Float>(0, 0)  // điểm ảnh / giây, để nhìn quanh có quán tính
    private var lookActive = false
    private var lastLookT: TimeInterval = 0
    private var walkTimer: Timer?
    private var walkLast: TimeInterval = 0
    static let eyeHeight: Float = 1.7

    func walkDirection() -> SIMD3<Float> {
        let cp = cos(walkLook)
        return SIMD3<Float>(-sin(walkYaw) * cp, sin(walkLook), -cos(walkYaw) * cp)
    }

    func toggleWalk() {
        if walkMode { exitWalk() } else { enterWalk() }
    }

    /// Vào chế độ đi dạo tại đúng vị trí và hướng nhìn của camera hiện tại (bắt đầu ở trạng thái bay, bấm "Xuống đất" để đi bộ).
    func enterWalk() {
        stopInertia()
        selectedID = nil
        moveMode = false
        roadStart = nil
        refreshOverlays()
        // đứng xuống mặt đất ngay dưới chỗ camera đang đứng, nhìn cùng hướng (từ trên cao hạ xuống mượt)
        let p = cameraPosition()
        walkPos = SIMD2<Float>(p.x, p.z)
        walkHeight = max(p.y, Self.eyeHeight)
        walkYaw = camYaw
        walkLook = -0.12
        flyMode = false
        runMode = false
        lift = 0
        lookVel = .zero
        joy = .zero
        viewOnly = true
        walkMode = true
        cameraNode.camera?.zNear = 0.2
        applyCamera()
        startWalkTimer()
    }

    func exitWalk() {
        walkTimer?.invalidate()
        walkTimer = nil
        joy = .zero
        walkMode = false
        flyMode = false
        runMode = false
        lift = 0
        viewOnly = false
        cameraNode.camera?.zNear = 0.5
        // về camera bản đồ, đứng đúng chỗ đang đứng, nhìn cùng hướng
        let dist: Float = 44
        let pitch: Float = 0.69
        let back = cos(pitch) * dist
        let L = Self.camLimit
        camYaw = walkYaw
        camPitch = pitch
        camDist = dist
        camTarget = SIMD2<Float>(min(max(walkPos.x - sin(walkYaw) * back, -L), L),
                                 min(max(walkPos.y - cos(walkYaw) * back, -L), L))
        message = tool.hint
        animateCamera()
    }

    func toggleFly() {
        flyMode.toggle()
        if flyMode {
            walkHeight = max(walkHeight, 15)
            walkLook = min(walkLook, -0.4)
            message = "Đang bay: đẩy cần tới để bay theo hướng nhìn (nhìn xuống thì hạ thấp)."
        } else {
            message = "Đang đi bộ trên mặt đất."
        }
    }

    func toggleRun() { runMode.toggle() }

    func beginLook() {
        lookActive = true
        lookVel = .zero
        lastLookT = ProcessInfo.processInfo.systemUptime
    }

    func endLook() { lookActive = false }

    /// Kéo ngón để nhìn quanh (kéo sang phải = quay phải, kéo lên = ngước lên).
    func walkLookBy(dx: Float, dy: Float) {
        walkYaw -= dx * 0.006
        walkLook = min(max(walkLook - dy * 0.006, -1.45), 1.45)
        let now = ProcessInfo.processInfo.systemUptime
        let dt = Float(max(now - lastLookT, 0.008))
        lastLookT = now
        let inst = SIMD2<Float>(dx, dy) / dt
        lookVel = lookVel * 0.5 + inst * 0.5
        let l = simd_length(lookVel)
        if l > 2500 { lookVel = lookVel / l * 2500 }
        applyCamera()
    }

    private func startWalkTimer() {
        walkTimer?.invalidate()
        walkLast = ProcessInfo.processInfo.systemUptime
        let t = Timer(timeInterval: 1.0 / 60, repeats: true) { [weak self] _ in
            self?.walkStep()
        }
        RunLoop.main.add(t, forMode: .common)   // .common để vẫn chạy khi đang chạm màn hình
        walkTimer = t
    }

    private func walkStep() {
        guard walkMode else { return }
        let now = ProcessInfo.processInfo.systemUptime
        let dt = Float(min(now - walkLast, 0.1))
        walkLast = now

        let m = simd_length(joy)
        if m > 0.05 {
            // đẩy nhẹ thì đi chậm, đẩy hết cỡ thì đi nhanh (dễ canh hơn đường thẳng)
            let mm = min(m, 1)
            let j = (joy / m) * (mm * (0.35 + 0.65 * mm))
            let right2 = SIMD2<Float>(cos(walkYaw), -sin(walkYaw))
            let dx: Float
            let dz: Float
            var dy: Float = 0
            // tốc độ tối đa: đi bộ 7 m/s, bay nhanh dần theo độ cao
            let top: Float = flyMode ? max(14, walkHeight * 0.9) : 7
            if flyMode {
                let d = walkDirection()
                dx = d.x * j.y + right2.x * j.x
                dy = d.y * j.y
                dz = d.z * j.y + right2.y * j.x
            } else {
                let fwd2 = SIMD2<Float>(-sin(walkYaw), -cos(walkYaw))
                dx = fwd2.x * j.y + right2.x * j.x
                dz = fwd2.y * j.y + right2.y * j.x
            }
            let k = top * (runMode ? 2.2 : 1) * dt
            let L = Self.camLimit
            walkPos.x = min(max(walkPos.x + dx * k, -L), L)
            walkPos.y = min(max(walkPos.y + dz * k, -L), L)
            if flyMode { walkHeight = min(max(walkHeight + dy * k, Self.eyeHeight), 250) }
        }

        if !flyMode {
            // hạ xuống ngang tầm mắt người một cách mượt
            let diff = Self.eyeHeight - walkHeight
            walkHeight = abs(diff) < 0.01 ? Self.eyeHeight : walkHeight + diff * min(1, dt * 4)
        } else if lift != 0 {
            let up = max(8, walkHeight * 0.6) * (runMode ? 2 : 1)
            walkHeight = min(max(walkHeight + lift * up * dt, Self.eyeHeight), 250)
        }
        // nhìn quanh có quán tính: thả tay vẫn trượt thêm rồi dừng dần
        if !lookActive && simd_length(lookVel) > 8 {
            walkYaw -= lookVel.x * 0.006 * dt
            walkLook = min(max(walkLook - lookVel.y * 0.006 * dt, -1.45), 1.45)
            lookVel = lookVel * max(0, 1 - dt * 6)
        }
        applyCamera()
    }

    private func animateCamera() {
        SCNTransaction.begin()
        SCNTransaction.animationDuration = 0.4
        applyCamera()
        SCNTransaction.commit()
    }

    /// Đưa camera tới vật đang chọn.
    func focusSelected() {
        guard let it = selectedItem else { return }
        stopInertia()
        camTarget = SIMD2<Float>(it.x, it.z)
        camDist = min(camDist, 30)
        animateCamera()
    }

    func resetCamera() {
        stopInertia()
        camTarget = SIMD2<Float>(0, 0)
        camDist = 44
        camYaw = 0
        camPitch = 0.69
        animateCamera()
    }

    /// Nhìn thẳng từ trên xuống như bản đồ.
    func topDownCamera() {
        stopInertia()
        camPitch = 1.5
        camYaw = 0
        camDist = max(camDist, 60)
        animateCamera()
    }

    private func buildOverlays() {
        let torus = SCNTorus(ringRadius: 3, pipeRadius: 0.07)
        let rm = SCNMaterial()
        rm.diffuse.contents = UIColor.yellow
        rm.emission.contents = UIColor.yellow
        rm.lightingModel = .constant
        torus.materials = [rm]
        ring.geometry = torus
        ring.castsShadow = false
        ring.isHidden = true
        scene.rootNode.addChildNode(ring)

        let cyl = SCNCylinder(radius: 0.45, height: 1.5)
        let mm = SCNMaterial()
        mm.diffuse.contents = UIColor.red
        mm.lightingModel = .constant
        cyl.materials = [mm]
        marker.geometry = cyl
        marker.castsShadow = false
        marker.isHidden = true
        scene.rootNode.addChildNode(marker)
    }

    private func refreshOverlays() {
        if let id = selectedID, let it = items.first(where: { $0.id == id }) {
            ring.isHidden = false
            if it.kind.isLine {
                ring.position = SCNVector3((it.x + it.x2) / 2, 0.45, (it.z + it.z2) / 2)
                ring.scale = SCNVector3(1, 1, 1)
            } else {
                ring.position = SCNVector3(it.x, 0.15, it.z)
                var r = it.scale
                if it.kind == .model {
                    if (it.motion ?? 0) == 4 {
                        r = 1                                  // vòng vàng = đường đi vòng, bán kính 3 m
                    } else if let node = nodes[it.id] {
                        // vòng ôm vừa chân mô hình, không còn cố định 3 m cho mọi cỡ
                        let (lo, hi) = node.boundingBox
                        let ext = max(hi.x - lo.x, hi.z - lo.z) * 0.5 * it.scale
                        r = min(max(ext * 1.15, 0.8), 60) / 3
                    }
                }
                ring.scale = SCNVector3(r, 1, r)
            }
        } else {
            ring.isHidden = true
        }
        if let s = roadStart {
            marker.isHidden = false
            marker.position = SCNVector3(s.x, 0.75, s.y)
        } else {
            marker.isHidden = true
        }
    }

    // MARK: - Chạm màn hình

    func setTool(_ t: Tool) {
        tool = t
        roadStart = nil
        moveMode = false
        if t != .select { selectedID = nil }
        message = t.hint
        refreshOverlays()
    }

    func handleTap(at point: CGPoint, in view: SCNView) {
        if viewOnly { return }
        switch tool {
        case .select:
            if moveMode, let id = selectedID, let g = groundPoint(point, in: view) {
                move(id, to: g)
                moveMode = false
                message = "Đã dời."
                return
            }
            selectedID = pickID(point, in: view)
            moveMode = false
            message = selectedID == nil ? Tool.select.hint : "Đã chọn. Dùng thanh nút bên dưới."
            refreshOverlays()
        case .erase:
            if let id = pickID(point, in: view) { remove(id) }
        case .road, .canal, .bridge:
            guard let kind = tool.kind, let g = groundPoint(point, in: view) else { return }
            if let s = roadStart {
                if s != g { addLine(kind, from: s, to: g) }
                if kind == .bridge {
                    roadStart = nil
                    message = Tool.bridge.hint
                } else {
                    roadStart = g          // nối tiếp đoạn sau
                    message = "Chạm điểm tiếp theo, hoặc bấm “Dừng”."
                }
            } else {
                roadStart = g
                message = "Chạm điểm cuối."
            }
            refreshOverlays()
        case .model:
            guard let name = currentModel else {
                message = "Chưa chọn mô hình. Hãy nhập hoặc chọn một mô hình ở thanh dưới."
                return
            }
            if let g = groundPoint(point, in: view) { add(.model, at: g, model: name) }
        default:
            if let kind = tool.kind, let g = groundPoint(point, in: view) {
                add(kind, at: g)
            }
        }
    }

    func stopRoad() {
        roadStart = nil
        message = tool.hint
        refreshOverlays()
    }

    /// Chiếu tia từ ngón tay xuống mặt phẳng y = 0.
    func groundPoint(_ p: CGPoint, in view: SCNView) -> SIMD2<Float>? {
        let a = view.unprojectPoint(SCNVector3(Float(p.x), Float(p.y), 0))
        let b = view.unprojectPoint(SCNVector3(Float(p.x), Float(p.y), 1))
        let dy = b.y - a.y
        guard abs(dy) > 0.0001 else { return nil }
        let t = -a.y / dy
        guard t > 0 else { return nil }
        var x = a.x + (b.x - a.x) * t
        var z = a.z + (b.z - a.z) * t
        guard abs(x) < Self.camLimit, abs(z) < Self.camLimit else { return nil }
        if snapToGrid {
            x = x.rounded()
            z = z.rounded()
        }
        return SIMD2<Float>(x, z)
    }

    func pickID(_ p: CGPoint, in view: SCNView) -> UUID? {
        let options: [SCNHitTestOption: Any] = [
            .searchMode: SCNHitTestSearchMode.all.rawValue
        ]
        for hit in view.hitTest(p, options: options) {
            var n: SCNNode? = hit.node
            while let cur = n {
                if let name = cur.name, let id = UUID(uuidString: name), nodes[id] != nil {
                    return id
                }
                n = cur.parent
            }
        }
        return nil
    }

    // MARK: - Thêm / sửa / xóa

    private func insert(_ it: Item) {
        let n = Builder.node(for: it)
        world.addChildNode(n)
        nodes[it.id] = n
        items.append(it)
    }

    func add(_ kind: Kind, at p: SIMD2<Float>, model: String? = nil) {
        // Chống đặt chồng khi bấm đúp (đúp chạm cũng là thao tác đặt lại camera)
        if items.contains(where: { $0.kind == kind && $0.model == model && abs($0.x - p.x) < 0.5 && abs($0.z - p.y) < 0.5 }) {
            return
        }
        var it = Item(kind: kind, x: p.x, z: p.y)
        it.model = model
        it.colorIndex = Int.random(in: 0..<kind.variantCount)
        insert(it)
        undoStack.append(it.id)
        autosave()
    }

    func addLine(_ kind: Kind, from a: SIMD2<Float>, to b: SIMD2<Float>) {
        var it = Item(kind: kind, x: a.x, z: a.y)
        it.x2 = b.x
        it.z2 = b.y
        insert(it)
        undoStack.append(it.id)
        autosave()
    }

    func remove(_ id: UUID) {
        nodes[id]?.removeFromParentNode()
        nodes[id] = nil
        items.removeAll { $0.id == id }
        if selectedID == id { selectedID = nil }
        refreshOverlays()
        autosave()
    }

    func undo() {
        while let last = undoStack.popLast() {
            if nodes[last] != nil {
                remove(last)
                return
            }
        }
    }

    func clearAll() {
        for (_, n) in nodes { n.removeFromParentNode() }
        nodes.removeAll()
        items.removeAll()
        undoStack.removeAll()
        selectedID = nil
        roadStart = nil
        refreshOverlays()
        autosave()
    }

    private func update(_ id: UUID, _ change: (inout Item) -> Void) {
        guard let i = items.firstIndex(where: { $0.id == id }) else { return }
        let old = items[i]
        change(&items[i])
        let it = items[i]
        if let node = nodes[id], Builder.canReposition(from: old, to: it) {
            // chỉ dời / xoay / đổi cỡ: chỉnh thẳng node đang có
            node.position = SCNVector3(it.x, 0, it.z)
            node.eulerAngles.y = it.rot
            node.scale = SCNVector3(it.scale, it.scale, it.scale)
        } else {
            nodes[id]?.removeFromParentNode()
            let n = Builder.node(for: it)
            world.addChildNode(n)
            nodes[id] = n
        }
        refreshOverlays()
        autosave()
    }

    func move(_ id: UUID, to p: SIMD2<Float>) {
        update(id) { it in
            if it.kind.isLine {
                let dx = p.x - (it.x + it.x2) / 2
                let dz = p.y - (it.z + it.z2) / 2
                it.x += dx
                it.x2 += dx
                it.z += dz
                it.z2 += dz
            } else {
                it.x = p.x
                it.z = p.y
            }
        }
    }

    var selectedItem: Item? {
        guard let id = selectedID else { return nil }
        return items.first { $0.id == id }
    }

    /// Đổi kiểu chuyển động của mô hình đang chọn: đứng yên → đung đưa → lá lay → nhún → đi vòng.
    func cycleMotion() {
        guard let id = selectedID else { return }
        update(id) { it in
            if it.kind == .model { it.motion = ((it.motion ?? 0) + 1) % Builder.motionTitles.count }
        }
    }

    /// Chỉnh hướng đi của mô hình "Đi vòng": mỗi lần bấm quay thêm 90° (mặt nhìn đúng hướng đi).
    func flipMotion() {
        guard let id = selectedID else { return }
        update(id) { it in
            if it.kind == .model { it.motionTurn = ((it.motionTurn ?? 0) + 1) % 4 }
        }
    }

    func rotateSelected() {
        guard let id = selectedID, let cur = selectedItem else { return }
        guard !cur.kind.isLine else {
            message = "Đường, kênh, cầu không xoay được. Dùng nút Dời."
            return
        }
        update(id) { it in it.rot += Float.pi / 4 }
        let deg = Int((Double(selectedItem?.rot ?? 0) * 180 / Double.pi).rounded())
        message = "Đã xoay (góc \(((deg % 360) + 360) % 360)°)."
    }

    func scaleSelected(_ factor: Float) {
        guard let id = selectedID, let cur = selectedItem else { return }
        guard !cur.kind.isLine else {
            message = "Đường, kênh, cầu không đổi cỡ được. Dùng nút Dời."
            return
        }
        // mô hình nhập có thể rất nhỏ hoặc rất lớn (sai đơn vị) nên cho khoảng cỡ rộng hơn, mỗi lần đổi mạnh hơn
        let isModel = cur.kind == .model
        let f = isModel ? factor * factor : factor
        let lo: Float = isModel ? 0.05 : 0.2
        let hi: Float = isModel ? 100 : 6
        update(id) { it in it.scale = min(max(it.scale * f, lo), hi) }
        if let it = selectedItem {
            var text = String(format: "Cỡ ×%.2f", it.scale)
            if isModel, let node = nodes[id] {
                let (bl, bh) = node.boundingBox
                text += String(format: ", cao khoảng %.1f m", max(bh.y - bl.y, 0) * it.scale)
            }
            if it.scale <= lo + 0.0001 { text += " (nhỏ nhất)" }
            if it.scale >= hi - 0.0001 { text += " (lớn nhất)" }
            message = text
        }
    }

    func recolorSelected() {
        guard let id = selectedID else { return }
        update(id) { it in
            it.colorIndex = (it.colorIndex + 1) % max(it.kind.variantCount, 1)
        }
    }

    func deleteSelected() {
        if let id = selectedID { remove(id) }
    }

    func toggleMove() {
        moveMode.toggle()
        message = moveMode ? "Chạm lên nền nơi muốn đặt vật thể." : "Đã hủy dời."
    }

    // MARK: - Thư viện mô hình

    /// Mô hình đóng sẵn trong app (thư mục Builtin): chép vào thư viện ở lần chạy đầu.
    /// Nếu bạn xóa, app không tự thêm lại.
    private func installBuiltinModels() {
        let fm = FileManager.default
        let ud = UserDefaults.standard
        let list: [(name: String, file: String)] = [("Nhân vật nam", "Male_Character")]
        for item in list {
            let key = "builtin.model.\(item.file)"
            if ud.bool(forKey: key) { continue }
            guard let obj = Bundle.main.url(forResource: item.file, withExtension: "obj", subdirectory: "Builtin"),
                  let mtl = Bundle.main.url(forResource: item.file, withExtension: "mtl", subdirectory: "Builtin")
            else { continue }
            let dir = Builder.modelsDirectory.appendingPathComponent(item.name, isDirectory: true)
            if !fm.fileExists(atPath: dir.path) {
                do {
                    try fm.createDirectory(at: dir, withIntermediateDirectories: true)
                    try fm.copyItem(at: obj, to: dir.appendingPathComponent(obj.lastPathComponent))
                    try fm.copyItem(at: mtl, to: dir.appendingPathComponent(mtl.lastPathComponent))
                } catch {
                    try? fm.removeItem(at: dir)
                    continue
                }
            }
            ud.set(true, forKey: key)
        }
    }

    func refreshModels() {
        let fm = FileManager.default
        let dir = Builder.modelsDirectory
        let entries = (try? fm.contentsOfDirectory(at: dir, includingPropertiesForKeys: nil,
                                                    options: [.skipsHiddenFiles])) ?? []
        models = entries
            .filter { Builder.mainModelURL(for: $0.lastPathComponent) != nil }
            .map { $0.lastPathComponent }
            .sorted { $0.localizedStandardCompare($1) == .orderedAscending }
        if let cur = currentModel, !models.contains(cur) { currentModel = nil }
        reconcileLibrary()
    }

    private func uniqueEntryName(_ base: String) -> String {
        let fm = FileManager.default
        let dir = Builder.modelsDirectory
        var name = base
        var n = 2
        while fm.fileExists(atPath: dir.appendingPathComponent(name).path) {
            name = "\(base) \(n)"
            n += 1
        }
        return name
    }

    /// Gói các file chọn lẻ (.obj + .mtl + ảnh…) thành một thư mục trong thư viện.
    private func makeBundle(base: String, files: [URL]) -> String? {
        let fm = FileManager.default
        let name = uniqueEntryName(base)
        let dir = Builder.modelsDirectory.appendingPathComponent(name, isDirectory: true)
        do {
            try fm.createDirectory(at: dir, withIntermediateDirectories: true)
            for f in files {
                try fm.copyItem(at: f, to: dir.appendingPathComponent(f.lastPathComponent))
            }
        } catch {
            try? fm.removeItem(at: dir)
            return nil
        }
        if let main = Builder.findMainModel(in: dir), Builder.canLoadModel(at: main) { return name }
        try? fm.removeItem(at: dir)
        return nil
    }

    /// Giải nén file .zip rồi đưa cả thư mục vào thư viện.
    private func importArchive(_ url: URL) -> (name: String?, problem: String?) {
        let fm = FileManager.default
        let tmp = fm.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
        let localZip = fm.temporaryDirectory.appendingPathComponent(UUID().uuidString + ".zip")
        defer { try? fm.removeItem(at: localZip) }
        do {
            try fm.createDirectory(at: tmp, withIntermediateDirectories: true)
            // chép zip về thư mục của app trước, tránh đọc trực tiếp từ vùng của app Tệp / iCloud
            try fm.copyItem(at: url, to: localZip)
            try fm.unzipItem(at: localZip, to: tmp)
        } catch {
            try? fm.removeItem(at: tmp)
            return (nil, "\(url.lastPathComponent): không giải nén được (\(error.localizedDescription))")
        }
        guard let main = Builder.findMainModel(in: tmp) else {
            let hasGLB = (fm.enumerator(at: tmp, includingPropertiesForKeys: nil)?
                .allObjects as? [URL] ?? []).contains { ["glb", "gltf"].contains($0.pathExtension.lowercased()) }
            try? fm.removeItem(at: tmp)
            return (nil, hasGLB
                ? "\(url.lastPathComponent): chỉ có GLB/GLTF, hãy chuyển sang USDZ hoặc OBJ"
                : "\(url.lastPathComponent): không thấy file mô hình (USDZ, OBJ…) trong zip")
        }
        guard Builder.canLoadModel(at: main) else {
            try? fm.removeItem(at: tmp)
            return (nil, "\(url.lastPathComponent): file mô hình không đọc được"
                    + (Builder.lastLoadError.map { " (\($0))" } ?? ""))
        }
        let name = uniqueEntryName(url.deletingPathExtension().lastPathComponent)
        do {
            try fm.moveItem(at: tmp, to: Builder.modelsDirectory.appendingPathComponent(name, isDirectory: true))
        } catch {
            try? fm.removeItem(at: tmp)
            return (nil, "\(url.lastPathComponent): không lưu được")
        }
        return (name, nil)
    }

    /// Nhập từ app Tệp: nhận file .zip, file mô hình lẻ, hoặc chọn cùng lúc .obj + .mtl + ảnh.
    func importModels(_ result: Result<[URL], Error>) {
        let urls: [URL]
        switch result {
        case .failure(let e):
            message = "Không mở được file: \(e.localizedDescription)"
            return
        case .success(let u):
            urls = u
        }

        let modelsBefore = Set(models)
        let scoped = urls.filter { $0.startAccessingSecurityScopedResource() }
        defer { scoped.forEach { $0.stopAccessingSecurityScopedResource() } }

        var lastOK: String? = nil
        var problems: [String] = []
        var loose: [URL] = []

        for url in urls {
            if url.pathExtension.lowercased() == "zip" {
                let r = importArchive(url)
                if let n = r.name { lastOK = n }
                if let p = r.problem { problems.append(p) }
            } else {
                loose.append(url)
            }
        }

        if !loose.isEmpty {
            let isModel: (URL) -> Bool = { Builder.modelExtensions.contains($0.pathExtension.lowercased()) }
            let modelFiles = loose.filter(isModel)
            let support = loose.filter { !isModel($0) }
            if modelFiles.isEmpty {
                problems.append("Không thấy file mô hình (USDZ, OBJ, GLB…) trong những file đã chọn")
            } else {
                for m in modelFiles {
                    let base = m.deletingPathExtension().lastPathComponent
                    if let n = makeBundle(base: base, files: [m] + support) {
                        lastOK = n
                    } else {
                        problems.append("\(m.lastPathComponent): file không đọc được"
                                        + (Builder.lastLoadError.map { " (\($0))" } ?? ""))
                    }
                }
            }
        }

        refreshModels()
        if let name = lastOK {
            currentModel = name
            setTool(.model)
            message = problems.isEmpty
                ? "Đã nhập “\(name)”. Chạm lên nền để đặt."
                : "Đã nhập “\(name)”. Bỏ qua: " + problems.joined(separator: "; ")
        } else if !problems.isEmpty {
            message = problems.joined(separator: "; ")
        }
        assignImported(before: modelsBefore)
    }

    func selectModel(_ name: String) {
        currentModel = name
        setTool(.model)
    }

    /// Xóa mô hình khỏi thư viện, kèm các bản đã đặt trong cảnh.
    func deleteModel(_ name: String) {
        for it in items where it.kind == .model && it.model == name { remove(it.id) }
        try? FileManager.default.removeItem(at: Builder.modelsDirectory.appendingPathComponent(name))
        Builder.forgetModel(name)
        refreshModels()
        if currentModel == name { currentModel = nil }
    }

    // MARK: - Cảnh mẫu

    private func samplePlace(_ kind: Kind, _ x: Float, _ z: Float, rot: Float = 0, variant: Int? = nil) {
        var it = Item(kind: kind, x: x, z: z)
        it.rot = rot
        it.colorIndex = variant ?? Int.random(in: 0..<kind.variantCount)
        insert(it)
    }

    private func sampleLine(_ kind: Kind, _ a: SIMD2<Float>, _ b: SIMD2<Float>, variant: Int) {
        var it = Item(kind: kind, x: a.x, z: a.y)
        it.x2 = b.x
        it.z2 = b.y
        it.colorIndex = variant
        insert(it)
    }

    /// Khu phố đô thị mẫu
    func addSample() {
        clearAll()
        sampleLine(.road, SIMD2<Float>(-30, 0), SIMD2<Float>(30, 0), variant: 0)
        sampleLine(.road, SIMD2<Float>(0, -30), SIMD2<Float>(0, 30), variant: 0)

        for x in stride(from: -24 as Float, through: 24, by: 8) where abs(x) > 6 {
            samplePlace(.house, x, -5)
            samplePlace(.house, x, 5, rot: Float.pi)
        }
        for z in stride(from: -24 as Float, through: 24, by: 8) where abs(z) > 6 {
            samplePlace(.house, -5, z, rot: Float.pi / 2)
            samplePlace(.house, 5, z, rot: -Float.pi / 2)
        }
        for sx: Float in [-1, 1] {
            for sz: Float in [-1, 1] {
                samplePlace(.tower, sx * 16, sz * 16)
                samplePlace(.tree, sx * 12, sz * 10)
                samplePlace(.pine, sx * 20, sz * 10)
                samplePlace(.pine, sx * 22, sz * 20)
                samplePlace(.grass, sx * 9, sz * 14)
                samplePlace(.grass, sx * 26, sz * 6)
            }
        }
        autosave()
        message = "Đã tạo khu phố mẫu. Thử bấm Menu → Xuất OBJ."
    }

    /// Xóm ven kênh miền Tây mẫu
    func addSampleMekong() {
        clearAll()
        sampleLine(.canal, SIMD2<Float>(-40, 0), SIMD2<Float>(0, 0), variant: 0)   // bờ đất
        sampleLine(.canal, SIMD2<Float>(0, 0), SIMD2<Float>(40, 0), variant: 1)    // kè gạch
        sampleLine(.road, SIMD2<Float>(-40, -16), SIMD2<Float>(40, -16), variant: 1) // đường bê tông
        sampleLine(.road, SIMD2<Float>(0, -16), SIMD2<Float>(0, -4), variant: 2)     // đường đất ra cầu
        sampleLine(.bridge, SIMD2<Float>(0, -4), SIMD2<Float>(0, 4), variant: 0)

        var i = 0
        for x in stride(from: -36 as Float, through: 36, by: 9) where x != 0 {
            samplePlace(.stilt, x, -9.5, variant: i % 3)                 // bờ bắc, quay mặt ra kênh
            samplePlace(.coconut, x + 4.5, -7.5)
            samplePlace(.tole, x, 8, rot: Float.pi, variant: i % 5)      // bờ nam
            samplePlace(.coconut, x + 4.5, 7.5)
            samplePlace(.grass, x + 2, -4.2)
            samplePlace(.grass, x - 2, 4.4)
            i += 1
        }
        for x: Float in [-31, -13, 4, 22, 31] {
            samplePlace(.nipa, x, -4.0)
            samplePlace(.nipa, x + 3, 4.0)
        }
        for x: Float in [-24, -8, 10, 28] {
            samplePlace(.grass, x, -13.5)
            samplePlace(.grass, x + 4, 13)
        }
        // cây trái, hoa lá và nét đặc trưng miền Tây
        for x: Float in [-33, -15, 12, 30] { samplePlace(.banana, x, -13) }
        samplePlace(.ban, -22, -3.6)
        samplePlace(.ban, 17, 3.8)
        samplePlace(.bamboo, -38, 13)
        samplePlace(.bamboo, 38, -12)
        for (i, x) in ([-30, -12, 6, 24] as [Float]).enumerated() { samplePlace(.fruit, x, 14.5, variant: i) }
        samplePlace(.mai, -5, -12, variant: 0)
        samplePlace(.hibiscus, -7.5, 11)
        samplePlace(.hibiscus, 7.5, 11, variant: 1)
        samplePlace(.flowers, -3.5, 12.5, variant: 0)
        samplePlace(.flowers, 3.5, 12.5, variant: 1)
        samplePlace(.lotus, 16, 20, variant: 0)
        samplePlace(.lotus, -18, 20, variant: 1)
        samplePlace(.rice, -22, -24, variant: 1)
        samplePlace(.rice, 22, -24, variant: 0)
        samplePlace(.dragonFruit, 34, 14)
        samplePlace(.nhaCo, 0, 9.5, rot: Float.pi, variant: 0)
        samplePlace(.chuaKhmer, 4, -31)
        samplePlace(.brickKiln, 38, -22)
        samplePlace(.haystack, 8, -22)
        samplePlace(.gourdTrellis, -26, 12.5, variant: 0)
        samplePlace(.waterJars, 11, 6.2)
        samplePlace(.riverStall, -12, -12)
        samplePlace(.buffalo, -30, 18)
        samplePlace(.duckFlock, 8, 0.2, variant: 0)
        samplePlace(.gheBeo, -4, 0.2, variant: 0)
        samplePlace(.fishRaft, 34, 0)
        samplePlace(.boat, -14, 0.3, variant: 0)
        samplePlace(.boat, 14, -0.3, rot: 0.05, variant: 1)
        samplePlace(.boat, 26, 0, variant: 2)
        autosave()
        message = "Đã tạo xóm ven kênh miền Tây mẫu."
    }

    // MARK: - Lưu / mở dự án (tự động)

    var documentsURL: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }

    var projectURL: URL {
        documentsURL.appendingPathComponent("project.json")
    }

    func autosave() {
        if let data = try? JSONEncoder().encode(items) {
            try? data.write(to: projectURL, options: .atomic)
        }
    }

    func loadProject() {
        guard let data = try? Data(contentsOf: projectURL),
              let loaded = try? JSONDecoder().decode([Item].self, from: data) else { return }
        for it in loaded { insert(it) }
    }

    // MARK: - Xuất file 3D

    func export(_ format: ExportFormat) {
        guard !items.isEmpty else {
            message = "Chưa có gì để xuất. Hãy đặt vài vật thể trước."
            return
        }

        let exp = SCNScene()
        exp.rootNode.addChildNode(world.clone())
        if includeGround {
            let g = SCNPlane(width: 160, height: 160)
            g.materials = [TextureLibrary.material(.grass, roughness: 1, repeatX: 40, repeatY: 40)]
            let gn = SCNNode(geometry: g)
            gn.eulerAngles.x = -Float.pi / 2
            gn.name = "ground"
            exp.rootNode.addChildNode(gn)
        }

        let f = DateFormatter()
        f.dateFormat = "yyyyMMdd_HHmmss"
        let url = documentsURL.appendingPathComponent("ThanhPho_\(f.string(from: Date())).\(format.ext)")

        do {
            switch format {
            case .obj:
                let asset = MDLAsset(scnScene: exp)
                try asset.export(to: url)
            case .usdz, .scn:
                let ok = exp.write(to: url, options: nil, delegate: nil, progressHandler: nil)
                if !ok { throw ExportError(text: "Không ghi được file \(format.ext)") }
            }
            shareItem = ShareItem(url: url)
            message = "Đã xuất \(url.lastPathComponent). Lưu vào Tệp hoặc gửi đi."
        } catch {
            message = "Lỗi xuất file: \(error.localizedDescription)"
        }
    }
}
