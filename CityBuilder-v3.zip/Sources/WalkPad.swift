import SwiftUI

/// Điều khiển kiểu game di động trong chế độ đi dạo:
/// chạm bất kỳ đâu ở NỬA TRÁI màn hình thì cần đi hiện ra đúng chỗ ngón tay (kéo để đi, thả để dừng);
/// kéo ở NỬA PHẢI để nhìn quanh (thả tay vẫn trượt thêm một chút cho mượt).
struct WalkPad: View {
    @ObservedObject var c: SceneController

    @State private var joyOrigin: CGPoint? = nil
    @State private var knob: CGSize = .zero
    @State private var lookPrev: CGSize = .zero
    @State private var lookActive = false
    private let radius: CGFloat = 62

    var body: some View {
        GeometryReader { geo in
            HStack(spacing: 0) {
                ZStack(alignment: .topLeading) {
                    Color.clear
                    if joyOrigin == nil {
                        // vòng gợi ý lúc chưa chạm (chạm chỗ nào ở nửa trái cũng được)
                        ring
                            .opacity(0.45)
                            .position(x: 92, y: geo.size.height - 150)
                            .allowsHitTesting(false)
                    }
                    if let o = joyOrigin {
                        ZStack {
                            ring
                            Circle()
                                .fill(Theme.gradient)
                                .frame(width: 56, height: 56)
                                .shadow(color: .black.opacity(0.35), radius: 6, y: 3)
                                .offset(knob)
                        }
                        .position(x: o.x, y: o.y)
                        .allowsHitTesting(false)
                    }
                }
                .frame(width: geo.size.width / 2, height: geo.size.height)
                .contentShape(Rectangle())
                .gesture(joyGesture)

                Color.clear
                    .frame(width: geo.size.width / 2, height: geo.size.height)
                    .contentShape(Rectangle())
                    .gesture(lookGesture)
            }
        }
    }

    private var ring: some View {
        Circle()
            .fill(Color.white.opacity(0.10))
            .overlay(Circle().stroke(Color.white.opacity(0.40), lineWidth: 1.5))
            .frame(width: radius * 2, height: radius * 2)
    }

    private var joyGesture: some Gesture {
        DragGesture(minimumDistance: 0)
            .onChanged { v in
                if joyOrigin == nil { joyOrigin = v.startLocation }
                let o = joyOrigin ?? v.startLocation
                let dx = v.location.x - o.x
                let dy = v.location.y - o.y
                let len = sqrt(dx * dx + dy * dy)
                let k: CGFloat = len > radius ? radius / len : 1
                knob = CGSize(width: dx * k, height: dy * k)
                c.joy = SIMD2<Float>(Float(dx * k / radius), Float(-dy * k / radius))
            }
            .onEnded { _ in
                joyOrigin = nil
                knob = .zero
                c.joy = SIMD2<Float>(0, 0)
            }
    }

    private var lookGesture: some Gesture {
        DragGesture(minimumDistance: 0)
            .onChanged { v in
                if !lookActive {
                    lookActive = true
                    lookPrev = .zero
                    c.beginLook()
                }
                let t = v.translation
                let dx = t.width - lookPrev.width
                let dy = t.height - lookPrev.height
                lookPrev = t
                c.walkLookBy(dx: Float(dx), dy: Float(dy))
            }
            .onEnded { _ in
                lookActive = false
                lookPrev = .zero
                c.endLook()
            }
    }
}
