import SceneKit
import UIKit
import simd

/// Nhân vật 2D dựng từ ảnh (ảnh PNG nền trong suốt "photoChar" trong Assets).
/// Là một tấm phẳng luôn quay mặt về phía camera (billboard quanh trục Y), đứng trên mặt đất,
/// có bóng dưới chân. Dáng đi được giả bằng nhún, nghiêng và co giãn theo vận tốc.
final class PhotoAvatar: WalkAvatar {
    /// Tên đặc biệt lưu trong `walkCharacter` để chọn nhân vật ảnh này.
    static let key = "@photo"
    static let title = "Nhân vật ảnh"

    let root = SCNNode()
    private let sprite = SCNNode()   // billboard + nhún lên xuống
    private let sway = SCNNode()     // nghiêng và co giãn quanh chân (không bị billboard ghi đè)
    private let shadow = SCNNode()
    private var phase: Float = 0
    private var amount: Float = 0
    private var flip = false
    private var jumpT: Float = -1
    private var emote: WalkEmote? = nil
    private var emoteT: Float = 0
    private var emoteHold = false
    private let height: CGFloat = 1.75
    private var material = SCNMaterial()
    private var frontImage: UIImage
    private var backImage: UIImage?
    private var showingBack = false
    /// Camera để biết đang nhìn thấy mặt trước, mặt sau hay mặt bên của nhân vật.
    weak var cameraNode: SCNNode?

    static func load() -> PhotoAvatar? {
        guard let img = UIImage(named: "photoChar") else { return nil }
        return PhotoAvatar(image: img, back: UIImage(named: "photoCharBack"))
    }

    private init(image: UIImage, back: UIImage?) {
        frontImage = image
        backImage = back
        let aspect = image.size.width / max(image.size.height, 1)
        let plane = SCNPlane(width: height * aspect, height: height)
        let m = material
        m.diffuse.contents = image
        m.diffuse.mipFilter = .linear
        m.lightingModel = .constant
        m.isDoubleSided = true
        m.transparencyMode = .aOne
        m.writesToDepthBuffer = true
        plane.materials = [m]
        let planeNode = SCNNode(geometry: plane)
        planeNode.position = SCNVector3(0, Float(height / 2), 0)
        sway.addChildNode(planeNode)
        sprite.addChildNode(sway)
        // luôn quay mặt về camera, chỉ xoay quanh trục đứng
        let bb = SCNBillboardConstraint()
        bb.freeAxes = .Y
        sprite.constraints = [bb]
        root.addChildNode(sprite)

        // bóng tròn mềm dưới chân
        let s = SCNPlane(width: 0.8, height: 0.8)
        let sm = SCNMaterial()
        sm.diffuse.contents = PhotoAvatar.shadowImage()
        sm.lightingModel = .constant
        sm.writesToDepthBuffer = false
        s.materials = [sm]
        shadow.geometry = s
        shadow.eulerAngles.x = -Float.pi / 2
        shadow.position = SCNVector3(0, 0.02, 0)
        root.addChildNode(shadow)
    }

    private static func shadowImage() -> UIImage {
        let size = CGSize(width: 128, height: 128)
        return UIGraphicsImageRenderer(size: size).image { ctx in
            let cs = CGColorSpaceCreateDeviceRGB()
            let colors = [UIColor(white: 0, alpha: 0.45).cgColor, UIColor(white: 0, alpha: 0).cgColor] as CFArray
            if let g = CGGradient(colorsSpace: cs, colors: colors, locations: [0, 1]) {
                ctx.cgContext.drawRadialGradient(g, startCenter: CGPoint(x: 64, y: 64), startRadius: 0,
                                                 endCenter: CGPoint(x: 64, y: 64), endRadius: 64, options: [])
            }
        }
    }

    // MARK: - WalkAvatar

    func animate(speed: Float, dt: Float) {
        let target: Float = min(speed / 1.6, 2.2)
        amount += (target - amount) * min(1, dt * 8)
        phase += dt * (4 + 5 * amount) * 1.6

        var y: Float = 0
        var roll: Float = 0
        var sx: Float = 1, sy: Float = 1

        // Chọn ảnh theo hướng nhìn: mặt trước / mặt sau, quay ngang thì thu hẹp bề ngang.
        if let cam = cameraNode {
            let yaw = root.eulerAngles.y
            let fwd = SIMD2<Float>(sin(yaw), cos(yaw))
            let rp = root.simdWorldPosition, cp = cam.simdWorldPosition
            var toCam = SIMD2<Float>(cp.x - rp.x, cp.z - rp.z)
            let len = simd_length(toCam)
            if len > 0.001 {
                toCam /= len
                let d = simd_dot(fwd, toCam)           // > 0: camera ở phía trước mặt nhân vật
                let wantBack = d < -0.15 && backImage != nil
                if wantBack != showingBack {
                    showingBack = wantBack
                    material.diffuse.contents = wantBack ? backImage : frontImage
                }
                sx *= 0.42 + 0.58 * pow(abs(d), 0.6)
            }
        }

        if amount > 0.02 {
            let step = abs(sin(phase))
            y += step * 0.07 * min(amount, 1.4)
            roll += sin(phase) * 0.07 * min(amount, 1.4)
            sy += (0.5 - step) * 0.03 * amount
            sx -= (0.5 - step) * 0.02 * amount
        } else {
            let breathe = sin(phase * 0.25)
            sy += breathe * 0.006
        }

        if jumpT >= 0 {
            jumpT += dt
            let d: Float = 0.7
            if jumpT >= d { jumpT = -1 } else {
                let k = jumpT / d
                y += 4 * k * (1 - k) * 0.9
                sy += 4 * k * (1 - k) * 0.05
            }
        }

        if let e = emote {
            emoteT += dt
            switch e {
            case .wave:
                roll += sin(emoteT * 9) * 0.10
                if emoteT > 2.2 { stopEmote() }
            case .dance:
                roll += sin(emoteT * 7) * 0.18
                y += abs(sin(emoteT * 7)) * 0.12
                if emoteT > 4 { stopEmote() }
            case .work:
                roll += sin(emoteT * 5) * 0.05
                sy += sin(emoteT * 5) * 0.03
                if emoteT > 3 { stopEmote() }
            case .bow:
                let k = min(emoteT / 0.5, 1)
                let back = emoteT > 1.4 ? max(0, 1 - (emoteT - 1.4) / 0.5) : 1
                sy -= 0.14 * k * back
                roll += 0.0
                if emoteT > 1.9 { stopEmote() }
            case .sit, .squat, .cross:
                sy -= 0.28
                y -= 0
            case .jump, .climb:
                if emoteT > 1 { stopEmote() }
            }
        }

        sprite.position = SCNVector3(0, y, 0)
        sway.scale = SCNVector3((flip ? -sx : sx), sy, 1)
        sway.eulerAngles.z = roll
        shadow.scale = SCNVector3(1 - y * 0.4, 1 - y * 0.4, 1)
    }

    func cycleOutfit() {}

    func doAction() -> String {
        if jumpT < 0 { jumpT = 0 }
        return "Nhảy!"
    }

    func turnFacing() {
        flip.toggle()
    }

    func perform(_ e: WalkEmote) -> String {
        emoteT = 0
        switch e {
        case .jump:
            jumpT = 0
            emote = nil
            emoteHold = false
            return "Nhảy!"
        case .sit, .squat, .cross:
            emote = e
            emoteHold = true
            return e.title
        default:
            emote = e
            emoteHold = false
            return e.title
        }
    }

    func stopEmote() {
        emote = nil
        emoteHold = false
        emoteT = 0
    }

    var customActions: [String] { [] }
    func playCustom(_ index: Int) -> String { "" }
}
