import SceneKit
import UIKit
import simd

/// Nhân vật 3D điều khiển được. Dựng từ file OBJ có sẵn (Male_Character): tách từng bộ phận
/// (áo, quần, giày, tay, chân, đầu, ba lô...) rồi gắn vào các khớp hông, gối, vai, khuỷu
/// để có dáng đi và chạy thật. Quay mặt về +Z.
final class Avatar {
    let root = SCNNode()          // vị trí + hướng quay trong thế giới
    private let body = SCNNode()  // đưa chân xuống đất + tỉ lệ
    private let torso = SCNNode()
    private let legL = SCNNode()
    private let kneeL = SCNNode()
    private let legR = SCNNode()
    private let kneeR = SCNNode()
    private let armL = SCNNode()
    private let elbowL = SCNNode()
    private let armR = SCNNode()
    private let elbowR = SCNNode()

    private var phase: Float = 0
    private var amount: Float = 0       // 0 đứng yên ... ~1 đi nhanh ... ~2 chạy (làm mượt)
    private var materials: [String: SCNMaterial] = [:]
    private var original: [String: UIColor] = [:]
    private var outfit = 0
    private let baseY: Float
    private var hat: SCNNode?
    private var scarfMats: [SCNMaterial] = []

    private init(scale: Float, footOffset: Float) {
        baseY = -footOffset * scale
        body.scale = SCNVector3(scale, scale, scale)
        body.position = SCNVector3(0, baseY, 0)
        root.addChildNode(body)
    }

    // MARK: - Dựng từ file OBJ

    private enum Group { case torso, thighL, shinL, thighR, shinR, upperL, foreL, upperR, foreR }

    private static func group(_ n: String) -> Group {
        for (side, thigh, shin, upper, fore) in [("L", Group.thighL, Group.shinL, Group.upperL, Group.foreL),
                                                  ("R", Group.thighR, Group.shinR, Group.upperR, Group.foreR)] {
            if n.hasPrefix("Sole_\(side)") || n.hasPrefix("Sneaker_\(side)") || n.hasPrefix("Laces_\(side)")
                || n.hasPrefix("Trouser_\(side)_lower") { return shin }
            if n.hasPrefix("Trouser_\(side)_upper") || n.hasPrefix("CargoPocket_\(side)")
                || n.hasPrefix("PocketFlap_\(side)") { return thigh }
            if n.hasPrefix("SleeveUpper_\(side)") { return upper }
            if n.hasPrefix("Elbow_\(side)") || n.hasPrefix("SleeveLower_\(side)")
                || n.hasPrefix("Cuff_\(side)") || n.hasPrefix("Hand_\(side)") { return fore }
        }
        return .torso
    }

    private struct Part {
        var name: String
        var mat: String
        var tris: [(Int, Int, Int)]
    }

    private static func parseOBJ(_ url: URL) -> (verts: [SIMD3<Float>], parts: [Part])? {
        guard let text = try? String(contentsOf: url, encoding: .utf8) else { return nil }
        var verts: [SIMD3<Float>] = []
        var parts: [Part] = []
        for line in text.split(whereSeparator: { $0.isNewline }) {
            if line.hasPrefix("v ") {
                let c = line.split(separator: " ")
                if c.count >= 4, let x = Float(c[1]), let y = Float(c[2]), let z = Float(c[3]) {
                    verts.append(SIMD3<Float>(x, y, z))
                }
            } else if line.hasPrefix("o ") || line.hasPrefix("g ") {
                let name = String(line.dropFirst(2)).trimmingCharacters(in: .whitespaces)
                parts.append(Part(name: name, mat: "", tris: []))
            } else if line.hasPrefix("usemtl ") {
                if parts.isEmpty { parts.append(Part(name: "body", mat: "", tris: [])) }
                parts[parts.count - 1].mat = String(line.dropFirst(7)).trimmingCharacters(in: .whitespaces)
            } else if line.hasPrefix("f ") {
                if parts.isEmpty { parts.append(Part(name: "body", mat: "", tris: [])) }
                var idx: [Int] = []
                for tok in line.split(separator: " ").dropFirst() {
                    let first = tok.split(separator: "/", omittingEmptySubsequences: false).first ?? ""
                    if let i = Int(first) { idx.append(i > 0 ? i - 1 : verts.count + i) }
                }
                if idx.count >= 3 {
                    for k in 1..<(idx.count - 1) {
                        parts[parts.count - 1].tris.append((idx[0], idx[k], idx[k + 1]))
                    }
                }
            }
        }
        return (verts, parts)
    }

    private static func parseMTL(_ url: URL?) -> [String: SCNMaterial] {
        var out: [String: SCNMaterial] = [:]
        guard let url = url, let text = try? String(contentsOf: url, encoding: .utf8) else { return out }
        var cur: SCNMaterial? = nil
        for line in text.split(whereSeparator: { $0.isNewline }) {
            let c = line.split(separator: " ")
            guard let key = c.first else { continue }
            if key == "newmtl", c.count >= 2 {
                let m = SCNMaterial()
                m.lightingModel = .blinn
                m.diffuse.contents = UIColor(white: 0.7, alpha: 1)
                m.isDoubleSided = true
                out[String(c[1])] = m
                cur = m
            } else if key == "Kd", c.count >= 4, let m = cur,
                      let r = Float(c[1]), let g = Float(c[2]), let b = Float(c[3]) {
                m.diffuse.contents = UIColor(red: CGFloat(r), green: CGFloat(g), blue: CGFloat(b), alpha: 1)
            } else if key == "Ks", c.count >= 4, let m = cur,
                      let r = Float(c[1]), let g = Float(c[2]), let b = Float(c[3]) {
                m.specular.contents = UIColor(red: CGFloat(r), green: CGFloat(g), blue: CGFloat(b), alpha: 1)
            } else if key == "Ns", c.count >= 2, let m = cur, let n = Float(c[1]) {
                m.shininess = CGFloat(n / 100)
            }
        }
        return out
    }

    /// Hình học của một bộ phận. Pháp tuyến mịn trên mặt cong, giữ cạnh sắc ở góc gấp (> ~45°).
    private static func geometry(_ verts: [SIMD3<Float>], _ tris: [(Int, Int, Int)]) -> SCNGeometry? {
        guard !tris.isEmpty else { return nil }
        var faceN: [SIMD3<Float>] = []
        var adj: [Int: [Int]] = [:]
        for (i, t) in tris.enumerated() {
            guard t.0 < verts.count, t.1 < verts.count, t.2 < verts.count else {
                faceN.append(SIMD3<Float>(0, 1, 0))
                continue
            }
            let a = verts[t.0]
            let b = verts[t.1]
            let c = verts[t.2]
            let n = simd_cross(b - a, c - a)
            let l = simd_length(n)
            faceN.append(l > 1e-9 ? n / l : SIMD3<Float>(0, 1, 0))
            adj[t.0, default: []].append(i)
            adj[t.1, default: []].append(i)
            adj[t.2, default: []].append(i)
        }
        var pos: [SCNVector3] = []
        var nor: [SCNVector3] = []
        var idx: [Int32] = []
        for (i, t) in tris.enumerated() {
            guard t.0 < verts.count, t.1 < verts.count, t.2 < verts.count else { continue }
            for v in [t.0, t.1, t.2] {
                var sum = SIMD3<Float>(0, 0, 0)
                for j in adj[v] ?? [] where simd_dot(faceN[i], faceN[j]) > 0.7 {
                    sum += faceN[j]
                }
                let l = simd_length(sum)
                let n = l > 1e-6 ? sum / l : faceN[i]
                let p = verts[v]
                idx.append(Int32(pos.count))
                pos.append(SCNVector3(p.x, p.y, p.z))
                nor.append(SCNVector3(n.x, n.y, n.z))
            }
        }
        return SCNGeometry(sources: [SCNGeometrySource(vertices: pos), SCNGeometrySource(normals: nor)],
                           elements: [SCNGeometryElement(indices: idx, primitiveType: .triangles)])
    }

    // MARK: - Trang phục miền Tây: áo bà ba, quần lụa, khăn rằn, nón lá

    /// Biến đổi hình dáng từng bộ phận của mô hình gốc cho ra áo bà ba (dài tới hông, tà hơi xòe)
    /// và quần ống rộng; bàn chân để trần đi dép.
    private static func reshaper(_ name: String) -> ((SIMD3<Float>) -> SIMD3<Float>)? {
        if name == "JacketTorso" {
            return { p in
                var q = p
                if q.y < 1.30 {
                    q.y = 1.30 - (1.30 - q.y) * 2.3125            // kéo vạt áo xuống tới ~0.93 (ngang hông)
                    let t = min(max((1.30 - q.y) / 0.37, 0), 1)
                    let f = 1 + 0.07 * t                           // tà áo xòe nhẹ
                    q.x *= f
                    q.z *= f
                }
                return q
            }
        }
        if name.hasPrefix("Trouser_") {
            let cx: Float = name.contains("_L") ? -0.105 : 0.105
            return { p in
                let t = min(max((1.10 - p.y) / 0.91, 0), 1)      // 0 ở hông ... 1 ở cổ chân
                let f = 1.10 + 0.14 * t                            // ống quần suông, rộng dần xuống dưới
                return SIMD3<Float>(cx + (p.x - cx) * f, p.y, p.z * f)
            }
        }
        if name.hasPrefix("Sneaker_") {
            let cx: Float = name.hasSuffix("L") ? -0.115 : 0.115
            return { p in SIMD3<Float>(cx + (p.x - cx) * 0.9, p.y, 0.03 + (p.z - 0.03) * 0.92) }
        }
        return nil
    }

    private static func scarfImage(_ style: Int) -> UIImage {
        let size = CGSize(width: 96, height: 96)
        let base = style == 0 ? UIColor(red: 0.93, green: 0.91, blue: 0.86, alpha: 1)
                              : UIColor(red: 0.90, green: 0.92, blue: 0.93, alpha: 1)
        let band = style == 0 ? UIColor(red: 0.62, green: 0.10, blue: 0.10, alpha: 1)
                              : UIColor(red: 0.10, green: 0.25, blue: 0.50, alpha: 1)
        let dark = UIColor(red: 0.10, green: 0.10, blue: 0.11, alpha: 1)
        return UIGraphicsImageRenderer(size: size).image { ctx in
            base.setFill()
            ctx.fill(CGRect(origin: .zero, size: size))
            for i in 0..<3 {
                let o = CGFloat(i) * 32
                band.withAlphaComponent(0.85).setFill()
                ctx.fill(CGRect(x: o + 8, y: 0, width: 14, height: 96))
                ctx.fill(CGRect(x: 0, y: o + 8, width: 96, height: 14))
                dark.setFill()
                ctx.fill(CGRect(x: o + 13, y: 0, width: 4, height: 96))
                ctx.fill(CGRect(x: 0, y: o + 13, width: 96, height: 4))
            }
            // sợi vải
            UIColor(white: 0, alpha: 0.05).setFill()
            for k in stride(from: 0, to: 96, by: 3) {
                ctx.fill(CGRect(x: k, y: 0, width: 1, height: 96))
            }
        }
    }

    private static func strawImage() -> UIImage {
        let size = CGSize(width: 64, height: 64)
        return UIGraphicsImageRenderer(size: size).image { ctx in
            UIColor(red: 0.86, green: 0.74, blue: 0.47, alpha: 1).setFill()
            ctx.fill(CGRect(origin: .zero, size: size))
            UIColor(red: 0.62, green: 0.48, blue: 0.25, alpha: 0.55).setFill()
            for y in stride(from: 0, to: 64, by: 5) { ctx.fill(CGRect(x: 0, y: y, width: 64, height: 1)) }
            UIColor(red: 0.95, green: 0.86, blue: 0.60, alpha: 0.35).setFill()
            for x in stride(from: 0, to: 64, by: 4) { ctx.fill(CGRect(x: x, y: 0, width: 1, height: 64)) }
        }
    }

    /// Đọc nhân vật có sẵn trong app. Trả về nil nếu không đọc được file (khi đó dùng `fallback()`).
    static func load() -> Avatar? {
        let fm = FileManager.default
        var objURL = Bundle.main.url(forResource: "Male_Character", withExtension: "obj", subdirectory: "Builtin")
        var mtlURL = Bundle.main.url(forResource: "Male_Character", withExtension: "mtl", subdirectory: "Builtin")
        if objURL == nil {
            let d = Builder.modelsDirectory.appendingPathComponent("Nhân vật nam", isDirectory: true)
            objURL = d.appendingPathComponent("Male_Character.obj")
            mtlURL = d.appendingPathComponent("Male_Character.mtl")
        }
        guard let o = objURL, fm.fileExists(atPath: o.path),
              let parsed = parseOBJ(o), !parsed.parts.isEmpty else { return nil }

        let av = Avatar(scale: 0.82, footOffset: 0.045)
        av.materials = parseMTL(mtlURL)
        func tune(_ k: String, _ r: CGFloat, _ g: CGFloat, _ b: CGFloat, _ spec: CGFloat, _ shine: CGFloat) {
            let m = av.materials[k] ?? SCNMaterial()
            m.lightingModel = .blinn
            m.isDoubleSided = true
            m.diffuse.contents = UIColor(red: r, green: g, blue: b, alpha: 1)
            m.specular.contents = UIColor(white: spec, alpha: 1)
            m.shininess = shine
            av.materials[k] = m
        }
        tune("Jacket", 0.06, 0.06, 0.07, 0.35, 0.30)     // áo bà ba lụa đen
        tune("Pants", 0.045, 0.045, 0.05, 0.30, 0.30)    // quần lụa đen
        tune("Skin", 0.74, 0.51, 0.36, 0.10, 0.12)
        tune("Hair", 0.03, 0.025, 0.022, 0.20, 0.30)
        tune("Dep", 0.12, 0.30, 0.55, 0.20, 0.20)        // dép
        for (k, m) in av.materials {
            if let c = m.diffuse.contents as? UIColor { av.original[k] = c }
        }
        let fallbackMat = SCNMaterial()
        fallbackMat.lightingModel = .blinn
        fallbackMat.diffuse.contents = UIColor(white: 0.7, alpha: 1)

        // vị trí các khớp (toạ độ của mô hình gốc)
        let torsoJ = SIMD3<Float>(0, 1.0, 0)
        let hip: [Float: SIMD3<Float>] = [-1: SIMD3<Float>(-0.105, 1.05, 0), 1: SIMD3<Float>(0.105, 1.05, 0)]
        let knee: [Float: SIMD3<Float>] = [-1: SIMD3<Float>(-0.105, 0.70, 0), 1: SIMD3<Float>(0.105, 0.70, 0)]
        let shoulder: [Float: SIMD3<Float>] = [-1: SIMD3<Float>(-0.29, 1.60, 0.02), 1: SIMD3<Float>(0.29, 1.60, 0.02)]
        let elbow: [Float: SIMD3<Float>] = [-1: SIMD3<Float>(-0.335, 1.39, 0.03), 1: SIMD3<Float>(0.335, 1.39, 0.03)]

        func v3(_ v: SIMD3<Float>) -> SCNVector3 { SCNVector3(v.x, v.y, v.z) }

        av.torso.position = v3(torsoJ)
        av.body.addChildNode(av.torso)
        av.legL.position = v3(hip[-1]!)
        av.legR.position = v3(hip[1]!)
        av.body.addChildNode(av.legL)
        av.body.addChildNode(av.legR)
        av.kneeL.position = v3(knee[-1]! - hip[-1]!)
        av.kneeR.position = v3(knee[1]! - hip[1]!)
        av.legL.addChildNode(av.kneeL)
        av.legR.addChildNode(av.kneeR)
        av.armL.position = v3(shoulder[-1]! - torsoJ)
        av.armR.position = v3(shoulder[1]! - torsoJ)
        av.torso.addChildNode(av.armL)
        av.torso.addChildNode(av.armR)
        av.elbowL.position = v3(elbow[-1]! - shoulder[-1]!)
        av.elbowR.position = v3(elbow[1]! - shoulder[1]!)
        av.armL.addChildNode(av.elbowL)
        av.armR.addChildNode(av.elbowR)

        let skip = ["Backpack", "Strap_", "Zipper", "JacketPanel", "Collar_", "CargoPocket", "PocketFlap",
                    "Buckle", "Belt", "ShirtTorso", "Laces_"]
        var torsoPts: [SIMD3<Float>] = []
        var footPts: [Float: [SIMD3<Float>]] = [-1: [], 1: []]

        for part in parsed.parts {
            if skip.contains(where: { part.name.hasPrefix($0) }) { continue }
            var vs = parsed.verts
            let used = Set(part.tris.flatMap { [$0.0, $0.1, $0.2] })
            if let f = reshaper(part.name) {
                for i in used where i < vs.count { vs[i] = f(vs[i]) }
            }
            guard let g = geometry(vs, part.tris) else { continue }
            var matName = part.mat
            if part.name.hasPrefix("Cuff_") { matName = "Jacket" }
            if part.name.hasPrefix("Sneaker_") { matName = "Skin" }
            if part.name.hasPrefix("Sole_") { matName = "Dep" }
            g.materials = [av.materials[matName] ?? fallbackMat]
            if part.name == "JacketTorso" { torsoPts = used.filter { $0 < vs.count }.map { vs[$0] } }
            if part.name.hasPrefix("Sneaker_") {
                footPts[part.name.hasSuffix("L") ? -1 : 1] = used.filter { $0 < vs.count }.map { vs[$0] }
            }
            let n = SCNNode(geometry: g)
            let parent: SCNNode
            let joint: SIMD3<Float>
            switch group(part.name) {
            case .torso:  parent = av.torso;  joint = torsoJ
            case .thighL: parent = av.legL;   joint = hip[-1]!
            case .shinL:  parent = av.kneeL;  joint = knee[-1]!
            case .thighR: parent = av.legR;   joint = hip[1]!
            case .shinR:  parent = av.kneeR;  joint = knee[1]!
            case .upperL: parent = av.armL;   joint = shoulder[-1]!
            case .foreL:  parent = av.elbowL; joint = elbow[-1]!
            case .upperR: parent = av.armR;   joint = shoulder[1]!
            case .foreR:  parent = av.elbowR; joint = elbow[1]!
            }
            n.position = v3(-joint)
            parent.addChildNode(n)
        }

        // ---- chi tiết áo bà ba ----
        func frontZ(_ x: Float, _ y: Float) -> Float {
            let z = torsoPts.filter { abs($0.x - x) < 0.05 && abs($0.y - y) < 0.05 }.map { $0.z }.max()
            return z ?? 0.14
        }
        func add(_ geo: SCNGeometry, _ mat: SCNMaterial, _ parent: SCNNode, _ pos: SIMD3<Float>, _ base: SIMD3<Float>) -> SCNNode {
            geo.materials = [mat]
            let nd = SCNNode(geometry: geo)
            nd.position = v3(pos - base)
            parent.addChildNode(nd)
            return nd
        }
        let jacketMat = av.materials["Jacket"] ?? fallbackMat
        let pearl = SCNMaterial()
        pearl.lightingModel = .blinn
        pearl.diffuse.contents = UIColor(red: 0.92, green: 0.88, blue: 0.78, alpha: 1)
        pearl.specular.contents = UIColor(white: 0.5, alpha: 1)
        // hàng cúc giữa ngực
        for y in stride(from: Float(1.62), through: 1.05, by: -0.095) {
            _ = add(SCNSphere(radius: 0.0125), pearl, av.torso, SIMD3<Float>(0.0, y, frontZ(0, y) + 0.004), torsoJ)
        }
        // hai túi áo ở vạt dưới
        for sx in [Float(-1), Float(1)] {
            let x = sx * 0.115
            let y: Float = 1.08
            let z = frontZ(x, y) + 0.003
            let pocket = add(SCNBox(width: 0.10, height: 0.11, length: 0.008, chamferRadius: 0.003),
                             jacketMat, av.torso, SIMD3<Float>(x, y, z), torsoJ)
            pocket.eulerAngles.x = 0.05
        }
        // cổ áo tròn (cổ tàu thấp)
        _ = add(SCNTube(innerRadius: 0.066, outerRadius: 0.088, height: 0.035), jacketMat, av.torso,
                SIMD3<Float>(0, 1.715, -0.004), torsoJ)

        // ---- khăn rằn quàng cổ ----
        func scarfMat(_ sx: Float, _ sy: Float) -> SCNMaterial {
            let m = SCNMaterial()
            m.lightingModel = .blinn
            m.isDoubleSided = true
            m.diffuse.contents = scarfImage(0)
            m.diffuse.wrapS = .repeat
            m.diffuse.wrapT = .repeat
            m.diffuse.contentsTransform = SCNMatrix4MakeScale(sx, sy, 1)
            m.specular.contents = UIColor(white: 0.05, alpha: 1)
            av.scarfMats.append(m)
            return m
        }
        let ring = SCNTorus(ringRadius: 0.100, pipeRadius: 0.040)
        let ringNode = add(ring, scarfMat(10, 2), av.torso, SIMD3<Float>(0, 1.705, -0.004), torsoJ)
        ringNode.scale = SCNVector3(1, 0.85, 1.05)
        let fz = frontZ(0.05, 1.50)
        let knot = SCNSphere(radius: 0.034)
        _ = add(knot, scarfMat(2, 2), av.torso, SIMD3<Float>(0.045, 1.655, frontZ(0.045, 1.655) + 0.012), torsoJ)
        let tail = add(SCNBox(width: 0.075, height: 0.30, length: 0.012, chamferRadius: 0.002),
                       scarfMat(1, 3), av.torso, SIMD3<Float>(0.055, 1.50, fz + 0.016), torsoJ)
        tail.eulerAngles.z = -0.10
        tail.eulerAngles.x = 0.06

        // ---- nón lá ----
        let hatMat = SCNMaterial()
        hatMat.lightingModel = .blinn
        hatMat.isDoubleSided = true
        hatMat.diffuse.contents = strawImage()
        hatMat.diffuse.wrapS = .repeat
        hatMat.diffuse.wrapT = .repeat
        hatMat.diffuse.contentsTransform = SCNMatrix4MakeScale(4, 3, 1)
        hatMat.specular.contents = UIColor(white: 0.12, alpha: 1)
        let cone = SCNCone(topRadius: 0.0, bottomRadius: 0.25, height: 0.21)
        cone.radialSegmentCount = 48
        let hatNode = add(cone, hatMat, av.torso, SIMD3<Float>(0, 2.10, -0.012), torsoJ)
        hatNode.eulerAngles.x = -0.10
        let rim = SCNTorus(ringRadius: 0.25, pipeRadius: 0.006)
        rim.pipeSegmentCount = 8
        rim.ringSegmentCount = 48
        let rimMat = SCNMaterial()
        rimMat.diffuse.contents = UIColor(red: 0.50, green: 0.36, blue: 0.18, alpha: 1)
        let rimNode = add(rim, rimMat, hatNode, SIMD3<Float>(0, 0, 0), SIMD3<Float>(0, 0, 0))
        rimNode.position = SCNVector3(0, -0.105, 0)
        av.hat = hatNode

        // ---- dép: quai ngang trên mu bàn chân ----
        let strapMat = av.materials["Dep"] ?? fallbackMat
        for sgn in [Float(-1), Float(1)] {
            let pts = (footPts[sgn] ?? []).filter { abs($0.z - 0.06) < 0.03 }
            guard let top = pts.map({ $0.y }).max(),
                  let x0 = pts.map({ $0.x }).min(), let x1 = pts.map({ $0.x }).max() else { continue }
            let kneeNode = sgn < 0 ? av.kneeL : av.kneeR
            let kj = knee[sgn]!
            let strap = SCNBox(width: CGFloat(x1 - x0) * 1.03, height: 0.012, length: 0.05, chamferRadius: 0.004)
            _ = add(strap, strapMat, kneeNode, SIMD3<Float>((x0 + x1) / 2, top + 0.002, 0.06), kj)
        }
        return av
    }

    /// Nhân vật dựng bằng hình khối đơn giản, dùng khi không đọc được file.
    static func fallback() -> Avatar {
        let av = Avatar(scale: 1.0, footOffset: 0)
        func mat(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat) -> SCNMaterial {
            let m = SCNMaterial()
            m.lightingModel = .blinn
            m.diffuse.contents = UIColor(red: r, green: g, blue: b, alpha: 1)
            return m
        }
        let skin = mat(0.90, 0.72, 0.58)
        let shirt = mat(0.20, 0.45, 0.75)
        let pants = mat(0.18, 0.20, 0.30)
        func add(_ g: SCNGeometry, _ m: SCNMaterial, _ parent: SCNNode, _ x: Float, _ y: Float, _ z: Float) {
            g.materials = [m]
            let n = SCNNode(geometry: g)
            n.position = SCNVector3(x, y, z)
            parent.addChildNode(n)
        }
        av.torso.position = SCNVector3(0, 1.0, 0)
        av.body.addChildNode(av.torso)
        add(SCNBox(width: 0.42, height: 0.6, length: 0.24, chamferRadius: 0.05), shirt, av.torso, 0, 0.35, 0)
        add(SCNSphere(radius: 0.12), skin, av.torso, 0, 0.85, 0)
        for sgn in [Float(-1), Float(1)] {
            let leg = sgn < 0 ? av.legL : av.legR
            let knee = sgn < 0 ? av.kneeL : av.kneeR
            leg.position = SCNVector3(sgn * 0.1, 1.0, 0)
            av.body.addChildNode(leg)
            add(SCNCapsule(capRadius: 0.08, height: 0.5), pants, leg, 0, -0.25, 0)
            knee.position = SCNVector3(0, -0.5, 0)
            leg.addChildNode(knee)
            add(SCNCapsule(capRadius: 0.07, height: 0.5), pants, knee, 0, -0.25, 0)
            add(SCNBox(width: 0.1, height: 0.06, length: 0.24, chamferRadius: 0.02), mat(0.1, 0.1, 0.1), knee, 0, -0.5, 0.05)
            let arm = sgn < 0 ? av.armL : av.armR
            let elbow = sgn < 0 ? av.elbowL : av.elbowR
            arm.position = SCNVector3(sgn * 0.27, 0.58, 0)
            av.torso.addChildNode(arm)
            add(SCNCapsule(capRadius: 0.05, height: 0.32), shirt, arm, 0, -0.16, 0)
            elbow.position = SCNVector3(0, -0.3, 0)
            arm.addChildNode(elbow)
            add(SCNCapsule(capRadius: 0.045, height: 0.3), skin, elbow, 0, -0.15, 0)
            add(SCNSphere(radius: 0.05), skin, elbow, 0, -0.32, 0)
        }
        return av
    }

    // MARK: - Dáng đi, đổi trang phục

    /// `speed` = vận tốc thật (m/s). Chân tay đánh theo quãng đường đã đi nên không bị trượt chân.
    func animate(speed: Float, dt: Float) {
        let target = min(speed / 4.0, 2.2)
        amount += (target - amount) * min(1, dt * 8)
        if speed > 0.15 {
            let cycle = min(1.5 + 0.5 * max(speed - 1.4, 0), 4.5)   // mét đi được trong một chu kỳ bước
            phase += speed * dt / cycle * 2 * Float.pi
            if phase > 2 * Float.pi { phase -= 2 * Float.pi }
        }
        let k = amount
        let s = sin(phase)
        let c = cos(phase)
        let legSwing = 0.30 * k + 0.15 * max(k - 1, 0)
        let armSwing = 0.8 * legSwing
        let kneeBend = 0.40 * k + 0.25 * max(k - 1, 0)

        legL.eulerAngles.x = -legSwing * s
        legR.eulerAngles.x = legSwing * s
        kneeL.eulerAngles.x = kneeBend * max(0, c)
        kneeR.eulerAngles.x = kneeBend * max(0, -c)
        armL.eulerAngles.x = armSwing * s
        armR.eulerAngles.x = -armSwing * s
        let elbowBase = 0.10 + 0.30 * k
        elbowL.eulerAngles.x = -(elbowBase + 0.25 * k * max(0, -s))
        elbowR.eulerAngles.x = -(elbowBase + 0.25 * k * max(0, s))
        torso.eulerAngles.y = 0.12 * min(k, 1.5) * s
        torso.eulerAngles.x = 0.07 * min(k, 2.2)
        body.position.y = baseY + 0.03 * min(k, 1.5) * (1 - abs(s))
    }

    /// Đổi bộ bà ba: màu áo / quần, khăn rằn, nón lá.
    func cycleOutfit() {
        func c(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat) -> UIColor { UIColor(red: r, green: g, blue: b, alpha: 1) }
        // (áo, quần, kiểu khăn rằn, đội nón lá)
        let sets: [(jacket: UIColor?, pants: UIColor?, scarf: Int, hat: Bool)] = [
            (nil, nil, 0, true),                                   // bà ba đen, quần đen, khăn rằn đỏ
            (c(0.90, 0.87, 0.78), c(0.05, 0.05, 0.06), 1, false),  // bà ba trắng kem, quần đen, khăn xanh
            (c(0.16, 0.48, 0.50), c(0.88, 0.86, 0.80), 0, true),   // bà ba xanh ngọc, quần trắng
            (c(0.42, 0.24, 0.14), c(0.05, 0.05, 0.06), 1, false)   // bà ba nâu cánh gián
        ]
        outfit = (outfit + 1) % sets.count
        let o = sets[outfit]
        materials["Jacket"]?.diffuse.contents = o.jacket ?? original["Jacket"]
        materials["Pants"]?.diffuse.contents = o.pants ?? original["Pants"]
        let img = Avatar.scarfImage(o.scarf)
        for m in scarfMats { m.diffuse.contents = img }
        hat?.isHidden = !o.hat
    }
}
