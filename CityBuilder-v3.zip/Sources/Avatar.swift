import SceneKit
import UIKit
import simd

/// Nhân vật 3D điều khiển được. Dựng từ file OBJ có sẵn (Male_Character): tách từng bộ phận
/// (áo, quần, giày, tay, chân, đầu, ba lô...) rồi gắn vào các khớp hông, gối, vai, khuỷu
/// để có dáng đi và chạy thật. Quay mặt về +Z.
final class Avatar {
    let root = SCNNode()          // vị trí + hướng quay trong thế giới
    private let body = SCNNode()  // đưa chân xuống đất + tỉ lệ
    private let torso = SCNNode()
    private let legL = SCNNode()
    private let kneeL = SCNNode()
    private let legR = SCNNode()
    private let kneeR = SCNNode()
    private let armL = SCNNode()
    private let elbowL = SCNNode()
    private let armR = SCNNode()
    private let elbowR = SCNNode()

    private var phase: Float = 0
    private var amount: Float = 0       // 0 đứng yên ... ~1 đi nhanh ... ~2 chạy (làm mượt)
    private var materials: [String: SCNMaterial] = [:]
    private var original: [String: UIColor] = [:]
    private var outfit = 0
    private let baseY: Float

    private init(scale: Float, footOffset: Float) {
        baseY = -footOffset * scale
        body.scale = SCNVector3(scale, scale, scale)
        body.position = SCNVector3(0, baseY, 0)
        root.addChildNode(body)
    }

    // MARK: - Dựng từ file OBJ

    private enum Group { case torso, thighL, shinL, thighR, shinR, upperL, foreL, upperR, foreR }

    private static func group(_ n: String) -> Group {
        for (side, thigh, shin, upper, fore) in [("L", Group.thighL, Group.shinL, Group.upperL, Group.foreL),
                                                  ("R", Group.thighR, Group.shinR, Group.upperR, Group.foreR)] {
            if n.hasPrefix("Sole_\(side)") || n.hasPrefix("Sneaker_\(side)") || n.hasPrefix("Laces_\(side)")
                || n.hasPrefix("Trouser_\(side)_lower") { return shin }
            if n.hasPrefix("Trouser_\(side)_upper") || n.hasPrefix("CargoPocket_\(side)")
                || n.hasPrefix("PocketFlap_\(side)") { return thigh }
            if n.hasPrefix("SleeveUpper_\(side)") { return upper }
            if n.hasPrefix("Elbow_\(side)") || n.hasPrefix("SleeveLower_\(side)")
                || n.hasPrefix("Cuff_\(side)") || n.hasPrefix("Hand_\(side)") { return fore }
        }
        return .torso
    }

    private struct Part {
        var name: String
        var mat: String
        var tris: [(Int, Int, Int)]
    }

    private static func parseOBJ(_ url: URL) -> (verts: [SIMD3<Float>], parts: [Part])? {
        guard let text = try? String(contentsOf: url, encoding: .utf8) else { return nil }
        var verts: [SIMD3<Float>] = []
        var parts: [Part] = []
        for line in text.split(whereSeparator: { $0.isNewline }) {
            if line.hasPrefix("v ") {
                let c = line.split(separator: " ")
                if c.count >= 4, let x = Float(c[1]), let y = Float(c[2]), let z = Float(c[3]) {
                    verts.append(SIMD3<Float>(x, y, z))
                }
            } else if line.hasPrefix("o ") || line.hasPrefix("g ") {
                let name = String(line.dropFirst(2)).trimmingCharacters(in: .whitespaces)
                parts.append(Part(name: name, mat: "", tris: []))
            } else if line.hasPrefix("usemtl ") {
                if parts.isEmpty { parts.append(Part(name: "body", mat: "", tris: [])) }
                parts[parts.count - 1].mat = String(line.dropFirst(7)).trimmingCharacters(in: .whitespaces)
            } else if line.hasPrefix("f ") {
                if parts.isEmpty { parts.append(Part(name: "body", mat: "", tris: [])) }
                var idx: [Int] = []
                for tok in line.split(separator: " ").dropFirst() {
                    let first = tok.split(separator: "/", omittingEmptySubsequences: false).first ?? ""
                    if let i = Int(first) { idx.append(i > 0 ? i - 1 : verts.count + i) }
                }
                if idx.count >= 3 {
                    for k in 1..<(idx.count - 1) {
                        parts[parts.count - 1].tris.append((idx[0], idx[k], idx[k + 1]))
                    }
                }
            }
        }
        return (verts, parts)
    }

    private static func parseMTL(_ url: URL?) -> [String: SCNMaterial] {
        var out: [String: SCNMaterial] = [:]
        guard let url = url, let text = try? String(contentsOf: url, encoding: .utf8) else { return out }
        var cur: SCNMaterial? = nil
        for line in text.split(whereSeparator: { $0.isNewline }) {
            let c = line.split(separator: " ")
            guard let key = c.first else { continue }
            if key == "newmtl", c.count >= 2 {
                let m = SCNMaterial()
                m.lightingModel = .blinn
                m.diffuse.contents = UIColor(white: 0.7, alpha: 1)
                m.isDoubleSided = true
                out[String(c[1])] = m
                cur = m
            } else if key == "Kd", c.count >= 4, let m = cur,
                      let r = Float(c[1]), let g = Float(c[2]), let b = Float(c[3]) {
                m.diffuse.contents = UIColor(red: CGFloat(r), green: CGFloat(g), blue: CGFloat(b), alpha: 1)
            } else if key == "Ks", c.count >= 4, let m = cur,
                      let r = Float(c[1]), let g = Float(c[2]), let b = Float(c[3]) {
                m.specular.contents = UIColor(red: CGFloat(r), green: CGFloat(g), blue: CGFloat(b), alpha: 1)
            } else if key == "Ns", c.count >= 2, let m = cur, let n = Float(c[1]) {
                m.shininess = CGFloat(n / 100)
            }
        }
        return out
    }

    /// Hình học của một bộ phận. Pháp tuyến mịn trên mặt cong, giữ cạnh sắc ở góc gấp (> ~45°).
    private static func geometry(_ verts: [SIMD3<Float>], _ tris: [(Int, Int, Int)]) -> SCNGeometry? {
        guard !tris.isEmpty else { return nil }
        var faceN: [SIMD3<Float>] = []
        var adj: [Int: [Int]] = [:]
        for (i, t) in tris.enumerated() {
            guard t.0 < verts.count, t.1 < verts.count, t.2 < verts.count else {
                faceN.append(SIMD3<Float>(0, 1, 0))
                continue
            }
            let a = verts[t.0]
            let b = verts[t.1]
            let c = verts[t.2]
            let n = simd_cross(b - a, c - a)
            let l = simd_length(n)
            faceN.append(l > 1e-9 ? n / l : SIMD3<Float>(0, 1, 0))
            adj[t.0, default: []].append(i)
            adj[t.1, default: []].append(i)
            adj[t.2, default: []].append(i)
        }
        var pos: [SCNVector3] = []
        var nor: [SCNVector3] = []
        var idx: [Int32] = []
        for (i, t) in tris.enumerated() {
            guard t.0 < verts.count, t.1 < verts.count, t.2 < verts.count else { continue }
            for v in [t.0, t.1, t.2] {
                var sum = SIMD3<Float>(0, 0, 0)
                for j in adj[v] ?? [] where simd_dot(faceN[i], faceN[j]) > 0.7 {
                    sum += faceN[j]
                }
                let l = simd_length(sum)
                let n = l > 1e-6 ? sum / l : faceN[i]
                let p = verts[v]
                idx.append(Int32(pos.count))
                pos.append(SCNVector3(p.x, p.y, p.z))
                nor.append(SCNVector3(n.x, n.y, n.z))
            }
        }
        return SCNGeometry(sources: [SCNGeometrySource(vertices: pos), SCNGeometrySource(normals: nor)],
                           elements: [SCNGeometryElement(indices: idx, primitiveType: .triangles)])
    }

    /// Đọc nhân vật có sẵn trong app. Trả về nil nếu không đọc được file (khi đó dùng `fallback()`).
    static func load() -> Avatar? {
        let fm = FileManager.default
        var objURL = Bundle.main.url(forResource: "Male_Character", withExtension: "obj", subdirectory: "Builtin")
        var mtlURL = Bundle.main.url(forResource: "Male_Character", withExtension: "mtl", subdirectory: "Builtin")
        if objURL == nil {
            let d = Builder.modelsDirectory.appendingPathComponent("Nhân vật nam", isDirectory: true)
            objURL = d.appendingPathComponent("Male_Character.obj")
            mtlURL = d.appendingPathComponent("Male_Character.mtl")
        }
        guard let o = objURL, fm.fileExists(atPath: o.path),
              let parsed = parseOBJ(o), !parsed.parts.isEmpty else { return nil }

        let av = Avatar(scale: 0.82, footOffset: 0.045)
        av.materials = parseMTL(mtlURL)
        for (k, m) in av.materials {
            if let c = m.diffuse.contents as? UIColor { av.original[k] = c }
        }
        let fallbackMat = SCNMaterial()
        fallbackMat.lightingModel = .blinn
        fallbackMat.diffuse.contents = UIColor(white: 0.7, alpha: 1)

        // vị trí các khớp (toạ độ của mô hình gốc)
        let torsoJ = SIMD3<Float>(0, 1.0, 0)
        let hip: [Float: SIMD3<Float>] = [-1: SIMD3<Float>(-0.105, 1.05, 0), 1: SIMD3<Float>(0.105, 1.05, 0)]
        let knee: [Float: SIMD3<Float>] = [-1: SIMD3<Float>(-0.105, 0.70, 0), 1: SIMD3<Float>(0.105, 0.70, 0)]
        let shoulder: [Float: SIMD3<Float>] = [-1: SIMD3<Float>(-0.29, 1.60, 0.02), 1: SIMD3<Float>(0.29, 1.60, 0.02)]
        let elbow: [Float: SIMD3<Float>] = [-1: SIMD3<Float>(-0.335, 1.39, 0.03), 1: SIMD3<Float>(0.335, 1.39, 0.03)]

        func v3(_ v: SIMD3<Float>) -> SCNVector3 { SCNVector3(v.x, v.y, v.z) }

        av.torso.position = v3(torsoJ)
        av.body.addChildNode(av.torso)
        av.legL.position = v3(hip[-1]!)
        av.legR.position = v3(hip[1]!)
        av.body.addChildNode(av.legL)
        av.body.addChildNode(av.legR)
        av.kneeL.position = v3(knee[-1]! - hip[-1]!)
        av.kneeR.position = v3(knee[1]! - hip[1]!)
        av.legL.addChildNode(av.kneeL)
        av.legR.addChildNode(av.kneeR)
        av.armL.position = v3(shoulder[-1]! - torsoJ)
        av.armR.position = v3(shoulder[1]! - torsoJ)
        av.torso.addChildNode(av.armL)
        av.torso.addChildNode(av.armR)
        av.elbowL.position = v3(elbow[-1]! - shoulder[-1]!)
        av.elbowR.position = v3(elbow[1]! - shoulder[1]!)
        av.armL.addChildNode(av.elbowL)
        av.armR.addChildNode(av.elbowR)

        for part in parsed.parts {
            guard let g = geometry(parsed.verts, part.tris) else { continue }
            g.materials = [av.materials[part.mat] ?? fallbackMat]
            let n = SCNNode(geometry: g)
            let parent: SCNNode
            let joint: SIMD3<Float>
            switch group(part.name) {
            case .torso:  parent = av.torso;  joint = torsoJ
            case .thighL: parent = av.legL;   joint = hip[-1]!
            case .shinL:  parent = av.kneeL;  joint = knee[-1]!
            case .thighR: parent = av.legR;   joint = hip[1]!
            case .shinR:  parent = av.kneeR;  joint = knee[1]!
            case .upperL: parent = av.armL;   joint = shoulder[-1]!
            case .foreL:  parent = av.elbowL; joint = elbow[-1]!
            case .upperR: parent = av.armR;   joint = shoulder[1]!
            case .foreR:  parent = av.elbowR; joint = elbow[1]!
            }
            n.position = v3(-joint)
            parent.addChildNode(n)
        }
        return av
    }

    /// Nhân vật dựng bằng hình khối đơn giản, dùng khi không đọc được file.
    static func fallback() -> Avatar {
        let av = Avatar(scale: 1.0, footOffset: 0)
        func mat(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat) -> SCNMaterial {
            let m = SCNMaterial()
            m.lightingModel = .blinn
            m.diffuse.contents = UIColor(red: r, green: g, blue: b, alpha: 1)
            return m
        }
        let skin = mat(0.90, 0.72, 0.58)
        let shirt = mat(0.20, 0.45, 0.75)
        let pants = mat(0.18, 0.20, 0.30)
        func add(_ g: SCNGeometry, _ m: SCNMaterial, _ parent: SCNNode, _ x: Float, _ y: Float, _ z: Float) {
            g.materials = [m]
            let n = SCNNode(geometry: g)
            n.position = SCNVector3(x, y, z)
            parent.addChildNode(n)
        }
        av.torso.position = SCNVector3(0, 1.0, 0)
        av.body.addChildNode(av.torso)
        add(SCNBox(width: 0.42, height: 0.6, length: 0.24, chamferRadius: 0.05), shirt, av.torso, 0, 0.35, 0)
        add(SCNSphere(radius: 0.12), skin, av.torso, 0, 0.85, 0)
        for sgn in [Float(-1), Float(1)] {
            let leg = sgn < 0 ? av.legL : av.legR
            let knee = sgn < 0 ? av.kneeL : av.kneeR
            leg.position = SCNVector3(sgn * 0.1, 1.0, 0)
            av.body.addChildNode(leg)
            add(SCNCapsule(capRadius: 0.08, height: 0.5), pants, leg, 0, -0.25, 0)
            knee.position = SCNVector3(0, -0.5, 0)
            leg.addChildNode(knee)
            add(SCNCapsule(capRadius: 0.07, height: 0.5), pants, knee, 0, -0.25, 0)
            add(SCNBox(width: 0.1, height: 0.06, length: 0.24, chamferRadius: 0.02), mat(0.1, 0.1, 0.1), knee, 0, -0.5, 0.05)
            let arm = sgn < 0 ? av.armL : av.armR
            let elbow = sgn < 0 ? av.elbowL : av.elbowR
            arm.position = SCNVector3(sgn * 0.27, 0.58, 0)
            av.torso.addChildNode(arm)
            add(SCNCapsule(capRadius: 0.05, height: 0.32), shirt, arm, 0, -0.16, 0)
            elbow.position = SCNVector3(0, -0.3, 0)
            arm.addChildNode(elbow)
            add(SCNCapsule(capRadius: 0.045, height: 0.3), skin, elbow, 0, -0.15, 0)
            add(SCNSphere(radius: 0.05), skin, elbow, 0, -0.32, 0)
        }
        return av
    }

    // MARK: - Dáng đi, đổi trang phục

    /// `speed` = vận tốc thật (m/s). Chân tay đánh theo quãng đường đã đi nên không bị trượt chân.
    func animate(speed: Float, dt: Float) {
        let target = min(speed / 4.0, 2.2)
        amount += (target - amount) * min(1, dt * 8)
        if speed > 0.15 {
            let cycle = min(1.5 + 0.5 * max(speed - 1.4, 0), 4.5)   // mét đi được trong một chu kỳ bước
            phase += speed * dt / cycle * 2 * Float.pi
            if phase > 2 * Float.pi { phase -= 2 * Float.pi }
        }
        let k = amount
        let s = sin(phase)
        let c = cos(phase)
        let legSwing = 0.30 * k + 0.15 * max(k - 1, 0)
        let armSwing = 0.8 * legSwing
        let kneeBend = 0.40 * k + 0.25 * max(k - 1, 0)

        legL.eulerAngles.x = -legSwing * s
        legR.eulerAngles.x = legSwing * s
        kneeL.eulerAngles.x = kneeBend * max(0, c)
        kneeR.eulerAngles.x = kneeBend * max(0, -c)
        armL.eulerAngles.x = armSwing * s
        armR.eulerAngles.x = -armSwing * s
        let elbowBase = 0.10 + 0.30 * k
        elbowL.eulerAngles.x = -(elbowBase + 0.25 * k * max(0, -s))
        elbowR.eulerAngles.x = -(elbowBase + 0.25 * k * max(0, s))
        torso.eulerAngles.y = 0.12 * min(k, 1.5) * s
        torso.eulerAngles.x = 0.07 * min(k, 2.2)
        body.position.y = baseY + 0.03 * min(k, 1.5) * (1 - abs(s))
    }

    /// Đổi màu áo / quần / tóc theo bộ có sẵn.
    func cycleOutfit() {
        let sets: [[String: UIColor]] = [
            [:],
            ["Jacket": UIColor(red: 0.75, green: 0.15, blue: 0.15, alpha: 1),
             "Pants": UIColor(red: 0.75, green: 0.68, blue: 0.50, alpha: 1),
             "Hair": UIColor(red: 0.35, green: 0.20, blue: 0.10, alpha: 1)],
            ["Jacket": UIColor(red: 0.20, green: 0.50, blue: 0.30, alpha: 1),
             "Shirt": UIColor(red: 0.95, green: 0.90, blue: 0.50, alpha: 1),
             "Pants": UIColor(red: 0.20, green: 0.20, blue: 0.25, alpha: 1)],
            ["Jacket": UIColor(red: 0.95, green: 0.75, blue: 0.15, alpha: 1),
             "Pants": UIColor(red: 0.25, green: 0.30, blue: 0.55, alpha: 1),
             "Backpack": UIColor(red: 0.70, green: 0.20, blue: 0.20, alpha: 1)]
        ]
        outfit = (outfit + 1) % sets.count
        for (name, m) in materials {
            if let c = sets[outfit][name] ?? original[name] {
                m.diffuse.contents = c
            }
        }
    }
}
