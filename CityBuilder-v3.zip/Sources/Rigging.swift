import SceneKit
import SwiftUI
import UIKit
import simd

// MARK: - Các khớp người dùng đánh dấu

/// 15 điểm để gắn xương cho mô hình tĩnh (không có xương). Nhân vật quay mặt về +Z.
/// Bên A là phía +X (nhìn từ phía trước màn hình thì nằm bên PHẢI màn hình), bên B là phía -X.
enum RigJoint: String, CaseIterable {
    case headTop, neck, hips
    case shoulderA, elbowA, handA
    case shoulderB, elbowB, handB
    case hipA, kneeA, ankleA
    case hipB, kneeB, ankleB

    var label: String {
        switch self {
        case .headTop:   return "Đỉnh đầu"
        case .neck:      return "Cổ"
        case .hips:      return "Hông (giữa người)"
        case .shoulderA: return "Vai (phải màn hình)"
        case .elbowA:    return "Khuỷu tay (phải màn hình)"
        case .handA:     return "Cổ tay (phải màn hình)"
        case .shoulderB: return "Vai (trái màn hình)"
        case .elbowB:    return "Khuỷu tay (trái màn hình)"
        case .handB:     return "Cổ tay (trái màn hình)"
        case .hipA:      return "Khớp háng (phải màn hình)"
        case .kneeA:     return "Đầu gối (phải màn hình)"
        case .ankleA:    return "Cổ chân (phải màn hình)"
        case .hipB:      return "Khớp háng (trái màn hình)"
        case .kneeB:     return "Đầu gối (trái màn hình)"
        case .ankleB:    return "Cổ chân (trái màn hình)"
        }
    }

    var markerColor: UIColor {
        switch self {
        case .headTop, .neck, .hips: return .systemYellow
        case .shoulderA, .elbowA, .handA, .hipA, .kneeA, .ankleA: return .systemRed
        default: return .systemBlue
        }
    }
}

/// Lưu các điểm đã đặt cho từng mô hình (tọa độ trong hệ của mô hình, chưa co giãn).
enum RigStore {
    private static func key(_ model: String) -> String { "rig.points." + model }

    static func load(_ model: String) -> [RigJoint: SIMD3<Float>]? {
        guard let data = UserDefaults.standard.data(forKey: key(model)),
              let raw = try? JSONDecoder().decode([String: [Float]].self, from: data) else { return nil }
        var out: [RigJoint: SIMD3<Float>] = [:]
        for j in RigJoint.allCases {
            guard let v = raw[j.rawValue], v.count == 3 else { return nil }
            out[j] = SIMD3<Float>(v[0], v[1], v[2])
        }
        return out
    }

    static func has(_ model: String) -> Bool { load(model) != nil }

    static func save(_ model: String, _ pts: [RigJoint: SIMD3<Float>]) {
        var raw: [String: [Float]] = [:]
        for (j, p) in pts { raw[j.rawValue] = [p.x, p.y, p.z] }
        if let d = try? JSONEncoder().encode(raw) {
            UserDefaults.standard.set(d, forKey: key(model))
        }
    }

    static func remove(_ model: String) {
        UserDefaults.standard.removeObject(forKey: key(model))
    }

    /// Đoán vị trí các khớp từ khung bao của mô hình: người đứng thẳng, mặt về +Z,
    /// dang tay chữ T (rộng ≈ cao) hoặc xuôi tay chữ A.
    static func guess(lo: SIMD3<Float>, hi: SIMD3<Float>) -> [RigJoint: SIMD3<Float>] {
        let h = max(hi.y - lo.y, 0.0001)
        let w = hi.x - lo.x
        let cx = (lo.x + hi.x) / 2
        let cz = (lo.z + hi.z) / 2
        func pt(_ x: Float, _ f: Float) -> SIMD3<Float> { SIMD3<Float>(cx + x * h, lo.y + f * h, cz) }

        var r: [RigJoint: SIMD3<Float>] = [:]
        r[.headTop] = pt(0, 0.985)
        r[.neck] = pt(0, 0.84)
        r[.hips] = pt(0, 0.52)

        let sx: Float = 0.11
        if w > 0.7 * h {
            // dang tay chữ T
            let half = w / 2 / h
            let el = sx + (half - sx) * 0.5
            let ha = half - 0.02
            // tay dang chữ T thường hơi chúc xuống: vai cao nhất, cổ tay thấp hơn một chút
            r[.shoulderA] = pt(sx, 0.82);  r[.elbowA] = pt(el, 0.76);  r[.handA] = pt(ha, 0.69)
            r[.shoulderB] = pt(-sx, 0.82); r[.elbowB] = pt(-el, 0.76); r[.handB] = pt(-ha, 0.69)
        } else {
            // xuôi tay
            r[.shoulderA] = pt(sx, 0.80);  r[.elbowA] = pt(0.17, 0.62);  r[.handA] = pt(0.20, 0.45)
            r[.shoulderB] = pt(-sx, 0.80); r[.elbowB] = pt(-0.17, 0.62); r[.handB] = pt(-0.20, 0.45)
        }
        r[.hipA] = pt(0.05, 0.50);  r[.kneeA] = pt(0.055, 0.27);  r[.ankleA] = pt(0.055, 0.05)
        r[.hipB] = pt(-0.05, 0.50); r[.kneeB] = pt(-0.055, 0.27); r[.ankleB] = pt(-0.055, 0.05)
        return r
    }
}

// MARK: - Bộ xương tự dựng + chuyển động tự tạo

/// Dựng bộ xương từ các điểm người dùng đặt, tự tính trọng số cho từng đỉnh (gần đoạn xương nào thì
/// theo đoạn đó), gắn SCNSkinner, rồi tự tạo chuyển động đứng thở / đi / chạy / nhảy / vẫy tay / nhảy múa.
final class ProceduralRig {
    final class Bone {
        let node = SCNNode()
        var axis = SIMD3<Float>(1, 0, 0)     // trục để vung "về phía trước" (trong hệ của bone cha)
        var base = simd_quatf(angle: 0, axis: SIMD3<Float>(0, 1, 0))   // tư thế nghỉ (hạ tay xuống nếu đang dang)
        var start = SIMD3<Float>(0, 0, 0)
        var end = SIMD3<Float>(0, 0, 0)
        var radius: Float = 0.05
    }

    static let actionNames = ["Nhảy", "Vẫy tay", "Nhảy múa", "Làm việc", "Ngồi bệt", "Leo trèo", "Cúi chào", "Ngồi xổm", "Ngồi xếp bằng"]
    private static let actionDurations: [Float] = [0.8, 2.0, 3.0, 4.0, 4.0, 4.0, 2.4, 4.0, 4.0]

    private var bones: [String: Bone] = [:]
    private let height: Float
    private let hipsRest: SIMD3<Float>

    private var phase: Float = 0
    private var amount: Float = 0
    private var clock: Float = 0
    private var action = -1
    private var actionT: Float = 0
    private var actionHold = false      // ngồi / leo: giữ tới khi gọi release()
    private var nextAction = 0

    private init(height: Float, hipsRest: SIMD3<Float>) {
        self.height = height
        self.hipsRest = hipsRest
    }

    // MARK: Dựng

    private static func readVec3(_ s: SCNGeometrySource) -> [SIMD3<Float>]? {
        guard s.bytesPerComponent == 4, s.componentsPerVector >= 3, s.usesFloatComponents else { return nil }
        var out: [SIMD3<Float>] = []
        out.reserveCapacity(s.vectorCount)
        let stride = s.dataStride
        let offset = s.dataOffset
        let count = s.vectorCount
        s.data.withUnsafeBytes { raw in
            for i in 0..<count {
                let o = offset + i * stride
                let x = raw.loadUnaligned(fromByteOffset: o, as: Float.self)
                let y = raw.loadUnaligned(fromByteOffset: o + 4, as: Float.self)
                let z = raw.loadUnaligned(fromByteOffset: o + 8, as: Float.self)
                out.append(SIMD3<Float>(x, y, z))
            }
        }
        return out
    }

    private static func segDist(_ p: SIMD3<Float>, _ a: SIMD3<Float>, _ b: SIMD3<Float>) -> Float {
        let ab = b - a
        let l2 = simd_dot(ab, ab)
        let t: Float = l2 > 1e-12 ? min(max(simd_dot(p - a, ab) / l2, 0), 1) : 0
        return simd_length(p - (a + ab * t))
    }

    private struct Spec {
        let name: String
        let parent: String?
        let a: SIMD3<Float>
        let b: SIMD3<Float>
        let r: Float
    }

    /// Thay toàn bộ hình trong `content` bằng bản có xương. Trả về nil nếu mô hình không đọc được.
    static func build(content: SCNNode, joints j: [RigJoint: SIMD3<Float>]) -> ProceduralRig? {
        guard let headTop = j[.headTop], let neck = j[.neck], let hips = j[.hips],
              let shA = j[.shoulderA], let elA = j[.elbowA], let haA = j[.handA],
              let shB = j[.shoulderB], let elB = j[.elbowB], let haB = j[.handB],
              let hipA = j[.hipA], let knA = j[.kneeA], let anA = j[.ankleA],
              let hipB = j[.hipB], let knB = j[.kneeB], let anB = j[.ankleB] else { return nil }

        let h = max(headTop.y - min(anA.y, anB.y), 0.0001)
        let chest = (hips + neck) * 0.5
        func toe(_ a: SIMD3<Float>) -> SIMD3<Float> { SIMD3<Float>(a.x, a.y - 0.03 * h, a.z + 0.09 * h) }

        let specs: [Spec] = [
            Spec(name: "hips", parent: nil, a: hips, b: chest, r: 0.15 * h),
            Spec(name: "chest", parent: "hips", a: chest, b: neck, r: 0.15 * h),
            Spec(name: "neck", parent: "chest", a: neck, b: headTop, r: 0.07 * h),
            Spec(name: "armA", parent: "chest", a: shA, b: elA, r: 0.045 * h),
            Spec(name: "foreA", parent: "armA", a: elA, b: haA + (haA - elA) * 0.3, r: 0.04 * h),
            Spec(name: "armB", parent: "chest", a: shB, b: elB, r: 0.045 * h),
            Spec(name: "foreB", parent: "armB", a: elB, b: haB + (haB - elB) * 0.3, r: 0.04 * h),
            Spec(name: "thighA", parent: "hips", a: hipA, b: knA, r: 0.07 * h),
            Spec(name: "shinA", parent: "thighA", a: knA, b: anA, r: 0.05 * h),
            Spec(name: "footA", parent: "shinA", a: anA, b: toe(anA), r: 0.04 * h),
            Spec(name: "thighB", parent: "hips", a: hipB, b: knB, r: 0.07 * h),
            Spec(name: "shinB", parent: "thighB", a: knB, b: anB, r: 0.05 * h),
            Spec(name: "footB", parent: "shinB", a: anB, b: toe(anB), r: 0.04 * h)
        ]

        let rig = ProceduralRig(height: h, hipsRest: hips)
        let forward = SIMD3<Float>(0, 0, 1)
        let identity = simd_quatf(angle: 0, axis: SIMD3<Float>(0, 1, 0))
        var frames: [String: simd_quatf] = [:]
        var order: [Bone] = []

        // 1) bộ xương: vị trí, tư thế nghỉ, trục vung
        for sp in specs {
            let bone = Bone()
            bone.node.name = "rig_" + sp.name
            bone.start = sp.a
            bone.end = sp.b
            bone.radius = sp.r

            let parentStart: SIMD3<Float> = sp.parent.flatMap { rig.bones[$0]?.start } ?? SIMD3<Float>(0, 0, 0)
            bone.node.simdPosition = sp.a - parentStart

            let p = sp.parent.flatMap { frames[$0] } ?? identity
            var dir = sp.b - sp.a
            dir = simd_length(dir) > 1e-6 ? simd_normalize(dir) : SIMD3<Float>(0, -1, 0)

            var base = identity
            if sp.name.hasPrefix("arm") && dir.y > -0.97 {
                // tay đang dang ra (chữ T hoặc chữ A): khép xuống sát người như đứng bình thường,
                // chỉ chừa một chút hở để tay không xuyên vào hông
                let tx: Float = dir.x >= 0 ? 0.10 : -0.10
                base = simd_quatf(from: dir, to: simd_normalize(SIMD3<Float>(tx, -0.99, 0)))
            }
            let wDir = (p * base).act(dir)
            var axisWorld = simd_cross(wDir, forward)
            axisWorld = simd_length(axisWorld) > 1e-4 ? simd_normalize(axisWorld) : SIMD3<Float>(1, 0, 0)
            bone.axis = p.inverse.act(axisWorld)
            bone.base = base
            bone.node.simdOrientation = base
            frames[sp.name] = p * base

            if sp.name.hasPrefix("foot"), let shin = rig.bones["shin" + String(sp.name.suffix(1))] {
                bone.axis = shin.axis
            }

            if let par = sp.parent, let pb = rig.bones[par] {
                pb.node.addChildNode(bone.node)
            }
            rig.bones[sp.name] = bone
            order.append(bone)
        }
        guard let hipsBone = rig.bones["hips"] else { return nil }

        // 2) gom hình, đổi sang hệ của content, tính trọng số rồi gắn skinner
        var parts: [(node: SCNNode, geo: SCNGeometry)] = []
        content.enumerateHierarchy { n, _ in
            if let g = n.geometry, n.name != "rigmarker" { parts.append((n, g)) }
        }
        guard !parts.isEmpty else { return nil }

        let inv = content.simdWorldTransform.inverse
        let eps = 0.01 * h
        var newNodes: [SCNNode] = []

        var ibms: [NSValue] = []
        for b in order {
            ibms.append(NSValue(scnMatrix4: SCNMatrix4MakeTranslation(-b.start.x, -b.start.y, -b.start.z)))
        }
        let boneNodes = order.map { $0.node }
        let boneCount = order.count

        for part in parts {
            guard let vs = part.geo.sources(for: .vertex).first, let pos = readVec3(vs) else { return nil }
            let m = inv * part.node.simdWorldTransform
            let rot = simd_float3x3(SIMD3<Float>(m.columns.0.x, m.columns.0.y, m.columns.0.z),
                                    SIMD3<Float>(m.columns.1.x, m.columns.1.y, m.columns.1.z),
                                    SIMD3<Float>(m.columns.2.x, m.columns.2.y, m.columns.2.z))

            var newPos: [SIMD3<Float>] = []
            newPos.reserveCapacity(pos.count)
            for q in pos {
                let r = m * SIMD4<Float>(q.x, q.y, q.z, 1)
                newPos.append(SIMD3<Float>(r.x, r.y, r.z))
            }

            var sources: [SCNGeometrySource] = [
                SCNGeometrySource(vertices: newPos.map { SCNVector3($0.x, $0.y, $0.z) })
            ]
            if let ns = part.geo.sources(for: .normal).first, let nor = readVec3(ns), nor.count == pos.count {
                let nn = nor.map { v -> SCNVector3 in
                    var t = rot * v
                    t = simd_length(t) > 1e-8 ? simd_normalize(t) : SIMD3<Float>(0, 1, 0)
                    return SCNVector3(t.x, t.y, t.z)
                }
                sources.append(SCNGeometrySource(normals: nn))
            }
            for s in part.geo.sources where s.semantic != .vertex && s.semantic != .normal {
                sources.append(s)
            }
            let ng = SCNGeometry(sources: sources, elements: part.geo.elements)
            ng.materials = part.geo.materials

            // trọng số: gần đoạn xương nào (trừ bán kính của nó) thì theo xương đó, giữ tối đa 4 xương
            let n = newPos.count
            var idx = [UInt16](repeating: 0, count: n * 4)
            var wts = [Float](repeating: 0, count: n * 4)
            var ws = [Float](repeating: 0, count: boneCount)
            for v in 0..<n {
                let p = newPos[v]
                for i in 0..<boneCount {
                    let b = order[i]
                    let d = segDist(p, b.start, b.end)
                    let eff = max(d - b.radius, 0) + eps
                    ws[i] = 1 / (eff * eff * eff)
                }
                var sum: Float = 0
                for slot in 0..<4 {
                    var best = -1
                    var bestW: Float = 0
                    for i in 0..<boneCount where ws[i] > bestW {
                        best = i
                        bestW = ws[i]
                    }
                    if best < 0 { break }
                    idx[v * 4 + slot] = UInt16(best)
                    wts[v * 4 + slot] = bestW
                    sum += bestW
                    ws[best] = 0
                }
                if sum > 0 {
                    for slot in 0..<4 { wts[v * 4 + slot] /= sum }
                } else {
                    wts[v * 4] = 1
                }
            }
            let wd = wts.withUnsafeBufferPointer { Data(buffer: $0) }
            let idd = idx.withUnsafeBufferPointer { Data(buffer: $0) }
            let wSrc = SCNGeometrySource(data: wd, semantic: .boneWeights, vectorCount: n,
                                         usesFloatComponents: true, componentsPerVector: 4,
                                         bytesPerComponent: 4, dataOffset: 0, dataStride: 16)
            let iSrc = SCNGeometrySource(data: idd, semantic: .boneIndices, vectorCount: n,
                                         usesFloatComponents: false, componentsPerVector: 4,
                                         bytesPerComponent: 2, dataOffset: 0, dataStride: 8)
            let skinner = SCNSkinner(baseGeometry: ng, bones: boneNodes, boneInverseBindTransforms: ibms,
                                     boneWeights: wSrc, boneIndices: iSrc)
            skinner.skeleton = hipsBone.node
            let gn = SCNNode(geometry: ng)
            gn.skinner = skinner
            newNodes.append(gn)
        }

        let oldChildren = content.childNodes
        for n in newNodes { content.addChildNode(n) }
        content.addChildNode(hipsBone.node)
        for c in oldChildren { c.removeFromParentNode() }
        return rig
    }

    // MARK: Chuyển động

    var isActing: Bool { action >= 0 }

    /// Chạy ngay hành động số `index` (0 nhảy, 1 vẫy tay, 2 nhảy múa, 3 làm việc, 4 ngồi bệt, 5 leo, 6 cúi chào,
    /// 7 ngồi xổm, 8 ngồi xếp bằng) nếu đang rảnh. `hold` (chỉ các kiểu ngồi và leo) giữ nguyên tới khi gọi `release()`; `force` chen vào hành động đang chạy.
    func start(_ index: Int, hold: Bool = false, force: Bool = false) {
        guard action < 0 || force else { return }
        action = index % ProceduralRig.actionNames.count
        actionT = 0
        actionHold = hold && (action == 4 || action == 5 || action == 7 || action == 8)
    }

    /// Thôi giữ dáng ngồi / leo: hạ dần về tư thế đứng trong ~0,35 giây.
    func release() {
        guard action >= 0, actionHold else { return }
        actionHold = false
        actionT = ProceduralRig.actionDurations[action] - 0.35
    }

    /// Bấm nút Hành động: lần lượt nhảy, vẫy tay, nhảy múa, làm việc. Trả về tên hành động.
    func startAction() -> String {
        if action >= 0 { return "Đang thực hiện hành động…" }
        action = nextAction % ProceduralRig.actionNames.count
        nextAction += 1
        actionT = 0
        actionHold = false
        return "Hành động: " + ProceduralRig.actionNames[action]
    }

    private func mix(_ a: Float, _ b: Float, _ t: Float) -> Float { a + (b - a) * t }

    /// `side`: xoay thêm quanh trục trước-sau (dang tay sang bên). Dương = dang ra ngoài khi tay đang thõng.
    /// `spread`: xoay thêm quanh trục đứng (mở đùi sang hai bên khi ngồi xếp bằng).
    private func rot(_ name: String, _ angle: Float, side: Float = 0, spread: Float = 0) {
        guard let b = bones[name] else { return }
        var q = simd_quatf(angle: angle, axis: b.axis) * b.base
        if side != 0 {
            q = simd_quatf(angle: side, axis: SIMD3<Float>(0, 0, 1)) * q
        }
        if spread != 0 {
            q = simd_quatf(angle: spread, axis: SIMD3<Float>(0, 1, 0)) * q
        }
        b.node.simdOrientation = q
    }

    /// +1 nếu xương này nằm bên +x của thân (dang ra ngoài là xoay dương), -1 nếu bên kia.
    private func outward(_ name: String) -> Float {
        guard let b = bones[name] else { return 1 }
        return b.start.x >= hipsRest.x ? 1 : -1
    }

    /// Hông phải hạ bao nhiêu khi đùi hướng `t` và cẳng chân hướng `s` (góc tuyệt đối, tính từ hướng thẳng xuống,
    /// dương là về phía trước) mà bàn chân vẫn đứng nguyên chỗ.
    private func legDrop(_ t: Float, _ s: Float) -> Float {
        guard let th = bones["thighA"], let sh = bones["shinA"], let ft = bones["footA"] else { return 0.3 * height }
        let l1 = simd_length(th.end - th.start)
        let l2 = simd_length(sh.end - sh.start)
        let standing = th.start.y - ft.start.y
        return max(0, standing - (l1 * cos(t) + l2 * cos(s)))
    }

    /// Hạ hông xuống sát đất khi ngồi bệt duỗi chân.
    private var sitDrop: Float {
        guard let th = bones["thighA"], let ft = bones["footA"] else { return 0.45 * height }
        return max(0, th.start.y - (ft.start.y + 0.03 * height))
    }

    /// `speed` là vận tốc thật (m/s): 0 đứng yên, ~4 đi, ~9 chạy.
    func pose(speed: Float, dt: Float) {
        clock += dt
        let target = min(speed / 4.0, 2.2)
        amount += (target - amount) * min(1, dt * 8)
        if speed > 0.15 {
            let cycle = min(1.5 + 0.5 * max(speed - 1.4, 0), 4.5)     // mét đi được trong một chu kỳ bước
            phase += speed * dt / cycle * 2 * Float.pi
            if phase > 2 * Float.pi { phase -= 2 * Float.pi }
        }
        let k = amount
        let a = min(k, 2.0)
        let s = sin(phase)
        let c = cos(phase)
        let idleW = 1 - min(k, 1)

        var thighA = 0.5 * a * s
        var thighB = -thighA
        var shinA = -0.9 * a * max(0, c)
        var shinB = -0.9 * a * max(0, -c)
        var footA = -0.25 * thighA
        var footB = -0.25 * thighB
        var armA = -0.45 * a * s
        var armB = 0.45 * a * s
        var foreA = 0.15 + 0.5 * a * max(0, -s) + 0.08 * idleW
        var foreB = 0.15 + 0.5 * a * max(0, s) + 0.08 * idleW
        var hipsTwist = 0.12 * a * s
        var chestTwist = -0.2 * a * s
        var lean = 0.05 * min(k, 2.2)
        var bob = 0.012 * height * a * cos(2 * phase)
        var chestPitch = 0.02 * sin(clock * 1.8) * idleW
        var neckNod = 0.03 * sin(clock * 1.1) * idleW
        var armSideA: Float = 0, armSideB: Float = 0       // dang tay sang bên
        var foreSideA: Float = 0, foreSideB: Float = 0     // gập cẳng tay trong mặt phẳng ngang người
        var thighSpread: Float = 0                         // mở đùi sang hai bên (ngồi xếp bằng)

        if action >= 0 {
            actionT += dt
            let d = ProceduralRig.actionDurations[action]
            if actionT >= d && !actionHold {
                action = -1
                actionHold = false
            } else {
                let fadeOut: Float = actionHold ? 1 : (d - actionT) / 0.25
                let env = max(0, min(1, min(actionT / 0.25, fadeOut)))
                switch action {
                case 0:     // nhảy
                    let u = actionT / d
                    let arc = sin(Float.pi * u)
                    bob += 0.18 * height * 4 * u * (1 - u)
                    armA = mix(armA, 2.4 * arc, env)
                    armB = mix(armB, 2.4 * arc, env)
                    thighA += 0.5 * arc
                    thighB += 0.5 * arc
                    shinA -= 0.8 * arc
                    shinB -= 0.8 * arc
                case 1:     // vẫy tay: giơ tay sang bên cạnh đầu, cẳng tay vẫy qua lại (không quét ngang mặt)
                    armA = mix(armA, 0, env)
                    foreA = mix(foreA, 0, env)
                    armSideA = 1.75 * env
                    foreSideA = (1.25 + 0.4 * sin(actionT * 11)) * env
                case 3:     // làm việc: cúi người, tay phải vung lên hạ xuống như đóng búa, tay trái đỡ
                    let sw = sin(actionT * 5)
                    lean += 0.22 * env
                    armA = mix(armA, 0.9 + 1.0 * max(0, sw), env)
                    foreA = mix(foreA, 0.6 + 0.9 * max(0, sw), env)
                    armB = mix(armB, 0.5, env)
                    foreB = mix(foreB, 0.9, env)
                    bob += 0.008 * height * abs(sw) * env
                case 4:     // ngồi bệt, duỗi chân ra trước, hai tay đặt lên đùi
                    bob = mix(bob, -sitDrop, env)
                    thighA = mix(thighA, 1.5, env)
                    thighB = mix(thighB, 1.5, env)
                    shinA = mix(shinA, 0, env)
                    shinB = mix(shinB, 0, env)
                    footA = mix(footA, -1.0, env)
                    footB = mix(footB, -1.0, env)
                    armA = mix(armA, 0.45, env)
                    armB = mix(armB, 0.45, env)
                    foreA = mix(foreA, 0.35, env)
                    foreB = mix(foreB, 0.35, env)
                    hipsTwist = mix(hipsTwist, 0, env)
                    chestTwist = mix(chestTwist, 0, env)
                    lean = mix(lean, 0, env)
                case 5:     // leo: hai tay luân phiên với lên cao, hai chân luân phiên bước lên
                    let sw = sin(actionT * 4.5)
                    armA = mix(armA, 2.5 + 0.45 * sw, env)
                    armB = mix(armB, 2.5 - 0.45 * sw, env)
                    foreA = mix(foreA, 0.6 - 0.4 * sw, env)
                    foreB = mix(foreB, 0.6 + 0.4 * sw, env)
                    armSideA = -0.25 * env           // dang nhẹ ra ngoài để tay không che mặt
                    armSideB = -0.25 * env
                    thighA = mix(thighA, 0.4 + 0.9 * max(0, -sw), env)
                    thighB = mix(thighB, 0.4 + 0.9 * max(0, sw), env)
                    shinA = mix(shinA, -1.2 * max(0, -sw), env)
                    shinB = mix(shinB, -1.2 * max(0, sw), env)
                    footA = mix(footA, 0, env)
                    footB = mix(footB, 0, env)
                    lean = mix(lean, 0.12, env)
                    chestTwist = mix(chestTwist, 0.12 * sw, env)
                    hipsTwist = mix(hipsTwist, -0.10 * sw, env)
                    bob += 0.012 * height * abs(sw) * env
                case 6:     // cúi chào: cúi xuống, giữ một nhịp, ngẩng lên
                    let u = actionT / d
                    let prof: Float = u < 0.3 ? u / 0.3 : (u < 0.65 ? 1 : max(0, (1 - u) / 0.35))
                    let b = prof * prof * (3 - 2 * prof)
                    chestPitch += 0.95 * b
                    neckNod += 0.25 * b
                    lean += 0.08 * b
                    armA += 0.95 * b                    // giữ hai tay thõng xuống khi thân cúi
                    armB += 0.95 * b
                    foreA += 0.45 * b
                    foreB += 0.45 * b
                case 7:     // ngồi xổm: gót chạm đất, gối co sâu, thân hơi cúi, tay đặt lên gối
                    let t: Float = 1.9
                    let sAbs: Float = -0.4
                    bob = mix(bob, -legDrop(t, sAbs), env)
                    thighA = mix(thighA, t, env)
                    thighB = mix(thighB, t, env)
                    shinA = mix(shinA, sAbs - t, env)
                    shinB = mix(shinB, sAbs - t, env)
                    footA = mix(footA, -sAbs, env)
                    footB = mix(footB, -sAbs, env)
                    chestPitch = mix(chestPitch, 0.4, env)
                    neckNod = mix(neckNod, -0.2, env)
                    armA = mix(armA, 0.9, env)
                    armB = mix(armB, 0.9, env)
                    foreA = mix(foreA, 0.3, env)
                    foreB = mix(foreB, 0.3, env)
                    hipsTwist = mix(hipsTwist, 0, env)
                    chestTwist = mix(chestTwist, 0, env)
                    lean = mix(lean, 0, env)
                case 8:     // ngồi xếp bằng: đầu gối mở ra hai bên, cẳng chân gập vào, tay đặt lên gối
                    bob = mix(bob, -sitDrop, env)
                    thighA = mix(thighA, 1.5, env)
                    thighB = mix(thighB, 1.5, env)
                    thighSpread = 0.9 * env
                    shinA = mix(shinA, -2.9, env)
                    shinB = mix(shinB, -2.9, env)
                    footA = mix(footA, 1.0, env)
                    footB = mix(footB, 1.0, env)
                    armA = mix(armA, 0.6, env)
                    armB = mix(armB, 0.6, env)
                    foreA = mix(foreA, 0.5, env)
                    foreB = mix(foreB, 0.5, env)
                    armSideA = 0.3 * env
                    armSideB = 0.3 * env
                    hipsTwist = mix(hipsTwist, 0, env)
                    chestTwist = mix(chestTwist, 0, env)
                    lean = mix(lean, 0, env)
                default:    // nhảy múa
                    let sw = sin(actionT * 6)
                    armA = mix(armA, 1.9 * max(0, sw), env)
                    armB = mix(armB, 1.9 * max(0, -sw), env)
                    shinA -= 0.5 * max(0, sw) * env
                    shinB -= 0.5 * max(0, -sw) * env
                    hipsTwist += 0.35 * sin(actionT * 3) * env
                    chestTwist -= 0.2 * sin(actionT * 3) * env
                    bob += 0.02 * height * abs(sw) * env
                }
            }
        }

        let up = SIMD3<Float>(0, 1, 0)
        let side = SIMD3<Float>(1, 0, 0)
        if let hb = bones["hips"] {
            hb.node.simdOrientation = simd_quatf(angle: hipsTwist, axis: up) * simd_quatf(angle: lean, axis: side)
            hb.node.simdPosition = hipsRest + SIMD3<Float>(0, bob, 0)
        }
        if let cb = bones["chest"] {
            cb.node.simdOrientation = simd_quatf(angle: chestTwist, axis: up) * simd_quatf(angle: chestPitch, axis: side)
        }
        rot("neck", neckNod)
        rot("armA", armA, side: armSideA * outward("armA"))
        rot("armB", armB, side: armSideB * outward("armB"))
        rot("foreA", foreA, side: foreSideA * outward("armA"))
        rot("foreB", foreB, side: foreSideB * outward("armB"))
        rot("thighA", thighA, spread: thighSpread * outward("thighA"))
        rot("thighB", thighB, spread: thighSpread * outward("thighB"))
        rot("shinA", shinA)
        rot("shinB", shinB)
        rot("footA", footA)
        rot("footB", footB)
    }
}

// MARK: - Màn hình chọn điểm

struct RigTarget: Identifiable {
    let id: String      // tên mô hình
}

final class RigEditorModel: ObservableObject {
    let modelName: String
    let scene = SCNScene()
    let previewScene = SCNScene()
    let cameraNode = SCNNode()
    let previewCam = SCNNode()
    private let content = SCNNode()
    private let markerRoot = SCNNode()
    private var markers: [RigJoint: SCNNode] = [:]
    private var timer: Timer?
    private var previewRig: ProceduralRig?
    private var boundsLo = SIMD3<Float>(0, 0, 0)
    private var boundsHi = SIMD3<Float>(0, 1, 0)

    @Published var points: [RigJoint: SIMD3<Float>] = [:]
    @Published var selected: RigJoint = .headTop
    @Published var centerMode = true
    @Published var previewing = false
    @Published var previewSpeed: Float = 0
    @Published var message = ""
    @Published var loadError: String? = nil

    var isComplete: Bool { points.count == RigJoint.allCases.count }

    init(modelName: String) {
        self.modelName = modelName
        guard let loaded = RiggedAvatar.loadContent(modelName: modelName) else {
            loadError = "Không đọc được mô hình này."
            return
        }
        var hasSkin = false
        loaded.content.enumerateHierarchy { n, _ in
            if n.skinner != nil { hasSkin = true }
        }
        if hasSkin {
            loadError = "Mô hình này đã có xương sẵn, không cần gắn thêm."
            return
        }
        content.addChildNode(loaded.content)
        scene.rootNode.addChildNode(content)
        scene.rootNode.addChildNode(markerRoot)

        let (lo, hi) = content.boundingBox
        boundsLo = SIMD3<Float>(lo.x, lo.y, lo.z)
        boundsHi = SIMD3<Float>(hi.x, hi.y, hi.z)
        let h = max(hi.y - lo.y, 0.0001)
        let w = max(hi.x - lo.x, 0.0001)
        let center = SCNVector3((lo.x + hi.x) / 2, (lo.y + hi.y) / 2, (lo.z + hi.z) / 2)

        for node in [cameraNode, previewCam] {
            let cam = SCNCamera()
            cam.zNear = Double(h) * 0.01
            cam.zFar = Double(h) * 60
            node.camera = cam
            node.position = SCNVector3(center.x, center.y, center.z + 2.2 * max(h, w))
        }
        previewScene.rootNode.addChildNode(previewCam)

        if let saved = RigStore.load(modelName) {
            for (j, p) in saved { setPoint(j, p, advance: false) }
        }
    }

    deinit { timer?.invalidate() }

    private var markerRadius: CGFloat { CGFloat(max(boundsHi.y - boundsLo.y, 0.0001) * 0.014) }

    private func setPoint(_ j: RigJoint, _ p: SIMD3<Float>, advance: Bool) {
        points[j] = p
        if advance { message = "" }
        markers[j]?.removeFromParentNode()
        let sphere = SCNSphere(radius: markerRadius)
        let m = SCNMaterial()
        m.diffuse.contents = j.markerColor
        m.emission.contents = j.markerColor
        m.readsFromDepthBuffer = false
        sphere.materials = [m]
        let n = SCNNode(geometry: sphere)
        n.name = "rigmarker"
        n.renderingOrder = 200
        n.simdPosition = p
        markerRoot.addChildNode(n)
        markers[j] = n
        if advance, let next = RigJoint.allCases.first(where: { points[$0] == nil }) {
            selected = next
        }
    }

    /// Chạm vào mô hình: đặt khớp đang chọn. "Lấy giữa thân" lấy trung điểm giữa mặt trước và mặt sau
    /// theo tia chạm, để điểm nằm trong thân / tay / chân thay vì trên lớp da.
    func place(_ hits: [SCNHitTestResult]) {
        let real = hits.filter { $0.node.name != "rigmarker" }
        guard let first = real.first, let last = real.last else { return }
        let a = first.worldCoordinates
        let b = last.worldCoordinates
        let p = centerMode
            ? SIMD3<Float>((a.x + b.x) / 2, (a.y + b.y) / 2, (a.z + b.z) / 2)
            : SIMD3<Float>(a.x, a.y, a.z)
        setPoint(selected, p, advance: true)
    }

    func autoGuess() {
        for (j, p) in RigStore.guess(lo: boundsLo, hi: boundsHi) { setPoint(j, p, advance: false) }
        selected = .headTop
        message = "Đã đoán tự động. Chạm vào nhân vật để chỉnh từng điểm cho khớp."
    }

    func clearAll() {
        for (_, n) in markers { n.removeFromParentNode() }
        markers = [:]
        points = [:]
        selected = .headTop
    }

    // MARK: Xem thử

    func startPreview() {
        guard isComplete else {
            message = "Cần đặt đủ 15 điểm trước khi xem thử."
            return
        }
        guard let loaded = RiggedAvatar.loadContent(modelName: modelName),
              let rig = ProceduralRig.build(content: loaded.content, joints: points) else {
            message = "Không dựng được xương, thử đặt lại các điểm."
            return
        }
        for c in previewScene.rootNode.childNodes where c !== previewCam { c.removeFromParentNode() }
        previewScene.rootNode.addChildNode(loaded.content)
        previewRig = rig
        previewSpeed = 0
        previewing = true
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 1.0 / 60.0, repeats: true) { [weak self] _ in
            guard let self = self else { return }
            self.previewRig?.pose(speed: self.previewSpeed, dt: 1.0 / 60.0)
        }
    }

    func stopPreview() {
        message = ""
        timer?.invalidate()
        timer = nil
        previewRig = nil
        previewing = false
    }

    /// Chuyển sang khớp kế tiếp / trước đó (khi bảng đang ẩn).
    func selectStep(_ delta: Int) {
        let all = RigJoint.allCases
        guard let i = all.firstIndex(of: selected) else { return }
        selected = all[(i + delta + all.count) % all.count]
    }

    func previewAction() {
        if let r = previewRig { message = r.startAction() }
    }
}

struct RigSceneView: UIViewRepresentable {
    @ObservedObject var model: RigEditorModel

    func makeCoordinator() -> Coordinator { Coordinator(model) }

    func makeUIView(context: Context) -> SCNView {
        let v = SCNView()
        v.backgroundColor = UIColor(white: 0.12, alpha: 1)
        v.scene = model.scene
        v.pointOfView = model.cameraNode
        v.allowsCameraControl = true
        v.autoenablesDefaultLighting = true
        v.antialiasingMode = .multisampling4X
        let tap = UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.tapped(_:)))
        v.addGestureRecognizer(tap)
        return v
    }

    func updateUIView(_ v: SCNView, context: Context) {
        if context.coordinator.lastPreview != model.previewing {
            context.coordinator.lastPreview = model.previewing
            v.scene = model.previewing ? model.previewScene : model.scene
            v.pointOfView = model.previewing ? model.previewCam : model.cameraNode
        }
    }

    final class Coordinator: NSObject {
        let model: RigEditorModel
        var lastPreview = false

        init(_ m: RigEditorModel) { model = m }

        @objc func tapped(_ g: UITapGestureRecognizer) {
            guard let v = g.view as? SCNView, !model.previewing else { return }
            let hits = v.hitTest(g.location(in: v),
                                 options: [SCNHitTestOption.searchMode: SCNHitTestSearchMode.all.rawValue])
            model.place(hits)
        }
    }
}

struct RigEditorView: View {
    @ObservedObject var c: SceneController
    @StateObject private var m: RigEditorModel
    @State private var panelHidden = false
    let onClose: () -> Void

    init(modelName: String, c: SceneController, onClose: @escaping () -> Void) {
        self.c = c
        self.onClose = onClose
        _m = StateObject(wrappedValue: RigEditorModel(modelName: modelName))
    }

    var body: some View {
        VStack(spacing: 0) {
            topBar
            // vùng xem nằm TRÊN bảng điều khiển (không bị bảng che); ẩn bảng thì vùng xem rộng ra
            ZStack(alignment: .bottomTrailing) {
                RigSceneView(model: m)
                if m.loadError == nil {
                    Button {
                        withAnimation(.easeOut(duration: 0.2)) { panelHidden.toggle() }
                    } label: {
                        Label(panelHidden ? "Hiện bảng" : "Ẩn bảng",
                              systemImage: panelHidden ? "chevron.up.circle.fill" : "chevron.down.circle.fill")
                            .font(.footnote.weight(.semibold))
                            .padding(.horizontal, 12)
                            .padding(.vertical, 8)
                            .background(.ultraThinMaterial)
                            .clipShape(Capsule())
                    }
                    .padding(10)
                }
            }
            if let e = m.loadError {
                Text(e)
                    .font(.footnote)
                    .padding(12)
                    .frame(maxWidth: .infinity)
                    .background(.ultraThinMaterial)
            } else if panelHidden {
                if !m.previewing { compactBar }
            } else {
                panel
            }
        }
        .background(Color(white: 0.12).ignoresSafeArea())
        .preferredColorScheme(.dark)
    }

    private var topBar: some View {
        HStack {
            Button("Hủy") { m.stopPreview(); onClose() }
            Spacer()
            Text("Gắn xương: \(m.modelName)")
                .font(.footnote.weight(.semibold))
                .lineLimit(1)
            Spacer()
            Button("Lưu") { save() }
                .fontWeight(.bold)
                .disabled(!m.isComplete)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
        .background(.ultraThinMaterial)
    }

    /// Thanh nhỏ khi ẩn bảng: vẫn đổi được khớp đang đặt.
    private var compactBar: some View {
        HStack(spacing: 12) {
            Button { m.selectStep(-1) } label: { Image(systemName: "chevron.left.circle.fill").font(.title3) }
            Text(m.selected.label)
                .font(.footnote.weight(.semibold))
                .lineLimit(1)
                .frame(maxWidth: .infinity)
            Button { m.selectStep(1) } label: { Image(systemName: "chevron.right.circle.fill").font(.title3) }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 8)
        .background(.ultraThinMaterial)
    }

    private var panel: some View {
        VStack(spacing: 8) {
            if !m.message.isEmpty {
                Text(m.message).font(.caption).foregroundColor(.yellow)
            }
            if m.previewing {
                HStack(spacing: 6) {
                    speedButton("Đứng", 0)
                    speedButton("Đi", 4)
                    speedButton("Chạy", 9)
                    Button("Hành động") { m.previewAction() }
                        .buttonStyle(.bordered)
                        .controlSize(.small)
                }
                Button("Quay lại chỉnh điểm") { m.stopPreview() }
                    .buttonStyle(.borderedProminent)
                    .controlSize(.small)
            } else {
                Text("Chạm nhân vật để đặt: \(m.selected.label)")
                    .font(.footnote.weight(.semibold))
                    .lineLimit(1)
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 6) {
                        ForEach(RigJoint.allCases, id: \.self) { j in
                            Button {
                                m.selected = j
                            } label: {
                                Text((m.points[j] != nil ? "✓ " : "") + j.label)
                                    .font(.caption2)
                                    .lineLimit(1)
                                    .padding(.horizontal, 9)
                                    .padding(.vertical, 5)
                                    .background(m.selected == j ? Color.yellow.opacity(0.85) : Color.white.opacity(0.15))
                                    .foregroundColor(m.selected == j ? .black : .white)
                                    .cornerRadius(12)
                            }
                        }
                    }
                }
                HStack(spacing: 6) {
                    Button("Đoán tự động") { m.autoGuess() }
                        .buttonStyle(.bordered).controlSize(.small).lineLimit(1)
                    Button("Xóa hết") { m.clearAll() }
                        .buttonStyle(.bordered).controlSize(.small).lineLimit(1)
                    Button("Xem thử") { m.startPreview() }
                        .buttonStyle(.borderedProminent).controlSize(.small).lineLimit(1)
                        .disabled(!m.isComplete)
                }
                Toggle("Lấy giữa thân", isOn: $m.centerMode)
                    .font(.caption)
                Text("Kéo: xoay · Hai ngón: phóng to · Phải màn hình = bên +X · Nhân vật nhìn về phía bạn")
                    .font(.caption2)
                    .foregroundColor(.white.opacity(0.6))
                    .lineLimit(2)
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
        .background(.ultraThinMaterial)
    }

    private func speedButton(_ title: String, _ v: Float) -> some View {
        Button(title) { m.previewSpeed = v }
            .buttonStyle(.bordered)
            .controlSize(.small)
            .tint(m.previewSpeed == v ? .yellow : nil)
    }

    private func save() {
        guard m.isComplete else { return }
        m.stopPreview()
        RigStore.save(m.modelName, m.points)
        c.useAsCharacter(m.modelName)
        onClose()
    }
}
