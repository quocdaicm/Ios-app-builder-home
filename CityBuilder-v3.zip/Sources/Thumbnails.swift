import SceneKit
import SwiftUI
import UIKit
import Metal

/// Ảnh xem trước 3D của mô hình trong thư viện. Chụp một lần, lưu vào Caches, lần sau đọc lại ngay.
final class ModelThumbs {
    static let shared = ModelThumbs()
    static let size = CGSize(width: 192, height: 192)

    private let memory = NSCache<NSString, UIImage>()
    private let queue = DispatchQueue(label: "citybuilder.model-thumbs", qos: .utility)
    private var pending: [String: [(UIImage?) -> Void]] = [:]     // chỉ đụng trên main
    private var renderer: SCNRenderer?                              // chỉ dùng trên main
    private let dir: URL

    private init() {
        let caches = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
        dir = caches.appendingPathComponent("ModelThumbs-v1", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
    }

    private func fileURL(_ name: String) -> URL {
        let key = name.addingPercentEncoding(withAllowedCharacters: .alphanumerics) ?? "model"
        return dir.appendingPathComponent(key + ".png")
    }

    func cached(_ name: String) -> UIImage? {
        memory.object(forKey: name as NSString)
    }

    /// Xin ảnh xem trước (gọi trên main, completion cũng chạy trên main). Các yêu cầu được xếp hàng, chạy lần lượt.
    func request(_ name: String, completion: @escaping (UIImage?) -> Void) {
        if let im = cached(name) { completion(im); return }
        if pending[name] != nil { pending[name]!.append(completion); return }
        pending[name] = [completion]
        queue.async { [weak self] in
            guard let self = self else { return }
            let img = self.diskImage(name) ?? self.generate(name)
            DispatchQueue.main.async {
                if let img = img { self.memory.setObject(img, forKey: name as NSString) }
                let callbacks = self.pending.removeValue(forKey: name) ?? []
                callbacks.forEach { $0(img) }
            }
        }
    }

    /// Xóa ảnh đã lưu của một mô hình (khi xóa mô hình).
    func forget(_ name: String) {
        memory.removeObject(forKey: name as NSString)
        try? FileManager.default.removeItem(at: fileURL(name))
    }

    // MARK: Đọc / chụp

    private func diskImage(_ name: String) -> UIImage? {
        let f = fileURL(name)
        guard let a = try? FileManager.default.attributesOfItem(atPath: f.path),
              let thumbDate = a[.modificationDate] as? Date else { return nil }
        // mô hình được nhập lại / sửa sau ảnh → chụp lại
        if let src = Builder.mainModelURL(for: name),
           let sa = try? FileManager.default.attributesOfItem(atPath: src.path),
           let srcDate = sa[.modificationDate] as? Date, srcDate > thumbDate { return nil }
        return UIImage(contentsOfFile: f.path)
    }

    private func generate(_ name: String) -> UIImage? {
        // nạp mô hình ở luồng nền (có thể nặng), chỉ vẽ ở luồng chính
        guard let node = Builder.thumbnailContent(for: name) else { return nil }
        var img: UIImage? = nil
        DispatchQueue.main.sync { img = self.render(node) }
        if let img = img, let data = img.pngData() {
            try? data.write(to: fileURL(name), options: .atomic)
        }
        return img
    }

    private func render(_ node: SCNNode) -> UIImage? {
        let scene = SCNScene()
        scene.background.contents = UIColor(red: 0.20, green: 0.25, blue: 0.29, alpha: 1)
        scene.rootNode.addChildNode(node)

        let amb = SCNNode()
        amb.light = SCNLight()
        amb.light?.type = .ambient
        amb.light?.intensity = 700
        scene.rootNode.addChildNode(amb)

        let sun = SCNNode()
        sun.light = SCNLight()
        sun.light?.type = .directional
        sun.light?.intensity = 1100
        sun.eulerAngles = SCNVector3(-0.9, 0.7, 0)
        scene.rootNode.addChildNode(sun)

        let cam = SCNNode()
        cam.camera = SCNCamera()
        cam.camera?.fieldOfView = 32
        cam.camera?.zNear = 0.05
        cam.camera?.zFar = 50
        cam.position = SCNVector3(1.8, 1.3, 2.5)
        scene.rootNode.addChildNode(cam)
        cam.look(at: SCNVector3Zero)

        if renderer == nil {
            renderer = SCNRenderer(device: MTLCreateSystemDefaultDevice(), options: nil)
        }
        guard let r = renderer else { return nil }
        r.scene = scene
        r.pointOfView = cam
        r.autoenablesDefaultLighting = false
        let image = r.snapshot(atTime: 0, with: Self.size, antialiasingMode: .multisampling4X)
        r.scene = nil
        return image
    }
}

/// Ô vuông hiện ảnh xem trước; trong lúc chờ chụp thì hiện biểu tượng hình khối.
struct ModelThumbView: View {
    let name: String
    var side: CGFloat = 38
    @State private var image: UIImage? = nil

    var body: some View {
        Group {
            if let image = image {
                Image(uiImage: image).resizable().scaledToFill()
            } else {
                ZStack {
                    Color.white.opacity(0.08)
                    Image(systemName: "cube.fill")
                        .font(.system(size: side * 0.45, weight: .semibold))
                        .opacity(0.7)
                }
            }
        }
        .frame(width: side, height: side)
        .clipShape(RoundedRectangle(cornerRadius: side * 0.22, style: .continuous))
        .onAppear {
            if image == nil {
                image = ModelThumbs.shared.cached(name)
            }
            if image == nil {
                ModelThumbs.shared.request(name) { image = $0 }
            }
        }
        .id(name)
    }
}
