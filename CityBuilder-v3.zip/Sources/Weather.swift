import SceneKit
import UIKit
import simd

// MARK: - Thời tiết

enum Weather: String, CaseIterable, Identifiable {
    case clear, cloudy, wind, rain, storm, snow, fog

    var id: String { rawValue }

    var title: String {
        switch self {
        case .clear:  return "Nắng"
        case .cloudy: return "Nhiều mây"
        case .wind:   return "Gió"
        case .rain:   return "Mưa"
        case .storm:  return "Giông bão"
        case .snow:   return "Tuyết rơi"
        case .fog:    return "Sương mù"
        }
    }

    var symbol: String {
        switch self {
        case .clear:  return "sun.max.fill"
        case .cloudy: return "cloud.fill"
        case .wind:   return "wind"
        case .rain:   return "cloud.rain.fill"
        case .storm:  return "cloud.bolt.rain.fill"
        case .snow:   return "snowflake"
        case .fog:    return "cloud.fog.fill"
        }
    }
}

/// Thông số nhìn thấy được của từng kiểu thời tiết.
private struct Look {
    var top: UIColor
    var horizon: UIColor
    var sunColor: UIColor
    var fogFactor: CGFloat      // nhân với khoảng cách sương mù (nhỏ = sương dày)
    var sun: CGFloat            // cường độ nắng
    var ambient: CGFloat
    var env: CGFloat            // độ sáng phản chiếu bầu trời
    var thr: Float              // ngưỡng mây (thấp = nhiều mây)
    var soft: Float             // độ mềm mép mây
    var dark: Float             // 0 mây trắng ... 1 mây đen
    var drift: Float            // tốc độ mây trôi (rad/s)
    var wind: Float             // độ lay của lá cây
    var sunGlow: Float          // mặt trời trên nền trời
}

private func col(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat) -> UIColor {
    UIColor(red: r, green: g, blue: b, alpha: 1)
}

private func look(_ w: Weather) -> Look {
    switch w {
    case .clear:
        return Look(top: col(0.20, 0.45, 0.82), horizon: col(0.80, 0.88, 0.94), sunColor: col(1.0, 0.95, 0.86),
                    fogFactor: 1.0, sun: 2100, ambient: 180, env: 1.1, thr: 0.56, soft: 0.20, dark: 0,
                    drift: 0.004, wind: 1.0, sunGlow: 1.0)
    case .cloudy:
        return Look(top: col(0.42, 0.58, 0.78), horizon: col(0.80, 0.85, 0.90), sunColor: col(0.96, 0.96, 0.95),
                    fogFactor: 0.85, sun: 1000, ambient: 260, env: 1.0, thr: 0.36, soft: 0.26, dark: 0.15,
                    drift: 0.008, wind: 1.4, sunGlow: 0.25)
    case .wind:
        return Look(top: col(0.30, 0.52, 0.80), horizon: col(0.82, 0.86, 0.88), sunColor: col(1.0, 0.96, 0.88),
                    fogFactor: 0.75, sun: 1700, ambient: 200, env: 1.05, thr: 0.50, soft: 0.22, dark: 0.08,
                    drift: 0.03, wind: 3.5, sunGlow: 0.6)
    case .rain:
        return Look(top: col(0.40, 0.45, 0.52), horizon: col(0.64, 0.68, 0.72), sunColor: col(0.85, 0.90, 1.0),
                    fogFactor: 0.45, sun: 380, ambient: 320, env: 0.8, thr: 0.16, soft: 0.30, dark: 0.62,
                    drift: 0.012, wind: 1.8, sunGlow: 0)
    case .storm:
        return Look(top: col(0.18, 0.20, 0.25), horizon: col(0.38, 0.41, 0.46), sunColor: col(0.75, 0.80, 0.95),
                    fogFactor: 0.30, sun: 220, ambient: 260, env: 0.5, thr: 0.08, soft: 0.30, dark: 0.85,
                    drift: 0.022, wind: 3.2, sunGlow: 0)
    case .snow:
        return Look(top: col(0.58, 0.63, 0.70), horizon: col(0.84, 0.87, 0.90), sunColor: col(0.92, 0.95, 1.0),
                    fogFactor: 0.33, sun: 650, ambient: 380, env: 1.0, thr: 0.20, soft: 0.30, dark: 0.30,
                    drift: 0.006, wind: 0.6, sunGlow: 0)
    case .fog:
        return Look(top: col(0.72, 0.75, 0.78), horizon: col(0.80, 0.82, 0.83), sunColor: col(0.95, 0.95, 0.95),
                    fogFactor: 0.12, sun: 500, ambient: 360, env: 0.9, thr: 0.28, soft: 0.35, dark: 0.25,
                    drift: 0.004, wind: 0.5, sunGlow: 0)
    }
}

// MARK: - Nhiễu fractal để vẽ mây

private func hash2(_ x: Int32, _ y: Int32, _ s: UInt32) -> Float {
    var h = UInt32(bitPattern: x) &* 374761393 &+ UInt32(bitPattern: y) &* 668265263 &+ s &* 2246822519
    h = (h ^ (h >> 13)) &* 1274126177
    h ^= h >> 16
    return Float(h & 0xFFFFFF) / Float(0x1000000)
}

private func vnoise(_ x: Float, _ y: Float, _ s: UInt32) -> Float {
    let xi = floor(x), yi = floor(y)
    let fx = x - xi, fy = y - yi
    let ux = fx * fx * (3 - 2 * fx), uy = fy * fy * (3 - 2 * fy)
    let ix = Int32(xi), iy = Int32(yi)
    let a = hash2(ix, iy, s), b = hash2(ix + 1, iy, s)
    let c = hash2(ix, iy + 1, s), d = hash2(ix + 1, iy + 1, s)
    return a + (b - a) * ux + (c - a) * uy + (a - b - c + d) * ux * uy
}

private func fbm(_ x: Float, _ y: Float, _ s: UInt32, oct: Int) -> Float {
    var v: Float = 0, amp: Float = 0.5, f: Float = 1, tot: Float = 0
    for o in 0..<oct {
        v += amp * vnoise(x * f + Float(o) * 17.3, y * f + Float(o) * 9.1, s)
        tot += amp
        amp *= 0.5
        f *= 2.03
    }
    return v / tot
}

private func smooth(_ a: Float, _ b: Float, _ x: Float) -> Float {
    let t = min(max((x - a) / max(b - a, 0.0001), 0), 1)
    return t * t * (3 - 2 * t)
}

/// Mật độ và độ sáng mây tính một lần (tốn công), sau đó đổi thời tiết chỉ cần tô màu lại.
private final class CloudData {
    let w: Int
    let h: Int
    let density: UnsafeMutablePointer<UInt8>
    let shade: UnsafeMutablePointer<UInt8>

    init(w: Int, h: Int, seed: UInt32, ax: Float, az: Float, freq: Float, oct: Int) {
        self.w = w
        self.h = h
        density = UnsafeMutablePointer<UInt8>.allocate(capacity: w * h)
        shade = UnsafeMutablePointer<UInt8>.allocate(capacity: w * h)
        let d = density, s = shade
        DispatchQueue.concurrentPerform(iterations: h) { j in
            let el = (0.5 - (Float(j) + 0.5) / Float(h)) * Float.pi
            let y = sin(el), ce = cos(el)
            for i in 0..<w {
                let idx = j * w + i
                if y <= 0.01 {
                    d[idx] = 0
                    s[idx] = 0
                    continue
                }
                let a = (Float(i) + 0.5) / Float(w) * 2 * Float.pi
                // chiếu bầu trời lên một tầng mây phẳng: mây xa dần thu nhỏ về phía chân trời
                let k = 1 / (y + 0.10)
                let px = ce * cos(a) * k * ax * freq
                let pz = ce * sin(a) * k * az * freq
                let v = fbm(px, pz, seed, oct: oct)
                let v2 = fbm(px + 0.10 * freq * 0.707 * ax, pz + 0.10 * freq * 0.707 * az, seed, oct: oct)
                d[idx] = UInt8(max(0, min(255, v * 255)))
                // mép hướng về mặt trời sáng hơn, lõi dày thì tối hơn
                let lit = max(0, min(1, 0.62 - (v2 - v) * 3.4 - (v - 0.62) * 0.5))
                s[idx] = UInt8(lit * 255)
            }
        }
    }

    deinit {
        density.deallocate()
        shade.deallocate()
    }

    func image(_ lk: Look, alphaScale: Float) -> UIImage? {
        var buf = [UInt8](repeating: 0, count: w * h * 4)
        let dk = lk.dark
        let litC = SIMD3<Float>(1, 1, 1) * (1 - dk) + SIMD3<Float>(0.55, 0.57, 0.60) * dk
        let shC = SIMD3<Float>(0.58, 0.65, 0.77) * (1 - dk) + SIMD3<Float>(0.18, 0.20, 0.25) * dk
        var hr: CGFloat = 0, hg: CGFloat = 0, hb: CGFloat = 0, ha: CGFloat = 0
        lk.horizon.getRed(&hr, green: &hg, blue: &hb, alpha: &ha)
        let hz = SIMD3<Float>(Float(hr), Float(hg), Float(hb))
        let thr = lk.thr, soft = lk.soft
        let W = w, H = h
        let dd = density, ss = shade
        buf.withUnsafeMutableBufferPointer { bp in
            let out = bp.baseAddress!
            DispatchQueue.concurrentPerform(iterations: H) { j in
                let el = (0.5 - (Float(j) + 0.5) / Float(H)) * Float.pi
                let y = sin(el)
                if y <= 0.01 { return }
                let fade = smooth(0.0, 0.22, y)
                for i in 0..<W {
                    let idx = j * W + i
                    let dv = Float(dd[idx]) / 255
                    let a = smooth(thr, thr + soft, dv) * fade * alphaScale
                    if a < 0.004 { continue }
                    let sh = Float(ss[idx]) / 255
                    var c = shC + (litC - shC) * sh
                    let haze = 0.55 * (1 - fade)
                    c = c + (hz - c) * haze
                    let o = idx * 4
                    out[o] = UInt8(max(0, min(255, c.x * a * 255)))
                    out[o + 1] = UInt8(max(0, min(255, c.y * a * 255)))
                    out[o + 2] = UInt8(max(0, min(255, c.z * a * 255)))
                    out[o + 3] = UInt8(max(0, min(255, a * 255)))
                }
            }
        }
        guard let provider = CGDataProvider(data: Data(buf) as CFData),
              let cg = CGImage(width: w, height: h, bitsPerComponent: 8, bitsPerPixel: 32, bytesPerRow: w * 4,
                               space: CGColorSpaceCreateDeviceRGB(),
                               bitmapInfo: CGBitmapInfo(rawValue: CGImageAlphaInfo.premultipliedLast.rawValue),
                               provider: provider, decode: nil, shouldInterpolate: true,
                               intent: .defaultIntent) else { return nil }
        return UIImage(cgImage: cg)
    }
}

// MARK: - Ảnh cho hạt (mưa, tuyết, lá, sương)

private enum FXImage {
    static func render(_ size: CGSize, _ draw: (CGContext) -> Void) -> UIImage {
        let fmt = UIGraphicsImageRendererFormat()
        fmt.scale = 1
        fmt.opaque = false
        return UIGraphicsImageRenderer(size: size, format: fmt).image { draw($0.cgContext) }
    }

    static func radial(_ n: CGFloat, _ stops: [(CGFloat, CGFloat)]) -> UIImage {
        render(CGSize(width: n, height: n)) { c in
            let cs = CGColorSpaceCreateDeviceRGB()
            let colors = stops.map { UIColor(white: 1, alpha: $0.1).cgColor } as CFArray
            let locs = stops.map { $0.0 }
            guard let g = CGGradient(colorsSpace: cs, colors: colors, locations: locs) else { return }
            let mid = CGPoint(x: n / 2, y: n / 2)
            c.drawRadialGradient(g, startCenter: mid, startRadius: 0, endCenter: mid, endRadius: n / 2, options: [])
        }
    }

    /// Vệt mưa: mảnh, đầu sáng đuôi mờ.
    static let streak: UIImage = render(CGSize(width: 16, height: 64)) { c in
        let cs = CGColorSpaceCreateDeviceRGB()
        let g = CGGradient(colorsSpace: cs,
                           colors: [UIColor(white: 1, alpha: 0).cgColor, UIColor(white: 1, alpha: 0.95).cgColor] as CFArray,
                           locations: [0, 1])!
        c.saveGState()
        c.clip(to: CGRect(x: 6, y: 0, width: 4, height: 64))
        c.drawLinearGradient(g, start: CGPoint(x: 0, y: 0), end: CGPoint(x: 0, y: 64), options: [])
        c.restoreGState()
    }

    static let dot = radial(32, [(0, 1), (0.5, 0.55), (1, 0)])
    static let flake = radial(32, [(0, 1), (0.45, 0.85), (1, 0)])
    static let mist = radial(128, [(0, 0.55), (0.5, 0.25), (1, 0)])

    /// Một dải tia nắng: mềm hai mép, mờ dần hai đầu, loang lổ như ánh sáng lọt qua kẽ lá. Đã nhân sẵn màu nắng ấm.
    static let shaft: UIImage = {
        let w = 64, h = 256
        var px = [UInt8](repeating: 0, count: w * h * 4)
        for row in 0..<h {
            let t = 1 - Float(row) / Float(h - 1)              // 0 = chạm đất, 1 = đầu trên
            let vy = min(t / 0.08, 1) * pow(max(1 - t, 0), 0.8)
            let dapple = 0.25 + 0.75 * smooth(0.3, 0.7, fbm(t * 5, 3.7, 11, oct: 3))
            for col in 0..<w {
                let x = abs(Float(col) / Float(w - 1) * 2 - 1)   // 0 giữa, 1 mép
                let hx = pow(max(1 - x * x, 0), 1.6)
                let streak = 0.6 + 0.4 * vnoise(Float(col) * 0.35, t * 2, 29)
                let a = max(0, min(1, hx * vy * dapple * streak))
                let i = (row * w + col) * 4
                px[i] = UInt8(a * 255)
                px[i + 1] = UInt8(a * 0.93 * 255)
                px[i + 2] = UInt8(a * 0.72 * 255)
                px[i + 3] = UInt8(a * 255)
            }
        }
        let cs = CGColorSpaceCreateDeviceRGB()
        let info = CGBitmapInfo(rawValue: CGImageAlphaInfo.premultipliedLast.rawValue)
        guard let prov = CGDataProvider(data: Data(px) as CFData),
              let img = CGImage(width: w, height: h, bitsPerComponent: 8, bitsPerPixel: 32, bytesPerRow: w * 4,
                                space: cs, bitmapInfo: info, provider: prov, decode: nil,
                                shouldInterpolate: true, intent: .defaultIntent) else { return UIImage() }
        return UIImage(cgImage: img)
    }()

    static let leaf: UIImage = render(CGSize(width: 32, height: 20)) { c in
        c.setFillColor(UIColor(white: 0.95, alpha: 1).cgColor)
        c.fillEllipse(in: CGRect(x: 2, y: 3, width: 28, height: 14))
        c.setStrokeColor(UIColor(white: 0.55, alpha: 1).cgColor)
        c.setLineWidth(1)
        c.move(to: CGPoint(x: 2, y: 10))
        c.addLine(to: CGPoint(x: 30, y: 10))
        c.strokePath()
    }
}

// MARK: - Shader bề mặt: ướt, vũng nước, tuyết bám

/// Chèn vào MỌI chất liệu trong cảnh (nền cỏ, đất, nhà, cây, nhân vật…). Không đổi ảnh gốc,
/// chỉ pha thêm lúc vẽ: `wxWet` = độ ướt (tối màu, bóng, vũng nước gợn), `wxSnow` = độ dày tuyết bám,
/// `wxRain` = mưa đang rơi (để vũng nước còn gợn sóng).
private enum SurfaceFX {
    static let pbr = build(pbr: true)
    static let classic = build(pbr: false)

    private static func build(pbr: Bool) -> String {
        let head = """
        #pragma arguments
        float wxSnow;
        float wxWet;
        float wxRain;
        #pragma declaration
        float wxHash(float3 p) {
            p = fract(p * 0.3183099 + float3(0.1, 0.1, 0.1));
            p *= 17.0;
            return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
        }
        float wxHash2(float2 p) {
            return fract(sin(dot(p, float2(127.1, 311.7))) * 43758.5453);
        }
        float wxNoise(float3 x) {
            float3 i = floor(x);
            float3 f = fract(x);
            f = f * f * (3.0 - 2.0 * f);
            float a = mix(wxHash(i), wxHash(i + float3(1.0, 0.0, 0.0)), f.x);
            float b = mix(wxHash(i + float3(0.0, 1.0, 0.0)), wxHash(i + float3(1.0, 1.0, 0.0)), f.x);
            float c = mix(wxHash(i + float3(0.0, 0.0, 1.0)), wxHash(i + float3(1.0, 0.0, 1.0)), f.x);
            float d = mix(wxHash(i + float3(0.0, 1.0, 1.0)), wxHash(i + float3(1.0, 1.0, 1.0)), f.x);
            return mix(mix(a, b, f.y), mix(c, d, f.y), f.z);
        }
        #pragma body
        float wxW = clamp(wxWet, 0.0, 1.0);
        float wxS = clamp(wxSnow, 0.0, 1.0);
        if (wxW > 0.002 || wxS > 0.002) {
            float3 wN = normalize((scn_frame.inverseViewTransform * float4(_surface.normal, 0.0)).xyz);
            float3 wP = (scn_frame.inverseViewTransform * float4(_surface.position, 1.0)).xyz;
            float up = wN.y;
            float3 dif = _surface.diffuse.rgb;
            float3 nW = wN;
            float snowM = 0.0;
        """
        let look = pbr ? """

            float rgh = _surface.roughness;
            float isWater = 1.0 - smoothstep(0.10, 0.17, rgh);
        """ : """

            float shin = _surface.shininess;
            float3 spec = _surface.specular.rgb;
            float isWater = 0.0;
        """
        let wet = """

            if (wxW > 0.002) {
                float pn = wxNoise(float3(wP.x * 0.45, 3.0, wP.z * 0.45)) * 0.7
                         + wxNoise(float3(wP.x * 1.7, 9.0, wP.z * 1.7)) * 0.3;
                float plain = smoothstep(0.78, 0.94, up);
                float puddle = plain * smoothstep(0.74 - 0.18 * wxW, 0.82 - 0.18 * wxW, pn) * (1.0 - isWater);
                float damp = wxW * (1.0 - isWater);
                dif *= mix(1.0, 0.66, damp);
                dif = mix(dif, dif * 0.55, puddle);
        """
        let wetLook = pbr ? """

                rgh = mix(rgh, 0.28, damp * 0.8);
                rgh = mix(rgh, 0.03, puddle);
        """ : """

                shin = mix(shin, 40.0, damp * 0.6);
                spec = max(spec, float3(0.30, 0.30, 0.30) * damp);
        """
        let ripple = """

                float rp = max(puddle, isWater * wxW) * clamp(wxRain, 0.0, 1.0);
                if (rp > 0.02) {
                    float2 push = float2(0.0, 0.0);
                    for (int k = 0; k < 2; k++) {
                        float sc = (k == 0) ? 3.0 : 5.3;
                        float2 g = wP.xz * sc + float(k) * 17.0;
                        float2 cid = floor(g);
                        float2 f = fract(g) - 0.5;
                        float h = wxHash2(cid);
                        float2 ctr = (float2(wxHash2(cid + 3.1), wxHash2(cid + 7.7)) - 0.5) * 0.5;
                        float ph = fract(scn_frame.time * (0.8 + 0.5 * h) + h * 6.0);
                        float2 dv = f - ctr;
                        float d = length(dv);
                        float ring = (1.0 - smoothstep(0.0, 0.07, abs(d - ph * 0.42))) * (1.0 - ph);
                        ring *= step(1.0 - 0.75 * wxW, h);
                        push += normalize(dv + float2(0.0001, 0.0)) * ring;
                    }
                    nW.xz += push * 0.9 * rp;
                }
            }
        """
        let snow = """

            if (wxS > 0.002) {
                float nn = wxNoise(wP * 2.3) * 0.65 + wxNoise(wP * 9.0) * 0.35;
                float v = up - (1.0 - wxS) * 1.35 + (nn - 0.5) * 0.55;
                float m = smoothstep(0.12, 0.34, v) * (1.0 - isWater);
                float3 sc = float3(0.94, 0.96, 1.0) * (0.94 + 0.06 * wxNoise(wP * 18.0));
                dif = mix(dif, sc, m);
                nW = mix(nW, float3(0.0, 1.0, 0.0), m * 0.55);
                snowM = m;
        """
        let snowLook = pbr ? """

                rgh = mix(rgh, 0.88, m);
            }
        """ : """

                shin = mix(shin, 8.0, m);
                spec = mix(spec, float3(0.12, 0.12, 0.12), m);
            }
        """
        let tail = pbr ? """

            _surface.diffuse = float4(dif, _surface.diffuse.a);
            _surface.roughness = rgh;
            _surface.metalness = mix(_surface.metalness, 0.0, snowM);
            _surface.normal = normalize((scn_frame.viewTransform * float4(normalize(nW), 0.0)).xyz);
        }
        """ : """

            _surface.diffuse = float4(dif, _surface.diffuse.a);
            _surface.shininess = shin;
            _surface.specular = float4(spec, _surface.specular.a);
            _surface.normal = normalize((scn_frame.viewTransform * float4(normalize(nW), 0.0)).xyz);
        }
        """
        return head + look + wet + wetLook + ripple + snow + snowLook + tail
    }
}

// MARK: - Hệ thống thời tiết

final class WeatherSystem {
    private let scene: SCNScene
    private let cameraNode: SCNNode
    private let world: SCNNode
    private let ambient: SCNNode
    private let sun: SCNNode

    var onFog: ((CGFloat) -> Void)?
    private(set) var weather: Weather = .clear

    private let skyRoot = SCNNode()           // bám theo camera
    private let cumulus = SCNNode()
    private let cirrus = SCNNode()
    private let fx = SCNNode()                // hạt, bám theo điểm đang nhìn
    private let cumulusMat = SCNMaterial()
    private let cirrusMat = SCNMaterial()
    private var cumulusData: CloudData?
    private var cirrusData: CloudData?
    private var skyCache: [Weather: UIImage] = [:]
    private var level: Float = 1

    // ướt / tuyết bám: giá trị hiện tại, mục tiêu, và tốc độ (đơn vị 1/giây)
    private let surfMats = NSHashTable<SCNMaterial>.weakObjects()
    private var wxSnow: Float = 0, wxWet: Float = 0, wxRain: Float = 0
    private var snowGoal: Float = 0, wetGoal: Float = 0, rainGoal: Float = 0
    private var snowUp: Float = 1.0 / 50, snowDown: Float = 1.0 / 45
    private var wetUp: Float = 1.0 / 18, wetDown: Float = 1.0 / 70
    private var cloudToken = 0

    init(scene: SCNScene, camera: SCNNode, world: SCNNode, ambient: SCNNode, sun: SCNNode) {
        self.scene = scene
        self.cameraNode = camera
        self.world = world
        self.ambient = ambient
        self.sun = sun

        // hai tầng mây là hai mái vòm trong suốt bao quanh camera, vẽ ngay sau nền trời
        for (node, mat, radius) in [(cumulus, cumulusMat, CGFloat(98)), (cirrus, cirrusMat, CGFloat(99))] {
            let s = SCNSphere(radius: radius)
            s.segmentCount = 48
            mat.lightingModel = .constant
            mat.cullMode = .front
            mat.writesToDepthBuffer = false
            mat.readsFromDepthBuffer = false
            mat.diffuse.mipFilter = .linear
            s.materials = [mat]
            node.geometry = s
            node.castsShadow = false
            node.renderingOrder = -100
            node.isHidden = true
            skyRoot.addChildNode(node)
        }
        cirrus.renderingOrder = -99
        skyRoot.constraints = [SCNTransformConstraint.positionConstraint(inWorldSpace: true) { [weak camera] _, _ in
            camera?.worldPosition ?? SCNVector3Zero
        }]
        scene.rootNode.addChildNode(skyRoot)
        scene.rootNode.addChildNode(fx)

        // lá cây lay mạnh hay nhẹ theo gió (cây mới đặt cũng được cập nhật)
        fx.runAction(SCNAction.repeatForever(SCNAction.sequence([
            SCNAction.wait(duration: 2),
            SCNAction.run { [weak self] _ in
                self?.refreshWindGain()
                self?.refreshSurfaces()
            }
        ])))
        // độ ướt và tuyết bám tăng / giảm từ từ theo thời gian
        fx.runAction(SCNAction.repeatForever(SCNAction.sequence([
            SCNAction.wait(duration: 0.1),
            SCNAction.run { [weak self] _ in self?.stepSurface(0.1) }
        ])), forKey: "surface")

        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            let cum = CloudData(w: 2560, h: 1280, seed: 7, ax: 1, az: 1, freq: 1.3, oct: 6)
            let cir = CloudData(w: 1536, h: 768, seed: 91, ax: 0.35, az: 1.9, freq: 1.0, oct: 5)
            DispatchQueue.main.async {
                guard let self = self else { return }
                self.cumulusData = cum
                self.cirrusData = cir
                self.refreshClouds()
            }
        }
    }

    // MARK: Áp thời tiết

    func apply(_ w: Weather) {
        weather = w
        let lk = look(w)

        SCNTransaction.begin()
        SCNTransaction.animationDuration = 1.5
        sun.light?.intensity = lk.sun
        sun.light?.color = lk.sunColor
        ambient.light?.intensity = lk.ambient
        SCNTransaction.commit()
        sun.light?.castsShadow = lk.sun > 900

        let sky = skyImage(w)
        scene.background.contents = sky
        scene.lightingEnvironment.contents = sky
        scene.lightingEnvironment.intensity = CGFloat(lk.env)
        scene.fogColor = lk.horizon
        onFog?(lk.fogFactor)

        refreshClouds()
        for (node, mult) in [(cumulus, Float(1)), (cirrus, Float(1.7))] {
            node.removeAction(forKey: "drift")
            let period = Double(2 * Float.pi / (lk.drift * mult))
            node.runAction(SCNAction.repeatForever(SCNAction.rotateBy(x: 0, y: CGFloat(2 * Float.pi), z: 0, duration: period)),
                           forKey: "drift")
        }

        // ướt và tuyết bám lên mọi bề mặt (nền, nhà, cây, người), tan / khô dần khi hết
        switch w {
        case .rain:
            snowGoal = 0; wetGoal = 1; rainGoal = 1
            snowDown = 1.0 / 15; wetUp = 1.0 / 18
        case .storm:
            snowGoal = 0; wetGoal = 1; rainGoal = 1
            snowDown = 1.0 / 10; wetUp = 1.0 / 10
        case .snow:
            snowGoal = 1; wetGoal = 0; rainGoal = 0
            snowUp = 1.0 / 50; wetDown = 1.0 / 20
        case .fog:
            snowGoal = 0; wetGoal = 0.35; rainGoal = 0
            snowDown = 1.0 / 45; wetUp = 1.0 / 40
        default:
            snowGoal = 0; wetGoal = 0; rainGoal = 0
            snowDown = 1.0 / 45; wetDown = 1.0 / 70
        }
        refreshSurfaces()

        fx.removeAction(forKey: "lightning")
        rebuildParticles()
        if w == .storm { scheduleLightning() }
        refreshWindGain()
    }

    /// Gọi mỗi lần camera đổi: hạt bám theo điểm đang nhìn, kích cỡ theo độ xa.
    func cameraMoved(focus: SIMD3<Float>, ref: Float) {
        fx.simdPosition = SIMD3<Float>(focus.x, 0, focus.z)
        let steps: [Float] = [1, 1.6, 2.5, 4, 6]
        let want = ref / 24
        var lv = steps[0]
        for s in steps where want >= s * 0.85 { lv = s }
        if lv != level {
            level = lv
            rebuildParticles()
        }
    }

    // MARK: Bầu trời và mây

    private func skyImage(_ w: Weather) -> UIImage {
        if let c = skyCache[w] { return c }
        let lk = look(w)
        let size = CGSize(width: 1024, height: 512)
        let fmt = UIGraphicsImageRendererFormat()
        fmt.scale = 1
        fmt.opaque = true
        let img = UIGraphicsImageRenderer(size: size, format: fmt).image { ctx in
            let c = ctx.cgContext
            let cs = CGColorSpaceCreateDeviceRGB()
            func mix(_ a: UIColor, _ b: UIColor, _ t: CGFloat) -> UIColor {
                var ar: CGFloat = 0, ag: CGFloat = 0, ab: CGFloat = 0, aa: CGFloat = 0
                var br: CGFloat = 0, bg: CGFloat = 0, bb: CGFloat = 0, ba: CGFloat = 0
                a.getRed(&ar, green: &ag, blue: &ab, alpha: &aa)
                b.getRed(&br, green: &bg, blue: &bb, alpha: &ba)
                return UIColor(red: ar + (br - ar) * t, green: ag + (bg - ag) * t, blue: ab + (bb - ab) * t, alpha: 1)
            }
            let mid = mix(lk.top, lk.horizon, 0.55)
            let ground = mix(lk.horizon, UIColor(red: 0.45, green: 0.52, blue: 0.40, alpha: 1), 0.35)
            let colors = [lk.top.cgColor, mid.cgColor, lk.horizon.cgColor, lk.horizon.cgColor, ground.cgColor] as CFArray
            let grad = CGGradient(colorsSpace: cs, colors: colors, locations: [0, 0.30, 0.50, 0.56, 1])!
            c.drawLinearGradient(grad, start: .zero, end: CGPoint(x: 0, y: size.height), options: [])

            if lk.sunGlow > 0 {
                let sunPos = CGPoint(x: size.width * 0.62, y: size.height * 0.22)
                let k = CGFloat(lk.sunGlow)
                let warm = UIColor(red: 1, green: 0.93, blue: 0.75, alpha: 1)
                let corona = CGGradient(colorsSpace: cs,
                                        colors: [warm.withAlphaComponent(0.55 * k).cgColor,
                                                 warm.withAlphaComponent(0.18 * k).cgColor,
                                                 warm.withAlphaComponent(0).cgColor] as CFArray,
                                        locations: [0, 0.3, 1])!
                c.drawRadialGradient(corona, startCenter: sunPos, startRadius: 0, endCenter: sunPos,
                                     endRadius: 190 * k + 40, options: [])
                let disc = CGGradient(colorsSpace: cs,
                                      colors: [UIColor(white: 1, alpha: 1).cgColor,
                                               UIColor(white: 1, alpha: 1).cgColor,
                                               UIColor(red: 1, green: 0.96, blue: 0.85, alpha: 0).cgColor] as CFArray,
                                      locations: [0, 0.35, 1])!
                c.drawRadialGradient(disc, startCenter: sunPos, startRadius: 0, endCenter: sunPos,
                                     endRadius: 34 * k + 8, options: [])
            }
        }
        skyCache[w] = img
        return img
    }

    private func refreshClouds() {
        guard let cum = cumulusData, let cir = cirrusData else { return }
        cloudToken += 1
        let token = cloudToken
        let lk = look(weather)
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            let a = cum.image(lk, alphaScale: 1.0)
            var cl = lk
            cl.thr = min(lk.thr + 0.12, 0.7)
            cl.soft = 0.35
            let b = cir.image(cl, alphaScale: lk.dark > 0.5 ? 0.0 : 0.45)
            DispatchQueue.main.async {
                guard let self = self, token == self.cloudToken else { return }
                self.cumulusMat.diffuse.contents = a
                self.cirrusMat.diffuse.contents = b
                self.cumulus.isHidden = a == nil
                self.cirrus.isHidden = b == nil || lk.dark > 0.5
            }
        }
    }

    // MARK: Hạt

    private func emitter(_ sys: SCNParticleSystem, x: Float = 0, y: Float = 0, z: Float = 0, yaw: Float = 0) {
        let n = SCNNode()
        n.position = SCNVector3(x, y, z)
        n.eulerAngles.y = yaw
        n.addParticleSystem(sys)
        fx.addChildNode(n)
    }

    private func fade(_ keys: [Float], _ times: [Float]) -> SCNParticlePropertyController {
        let a = CAKeyframeAnimation()
        a.values = keys.map { NSNumber(value: $0) }
        a.keyTimes = times.map { NSNumber(value: $0) }
        a.duration = 1
        return SCNParticlePropertyController(animation: a)
    }

    private func rebuildParticles() {
        for c in fx.childNodes { c.removeFromParentNode() }
        let s = level
        switch weather {
        case .rain:
            addRain(s, heavy: 1.0, slant: 0.12)
            addSplash(s, heavy: 1.0)
            addMist(s, alpha: 0.07, rate: 2)
        case .storm:
            addRain(s, heavy: 1.8, slant: 0.32)
            addSplash(s, heavy: 1.8)
            addMist(s, alpha: 0.12, rate: 3)
            addLeaves(s, rate: 10)
        case .snow:
            addSnow(s, rate: 520, size: 0.075, fall: 1.1, drift: 0.5)
            addSnow(s, rate: 260, size: 0.13, fall: 1.5, drift: -0.7)
            addMist(s, alpha: 0.05, rate: 1.5)
        case .wind:
            addLeaves(s, rate: 16)
            addDust(s)
        case .fog:
            addMist(s, alpha: 0.20, rate: 6)
        case .clear:
            addMotes(s)
        case .cloudy:
            break
        }
    }

    private func addRain(_ s: Float, heavy: Float, slant: Float) {
        let p = SCNParticleSystem()
        p.particleImage = FXImage.streak
        let w = 36 * s
        p.emitterShape = SCNBox(width: CGFloat(w), height: 0.1, length: CGFloat(w), chamferRadius: 0)
        p.birthLocation = .volume
        p.birthRate = CGFloat(min(3800 * heavy * s * s, 9000))
        p.particleLifeSpan = 1.15
        p.particleLifeSpanVariation = 0.25
        p.particleVelocity = CGFloat(22 * s)
        p.particleVelocityVariation = CGFloat(5 * s)
        p.emittingDirection = SCNVector3(slant, -1, slant * 0.4)
        p.spreadingAngle = 1.2
        p.particleSize = CGFloat(0.035 * s)
        p.particleSizeVariation = CGFloat(0.012 * s)
        p.stretchFactor = 0.05
        p.particleColor = UIColor(white: 0.92, alpha: 0.5)
        p.blendMode = .alpha
        p.isLightingEnabled = false
        p.isAffectedByGravity = false
        p.isLocal = false
        p.loops = true
        emitter(p, y: 26 * s)
    }

    private func addSplash(_ s: Float, heavy: Float) {
        let p = SCNParticleSystem()
        p.particleImage = FXImage.dot
        let w = 30 * min(s, 2.5)
        p.emitterShape = SCNBox(width: CGFloat(w), height: 0.01, length: CGFloat(w), chamferRadius: 0)
        p.birthLocation = .volume
        p.birthRate = CGFloat(min(700 * heavy * s, 5000))
        p.particleLifeSpan = 0.38
        p.particleLifeSpanVariation = 0.12
        p.particleVelocity = CGFloat(1.7 * s)
        p.particleVelocityVariation = CGFloat(0.9 * s)
        p.emittingDirection = SCNVector3(0, 1, 0)
        p.spreadingAngle = 60
        p.acceleration = SCNVector3(0, -9.8 * s, 0)
        p.particleSize = CGFloat(0.03 * s)
        p.particleSizeVariation = CGFloat(0.012 * s)
        p.particleColor = UIColor(white: 1, alpha: 0.55)
        p.blendMode = .alpha
        p.isLightingEnabled = false
        p.isLocal = false
        p.loops = true
        p.propertyControllers = [.opacity: fade([1, 0.8, 0], [0, 0.5, 1])]
        emitter(p, y: 0.04)
    }

    private func addSnow(_ s: Float, rate: Float, size: Float, fall: Float, drift: Float) {
        let p = SCNParticleSystem()
        p.particleImage = FXImage.flake
        let w = 34 * s
        let h = 13 * s
        p.emitterShape = SCNBox(width: CGFloat(w), height: 0.1, length: CGFloat(w), chamferRadius: 0)
        p.birthLocation = .volume
        p.birthRate = CGFloat(min(rate * s * s, 6000))
        p.particleLifeSpan = CGFloat(h / (fall * s) + 1)
        p.particleLifeSpanVariation = 1.2
        p.particleVelocity = CGFloat(fall * s)
        p.particleVelocityVariation = CGFloat(0.5 * s)
        p.emittingDirection = SCNVector3(drift * 0.4, -1, 0.12)
        p.spreadingAngle = 14
        p.acceleration = SCNVector3(drift * 0.25 * s, 0, 0.1 * s)
        p.particleSize = CGFloat(size * s)
        p.particleSizeVariation = CGFloat(size * 0.6 * s)
        p.particleColor = UIColor(white: 1, alpha: 0.92)
        p.particleAngleVariation = 360
        p.particleAngularVelocity = 40
        p.particleAngularVelocityVariation = 80
        p.blendMode = .alpha
        p.isLightingEnabled = false
        p.isAffectedByGravity = false
        p.isLocal = false
        p.loops = true
        p.propertyControllers = [.opacity: fade([0, 1, 1, 0.6], [0, 0.08, 0.85, 1])]
        emitter(p, y: h)
    }

    private func addMist(_ s: Float, alpha: CGFloat, rate: Float) {
        let p = SCNParticleSystem()
        p.particleImage = FXImage.mist
        let w = 60 * s
        p.emitterShape = SCNBox(width: CGFloat(w), height: CGFloat(2 * s), length: CGFloat(w), chamferRadius: 0)
        p.birthLocation = .volume
        p.birthRate = CGFloat(rate * s)
        p.particleLifeSpan = 16
        p.particleLifeSpanVariation = 4
        p.particleVelocity = CGFloat(0.9 * s)
        p.particleVelocityVariation = CGFloat(0.4 * s)
        p.emittingDirection = SCNVector3(0.87, 0, 0.5)
        p.spreadingAngle = 20
        p.particleSize = CGFloat(9 * s)
        p.particleSizeVariation = CGFloat(5 * s)
        p.particleColor = UIColor(white: 0.86, alpha: alpha)
        p.blendMode = .alpha
        p.isLightingEnabled = false
        p.isAffectedByGravity = false
        p.isLocal = false
        p.loops = true
        p.propertyControllers = [.opacity: fade([0, 1, 1, 0], [0, 0.25, 0.7, 1])]
        emitter(p, y: 1.8 * s)
    }

    private func addLeaves(_ s: Float, rate: Float) {
        let p = SCNParticleSystem()
        p.particleImage = FXImage.leaf
        p.emitterShape = SCNBox(width: 2, height: CGFloat(7 * s), length: CGFloat(36 * s), chamferRadius: 0)
        p.birthLocation = .volume
        p.birthRate = CGFloat(rate * s)
        p.particleLifeSpan = 6.5
        p.particleLifeSpanVariation = 1.5
        p.particleVelocity = CGFloat(7 * s)
        p.particleVelocityVariation = CGFloat(3 * s)
        p.emittingDirection = SCNVector3(1, 0.08, 0)
        p.spreadingAngle = 12
        p.acceleration = SCNVector3(0, 0.5 * s, 0)
        p.particleSize = CGFloat(0.17 * s)
        p.particleSizeVariation = CGFloat(0.07 * s)
        p.particleColor = UIColor(red: 0.45, green: 0.62, blue: 0.22, alpha: 1)
        p.particleColorVariation = SCNVector4(0.25, 0.15, 0.1, 0)
        p.particleAngleVariation = 360
        p.particleAngularVelocity = 160
        p.particleAngularVelocityVariation = 320
        p.blendMode = .alpha
        p.isLightingEnabled = false
        p.isAffectedByGravity = false
        p.isLocal = false
        p.loops = true
        p.propertyControllers = [.opacity: fade([0, 1, 1, 0], [0, 0.1, 0.85, 1])]
        // trục X của emitter hướng theo gió (0,87; 0,5)
        emitter(p, x: -0.87 * 20 * s, y: 3.5 * s, z: -0.5 * 20 * s, yaw: -atan2(0.5, 0.87))
    }

    private func addDust(_ s: Float) {
        let p = SCNParticleSystem()
        p.particleImage = FXImage.streak
        p.emitterShape = SCNBox(width: 2, height: CGFloat(4 * s), length: CGFloat(40 * s), chamferRadius: 0)
        p.birthLocation = .volume
        p.birthRate = CGFloat(min(70 * s, 400))
        p.particleLifeSpan = 3
        p.particleLifeSpanVariation = 0.8
        p.particleVelocity = CGFloat(16 * s)
        p.particleVelocityVariation = CGFloat(5 * s)
        p.emittingDirection = SCNVector3(1, 0.02, 0)
        p.spreadingAngle = 4
        p.particleSize = CGFloat(0.05 * s)
        p.stretchFactor = 0.12
        p.particleColor = UIColor(red: 0.95, green: 0.9, blue: 0.8, alpha: 0.14)
        p.blendMode = .alpha
        p.isLightingEnabled = false
        p.isAffectedByGravity = false
        p.isLocal = false
        p.loops = true
        emitter(p, x: -0.87 * 20 * s, y: 2 * s, z: -0.5 * 20 * s, yaw: -atan2(0.5, 0.87))
    }

    /// Nắng: các dải tia nắng xiên theo hướng mặt trời, như ánh sáng xuyên qua tán lá; lung linh nhẹ, không có hạt rơi.
    private func addMotes(_ s: Float) {
        let toSun = -sun.simdWorldFront                        // hướng từ mặt đất lên phía mặt trời
        let up = simd_normalize(toSun)
        let q = simd_quatf(from: SIMD3<Float>(0, 1, 0), to: up)
        let len = 30 * s
        let count = 8
        for i in 0..<count {
            let m = SCNMaterial()
            m.lightingModel = .constant
            m.diffuse.contents = FXImage.shaft
            m.blendMode = .add
            m.isDoubleSided = true
            m.writesToDepthBuffer = false
            m.transparency = 0.0

            let width = CGFloat(Float.random(in: 1.0...2.4) * s)
            let holder = SCNNode()
            for k in 0..<2 {                                    // hai tấm vuông góc để nhìn hướng nào cũng thấy
                let plane = SCNPlane(width: width, height: CGFloat(len))
                plane.materials = [m]
                let n = SCNNode(geometry: plane)
                n.eulerAngles.y = Float(k) * Float.pi / 2
                n.castsShadow = false
                holder.addChildNode(n)
            }
            let bx = Float.random(in: -13...13) * s
            let bz = Float.random(in: -13...13) * s
            holder.simdOrientation = q
            holder.simdPosition = SIMD3<Float>(bx, 0, bz) + up * (len / 2)
            holder.castsShadow = false
            holder.renderingOrder = 5
            fx.addChildNode(holder)

            // lung linh: mỗi tia sáng lên rồi mờ đi theo nhịp riêng
            let peak = CGFloat(Float.random(in: 0.08...0.16))
            let period = Double.random(in: 4...9)
            let shimmer = SCNAction.customAction(duration: period) { _, t in
                let ph = Float(t / CGFloat(period)) * 2 * Float.pi
                m.transparency = peak * CGFloat(0.55 + 0.45 * sin(ph + Float(i)))
            }
            holder.runAction(SCNAction.repeatForever(shimmer))
        }
    }

    // MARK: Sấm sét

    private func scheduleLightning() {
        let wait = SCNAction.wait(duration: Double.random(in: 4...11))
        let strike = SCNAction.run { [weak self] _ in
            DispatchQueue.main.async {
                guard let self = self, self.weather == .storm else { return }
                self.strike()
                self.scheduleLightning()
            }
        }
        fx.runAction(SCNAction.sequence([wait, strike]), forKey: "lightning")
    }

    private func strike() {
        let focus = fx.simdPosition
        let ang = Float.random(in: 0..<(2 * Float.pi))
        let dist = Float.random(in: 130...330)
        let base = SIMD3<Float>(focus.x + cos(ang) * dist, 0, focus.z + sin(ang) * dist)
        let mat = SCNMaterial()
        mat.lightingModel = .constant
        mat.diffuse.contents = UIColor(red: 0.92, green: 0.95, blue: 1, alpha: 1)
        mat.diffuse.intensity = 3
        let bolt = SCNNode()
        var p = base + SIMD3<Float>(0, 380, 0)
        let thick = dist * 0.012
        var fork: SIMD3<Float>? = nil
        for i in 0..<16 {
            let next = SIMD3<Float>(p.x + Float.random(in: -22...22), max(p.y - 380 / 16, 0), p.z + Float.random(in: -22...22))
            bolt.addChildNode(Builder.link(p, next, r1: thick, r2: thick, mat, seg: 4))
            if i == 6 { fork = next }
            p = next
        }
        if var f = fork {
            for _ in 0..<5 {
                let next = f + SIMD3<Float>(Float.random(in: 8...30), -Float.random(in: 14...30), Float.random(in: -14...14))
                bolt.addChildNode(Builder.link(f, next, r1: thick * 0.6, r2: thick * 0.6, mat, seg: 4))
                f = next
            }
        }
        scene.rootNode.addChildNode(bolt)

        let lk = look(.storm)
        let flashSun = lk.sun + 2600
        let flashAmb = lk.ambient + 900
        let set: (CGFloat, CGFloat) -> SCNAction = { [weak self] sunI, ambI in
            SCNAction.run { _ in
                self?.sun.light?.intensity = sunI
                self?.ambient.light?.intensity = ambI
            }
        }
        scene.rootNode.runAction(SCNAction.sequence([
            set(flashSun, flashAmb), SCNAction.wait(duration: 0.07),
            set(lk.sun, lk.ambient), SCNAction.wait(duration: 0.09),
            set(flashSun * 0.8, flashAmb), SCNAction.wait(duration: 0.05),
            set(lk.sun, lk.ambient),
            SCNAction.wait(duration: 0.25),
            SCNAction.run { _ in bolt.removeFromParentNode() }
        ]), forKey: "flash")
    }

    // MARK: Ướt và tuyết bám

    private func approach(_ v: Float, _ g: Float, up: Float, down: Float, _ dt: Float) -> Float {
        v < g ? min(g, v + up * dt) : max(g, v - down * dt)
    }

    private func stepSurface(_ dt: Float) {
        let s = approach(wxSnow, snowGoal, up: snowUp, down: snowDown, dt)
        let w = approach(wxWet, wetGoal, up: wetUp, down: wetDown, dt)
        let r = approach(wxRain, rainGoal, up: 0.5, down: 0.25, dt)
        guard abs(s - wxSnow) > 0.0004 || abs(w - wxWet) > 0.0004 || abs(r - wxRain) > 0.0004 else { return }
        wxSnow = s
        wxWet = w
        wxRain = r
        for m in surfMats.allObjects { pushSurface(m) }
    }

    private func pushSurface(_ m: SCNMaterial) {
        m.setValue(NSNumber(value: wxSnow), forKey: "wxSnow")
        m.setValue(NSNumber(value: wxWet), forKey: "wxWet")
        m.setValue(NSNumber(value: wxRain), forKey: "wxRain")
    }

    /// Gắn shader ướt / tuyết cho mọi chất liệu đang có (kể cả vật mới đặt, nhân vật mới). Chỉ chạy khi cần.
    private func refreshSurfaces() {
        guard snowGoal > 0 || wetGoal > 0 || wxSnow > 0.001 || wxWet > 0.001 else { return }
        walkSurface(scene.rootNode)
    }

    private func walkSurface(_ n: SCNNode) {
        if n === skyRoot || n === fx { return }
        if let geo = n.geometry {
            for m in geo.materials where !surfMats.contains(m) { adoptSurface(m) }
        }
        for c in n.childNodes { walkSurface(c) }
    }

    private func adoptSurface(_ m: SCNMaterial) {
        guard m.lightingModel != .constant else { return }     // bầu trời, lưới, tia nắng, sét: bỏ qua
        let key = SCNShaderModifierEntryPoint.surface
        let src = m.lightingModel == .physicallyBased ? SurfaceFX.pbr : SurfaceFX.classic
        var mods = m.shaderModifiers ?? [:]
        if let old = mods[key] {
            if old != src { return }                          // shader khác của người dùng, không đè
        } else {
            mods[key] = src
            m.shaderModifiers = mods
        }
        surfMats.add(m)
        pushSurface(m)
    }

    // MARK: Gió làm lá cây lay

    private func refreshWindGain() {
        let g = NSNumber(value: look(weather).wind)
        world.enumerateHierarchy { n, _ in
            guard let geo = n.geometry else { return }
            for m in geo.materials {
                if let src = m.shaderModifiers?[SCNShaderModifierEntryPoint.geometry], src.contains("float gain") {
                    m.setValue(g, forKey: "gain")
                }
            }
        }
    }
}
