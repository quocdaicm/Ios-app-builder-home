import SceneKit
import UIKit
import simd

// MARK: - Model

enum Kind: String, Codable {
    case house, tower, tree, pine, road
    case canal, bridge, stilt, tole, coconut, nipa, boat
    case grass
    case model          // mô hình 3D người dùng nhập vào (USDZ / OBJ / SCN…)
}

extension Kind {
    /// Vật thể nối giữa 2 điểm (đường, kênh, cầu)
    var isLine: Bool { self == .road || self == .canal || self == .bridge }

    /// Số biến thể (màu / kiểu) để bấm "Màu" đổi qua lại
    var variantCount: Int {
        switch self {
        case .house, .tower, .tree, .tole: return 5
        case .stilt, .road, .boat, .grass: return 3
        case .canal, .coconut: return 2
        case .pine, .bridge, .nipa, .model: return 1
        }
    }
}

struct Item: Codable, Identifiable {
    var id = UUID()
    var kind: Kind
    var x: Float
    var z: Float
    var rot: Float = 0          // xoay quanh trục Y (radian)
    var scale: Float = 1
    var colorIndex: Int = 0     // biến thể màu / kiểu
    var x2: Float = 0           // điểm cuối (đường, kênh, cầu)
    var z2: Float = 0
    var motion: Int? = nil      // chuyển động của mô hình nhập: 0 đứng yên, 1 đung đưa, 2 lá lay, 3 nhún, 4 đi vòng
    var motionFlip: Bool? = nil // đảo hướng đầu khi đi vòng
    var model: String? = nil    // tên file mô hình (kind == .model), nằm trong Documents/Models
}

/// Bộ số ngẫu nhiên có hạt giống: mỗi cây có dáng riêng nhưng dựng lại vẫn y hệt.
struct SeededRNG: RandomNumberGenerator {
    var state: UInt64
    init(_ seed: UInt64) { state = seed &+ 0x9E3779B97F4A7C15 }
    mutating func next() -> UInt64 {
        state = state &* 6364136223846793005 &+ 1442695040888963407
        return state ^ (state >> 29)
    }
    mutating func f(_ lo: Float, _ hi: Float) -> Float {
        Float.random(in: lo...hi, using: &self)
    }
}

// MARK: - Dựng mô hình chân thực (vật liệu PBR + texture)

enum Builder {
    static func rgb(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat) -> UIColor {
        UIColor(red: r, green: g, blue: b, alpha: 1)
    }

    // Màu nhân lên texture (giữ vân, đổi tông)
    static let wallTints: [UIColor] = [
        rgb(1.00, 0.90, 0.72), rgb(1.00, 0.74, 0.68), rgb(0.80, 0.90, 1.00),
        rgb(1.00, 0.98, 0.92), rgb(0.82, 0.95, 0.80)
    ]
    static let tileTints: [UIColor] = [
        rgb(1.00, 1.00, 1.00), rgb(0.80, 0.78, 0.76), rgb(1.00, 0.88, 0.78),
        rgb(0.72, 0.76, 0.80), rgb(0.92, 0.86, 0.80)
    ]
    static let towerTints: [UIColor] = [
        rgb(0.95, 0.95, 0.97), rgb(1.00, 0.92, 0.80), rgb(0.80, 0.88, 0.95),
        rgb(0.95, 0.80, 0.76), rgb(1.00, 1.00, 0.96)
    ]
    static let glassTints: [UIColor] = [
        rgb(0.30, 0.45, 0.58), rgb(0.25, 0.46, 0.46), rgb(0.20, 0.30, 0.45),
        rgb(0.34, 0.42, 0.40), rgb(0.28, 0.40, 0.52)
    ]
    static let leafTints: [UIColor] = [
        rgb(1.00, 1.00, 1.00), rgb(1.10, 1.15, 0.85), rgb(0.80, 0.95, 0.95),
        rgb(1.00, 1.15, 0.70), rgb(0.95, 1.05, 0.90)
    ]
    static let toleWallTints: [UIColor] = [
        rgb(0.62, 0.80, 0.86), rgb(0.95, 0.90, 0.62), rgb(0.74, 0.88, 0.70),
        rgb(0.95, 0.76, 0.72), rgb(0.86, 0.86, 0.84)
    ]
    static let boatTints: [UIColor] = [
        rgb(0.70, 0.22, 0.16), rgb(0.20, 0.38, 0.62), rgb(0.22, 0.50, 0.32)
    ]

    static let bambooGreen = rgb(0.85, 0.95, 0.60)

    // MARK: Hàm dựng cơ bản

    private static var plainCache: [String: SCNMaterial] = [:]

    /// Vật liệu PBR màu trơn (dùng chung).
    static func plain(_ color: UIColor, rough: CGFloat = 0.8, metal: CGFloat = 0) -> SCNMaterial {
        let key = "\(color.description)|\(rough)|\(metal)"
        if let c = plainCache[key] { return c }
        let m = SCNMaterial()
        m.lightingModel = .physicallyBased
        m.diffuse.contents = color
        m.roughness.contents = rough
        m.metalness.contents = metal
        plainCache[key] = m
        return m
    }

    static func tex(_ t: Tex, tint: UIColor? = nil, rough: CGFloat = 0.85, metal: CGFloat = 0,
                    rx: Float = 1, ry: Float = 1, swapUV: Bool = false) -> SCNMaterial {
        TextureLibrary.material(t, tint: tint, roughness: rough, metalness: metal,
                                repeatX: rx, repeatY: ry, swapUV: swapUV)
    }

    /// Làm tròn số lần lặp để dùng chung vật liệu (đỡ tốn bộ nhớ).
    private static func rep(_ length: Float, _ tile: Float) -> Float {
        max((length / tile * 4).rounded() / 4, 0.25)
    }

    /// Khối hộp màu trơn.
    static func box(_ w: Float, _ h: Float, _ l: Float, _ color: UIColor,
                    rough: CGFloat = 0.8, metal: CGFloat = 0,
                    x: Float = 0, y: Float = 0, z: Float = 0) -> SCNNode {
        let g = SCNBox(width: CGFloat(w), height: CGFloat(h), length: CGFloat(l), chamferRadius: 0)
        g.materials = [plain(color, rough: rough, metal: metal)]
        let n = SCNNode(geometry: g)
        n.position = SCNVector3(x, y, z)
        return n
    }

    /// Khối hộp phủ texture; số lần lặp tính theo kích thước mỗi mặt nên vân không bị méo.
    static func tbox(_ w: Float, _ h: Float, _ l: Float, _ t: Tex, tint: UIColor? = nil,
                     rough: CGFloat = 0.85, metal: CGFloat = 0, tile: Float = 2,
                     x: Float = 0, y: Float = 0, z: Float = 0) -> SCNNode {
        let g = SCNBox(width: CGFloat(w), height: CGFloat(h), length: CGFloat(l), chamferRadius: 0)
        func m(_ a: Float, _ b: Float) -> SCNMaterial {
            tex(t, tint: tint, rough: rough, metal: metal, rx: rep(a, tile), ry: rep(b, tile))
        }
        // thứ tự mặt của SCNBox: trước, phải, sau, trái, trên, dưới
        g.materials = [m(w, h), m(l, h), m(w, h), m(l, h), m(w, l), m(w, l)]
        let n = SCNNode(geometry: g)
        n.position = SCNVector3(x, y, z)
        return n
    }

    static func cyl(_ r: Float, _ h: Float, _ color: UIColor, rough: CGFloat = 0.8, metal: CGFloat = 0,
                    x: Float = 0, y: Float = 0, z: Float = 0, seg: Int = 12) -> SCNNode {
        let g = SCNCylinder(radius: CGFloat(r), height: CGFloat(h))
        g.radialSegmentCount = seg
        g.materials = [plain(color, rough: rough, metal: metal)]
        let n = SCNNode(geometry: g)
        n.position = SCNVector3(x, y, z)
        return n
    }

    /// Trụ phủ texture (cột gỗ, thân tre...). `tileY` = số mét cho một vòng lặp theo chiều dọc.
    static func tcyl(_ r: Float, _ h: Float, _ t: Tex, tint: UIColor? = nil, tileY: Float = 2,
                     rough: CGFloat = 0.85, x: Float = 0, y: Float = 0, z: Float = 0, seg: Int = 12) -> SCNNode {
        let g = SCNCylinder(radius: CGFloat(r), height: CGFloat(h))
        g.radialSegmentCount = seg
        let circ = 2 * Float.pi * r
        g.materials = [tex(t, tint: tint, rough: rough, rx: rep(circ, 1.6), ry: rep(h, tileY))]
        let n = SCNNode(geometry: g)
        n.position = SCNVector3(x, y, z)
        return n
    }

    static func sphere(_ r: Float, _ material: SCNMaterial, x: Float = 0, y: Float = 0, z: Float = 0,
                       seg: Int = 12) -> SCNNode {
        let g = SCNSphere(radius: CGFloat(r))
        g.segmentCount = seg
        g.materials = [material]
        let n = SCNNode(geometry: g)
        n.position = SCNVector3(x, y, z)
        return n
    }

    /// Thanh tròn nối hai điểm bất kỳ trong không gian (thân dừa, chân cầu, thanh giằng...).
    static func link(_ a: SIMD3<Float>, _ b: SIMD3<Float>, r1: Float, r2: Float,
                     _ material: SCNMaterial, seg: Int = 10) -> SCNNode {
        let d = b - a
        let len = max(simd_length(d), 0.001)
        let g = SCNCone(topRadius: CGFloat(r2), bottomRadius: CGFloat(r1), height: CGFloat(len))
        g.radialSegmentCount = seg
        g.materials = [material]
        let n = SCNNode(geometry: g)
        let mid = (a + b) / 2
        n.position = SCNVector3(mid.x, mid.y, mid.z)
        n.simdOrientation = simd_quatf(from: SIMD3<Float>(0, 1, 0), to: d / len)
        return n
    }

    /// Dải lá cong (cho tàu lá dừa, dừa nước): chạy dọc trục X, rủ xuống ở đầu.
    static func arcStrip(length: Float, width: Float, lift: Float, droop: Float,
                         segs: Int = 8) -> SCNGeometry {
        var verts: [SCNVector3] = []
        var norms: [SCNVector3] = []
        var uvs: [CGPoint] = []
        var idx: [Int32] = []
        let hw = width / 2
        for i in 0...segs {
            let t = Float(i) / Float(segs)
            let x = t * length
            let y = length * (lift * t - droop * t * t)
            let s = lift - 2 * droop * t
            let inv = 1 / (1 + s * s).squareRoot()
            let n = SCNVector3(-s * inv, inv, 0)
            verts.append(SCNVector3(x, y, -hw))
            verts.append(SCNVector3(x, y, hw))
            norms.append(n)
            norms.append(n)
            uvs.append(CGPoint(x: CGFloat(t), y: 0))
            uvs.append(CGPoint(x: CGFloat(t), y: 1))
        }
        for i in 0..<segs {
            let a = Int32(i * 2)
            idx.append(contentsOf: [a, a + 1, a + 2, a + 1, a + 3, a + 2])
        }
        let g = SCNGeometry(sources: [SCNGeometrySource(vertices: verts),
                                      SCNGeometrySource(normals: norms),
                                      SCNGeometrySource(textureCoordinates: uvs)],
                            elements: [SCNGeometryElement(indices: idx, primitiveType: .triangles)])
        return g
    }

    // MARK: Chi tiết nhà: cửa, cửa sổ

    static let glass: SCNMaterial = {
        let m = SCNMaterial()
        m.lightingModel = .physicallyBased
        m.diffuse.contents = rgb(0.22, 0.32, 0.40)
        m.metalness.contents = 0.75
        m.roughness.contents = 0.05
        return m
    }()

    static func glassMat(_ tint: UIColor) -> SCNMaterial {
        plain(tint, rough: 0.05, metal: 0.85)
    }

    /// Cửa sổ nhìn ra hướng +Z, tâm ở gốc, có khung, ô kính, chấn song, bậu cửa, cánh chớp.
    static func window(_ w: Float, _ h: Float, frame: Tex = .woodPaint, frameTint: UIColor? = nil,
                       shutters: Bool = true) -> SCNNode {
        let root = SCNNode()
        let ft: Float = 0.07
        let fc = frameTint ?? rgb(0.95, 0.93, 0.88)
        // ô kính lùi vào trong
        let pane = SCNBox(width: CGFloat(w), height: CGFloat(h), length: 0.04, chamferRadius: 0)
        pane.materials = [glass]
        let pn = SCNNode(geometry: pane)
        pn.position = SCNVector3(0, 0, 0.0)
        root.addChildNode(pn)
        // khung
        root.addChildNode(tbox(w + ft * 2, ft, 0.12, frame, tint: fc, tile: 1, y: h / 2 + ft / 2, z: 0.04))
        root.addChildNode(tbox(w + ft * 2, ft, 0.12, frame, tint: fc, tile: 1, y: -h / 2 - ft / 2, z: 0.04))
        root.addChildNode(tbox(ft, h, 0.12, frame, tint: fc, tile: 1, x: -w / 2 - ft / 2, z: 0.04))
        root.addChildNode(tbox(ft, h, 0.12, frame, tint: fc, tile: 1, x: w / 2 + ft / 2, z: 0.04))
        // chấn song
        root.addChildNode(tbox(0.04, h, 0.06, frame, tint: fc, tile: 1, z: 0.03))
        root.addChildNode(tbox(w, 0.04, 0.06, frame, tint: fc, tile: 1, z: 0.03))
        // bậu cửa
        root.addChildNode(tbox(w + 0.28, 0.06, 0.2, .concrete, tile: 1, y: -h / 2 - ft - 0.03, z: 0.09))
        if shutters {
            for sign in [Float(-1), Float(1)] {
                let sh = tbox(w / 2, h + ft * 2, 0.05, .wood, tint: rgb(0.45, 0.62, 0.55), tile: 1,
                              x: sign * (w / 2 + ft + w / 4), z: 0.06)
                root.addChildNode(sh)
            }
        }
        return root
    }

    /// Cửa đi nhìn ra +Z, đáy ở y=0.
    static func door(_ w: Float, _ h: Float, tint: UIColor? = nil, frameTint: UIColor? = nil) -> SCNNode {
        let root = SCNNode()
        let fc = frameTint ?? rgb(0.35, 0.24, 0.15)
        root.addChildNode(tbox(w, h, 0.06, .woodDark, tint: tint, tile: 1, y: h / 2, z: 0.0))
        root.addChildNode(tbox(w + 0.2, 0.1, 0.12, .woodDark, tint: fc, tile: 1, y: h + 0.05, z: 0.03))
        root.addChildNode(tbox(0.1, h, 0.12, .woodDark, tint: fc, tile: 1, x: -w / 2 - 0.05, y: h / 2, z: 0.03))
        root.addChildNode(tbox(0.1, h, 0.12, .woodDark, tint: fc, tile: 1, x: w / 2 + 0.05, y: h / 2, z: 0.03))
        // tay nắm đồng
        let knob = sphere(0.045, plain(rgb(0.80, 0.62, 0.25), rough: 0.3, metal: 1),
                          x: w * 0.32, y: h * 0.48, z: 0.07, seg: 8)
        root.addChildNode(knob)
        return root
    }

    // MARK: Mái nhà hai dốc

    /// Mái hai dốc chạy dọc trục Z, vân mái chạy ngang theo hướng nóc, có mái đua, nóc, đầu hồi.
    static func gableRoof(halfSpan s: Float, rise r: Float, baseY: Float,
                          zBack: Float, zFront: Float, ovBack: Float, ovFront: Float,
                          roofTex: Tex, roofTint: UIColor?, roofRough: CGFloat = 0.9, roofMetal: CGFloat = 0,
                          thickness: Float = 0.14, tile: Float = 2,
                          gableTex: Tex, gableTint: UIColor?) -> SCNNode {
        let root = SCNNode()
        let hyp = (s * s + r * r).squareRoot()
        let ov: Float = 0.5
        let panelLen = hyp + ov
        let angle = atan2(r, s)
        let zLen = (zFront + ovFront) - (zBack - ovBack)
        let zMid = ((zFront + ovFront) + (zBack - ovBack)) / 2

        let top = tex(roofTex, tint: roofTint, rough: roofRough, metal: roofMetal,
                      rx: rep(zLen, tile), ry: rep(panelLen, tile), swapUV: true)
        let side = tex(roofTex, tint: roofTint, rough: roofRough, metal: roofMetal, rx: 1, ry: 0.25)

        func panel(_ sign: Float) -> SCNNode {
            let g = SCNBox(width: CGFloat(panelLen), height: CGFloat(thickness), length: CGFloat(zLen), chamferRadius: 0)
            g.materials = [side, side, side, side, top, side]
            let n = SCNNode(geometry: g)
            n.position = SCNVector3(sign * s / 2, baseY + r / 2 + thickness / 2, zMid)
            n.eulerAngles.z = -sign * angle
            return n
        }
        root.addChildNode(panel(-1))
        root.addChildNode(panel(1))

        // nóc mái
        let ridge = SCNCylinder(radius: CGFloat(thickness * 1.3 + 0.05), height: CGFloat(zLen + 0.1))
        ridge.radialSegmentCount = 8
        ridge.materials = [tex(roofTex, tint: roofTint, rough: roofRough, metal: roofMetal, rx: rep(zLen, tile), ry: 1)]
        let rn = SCNNode(geometry: ridge)
        rn.position = SCNVector3(0, baseY + r + thickness * 0.75, zMid)
        rn.eulerAngles.x = Float.pi / 2
        root.addChildNode(rn)

        // đầu hồi tam giác (đóng kín phần trên tường)
        let tri = UIBezierPath()
        tri.move(to: CGPoint(x: CGFloat(-s + 0.3), y: 0))
        tri.addLine(to: CGPoint(x: CGFloat(s - 0.3), y: 0))
        tri.addLine(to: CGPoint(x: 0, y: CGFloat(r - 0.1)))
        tri.close()
        for z in [zBack, zFront] {
            let shape = SCNShape(path: tri, extrusionDepth: 0.1)
            shape.materials = [tex(gableTex, tint: gableTint, rough: 0.9, rx: 1.5, ry: 1.5)]
            let n = SCNNode(geometry: shape)
            n.position = SCNVector3(0, baseY, z)
            root.addChildNode(n)
        }
        return root
    }

    // MARK: Nhà ngói (nhà xây)

    static func house(_ variant: Int) -> SCNNode {
        let root = SCNNode()
        let wallTint = wallTints[variant % wallTints.count]
        let tileTint = tileTints[variant % tileTints.count]

        root.addChildNode(tbox(4.8, 0.4, 4.2, .brick, tile: 1.6, y: 0.2))                 // chân móng gạch
        root.addChildNode(tbox(4.4, 2.5, 3.8, .plaster, tint: wallTint, tile: 2.4, y: 1.65)) // tường tô vữa
        // gờ chỉ ngang dưới mái
        root.addChildNode(tbox(4.52, 0.1, 3.92, .plaster, tint: wallTint, tile: 2.4, y: 2.85))

        root.addChildNode(gableRoof(halfSpan: 2.55, rise: 1.65, baseY: 2.9,
                                    zBack: -1.9, zFront: 1.9, ovBack: 0.45, ovFront: 0.55,
                                    roofTex: .roofTile, roofTint: tileTint, roofRough: 0.7, thickness: 0.14,
                                    gableTex: .plaster, gableTint: wallTint))

        // cửa đi + bậc thềm
        let d = door(0.95, 1.8)
        d.position = SCNVector3(0, 0.4, 1.9)
        root.addChildNode(d)
        root.addChildNode(tbox(1.8, 0.2, 0.7, .concrete, tile: 1, y: 0.1, z: 2.3))
        root.addChildNode(tbox(1.4, 0.2, 0.45, .concrete, tile: 1, y: 0.0, z: 2.75))

        // cửa sổ mặt trước
        for sx in [Float(-1.4), Float(1.4)] {
            let w = window(0.9, 1.0)
            w.position = SCNVector3(sx, 1.95, 1.9)
            root.addChildNode(w)
        }
        // cửa sổ hai bên hông
        for sign in [Float(-1), Float(1)] {
            let w = window(0.9, 1.0, shutters: false)
            w.position = SCNVector3(sign * 2.2, 1.95, 0)
            w.eulerAngles.y = sign * Float.pi / 2
            root.addChildNode(w)
        }
        // ống khói gạch
        root.addChildNode(tbox(0.55, 2.2, 0.55, .brick, tile: 1.2, x: 1.25, y: 4.0, z: -0.7))
        root.addChildNode(tbox(0.7, 0.1, 0.7, .concrete, tile: 1, x: 1.25, y: 5.15, z: -0.7))
        return root
    }

    // MARK: Nhà sàn miền Tây

    /// Nhà sàn: cột gỗ tròn, sàn ván, vách ván, mái lá nhiều lớp (hoặc tôn gỉ), hiên có lan can, cầu thang.
    static func stilt(_ variant: Int) -> SCNNode {
        let root = SCNNode()
        let v = variant % 3
        let wallTex: Tex = v == 1 ? .woodDark : .wood
        let wallTint: UIColor? = v == 2 ? rgb(0.88, 0.88, 0.84) : nil
        let floorTop: Float = 1.85

        // cột
        for px in [Float(-1.9), 0, 1.9] {
            for pz in [Float(-1.6), 1.6, 2.9] {
                root.addChildNode(tcyl(0.13, 1.8, .palmBark, tileY: 2.4, x: px, y: 0.9, z: pz, seg: 10))
            }
        }
        // thanh giằng chéo bằng tre
        let bambooMat = tex(.bamboo, tint: rgb(0.9, 0.85, 0.6), rx: 1, ry: 2)
        for sx in [Float(-1.9), 1.9] {
            root.addChildNode(link(SIMD3<Float>(sx, 0.15, 1.6), SIMD3<Float>(sx, 1.55, 2.9),
                                   r1: 0.045, r2: 0.045, bambooMat, seg: 6))
            root.addChildNode(link(SIMD3<Float>(sx, 0.15, 2.9), SIMD3<Float>(sx, 1.55, 1.6),
                                   r1: 0.045, r2: 0.045, bambooMat, seg: 6))
        }
        // sàn ván (ván chạy ngang)
        root.addChildNode(tbox(4.7, 0.16, 5.4, .wood, tint: rgb(0.85, 0.80, 0.72), tile: 1.8, y: 1.77, z: 0.6))
        // dầm
        for px in [Float(-1.9), 0, 1.9] {
            root.addChildNode(tbox(0.16, 0.18, 5.4, .woodDark, tile: 1.5, x: px, y: 1.6, z: 0.6))
        }

        // vách
        root.addChildNode(tbox(4.2, 2.1, 3.6, wallTex, tint: wallTint, tile: 2.1, y: floorTop + 1.05))

        // mái
        let roofTex: Tex = v == 2 ? .tole : .thatch
        let roofTint: UIColor? = v == 1 ? rgb(0.80, 0.74, 0.66) : (v == 2 ? rgb(0.95, 0.85, 0.80) : nil)
        root.addChildNode(gableRoof(halfSpan: 2.75, rise: 1.7, baseY: floorTop + 2.1,
                                    zBack: -1.8, zFront: 1.8, ovBack: 0.55, ovFront: 1.55,
                                    roofTex: roofTex, roofTint: roofTint,
                                    roofRough: v == 2 ? 0.45 : 0.95, roofMetal: v == 2 ? 0.7 : 0,
                                    thickness: v == 2 ? 0.06 : 0.30, tile: v == 2 ? 2 : 1.8,
                                    gableTex: wallTex, gableTint: wallTint))

        // cột hiên chống mái
        for sx in [Float(-2.1), 2.1] {
            root.addChildNode(tcyl(0.1, 2.15, .palmBark, tileY: 2.4, x: sx, y: floorTop + 1.07, z: 3.1, seg: 8))
        }

        // cửa + cửa sổ
        let d = door(0.95, 1.7)
        d.position = SCNVector3(0, floorTop, 1.8)
        root.addChildNode(d)
        for sx in [Float(-1.4), Float(1.4)] {
            let w = window(0.8, 0.8, frame: .woodDark, frameTint: nil, shutters: false)
            w.position = SCNVector3(sx, floorTop + 1.3, 1.8)
            root.addChildNode(w)
        }
        for sign in [Float(-1), Float(1)] {
            let w = window(0.7, 0.8, frame: .woodDark, frameTint: nil, shutters: false)
            w.position = SCNVector3(sign * 2.1, floorTop + 1.3, 0)
            w.eulerAngles.y = sign * Float.pi / 2
            root.addChildNode(w)
        }

        // lan can hiên trước (chừa lối cầu thang) và hai bên
        func railRun(x: Float, z: Float, length: Float, alongX: Bool) {
            let rail = tbox(alongX ? length : 0.07, 0.07, alongX ? 0.07 : length, .woodDark, tile: 1,
                            x: x, y: floorTop + 0.95, z: z)
            root.addChildNode(rail)
            let n = max(Int(length / 0.4), 1)
            for i in 0...n {
                let o = -length / 2 + length * Float(i) / Float(n)
                root.addChildNode(tbox(0.05, 0.9, 0.05, .woodDark, tile: 1,
                                       x: alongX ? x + o : x, y: floorTop + 0.5, z: alongX ? z : z + o))
            }
        }
        railRun(x: -1.5, z: 3.25, length: 1.7, alongX: true)
        railRun(x: 1.5, z: 3.25, length: 1.7, alongX: true)
        railRun(x: -2.3, z: 2.55, length: 1.5, alongX: false)
        railRun(x: 2.3, z: 2.55, length: 1.5, alongX: false)

        // cầu thang
        for i in 0..<4 {
            root.addChildNode(tbox(1.3, 0.1, 0.36, .wood, tile: 1,
                                   y: 0.3 + Float(i) * 0.45, z: 4.9 - Float(i) * 0.4))
        }
        for sx in [Float(-0.7), Float(0.7)] {
            root.addChildNode(link(SIMD3<Float>(sx, 0.1, 5.15), SIMD3<Float>(sx, 1.78, 3.45),
                                   r1: 0.05, r2: 0.05, plain(rgb(0.30, 0.20, 0.12), rough: 0.9), seg: 6))
        }

        // lu nước (chum) cạnh cầu thang
        let clay = plain(rgb(0.55, 0.30, 0.18), rough: 0.6)
        let jar = sphere(0.36, clay, x: -1.6, y: 0.38, z: 4.3, seg: 14)
        jar.scale = SCNVector3(1, 1.1, 1)
        root.addChildNode(jar)
        let neck = SCNCylinder(radius: 0.17, height: 0.14)
        neck.materials = [clay]
        let nn = SCNNode(geometry: neck)
        nn.position = SCNVector3(-1.6, 0.8, 4.3)
        root.addChildNode(nn)
        return root
    }

    // MARK: Nhà tôn vách ván

    static func tole(_ variant: Int) -> SCNNode {
        let root = SCNNode()
        let wallTint = toleWallTints[variant % toleWallTints.count]
        let roofTints: [UIColor] = [rgb(1, 1, 1), rgb(0.95, 0.70, 0.60), rgb(0.70, 0.82, 1.0),
                                    rgb(0.85, 0.85, 0.85), rgb(1.0, 0.90, 0.80)]

        root.addChildNode(tbox(4.8, 0.3, 4.2, .concrete, tile: 2.4, y: 0.15))                  // nền xi măng
        root.addChildNode(tbox(4.4, 0.25, 1.8, .concrete, tile: 2.4, y: 0.15, z: 3.0))         // hiên xi măng
        root.addChildNode(tbox(4.2, 2.3, 3.6, .woodPaint, tint: wallTint, tile: 2.0, y: 1.45)) // vách ván sơn

        root.addChildNode(gableRoof(halfSpan: 2.5, rise: 1.15, baseY: 2.6,
                                    zBack: -1.8, zFront: 1.8, ovBack: 0.45, ovFront: 1.6,
                                    roofTex: .tole, roofTint: roofTints[variant % roofTints.count],
                                    roofRough: 0.45, roofMetal: 0.7, thickness: 0.06, tile: 2,
                                    gableTex: .woodPaint, gableTint: wallTint))

        // cột hiên
        for px in [Float(-2.05), Float(2.05)] {
            root.addChildNode(tcyl(0.08, 2.3, .woodDark, tileY: 2, x: px, y: 1.45, z: 3.3, seg: 8))
        }
        let d = door(0.9, 1.75)
        d.position = SCNVector3(0, 0.3, 1.8)
        root.addChildNode(d)
        for sx in [Float(-1.4), Float(1.4)] {
            let w = window(0.8, 0.8, shutters: true)
            w.position = SCNVector3(sx, 1.75, 1.8)
            root.addChildNode(w)
        }
        let sw = window(0.8, 0.8, shutters: false)
        sw.position = SCNVector3(2.1, 1.75, 0)
        sw.eulerAngles.y = Float.pi / 2
        root.addChildNode(sw)

        // bồn nước inox trên giàn cạnh nhà
        for (lx, lz) in [(Float(-0.3), Float(-0.3)), (0.3, -0.3), (-0.3, 0.3), (0.3, 0.3)] {
            root.addChildNode(cyl(0.05, 1.5, rgb(0.35, 0.35, 0.37), rough: 0.5, metal: 0.8,
                                  x: -3.1 + lx, y: 0.75, z: -1.0 + lz, seg: 6))
        }
        root.addChildNode(box(0.9, 0.08, 0.9, rgb(0.35, 0.35, 0.37), rough: 0.5, metal: 0.8,
                              x: -3.1, y: 1.52, z: -1.0))
        root.addChildNode(cyl(0.42, 1.05, rgb(0.78, 0.80, 0.82), rough: 0.25, metal: 1.0,
                              x: -3.1, y: 2.1, z: -1.0, seg: 20))
        root.addChildNode(sphere(0.42, plain(rgb(0.78, 0.80, 0.82), rough: 0.25, metal: 1.0),
                                 x: -3.1, y: 2.62, z: -1.0, seg: 16))
        return root
    }

    // MARK: Tòa nhà cao tầng

    static func tower(_ variant: Int) -> SCNNode {
        let root = SCNNode()
        let floors = 5 + (variant % 5) * 2          // 5, 7, 9, 11, 13 tầng
        let floorH: Float = 1.2
        let h = Float(floors) * floorH + 0.4
        let body = towerTints[variant % towerTints.count]
        let glassM = glassMat(glassTints[variant % glassTints.count])

        // lõi bê tông
        root.addChildNode(tbox(4.3, h, 4.3, .concrete, tint: body, tile: 2.4, y: h / 2))

        // mặt kính từng tầng + nẹp đứng
        for i in 0..<floors {
            let y = 0.95 + Float(i) * floorH
            let gb = SCNBox(width: 4.4, height: 0.7, length: 4.4, chamferRadius: 0)
            gb.materials = [glassM]
            let gn = SCNNode(geometry: gb)
            gn.position = SCNVector3(0, y, 0)
            root.addChildNode(gn)
            // sàn bê tông nhô ra
            root.addChildNode(tbox(4.6, 0.12, 4.6, .concrete, tint: body, tile: 2.4, y: y - 0.5))
        }
        for k in [Float(-1.6), -0.55, 0.55, 1.6] {
            root.addChildNode(tbox(0.08, h - 0.3, 0.08, .concrete, tint: body, tile: 1, x: k, y: h / 2 + 0.1, z: 2.24))
            root.addChildNode(tbox(0.08, h - 0.3, 0.08, .concrete, tint: body, tile: 1, x: k, y: h / 2 + 0.1, z: -2.24))
            root.addChildNode(tbox(0.08, h - 0.3, 0.08, .concrete, tint: body, tile: 1, x: 2.24, y: h / 2 + 0.1, z: k))
            root.addChildNode(tbox(0.08, h - 0.3, 0.08, .concrete, tint: body, tile: 1, x: -2.24, y: h / 2 + 0.1, z: k))
        }

        // sảnh vào + mái che
        let lobby = SCNBox(width: 2.2, height: 1.3, length: 0.1, chamferRadius: 0)
        lobby.materials = [glassM]
        let ln = SCNNode(geometry: lobby)
        ln.position = SCNVector3(0, 0.65, 2.3)
        root.addChildNode(ln)
        root.addChildNode(tbox(3.0, 0.1, 1.4, .concrete, tint: body, tile: 1.5, y: 1.55, z: 2.8))
        for sx in [Float(-1.4), Float(1.4)] {
            root.addChildNode(cyl(0.05, 1.5, rgb(0.3, 0.3, 0.32), rough: 0.4, metal: 0.8, x: sx, y: 0.75, z: 3.3, seg: 8))
        }

        // mái: lan can, máy lạnh, bồn nước, cột ăng-ten
        root.addChildNode(tbox(4.7, 0.5, 0.15, .concrete, tint: body, tile: 2, y: h + 0.25, z: 2.275))
        root.addChildNode(tbox(4.7, 0.5, 0.15, .concrete, tint: body, tile: 2, y: h + 0.25, z: -2.275))
        root.addChildNode(tbox(0.15, 0.5, 4.4, .concrete, tint: body, tile: 2, x: 2.275, y: h + 0.25))
        root.addChildNode(tbox(0.15, 0.5, 4.4, .concrete, tint: body, tile: 2, x: -2.275, y: h + 0.25))
        root.addChildNode(box(1.0, 0.5, 0.8, rgb(0.78, 0.80, 0.82), rough: 0.4, metal: 0.6, x: -1.2, y: h + 0.4, z: -0.8))
        root.addChildNode(box(0.9, 0.45, 0.7, rgb(0.78, 0.80, 0.82), rough: 0.4, metal: 0.6, x: 0.4, y: h + 0.38, z: -1.3))
        root.addChildNode(cyl(0.5, 0.9, rgb(0.20, 0.25, 0.35), rough: 0.5, metal: 0.3, x: 1.2, y: h + 0.6, z: 0.9, seg: 16))
        root.addChildNode(cyl(0.03, 2.0, rgb(0.5, 0.5, 0.5), rough: 0.4, metal: 0.9, x: -1.4, y: h + 1.4, z: 1.2, seg: 6))
        return root
    }

    // MARK: Cây

    /// Cây tán rộng: thân + cành bằng gỗ có vân, tán là nhiều cụm lá thật chồng nhau.
    static func tree(_ variant: Int, seed: UInt64) -> SCNNode {
        let root = SCNNode()
        var rng = SeededRNG(seed)
        let barkM = tex(.woodDark, tint: rgb(0.85, 0.80, 0.75), rough: 0.95, rx: 1.5, ry: 1)
        let trunkH = rng.f(1.8, 2.4)

        root.addChildNode(link(SIMD3<Float>(0, 0, 0), SIMD3<Float>(0, trunkH, 0), r1: 0.34, r2: 0.2, barkM, seg: 10))
        // bạnh gốc
        for i in 0..<4 {
            let a = Float(i) * Float.pi / 2 + rng.f(-0.3, 0.3)
            root.addChildNode(link(SIMD3<Float>(cos(a) * 0.55, 0.0, sin(a) * 0.55),
                                   SIMD3<Float>(cos(a) * 0.15, 0.7, sin(a) * 0.15),
                                   r1: 0.08, r2: 0.12, barkM, seg: 6))
        }
        // cành
        var tops: [SIMD3<Float>] = []
        for i in 0..<5 {
            let a = Float(i) * 1.26 + rng.f(-0.3, 0.3)
            let reach = rng.f(0.9, 1.5)
            let from = SIMD3<Float>(0, trunkH - rng.f(0, 0.5), 0)
            let to = SIMD3<Float>(cos(a) * reach, trunkH + rng.f(0.6, 1.3), sin(a) * reach)
            root.addChildNode(link(from, to, r1: 0.12, r2: 0.05, barkM, seg: 6))
            tops.append(to)
        }

        let tint = leafTints[variant % leafTints.count]
        let dark = plain(rgb(0.08, 0.20, 0.07), rough: 1)
        let leaf = TextureLibrary.foliageMaterial(.leafMask, tint: tint, repeatX: 3, repeatY: 2)

        root.addChildNode(sphere(1.1, dark, y: trunkH + 1.2, seg: 10))
        var clumpCenters = tops
        clumpCenters.append(SIMD3<Float>(0, trunkH + 1.9, 0))
        clumpCenters.append(SIMD3<Float>(rng.f(-0.6, 0.6), trunkH + 1.2, rng.f(-0.6, 0.6)))
        var clumpIndex = 0
        for c in clumpCenters {
            let r = rng.f(0.85, 1.25)
            let n = sphere(r, leaf, x: c.x, y: c.y + 0.35, z: c.z, seg: 14)
            n.scale = SCNVector3(1, rng.f(0.78, 0.95), 1)
            n.eulerAngles.y = rng.f(0, 6.28)
            root.addChildNode(n)
            clumpIndex += 1
            oscillate(n, x: 0.035, z: 0.03, period: 2.4 + Double(clumpIndex % 3) * 0.5,
                      phase: Double(clumpIndex) * 0.45)
        }
        // hoa (biến thể cuối: cây hoa giấy)
        if variant % 5 == 4 {
            let petal = plain(rgb(0.90, 0.25, 0.50), rough: 0.7)
            for _ in 0..<46 {
                let a = rng.f(0, 6.28)
                let e = rng.f(-0.2, 1.1)
                let rr: Float = 1.75
                let px: Float = cos(a) * cos(e) * rr
                let py: Float = trunkH + 1.4 + sin(e) * rr * 0.8
                let pz: Float = sin(a) * cos(e) * rr
                root.addChildNode(sphere(0.12, petal, x: px, y: py, z: pz, seg: 5))
            }
        }
        return root
    }

    static func pine(_ variant: Int, seed: UInt64) -> SCNNode {
        let root = SCNNode()
        var rng = SeededRNG(seed)
        root.addChildNode(tcyl(0.2, 2.2, .woodDark, tint: rgb(0.8, 0.75, 0.7), tileY: 2, y: 1.1, seg: 8))
        let needle = TextureLibrary.foliageMaterial(.needle, tint: rgb(1.0, 1.05, 1.0), repeatX: 6, repeatY: 2)
        let dark = plain(rgb(0.05, 0.16, 0.08), rough: 1)
        let tiers = 5
        for i in 0..<tiers {
            let t = Float(i) / Float(tiers - 1)
            let radius = 1.7 - t * 1.15 + rng.f(-0.05, 0.05)
            let height: Float = 1.9 - t * 0.5
            let y = 1.5 + Float(i) * 0.95
            let inner = SCNCone(topRadius: 0, bottomRadius: CGFloat(radius * 0.8), height: CGFloat(height))
            inner.radialSegmentCount = 12
            inner.materials = [dark]
            let inn = SCNNode(geometry: inner)
            inn.position = SCNVector3(0, y, 0)
            root.addChildNode(inn)
            let c = SCNCone(topRadius: 0, bottomRadius: CGFloat(radius), height: CGFloat(height))
            c.radialSegmentCount = 14
            c.materials = [needle]
            let cn = SCNNode(geometry: c)
            cn.position = SCNVector3(0, y, 0)
            cn.eulerAngles.y = rng.f(0, 3)
            root.addChildNode(cn)
        }
        return root
    }

    // MARK: Cây dừa

    /// Dừa: thân cong tự nhiên, thon dần, có vòng ngang; tán là các tàu lá lông chim cong rủ; buồng dừa.
    static func coconut(_ variant: Int, seed: UInt64) -> SCNNode {
        let root = SCNNode()
        var rng = SeededRNG(seed)
        let height = rng.f(7.5, 9.5)
        let bend = rng.f(0.6, 1.7)
        let dirAngle = rng.f(0, 6.28)
        let dx = cos(dirAngle), dz = sin(dirAngle)

        func spine(_ t: Float) -> SIMD3<Float> {
            let off = bend * pow(t, 1.7)
            return SIMD3<Float>(dx * off, height * t, dz * off)
        }
        func radius(_ t: Float) -> Float { 0.25 - 0.12 * t }

        // thân (nhiều đốt nối nhau)
        let segs = 14
        for i in 0..<segs {
            let t1 = Float(i) / Float(segs), t2 = Float(i + 1) / Float(segs)
            let p1 = spine(t1), p2 = spine(t2)
            let len = simd_length(p2 - p1)
            let m = tex(.palmBark, tint: rgb(1.0, 0.97, 0.92), rough: 0.95, rx: 2, ry: rep(len, 2.2))
            root.addChildNode(link(p1, p2, r1: radius(t1), r2: radius(t2), m, seg: 12))
        }
        // phần phình ở gốc
        let flare = tcyl(0.34, 0.45, .palmBark, tileY: 2, y: 0.22, seg: 12)
        root.addChildNode(flare)

        let top = spine(1)
        let crown = SCNNode()
        crown.position = SCNVector3(top.x, top.y, top.z)
        root.addChildNode(crown)

        // chùm sợi / bẹ lá ở ngọn
        crown.addChildNode(sphere(0.2, plain(rgb(0.40, 0.33, 0.18), rough: 1), y: 0.0, seg: 8))

        // các tàu lá
        let frondTint = variant == 1 ? rgb(1.15, 1.0, 0.65) : rgb(1.0, 1.0, 1.0)
        let frondM = TextureLibrary.foliageMaterial(.frondMask, tint: frondTint)
        let count = 14
        for i in 0..<count {
            let holder = SCNNode()
            holder.eulerAngles.y = Float(i) * (2 * Float.pi / Float(count)) + rng.f(-0.18, 0.18)
            let pivot = SCNNode()
            pivot.eulerAngles.z = rng.f(0.05, 0.85)                  // góc ngửa lên
            let length = rng.f(4.0, 5.0)
            let geo = arcStrip(length: length, width: length * 0.42,
                               lift: rng.f(0.30, 0.55), droop: rng.f(0.55, 0.95))
            geo.materials = [frondM]
            let leaf = SCNNode(geometry: geo)
            leaf.eulerAngles.x = rng.f(-0.25, 0.25)
            leaf.castsShadow = false
            pivot.addChildNode(leaf)
            holder.addChildNode(pivot)
            crown.addChildNode(holder)
            oscillate(pivot, z: 0.07, period: 2.6 + Double(i % 4) * 0.35, phase: Double(i) * 0.31)
            oscillate(leaf, x: 0.05, period: 1.9 + Double(i % 3) * 0.3, phase: Double(i) * 0.5)
        }
        // lá non mọc thẳng
        for i in 0..<3 {
            let holder = SCNNode()
            holder.eulerAngles.y = Float(i) * 2.1 + rng.f(-0.3, 0.3)
            let pivot = SCNNode()
            pivot.eulerAngles.z = rng.f(1.2, 1.4)
            let geo = arcStrip(length: 2.2, width: 0.7, lift: 0.5, droop: 0.2, segs: 5)
            geo.materials = [TextureLibrary.foliageMaterial(.frondMask, tint: rgb(1.15, 1.2, 0.8))]
            let leaf = SCNNode(geometry: geo)
            leaf.castsShadow = false
            pivot.addChildNode(leaf)
            holder.addChildNode(pivot)
            crown.addChildNode(holder)
        }

        // buồng dừa
        let nutColor = variant == 1 ? rgb(0.45, 0.32, 0.16) : rgb(0.42, 0.58, 0.20)
        let nutM = plain(nutColor, rough: 0.45)
        for i in 0..<6 {
            let a = Float(i) * 1.05 + rng.f(-0.2, 0.2)
            let r: Float = 0.2
            let n = sphere(r, nutM, x: cos(a) * 0.32, y: -0.35 - rng.f(0, 0.18), z: sin(a) * 0.32, seg: 10)
            n.scale = SCNVector3(0.9, 1.1, 0.9)
            crown.addChildNode(n)
        }
        return root
    }

    /// Dừa nước: bụi lá lông chim mọc chụm từ gốc, dựng đứng rồi cong ra ngoài.
    static func nipa(_ variant: Int, seed: UInt64) -> SCNNode {
        let root = SCNNode()
        var rng = SeededRNG(seed)
        let m = TextureLibrary.foliageMaterial(.nipaMask, tint: rgb(1.0, 1.05, 0.9))
        let count = 12
        for i in 0..<count {
            let holder = SCNNode()
            holder.eulerAngles.y = Float(i) * (2 * Float.pi / Float(count)) + rng.f(-0.25, 0.25)
            let pivot = SCNNode()
            pivot.eulerAngles.z = rng.f(0.75, 1.2)
            let length = rng.f(3.4, 4.6)
            let geo = arcStrip(length: length, width: length * 0.30, lift: rng.f(0.55, 0.8),
                               droop: rng.f(0.45, 0.8))
            geo.materials = [m]
            let leaf = SCNNode(geometry: geo)
            leaf.castsShadow = false
            leaf.eulerAngles.x = rng.f(-0.15, 0.15)
            pivot.addChildNode(leaf)
            holder.addChildNode(pivot)
            root.addChildNode(holder)
            oscillate(pivot, z: 0.06, period: 2.2 + Double(i % 3) * 0.3, phase: Double(i) * 0.27)
        }
        // gốc bẹ lá
        root.addChildNode(sphere(0.35, plain(rgb(0.25, 0.30, 0.12), rough: 1), y: 0.15, seg: 8))
        return root
    }

    /// Bụi cỏ: nhiều mặt phẳng cắt chéo mang ảnh cỏ có nền trong suốt.
    static func grass(_ variant: Int, seed: UInt64) -> SCNNode {
        let root = SCNNode()
        var rng = SeededRNG(seed)
        let tints: [UIColor] = [rgb(1.0, 1.0, 1.0), rgb(1.35, 1.2, 0.6), rgb(0.7, 0.9, 0.7)]
        let m = TextureLibrary.foliageMaterial(.grassTuft, tint: tints[variant % tints.count])
        for clump in 0..<4 {
            let cx = rng.f(-0.7, 0.7), cz = rng.f(-0.7, 0.7)
            let size = rng.f(1.0, 1.5)
            for k in 0..<3 {
                let plane = SCNPlane(width: CGFloat(size), height: CGFloat(size * 0.85))
                plane.materials = [m]
                let n = SCNNode(geometry: plane)
                n.position = SCNVector3(cx, size * 0.85 / 2, cz)
                n.eulerAngles.y = Float(k) * Float.pi / 3 + rng.f(0, 1) + Float(clump)
                n.castsShadow = false
                root.addChildNode(n)
            }
        }
        return root
    }

    // MARK: Xuồng

    static func boat(_ variant: Int) -> SCNNode {
        let root = SCNNode()
        let hullTint = boatTints[variant % boatTints.count]

        func outline(_ half: CGFloat, _ wide: CGFloat) -> UIBezierPath {
            let p = UIBezierPath()
            p.move(to: CGPoint(x: -half, y: 0))
            p.addCurve(to: CGPoint(x: half, y: 0),
                       controlPoint1: CGPoint(x: -half * 0.5, y: wide * 1.35),
                       controlPoint2: CGPoint(x: half * 0.5, y: wide * 1.35))
            p.addCurve(to: CGPoint(x: -half, y: 0),
                       controlPoint1: CGPoint(x: half * 0.5, y: -wide * 1.35),
                       controlPoint2: CGPoint(x: -half * 0.5, y: -wide * 1.35))
            p.close()
            return p
        }
        // thân xuồng (đùn khối từ hình dáng nhìn từ trên xuống)
        let hullShape = SCNShape(path: outline(1.75, 0.5), extrusionDepth: 0.45)
        let hm = tex(.woodPaint, tint: hullTint, rough: 0.55, rx: 2, ry: 1)
        hullShape.materials = [hm, hm, hm, hm]
        let hull = SCNNode(geometry: hullShape)
        hull.eulerAngles.x = -Float.pi / 2
        hull.position = SCNVector3(0, 0.3, 0)
        root.addChildNode(hull)

        // lòng xuồng (gỗ tối bên trong)
        let inner = SCNShape(path: outline(1.6, 0.42), extrusionDepth: 0.04)
        inner.materials = [tex(.woodDark, rough: 0.9, rx: 2, ry: 1)]
        let inn = SCNNode(geometry: inner)
        inn.eulerAngles.x = -Float.pi / 2
        inn.position = SCNVector3(0, 0.53, 0)
        root.addChildNode(inn)

        // mũi và lái vểnh lên
        let wood = tex(.woodPaint, tint: hullTint, rough: 0.55, rx: 1, ry: 1)
        for sign in [Float(-1), Float(1)] {
            root.addChildNode(link(SIMD3<Float>(sign * 1.65, 0.45, 0), SIMD3<Float>(sign * 1.98, 0.85, 0),
                                   r1: 0.09, r2: 0.05, wood, seg: 8))
        }
        // ván ngồi
        for px in [Float(-0.9), 0.1, 1.0] {
            root.addChildNode(tbox(0.22, 0.05, 1.0, .wood, tile: 1, x: px, y: 0.58))
        }
        // mui che bằng lá
        let thatchPos: Float = 0.3
        for px in [Float(-0.6), 1.2] {
            for pz in [Float(-0.42), 0.42] {
                root.addChildNode(tcyl(0.035, 0.85, .bamboo, tint: bambooGreen, tileY: 1, x: px, y: 1.0, z: pz, seg: 6))
            }
        }
        let canopy = gableRoof(halfSpan: 0.8, rise: 0.4, baseY: 1.35, zBack: -1.0, zFront: 1.0,
                               ovBack: 0.15, ovFront: 0.15, roofTex: .thatch, roofTint: nil,
                               roofRough: 0.95, thickness: 0.1, tile: 1.4,
                               gableTex: .thatch, gableTint: nil)
        canopy.eulerAngles.y = Float.pi / 2
        canopy.position = SCNVector3(thatchPos, 0, 0)
        root.addChildNode(canopy)

        // mái chèo gác bên mạn
        let oar = tbox(1.5, 0.03, 0.09, .wood, tile: 1, x: -0.5, y: 0.7, z: 0.55)
        oar.eulerAngles.y = 0.12
        root.addChildNode(oar)
        root.addChildNode(tbox(0.4, 0.03, 0.2, .wood, tile: 1, x: 0.3, y: 0.7, z: 0.62))
        return root
    }

    // MARK: Đường, kênh, cầu (nối giữa 2 điểm)

    private static func lineRoot(from a: SIMD2<Float>, to b: SIMD2<Float>) -> (SCNNode, Float) {
        let dx = b.x - a.x
        let dz = b.y - a.y
        let len = max((dx * dx + dz * dz).squareRoot(), 0.5)
        let root = SCNNode()
        root.position = SCNVector3((a.x + b.x) / 2, 0, (a.y + b.y) / 2)
        root.eulerAngles.y = atan2(-dz, dx)
        return (root, len)
    }

    static func road(from a: SIMD2<Float>, to b: SIMD2<Float>, variant: Int) -> SCNNode {
        let (root, len) = lineRoot(from: a, to: b)
        let v = variant % 3                       // 0 nhựa, 1 bê tông, 2 đường đất
        let width: Float = v == 0 ? 3.2 : (v == 1 ? 2.4 : 2.6)
        let t: Tex = v == 0 ? .asphalt : (v == 1 ? .concrete : .dirt)
        let h: Float = v == 2 ? 0.06 : 0.1
        let rough: CGFloat = v == 0 ? 0.9 : 0.95

        let g = SCNBox(width: CGFloat(len), height: CGFloat(h), length: CGFloat(width), chamferRadius: 0)
        let topM = tex(t, rough: rough, rx: rep(len, 4), ry: rep(width, 4))
        let sideM = tex(t, rough: rough, rx: 1, ry: 0.1)
        g.materials = [sideM, sideM, sideM, sideM, topM, sideM]
        let bn = SCNNode(geometry: g)
        bn.position = SCNVector3(0, h / 2, 0)
        root.addChildNode(bn)

        // đầu tròn hai đầu đoạn
        for sign in [Float(-1), Float(1)] {
            let c = SCNCylinder(radius: CGFloat(width / 2), height: CGFloat(h))
            c.radialSegmentCount = 20
            c.materials = [topM, topM, sideM]
            let cn = SCNNode(geometry: c)
            cn.position = SCNVector3(sign * len / 2, h / 2, 0)
            root.addChildNode(cn)
        }

        if v == 0 {
            // vạch kẻ đường: vạch đứt giữa, vạch liền hai mép
            let paint = plain(rgb(0.95, 0.80, 0.25), rough: 0.7)
            let white = plain(rgb(0.92, 0.92, 0.90), rough: 0.7)
            let dash: Float = 1.2, gap: Float = 1.0
            var x = -len / 2 + 0.4
            while x + dash < len / 2 - 0.3 {
                let d = SCNBox(width: CGFloat(dash), height: 0.006, length: 0.12, chamferRadius: 0)
                d.materials = [paint]
                let dn = SCNNode(geometry: d)
                dn.position = SCNVector3(x + dash / 2, h + 0.003, 0)
                root.addChildNode(dn)
                x += dash + gap
            }
            for sign in [Float(-1), Float(1)] {
                let e = SCNBox(width: CGFloat(len - 0.6), height: 0.006, length: 0.08, chamferRadius: 0)
                e.materials = [white]
                let en = SCNNode(geometry: e)
                en.position = SCNVector3(0, h + 0.003, sign * (width / 2 - 0.2))
                root.addChildNode(en)
            }
        }
        if v == 2 {
            // vệt bánh xe + mép cỏ hai bên
            let rut = plain(rgb(0.28, 0.20, 0.13), rough: 1)
            for sign in [Float(-1), Float(1)] {
                let r = SCNBox(width: CGFloat(len - 0.2), height: 0.004, length: 0.4, chamferRadius: 0)
                r.materials = [rut]
                let rn = SCNNode(geometry: r)
                rn.position = SCNVector3(0, h + 0.002, sign * 0.55)
                root.addChildNode(rn)
                root.addChildNode(tbox(len, 0.07, 0.55, .grass, tile: 2, y: 0.035, z: sign * (width / 2 + 0.1)))
            }
        }
        return root
    }

    /// Kênh nước: mặt nước có sóng gợn chuyển động chậm, hai bờ đất cỏ (0) hoặc kè gạch (1).
    static func canal(from a: SIMD2<Float>, to b: SIMD2<Float>, variant: Int) -> SCNNode {
        let (root, len) = lineRoot(from: a, to: b)
        let brick = variant % 2 == 1

        // nước (vật liệu riêng để chạy hiệu ứng sóng)
        let wm = SCNMaterial()
        wm.lightingModel = .physicallyBased
        wm.diffuse.contents = TextureLibrary.albedo(.water)
        wm.roughness.contents = 0.12
        wm.metalness.contents = 0.1
        if let n = TextureLibrary.normal(.water) {
            wm.normal.contents = n
            wm.normal.intensity = 1.1
        }
        let rx = rep(len, 3), ry: Float = 1.5
        for p in [wm.diffuse, wm.normal] {
            p.wrapS = .repeat
            p.wrapT = .repeat
            p.mipFilter = .linear
            p.contentsTransform = SCNMatrix4MakeScale(rx, ry, 1)
        }
        let wg = SCNBox(width: CGFloat(len), height: 0.05, length: 4.0, chamferRadius: 0)
        wg.materials = [wm]
        let wn = SCNNode(geometry: wg)
        wn.position = SCNVector3(0, 0.12, 0)
        // Dòng chảy: màu nước trôi chậm, nếp gợn trôi nhanh hơn và lắc nhẹ ngang
        // → hai lớp lệch tốc độ tạo cảm giác nước đang chảy. Chu kỳ lấy số nguyên ô nên lặp liền mạch.
        let period: Double = 12
        let flow = SCNAction.customAction(duration: period) { _, t in
            let u = Float(t / period)
            var a = SCNMatrix4MakeScale(rx, ry, 1)
            a.m41 = -u
            var b = SCNMatrix4MakeScale(rx, ry, 1)
            b.m41 = -2 * u
            b.m42 = 0.12 * sin(2 * Float.pi * u)
            wm.diffuse.contentsTransform = a
            wm.normal.contentsTransform = b
        }
        wn.runAction(SCNAction.repeatForever(flow))
        root.addChildNode(wn)
        root.addChildNode(tbox(len, 0.1, 4.2, .dirt, tint: rgb(0.7, 0.62, 0.55), tile: 3, y: 0.02))   // đáy kênh

        for sign in [Float(-1), Float(1)] {
            if brick {
                // kè gạch + gờ bê tông
                root.addChildNode(tbox(len, 0.5, 0.35, .brick, tile: 1.4, y: 0.25, z: sign * 2.18))
                root.addChildNode(tbox(len, 0.07, 0.55, .concrete, tile: 1.4, y: 0.53, z: sign * 2.18))
                root.addChildNode(tbox(len, 0.06, 0.9, .grass, tile: 2, y: 0.03, z: sign * 2.85))
            } else {
                // bờ đất dốc phủ cỏ
                let bank = tbox(len, 0.5, 1.3, .dirt, tile: 2, y: 0.12, z: sign * 2.45)
                bank.eulerAngles.x = sign * 0.38
                root.addChildNode(bank)
                root.addChildNode(tbox(len, 0.09, 0.8, .grass, tile: 2, y: 0.34, z: sign * 2.85))
            }
        }
        return root
    }

    /// Cầu khỉ: thân tre ghép sát, tay vịn tre một bên, chân chữ X cắm xuống bờ.
    static func bridge(from a: SIMD2<Float>, to b: SIMD2<Float>) -> SCNNode {
        let (root, len) = lineRoot(from: a, to: b)
        let bm = tex(.bamboo, tint: rgb(0.95, 0.90, 0.65), rough: 0.7, rx: 1, ry: max(len / 1.6, 1))

        // mặt cầu: các thân tre nằm ngang ghép sát nhau
        for k in 0..<4 {
            let r = SCNCylinder(radius: 0.075, height: CGFloat(len))
            r.radialSegmentCount = 8
            r.materials = [bm]
            let rn = SCNNode(geometry: r)
            rn.position = SCNVector3(0, 0.95, -0.22 + Float(k) * 0.15)
            rn.eulerAngles.z = Float.pi / 2
            root.addChildNode(rn)
        }
        // tay vịn
        let rail = SCNCylinder(radius: 0.045, height: CGFloat(len))
        rail.radialSegmentCount = 6
        rail.materials = [bm]
        let rln = SCNNode(geometry: rail)
        rln.position = SCNVector3(0, 1.95, 0.42)
        rln.eulerAngles.z = Float.pi / 2
        root.addChildNode(rln)

        let n = max(Int(len / 2), 1)
        for i in 0...n {
            let x = -len / 2 + len * Float(i) / Float(n)
            // chân chữ X
            root.addChildNode(link(SIMD3<Float>(x - 0.45, 0.0, 0.0), SIMD3<Float>(x + 0.05, 0.9, 0.0),
                                   r1: 0.07, r2: 0.06, bm, seg: 6))
            root.addChildNode(link(SIMD3<Float>(x + 0.45, 0.0, 0.0), SIMD3<Float>(x - 0.05, 0.9, 0.0),
                                   r1: 0.07, r2: 0.06, bm, seg: 6))
            // cột tay vịn
            root.addChildNode(link(SIMD3<Float>(x, 0.9, 0.4), SIMD3<Float>(x, 1.95, 0.42),
                                   r1: 0.05, r2: 0.045, bm, seg: 6))
        }
        return root
    }

    // MARK: Mô hình nhập từ ngoài

    /// Định dạng SceneKit đọc được, theo thứ tự ưu tiên khi một gói có nhiều file.
    static let modelExtensions = ["usdz", "usd", "usda", "usdc", "scn", "dae", "obj"]

    static var modelsDirectory: URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let dir = docs.appendingPathComponent("Models", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }

    private static var modelCache: [String: SCNNode] = [:]
    private static var modelForwardX: [String: Bool] = [:]   // trục dài của mô hình (hướng đi của con vật)

    /// Tìm file mô hình chính trong một thư mục (kể cả thư mục con).
    static func findMainModel(in dir: URL) -> URL? {
        guard let en = FileManager.default.enumerator(at: dir, includingPropertiesForKeys: nil) else { return nil }
        var best: (rank: Int, url: URL)? = nil
        for case let u as URL in en {
            if u.path.contains("__MACOSX") || u.lastPathComponent.hasPrefix(".") { continue }
            guard let r = modelExtensions.firstIndex(of: u.pathExtension.lowercased()) else { continue }
            if best == nil || r < best!.rank { best = (r, u) }
        }
        return best?.url
    }

    /// Mục trong thư viện là một file lẻ hoặc một thư mục (gói gồm .obj + .mtl + ảnh).
    static func mainModelURL(for name: String) -> URL? {
        let url = modelsDirectory.appendingPathComponent(name)
        var isDir: ObjCBool = false
        guard FileManager.default.fileExists(atPath: url.path, isDirectory: &isDir) else { return nil }
        return isDir.boolValue ? findMainModel(in: url) : url
    }

    static func canLoadModel(at url: URL) -> Bool {
        (try? SCNScene(url: url, options: nil)) != nil
    }

    static func forgetModel(_ name: String) {
        modelCache[name] = nil
    }

    private static func isPlainWhite(_ c: Any?) -> Bool {
        guard let col = c as? UIColor else { return false }
        var r: CGFloat = 0, g: CGFloat = 0, bl: CGFloat = 0, a: CGFloat = 0
        guard col.getRed(&r, green: &g, blue: &bl, alpha: &a) else { return false }
        return r > 0.97 && g > 0.97 && bl > 0.97
    }

    /// Nạp mô hình, đặt chân xuống mặt đất, căn giữa và đổi về đơn vị mét của cảnh.
    static func modelNode(_ name: String?) -> SCNNode {
        guard let name = name else { return modelPlaceholder() }
        if let cached = modelCache[name] { return cached.clone() }

        guard let url = mainModelURL(for: name),
              let scene = try? SCNScene(url: url, options: nil) else { return modelPlaceholder() }

        let content = SCNNode()
        for c in scene.rootNode.childNodes { content.addChildNode(c) }

        // vật liệu chưa có màu / texture (OBJ không kèm .mtl) → màu xám ấm để thấy được khối
        content.enumerateHierarchy { node, _ in
            guard let g = node.geometry else { return }
            for m in g.materials where m.diffuse.contents == nil || isPlainWhite(m.diffuse.contents) {
                m.diffuse.contents = rgb(0.78, 0.76, 0.72)
            }
        }

        let (lo, hi) = content.boundingBox
        let sx = hi.x - lo.x, sy = hi.y - lo.y, sz = hi.z - lo.z
        let biggest = max(sx, max(sy, sz))
        guard biggest.isFinite, biggest > 0.0001 else { return modelPlaceholder() }

        // Đoán đơn vị: 0,3–30 → mét; 30–3000 → cm (Sweet Home 3D, SketchUp…); còn lại co về 6 m.
        var s: Float
        if biggest >= 0.3 && biggest <= 30 {
            s = 1
        } else if biggest > 30 && biggest <= 3000 {
            s = 0.01
        } else {
            s = 6 / biggest
        }
        // quá nhỏ (< 0,5 m) thì phóng lên để còn thấy được
        if biggest * s < 0.5 { s = 0.5 / biggest }

        content.scale = SCNVector3(s, s, s)
        content.position = SCNVector3(-(lo.x + hi.x) / 2 * s, -lo.y * s, -(lo.z + hi.z) / 2 * s)

        modelForwardX[name] = sx >= sz

        let wrapper = SCNNode()
        wrapper.addChildNode(content)

        // Mô hình có sẵn hoạt ảnh (xương, đi, chạy…): dựng lại từng bản, không dùng bản sao, và cho chạy.
        var animated = false
        wrapper.enumerateHierarchy { node, _ in
            if !node.animationKeys.isEmpty { animated = true }
        }
        if animated {
            wrapper.enumerateHierarchy { node, _ in
                for key in node.animationKeys { node.animationPlayer(forKey: key)?.play() }
            }
            return wrapper
        }
        modelCache[name] = wrapper
        return wrapper.clone()
    }

    /// Hiện tạm một khối xám khi file mô hình bị mất hoặc hỏng.
    private static func modelPlaceholder() -> SCNNode {
        let root = SCNNode()
        root.addChildNode(box(2, 2, 2, rgb(0.6, 0.6, 0.65), rough: 0.9, y: 1))
        return root
    }

    // MARK: Chuyển động cho mô hình nhập

    static let motionTitles = ["Đứng yên", "Đung đưa", "Lá lay", "Nhún", "Đi vòng"]

    /// Lá lay: uốn đỉnh mô hình theo gió bằng shader, dùng được cho mô hình chỉ là một khối lưới.
    private static let leafShader = """
    #pragma arguments
    float amp;
    float lowY;
    float top;
    #pragma body
    float h = clamp((_geometry.position.y - lowY) / top, 0.0, 1.0);
    float t = scn_frame.time;
    float px = _geometry.position.x / top * 3.0;
    float pz = _geometry.position.z / top * 3.0;
    _geometry.position.x += sin(t * 1.8 + px + pz) * amp * h * h;
    _geometry.position.z += sin(t * 1.3 + pz * 1.5 + 1.7) * amp * 0.6 * h * h;
    """

    static func leafSway(_ n: SCNNode) {
        n.enumerateHierarchy { node, _ in
            guard let g0 = node.geometry, let g = g0.copy() as? SCNGeometry else { return }
            let (lo, hi) = node.boundingBox
            let top = max(hi.y - lo.y, 0.001)
            g.materials = g.materials.map { ($0.copy() as? SCNMaterial) ?? $0 }
            for m in g.materials {
                m.shaderModifiers = [SCNShaderModifierEntryPoint.geometry: leafShader]
                m.setValue(NSNumber(value: top * 0.05), forKey: "amp")
                m.setValue(NSNumber(value: lo.y), forKey: "lowY")
                m.setValue(NSNumber(value: top), forKey: "top")
            }
            node.geometry = g
        }
    }

    /// Đi vòng quanh điểm đặt, đầu hướng theo đường đi, bước chân nhún nhẹ.
    static func walkWrap(_ n: SCNNode, item: Item) {
        let body = SCNNode()
        for c in n.childNodes { body.addChildNode(c) }
        n.addChildNode(body)
        let sc = max(item.scale, 0.2)
        let radius: Float = 3.0 / sc
        let bob: Float = 0.05 / sc
        let period: Float = 26
        let alongX = modelForwardX[item.model ?? ""] ?? true
        let base: Float = (alongX ? -Float.pi / 2 : 0) + ((item.motionFlip ?? false) ? Float.pi : 0)
        let loop = SCNAction.customAction(duration: TimeInterval(period)) { node, t in
            let th = Float(t) / period * 2 * Float.pi
            node.position = SCNVector3(radius * (cos(th) - 1), bob * abs(sin(th * 14)), radius * sin(th))
            node.eulerAngles.y = -th + base
        }
        body.runAction(SCNAction.repeatForever(loop))
    }

    static func motionWrap(_ n: SCNNode, item: Item, seed: UInt64) {
        switch item.motion ?? 0 {
        case 1: windWrap(n, rot: item.rot, amp: 0.03, period: 3.6, seed: seed)
        case 2: leafSway(n)
        case 3: bobWrap(n, seed: seed)
        case 4: walkWrap(n, item: item)
        default: break
        }
    }

    // MARK: Gió & chuyển động

    /// Dao động qua lại quanh vị trí hiện tại (sin mượt, dừng nhẹ ở hai đầu biên độ).
    static func oscillate(_ n: SCNNode, x: Float = 0, z: Float = 0, period: Double, phase: Double) {
        let half = period / 2
        let fwd = SCNAction.rotateBy(x: CGFloat(2 * x), y: 0, z: CGFloat(2 * z), duration: half)
        let bwd = SCNAction.rotateBy(x: CGFloat(-2 * x), y: 0, z: CGFloat(-2 * z), duration: half)
        fwd.timingMode = .easeInEaseOut
        bwd.timingMode = .easeInEaseOut
        n.runAction(SCNAction.sequence([
            SCNAction.rotateBy(x: CGFloat(-x), y: 0, z: CGFloat(-z), duration: 0),
            SCNAction.wait(duration: phase),
            SCNAction.repeatForever(SCNAction.sequence([fwd, bwd]))
        ]))
    }

    /// Gió thổi theo một hướng chung trên cả khu: nghiêng thân cây qua lại, ngả theo hướng gió.
    static func windWrap(_ n: SCNNode, rot: Float, amp: Float, period: Double, seed: UInt64) {
        let body = SCNNode()
        for c in n.childNodes { body.addChildNode(c) }
        n.addChildNode(body)
        let wx: Float = 0.87, wz: Float = 0.5                       // hướng gió (thế giới)
        let dx = wx * cos(rot) - wz * sin(rot)                      // đổi sang hệ tọa độ của vật
        let dz = wx * sin(rot) + wz * cos(rot)
        let phase = Double(seed % 1000) / 1000 * period
        oscillate(body, x: dz * amp, z: -dx * amp, period: period, phase: phase)
    }

    /// Xuồng nhấp nhô theo sóng.
    static func bobWrap(_ n: SCNNode, seed: UInt64) {
        let body = SCNNode()
        for c in n.childNodes { body.addChildNode(c) }
        n.addChildNode(body)
        let up = SCNAction.moveBy(x: 0, y: 0.05, z: 0, duration: 1.6)
        up.timingMode = .easeInEaseOut
        let phase = Double(seed % 1000) / 1000 * 3
        body.runAction(SCNAction.sequence([
            SCNAction.wait(duration: phase),
            SCNAction.repeatForever(SCNAction.sequence([up, up.reversed()]))
        ]))
        oscillate(body, x: 0.02, z: 0.03, period: 3.4, phase: phase)
    }

    // MARK: Tạo node từ Item

    private static func seed(for item: Item) -> UInt64 {
        var h: UInt64 = 1469598103934665603
        let u = item.id.uuid
        let bytes = [u.0, u.1, u.2, u.3, u.4, u.5, u.6, u.7, u.8, u.9, u.10, u.11, u.12, u.13, u.14, u.15]
        for b in bytes { h = (h ^ UInt64(b)) &* 1099511628211 }
        return h
    }

    static func node(for item: Item) -> SCNNode {
        let n: SCNNode
        let sd = seed(for: item)
        switch item.kind {
        case .house:   n = house(item.colorIndex)
        case .tower:   n = tower(item.colorIndex)
        case .tree:    n = tree(item.colorIndex, seed: sd)
        case .pine:    n = pine(item.colorIndex, seed: sd)
        case .stilt:   n = stilt(item.colorIndex)
        case .tole:    n = tole(item.colorIndex)
        case .coconut: n = coconut(item.colorIndex, seed: sd)
        case .nipa:    n = nipa(item.colorIndex, seed: sd)
        case .boat:    n = boat(item.colorIndex)
        case .grass:   n = grass(item.colorIndex, seed: sd)
        case .model:   n = modelNode(item.model)
        case .road, .canal, .bridge:
            let a = SIMD2<Float>(item.x, item.z)
            let b = SIMD2<Float>(item.x2, item.z2)
            let r: SCNNode
            switch item.kind {
            case .road:  r = road(from: a, to: b, variant: item.colorIndex)
            case .canal: r = canal(from: a, to: b, variant: item.colorIndex)
            default:     r = bridge(from: a, to: b)
            }
            r.name = item.id.uuidString
            return r
        }
        switch item.kind {
        case .tree:    windWrap(n, rot: item.rot, amp: 0.018, period: 4.2, seed: sd)
        case .pine:    windWrap(n, rot: item.rot, amp: 0.014, period: 4.8, seed: sd)
        case .coconut: windWrap(n, rot: item.rot, amp: 0.022, period: 5.0, seed: sd)
        case .nipa:    windWrap(n, rot: item.rot, amp: 0.035, period: 3.2, seed: sd)
        case .grass:   windWrap(n, rot: item.rot, amp: 0.07, period: 2.4, seed: sd)
        case .boat:    bobWrap(n, seed: sd)
        case .model:   motionWrap(n, item: item, seed: sd)
        default: break
        }
        n.position = SCNVector3(item.x, 0, item.z)
        n.eulerAngles.y = item.rot
        n.scale = SCNVector3(item.scale, item.scale, item.scale)
        n.name = item.id.uuidString
        return n
    }
}
