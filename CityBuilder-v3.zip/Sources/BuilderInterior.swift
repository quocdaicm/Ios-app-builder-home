import SceneKit
import UIKit

// MARK: - Vách rỗng và khung cửa để đi vào trong nhà
// Ba loại nhà (nhà ngói, nhà sàn, nhà tôn) dùng chung hai hàm này: vách dựng từ các tấm riêng, mặt trước (+Z)
// chừa lối cửa mở. Nhóm vách được đặt tên "walls|x0,x1,z0,z1,y0,y1" (vùng bên trong, tọa độ của nhà) và mái
// đặt tên "roof" để chế độ đi dạo biết khi nào nhân vật đang ở trong nhà (làm mờ vách + mái, bật đèn).

extension Builder {
    static let wallsPrefix = "walls|"

    /// Vách bao bốn phía dày `t`, tâm ở gốc, đáy ở `baseY`, kích thước ngoài `w` (X) × `l` (Z), cao `h`.
    /// Mặt trước (+Z) chừa cửa rộng `doorW`, cao `doorH`, lệch `doorX`; phía trên cửa có thanh lanh tô.
    static func hollowWalls(w: Float, l: Float, h: Float, baseY: Float, t: Float = 0.2,
                            doorW: Float = 1.2, doorH: Float, doorX: Float = 0,
                            tex: Tex, tint: UIColor?, tile: Float,
                            rough: CGFloat = 0.85, metal: CGFloat = 0, named: Bool = true) -> SCNNode {
        let root = SCNNode()
        let a = w / 2 - t                  // nửa bề rộng bên trong
        let zEdge = l / 2 - t / 2          // tâm vách trước / sau theo Z

        func add(_ bw: Float, _ bh: Float, _ bl: Float, _ x: Float, _ y: Float, _ z: Float) {
            guard bw > 0.001, bh > 0.001, bl > 0.001 else { return }
            root.addChildNode(tbox(bw, bh, bl, tex, tint: tint, rough: rough, metal: metal, tile: tile,
                                   x: x, y: y, z: z))
        }
        // hai vách hông (suốt chiều sâu nhà)
        add(t, h, l, -(w / 2 - t / 2), baseY + h / 2, 0)
        add(t, h, l, w / 2 - t / 2, baseY + h / 2, 0)
        // vách sau
        add(w - 2 * t, h, t, 0, baseY + h / 2, -zEdge)
        // vách trước: hai mảng hai bên cửa + lanh tô phía trên
        let dl = doorX - doorW / 2
        let dr = doorX + doorW / 2
        add(dl + a, h, t, (dl - a) / 2, baseY + h / 2, zEdge)
        add(a - dr, h, t, (dr + a) / 2, baseY + h / 2, zEdge)
        add(doorW, h - doorH, t, doorX, baseY + doorH + (h - doorH) / 2, zEdge)

        if named {
            let z0 = -(l / 2 - t)
            let z1 = l / 2 - t
            root.name = wallsPrefix + String(format: "%.2f,%.2f,%.2f,%.2f,%.2f,%.2f",
                                             -a, a, z0, z1, baseY, baseY + h)
        }
        return root
    }

    /// Khung cửa không cánh: đáy ở y = 0, mặt ngoài vách ở z = 0, vách dày `depth` nằm ở phía -Z.
    /// Hai thanh đứng nằm gọn trong lối cửa (rộng `w`), thanh ngang chỉ ốp mặt ngoài nên không thấp trần lối đi.
    static func doorway(w: Float, h: Float, depth: Float, tex: Tex = .woodDark, tint: UIColor? = nil) -> SCNNode {
        let root = SCNNode()
        let jamb: Float = 0.07
        for sign in [Float(-1), Float(1)] {
            root.addChildNode(tbox(jamb, h, depth + 0.06, tex, tint: tint, tile: 1,
                                   x: sign * (w / 2 - jamb / 2), y: h / 2, z: -depth / 2 + 0.03))
        }
        root.addChildNode(tbox(w + 0.24, 0.1, 0.07, tex, tint: tint, tile: 1, y: h + 0.05, z: 0.035))
        return root
    }

    /// Đọc vùng bên trong từ tên nhóm vách ("walls|x0,x1,z0,z1,y0,y1").
    static func interiorBounds(of walls: SCNNode) -> (x0: Float, x1: Float, z0: Float, z1: Float, y0: Float, y1: Float)? {
        guard let name = walls.name, name.hasPrefix(wallsPrefix) else { return nil }
        let v = name.dropFirst(wallsPrefix.count).split(separator: ",").compactMap { Float($0) }
        guard v.count == 6 else { return nil }
        return (v[0], v[1], v[2], v[3], v[4], v[5])
    }
}
