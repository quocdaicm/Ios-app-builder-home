import SceneKit
import UIKit

// MARK: - Cảnh xa ở chân trời: làng mạc, hàng dừa, rặng cây

extension Builder {
    /// Cảnh xa quanh vùng làm việc (ngoài giới hạn kéo camera) để chân trời không bị trống:
    /// lớp gần dùng chính mô hình trong app (đường nhựa, kênh, cầu, nhà, dừa, cây trái), lớp giữa là nhà
    /// và cây dựng đơn giản, ngoài cùng là rặng cây mờ như đồi. Gộp thành vài khối lớn cho nhẹ.
    /// Không nằm trong dự án, không xuất file. Phải gọi sau khi texture đã nạp xong.
    static func horizonNode() -> SCNNode {
        var rng = SeededRNG(20261015)
        func mat(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat) -> SCNMaterial {
            let m = SCNMaterial()
            m.lightingModel = .lambert
            m.diffuse.contents = UIColor(red: r, green: g, blue: b, alpha: 1)
            return m
        }
        let trunk = mat(0.42, 0.32, 0.22)
        let frond = mat(0.17, 0.40, 0.15)
        let leaves = [mat(0.20, 0.45, 0.16), mat(0.28, 0.50, 0.20), mat(0.14, 0.34, 0.15)]
        let walls = [mat(0.92, 0.86, 0.70), mat(0.70, 0.84, 0.88), mat(0.94, 0.78, 0.72), mat(0.84, 0.90, 0.76)]
        let roofs = [mat(0.62, 0.28, 0.22), mat(0.35, 0.42, 0.52), mat(0.55, 0.50, 0.45)]
        let hill = mat(0.20, 0.36, 0.26)
        let node = { (it: Item) -> SCNNode in Builder.node(for: it) }

        func palm(_ h: Float) -> SCNNode {
            let n = SCNNode()
            let t = SCNCone(topRadius: 0.35, bottomRadius: 0.6, height: CGFloat(h))
            t.radialSegmentCount = 6
            t.materials = [trunk]
            let tn = SCNNode(geometry: t)
            tn.position = SCNVector3(0, h / 2, 0)
            n.addChildNode(tn)
            for k in 0..<7 {
                let holder = SCNNode()
                holder.position = SCNVector3(0, h, 0)
                holder.eulerAngles.y = Float(k) / 7 * 2 * Float.pi + rng.f(-0.2, 0.2)
                let fb = SCNBox(width: 6.5, height: 0.15, length: 1.5, chamferRadius: 0)
                fb.materials = [frond]
                let fn = SCNNode(geometry: fb)
                fn.position = SCNVector3(3.0, -0.3, 0)
                fn.eulerAngles.z = -0.42
                holder.addChildNode(fn)
                n.addChildNode(holder)
            }
            n.eulerAngles.z = rng.f(-0.08, 0.08)
            return n
        }

        func tree(_ h: Float) -> SCNNode {
            let n = SCNNode()
            let t = SCNCylinder(radius: 0.35, height: CGFloat(h * 0.45))
            t.radialSegmentCount = 6
            t.materials = [trunk]
            let tn = SCNNode(geometry: t)
            tn.position = SCNVector3(0, h * 0.225, 0)
            n.addChildNode(tn)
            let m = leaves[Int(rng.next() % UInt64(leaves.count))]
            for _ in 0..<3 {
                let r = rng.f(0.28, 0.4) * h
                let s = SCNSphere(radius: CGFloat(r))
                s.segmentCount = 8
                s.materials = [m]
                let sn = SCNNode(geometry: s)
                sn.position = SCNVector3(rng.f(-0.25, 0.25) * h, h * 0.6 + rng.f(-0.1, 0.2) * h, rng.f(-0.25, 0.25) * h)
                sn.scale = SCNVector3(1, 0.85, 1)
                n.addChildNode(sn)
            }
            return n
        }

        func house() -> SCNNode {
            let n = SCNNode()
            let w = rng.f(7, 12), d = rng.f(5, 8), h = rng.f(3.4, 4.6)
            let b = SCNBox(width: CGFloat(w), height: CGFloat(h), length: CGFloat(d), chamferRadius: 0)
            b.materials = [walls[Int(rng.next() % UInt64(walls.count))]]
            let bn = SCNNode(geometry: b)
            bn.position = SCNVector3(0, h / 2, 0)
            n.addChildNode(bn)
            let r = SCNPyramid(width: CGFloat(w * 1.18), height: 2.4, length: CGFloat(d * 1.2))
            r.materials = [roofs[Int(rng.next() % UInt64(roofs.count))]]
            let rn = SCNNode(geometry: r)
            rn.position = SCNVector3(0, h, 0)
            n.addChildNode(rn)
            return n
        }

        let all = SCNNode()
        func ring(_ radius: Float, spacing: Float, houseChance: Float) {
            let count = Int(2 * Float.pi * radius / spacing)
            for i in 0..<count {
                let a = (Float(i) + rng.f(-0.3, 0.3)) / Float(count) * 2 * Float.pi
                let r = radius + rng.f(-22, 22)
                let cx = cos(a) * r, cz = sin(a) * r
                let roll = rng.f(0, 1)
                if roll < houseChance {
                    let hn = house()
                    hn.position = SCNVector3(cx, 0, cz)
                    hn.eulerAngles.y = -a + Float.pi / 2 + rng.f(-0.4, 0.4)
                    all.addChildNode(hn)
                    for _ in 0..<rng.nextInt(1, 3) {
                        let p = palm(rng.f(12, 18))
                        p.position = SCNVector3(cx + rng.f(-10, 10), 0, cz + rng.f(-10, 10))
                        all.addChildNode(p)
                    }
                } else if roll < houseChance + 0.45 {
                    for _ in 0..<rng.nextInt(2, 4) {
                        let p = palm(rng.f(11, 19))
                        p.position = SCNVector3(cx + rng.f(-9, 9), 0, cz + rng.f(-9, 9))
                        all.addChildNode(p)
                    }
                } else {
                    for _ in 0..<rng.nextInt(2, 4) {
                        let t = tree(rng.f(8, 13))
                        t.position = SCNVector3(cx + rng.f(-9, 9), 0, cz + rng.f(-9, 9))
                        all.addChildNode(t)
                    }
                }
            }
        }
        ring(470, spacing: 26, houseChance: 0.22)

        // ---- lớp thật ở gần: đường nhựa, kênh, cầu, nhà, dừa, cây dùng chính mô hình trong app ----
        let real = SCNNode()
        func put(_ it: Item) { real.addChildNode(node(it)) }
        func chord(_ kind: Kind, _ r: Float, _ segments: Int, _ variant: (Int) -> Int) {
            for i in 0..<segments {
                let a0 = Float(i) / Float(segments) * 2 * Float.pi
                let a1 = Float(i + 1) / Float(segments) * 2 * Float.pi
                var it = Item(kind: kind, x: cos(a0) * r, z: sin(a0) * r)
                it.x2 = cos(a1) * r
                it.z2 = sin(a1) * r
                it.colorIndex = variant(i)
                put(it)
            }
        }
        func radial(_ kind: Kind, _ a: Float, _ r0: Float, _ r1: Float, _ variant: Int) {
            var it = Item(kind: kind, x: cos(a) * r0, z: sin(a) * r0)
            it.x2 = cos(a) * r1
            it.z2 = sin(a) * r1
            it.colorIndex = variant
            put(it)
        }
        chord(.road, 300, 48) { _ in 0 }                          // đường nhựa vòng ngoài
        chord(.canal, 345, 56) { ($0 / 7) % 2 }                    // kênh: đoạn bờ đất xen kè gạch
        for k in 0..<4 {
            let a = Float(k) * Float.pi / 2 + 0.4
            radial(.villageRoad, a, 303, 337, 0)                   // đường làng ra cầu
            radial(.bridge, a, 337, 353, 0)                        // cầu khỉ bắc qua kênh
            radial(.villageRoad, a, 353, 470, 0)                   // đường đất đi tiếp sang bên kia
        }
        func place(_ kind: Kind, _ a: Float, _ r: Float, scale: Float = 1) {
            var it = Item(kind: kind, x: cos(a) * r, z: sin(a) * r)
            it.rot = rng.f(0, 6.28)
            it.scale = scale
            it.colorIndex = rng.nextInt(0, kind.variantCount - 1)
            put(it)
        }
        // nhà ven đường, quay mặt ra đường
        let houseKinds: [Kind] = [.stilt, .tole, .house, .nhaCo, .tole, .stilt]
        for i in 0..<24 {
            let a = (Float(i) + rng.f(-0.25, 0.25)) / 24 * 2 * Float.pi
            let kind = houseKinds[i % houseKinds.count]
            var it = Item(kind: kind, x: cos(a) * 318, z: sin(a) * 318)
            it.rot = -a + Float.pi / 2 + (rng.f(0, 1) < 0.5 ? 0 : Float.pi)
            it.colorIndex = rng.nextInt(0, kind.variantCount - 1)
            put(it)
            place(.coconut, a + 0.012, 326)
            if i % 2 == 0 { place(.banana, a - 0.015, 324) }
        }
        // vườn cây bên kia kênh
        let orchard: [Kind] = [.coconut, .fruit, .coconut, .tree, .banana, .bamboo, .coconut, .mai]
        for i in 0..<36 {
            let a = (Float(i) + rng.f(-0.3, 0.3)) / 36 * 2 * Float.pi
            place(orchard[i % orchard.count], a, 368 + rng.f(-6, 12))
            if i % 3 == 0 { place(.coconut, a + 0.01, 385) }
        }
        // dừa nước, cỏ ven kênh
        for i in 0..<28 {
            let a = (Float(i) + rng.f(-0.3, 0.3)) / 28 * 2 * Float.pi
            place(.nipa, a, 350.5 + rng.f(-0.5, 1.5))
        }
        all.addChildNode(real)

        // rặng cây xa như đồi thấp
        let blobs = Int(2 * Float.pi * 560 / 38)
        for i in 0..<blobs {
            let a = (Float(i) + rng.f(-0.3, 0.3)) / Float(blobs) * 2 * Float.pi
            let r = 560 + rng.f(-25, 25)
            let s = SCNSphere(radius: CGFloat(rng.f(26, 46)))
            s.segmentCount = 10
            s.materials = [hill]
            let sn = SCNNode(geometry: s)
            sn.position = SCNVector3(cos(a) * r, 0, sin(a) * r)
            sn.scale = SCNVector3(1.3, 0.5, 1.3)
            all.addChildNode(sn)
        }

        let flat = all.flattenedClone()
        flat.name = "horizon"
        flat.castsShadow = false
        return flat
    }
}

private extension SeededRNG {
    mutating func nextInt(_ lo: Int, _ hi: Int) -> Int {
        lo + Int(next() % UInt64(hi - lo + 1))
    }
}
