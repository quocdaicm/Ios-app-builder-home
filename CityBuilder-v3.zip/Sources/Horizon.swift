import SceneKit
import UIKit

// MARK: - Đường chân trời: rặng cây xa và đồi thấp

extension Builder {
    /// Cảnh xa ở chân trời, như đứng giữa đồng bằng miền Tây nhìn ra xa: bên kia kênh gạch là hàng nhà,
    /// dừa, chuối, cây ăn trái (dùng chính mô hình trong app, phóng to cho rõ lá), xa hơn nữa là rặng cây
    /// và đồi thấp mờ. Tất cả nằm ngoài vùng làm việc (bán kính > 480m) nên không che nền đang xây.
    /// Không nằm trong dự án, không xuất file. Phải gọi sau khi texture đã nạp xong.
    static func horizonNode() -> SCNNode {
        var rng = SeededRNG(20261015)
        func mat(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat) -> SCNMaterial {
            let m = SCNMaterial()
            m.lightingModel = .lambert
            m.diffuse.contents = UIColor(red: r, green: g, blue: b, alpha: 1)
            return m
        }
        let trunk = mat(0.42, 0.32, 0.22)
        let frond = mat(0.17, 0.40, 0.15)
        let leaves = [mat(0.20, 0.45, 0.16), mat(0.28, 0.50, 0.20), mat(0.14, 0.34, 0.15)]
        let hill = mat(0.20, 0.36, 0.26)

        func palm(_ h: Float) -> SCNNode {
            let n = SCNNode()
            let t = SCNCone(topRadius: 0.35, bottomRadius: 0.6, height: CGFloat(h))
            t.radialSegmentCount = 6
            t.materials = [trunk]
            let tn = SCNNode(geometry: t)
            tn.position = SCNVector3(0, h / 2, 0)
            n.addChildNode(tn)
            for k in 0..<7 {
                let holder = SCNNode()
                holder.position = SCNVector3(0, h, 0)
                holder.eulerAngles.y = Float(k) / 7 * 2 * Float.pi + rng.f(-0.2, 0.2)
                let fb = SCNBox(width: 6.5, height: 0.15, length: 1.5, chamferRadius: 0)
                fb.materials = [frond]
                let fn = SCNNode(geometry: fb)
                fn.position = SCNVector3(3.0, -0.3, 0)
                fn.eulerAngles.z = -0.42
                holder.addChildNode(fn)
                n.addChildNode(holder)
            }
            n.eulerAngles.z = rng.f(-0.08, 0.08)
            return n
        }

        func tree(_ h: Float) -> SCNNode {
            let n = SCNNode()
            let t = SCNCylinder(radius: 0.35, height: CGFloat(h * 0.45))
            t.radialSegmentCount = 6
            t.materials = [trunk]
            let tn = SCNNode(geometry: t)
            tn.position = SCNVector3(0, h * 0.225, 0)
            n.addChildNode(tn)
            let m = leaves[Int(rng.next() % UInt64(leaves.count))]
            for _ in 0..<3 {
                let r = rng.f(0.28, 0.4) * h
                let s = SCNSphere(radius: CGFloat(r))
                s.segmentCount = 8
                s.materials = [m]
                let sn = SCNNode(geometry: s)
                sn.position = SCNVector3(rng.f(-0.25, 0.25) * h, h * 0.6 + rng.f(-0.1, 0.2) * h, rng.f(-0.25, 0.25) * h)
                sn.scale = SCNVector3(1, 0.85, 1)
                n.addChildNode(sn)
            }
            return n
        }

        let all = SCNNode()

        // ---- rặng cây xa nhất (dựng đơn giản) + đồi thấp mờ làm nền ----
        func farRing(_ radius: Float, spacing: Float, scale: Float) {
            let count = Int(2 * Float.pi * radius / spacing)
            for i in 0..<count {
                let a = (Float(i) + rng.f(-0.3, 0.3)) / Float(count) * 2 * Float.pi
                let r = radius + rng.f(-25, 25)
                let n = rng.f(0, 1) < 0.45 ? palm(rng.f(11, 19)) : tree(rng.f(8, 13))
                n.position = SCNVector3(cos(a) * r, 0, sin(a) * r)
                n.scale = SCNVector3(scale, scale, scale)
                all.addChildNode(n)
            }
        }
        farRing(790, spacing: 16, scale: 2.2)
        let blobs = Int(2 * Float.pi * 900 / 40)
        for i in 0..<blobs {
            let a = (Float(i) + rng.f(-0.3, 0.3)) / Float(blobs) * 2 * Float.pi
            let r = 900 + rng.f(-25, 25)
            let s = SCNSphere(radius: CGFloat(rng.f(34, 58)))
            s.segmentCount = 10
            s.materials = [hill]
            let sn = SCNNode(geometry: s)
            sn.position = SCNVector3(cos(a) * r, 0, sin(a) * r)
            sn.scale = SCNVector3(1.3, 0.5, 1.3)
            all.addChildNode(sn)
        }

        // (bỏ đường, kênh, nhà, vườn: chỉ giữ rặng cây xa và đồi thấp làm đường chân trời)

        let flat = all.flattenedClone()
        flat.name = "horizon"
        flat.castsShadow = false
        return flat
    }
}

private extension SeededRNG {
    mutating func nextInt(_ lo: Int, _ hi: Int) -> Int {
        lo + Int(next() % UInt64(hi - lo + 1))
    }
}
