import SceneKit
import UIKit

// MARK: - Cảnh xa ở chân trời: làng mạc, hàng dừa, rặng cây

extension Builder {
    /// Cảnh xa ở chân trời, như đứng giữa đồng bằng miền Tây nhìn ra xa: bên kia kênh gạch là hàng nhà,
    /// dừa, chuối, cây ăn trái (dùng chính mô hình trong app, phóng to cho rõ lá), xa hơn nữa là rặng cây
    /// và đồi thấp mờ. Tất cả nằm ngoài vùng làm việc (bán kính > 480m) nên không che nền đang xây.
    /// Không nằm trong dự án, không xuất file. Phải gọi sau khi texture đã nạp xong.
    static func horizonNode() -> SCNNode {
        var rng = SeededRNG(20261015)
        func mat(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat) -> SCNMaterial {
            let m = SCNMaterial()
            m.lightingModel = .lambert
            m.diffuse.contents = UIColor(red: r, green: g, blue: b, alpha: 1)
            return m
        }
        let trunk = mat(0.42, 0.32, 0.22)
        let frond = mat(0.17, 0.40, 0.15)
        let leaves = [mat(0.20, 0.45, 0.16), mat(0.28, 0.50, 0.20), mat(0.14, 0.34, 0.15)]
        let hill = mat(0.20, 0.36, 0.26)

        func palm(_ h: Float) -> SCNNode {
            let n = SCNNode()
            let t = SCNCone(topRadius: 0.35, bottomRadius: 0.6, height: CGFloat(h))
            t.radialSegmentCount = 6
            t.materials = [trunk]
            let tn = SCNNode(geometry: t)
            tn.position = SCNVector3(0, h / 2, 0)
            n.addChildNode(tn)
            for k in 0..<7 {
                let holder = SCNNode()
                holder.position = SCNVector3(0, h, 0)
                holder.eulerAngles.y = Float(k) / 7 * 2 * Float.pi + rng.f(-0.2, 0.2)
                let fb = SCNBox(width: 6.5, height: 0.15, length: 1.5, chamferRadius: 0)
                fb.materials = [frond]
                let fn = SCNNode(geometry: fb)
                fn.position = SCNVector3(3.0, -0.3, 0)
                fn.eulerAngles.z = -0.42
                holder.addChildNode(fn)
                n.addChildNode(holder)
            }
            n.eulerAngles.z = rng.f(-0.08, 0.08)
            return n
        }

        func tree(_ h: Float) -> SCNNode {
            let n = SCNNode()
            let t = SCNCylinder(radius: 0.35, height: CGFloat(h * 0.45))
            t.radialSegmentCount = 6
            t.materials = [trunk]
            let tn = SCNNode(geometry: t)
            tn.position = SCNVector3(0, h * 0.225, 0)
            n.addChildNode(tn)
            let m = leaves[Int(rng.next() % UInt64(leaves.count))]
            for _ in 0..<3 {
                let r = rng.f(0.28, 0.4) * h
                let s = SCNSphere(radius: CGFloat(r))
                s.segmentCount = 8
                s.materials = [m]
                let sn = SCNNode(geometry: s)
                sn.position = SCNVector3(rng.f(-0.25, 0.25) * h, h * 0.6 + rng.f(-0.1, 0.2) * h, rng.f(-0.25, 0.25) * h)
                sn.scale = SCNVector3(1, 0.85, 1)
                n.addChildNode(sn)
            }
            return n
        }

        let all = SCNNode()

        // ---- rặng cây xa nhất (dựng đơn giản) + đồi thấp mờ làm nền ----
        func farRing(_ radius: Float, spacing: Float, scale: Float) {
            let count = Int(2 * Float.pi * radius / spacing)
            for i in 0..<count {
                let a = (Float(i) + rng.f(-0.3, 0.3)) / Float(count) * 2 * Float.pi
                let r = radius + rng.f(-25, 25)
                let n = rng.f(0, 1) < 0.45 ? palm(rng.f(11, 19)) : tree(rng.f(8, 13))
                n.position = SCNVector3(cos(a) * r, 0, sin(a) * r)
                n.scale = SCNVector3(scale, scale, scale)
                all.addChildNode(n)
            }
        }
        farRing(790, spacing: 16, scale: 2.2)
        let blobs = Int(2 * Float.pi * 900 / 40)
        for i in 0..<blobs {
            let a = (Float(i) + rng.f(-0.3, 0.3)) / Float(blobs) * 2 * Float.pi
            let r = 900 + rng.f(-25, 25)
            let s = SCNSphere(radius: CGFloat(rng.f(34, 58)))
            s.segmentCount = 10
            s.materials = [hill]
            let sn = SCNNode(geometry: s)
            sn.position = SCNVector3(cos(a) * r, 0, sin(a) * r)
            sn.scale = SCNVector3(1.3, 0.5, 1.3)
            all.addChildNode(sn)
        }

        // ---- hình dạng đường làng và kênh: uốn lượn, không phải vòng tròn đều ----
        let twoPi = 2 * Float.pi
        func roadR(_ t: Float) -> Float { 498 + 12 * sin(3 * t + 0.6) + 6 * sin(7 * t + 2.0) + 3 * sin(13 * t) }
        func canalR(_ t: Float) -> Float { 580 + 14 * sin(2 * t + 1.3) + 8 * sin(5 * t + 0.4) + 4 * sin(11 * t) }
        func canalHW(_ t: Float) -> Float { 14 + 3 * sin(4 * t + 0.8) }          // nửa bề rộng mặt nước
        func cpt(_ t: Float) -> SIMD2<Float> { let r = canalR(t); return SIMD2<Float>(cos(t) * r, sin(t) * r) }
        /// Điểm cách tâm kênh `off` mét (dương = ra phía ngoài) cùng pháp tuyến hướng ra ngoài.
        func bank(_ t: Float, _ off: Float) -> (p: SIMD2<Float>, n: SIMD2<Float>) {
            let d = cpt(t + 0.002) - cpt(t - 0.002)
            let len = max((d.x * d.x + d.y * d.y).squareRoot(), 0.0001)
            let n = SIMD2<Float>(d.y, -d.x) / len
            return (cpt(t) + n * off, n)
        }
        func strip(_ p0: SIMD2<Float>, _ p1: SIMD2<Float>, width: CGFloat, height: CGFloat, y: Float, _ m: SCNMaterial) {
            let d = p1 - p0
            let len = (d.x * d.x + d.y * d.y).squareRoot()
            let b = SCNBox(width: width, height: height, length: CGFloat(len * 1.3), chamferRadius: 0)
            b.materials = [m]
            let bn = SCNNode(geometry: b)
            bn.position = SCNVector3((p0.x + p1.x) / 2, y, (p0.y + p1.y) / 2)
            bn.eulerAngles.y = atan2(d.x, d.y)
            all.addChildNode(bn)
        }
        let dirt = TextureLibrary.material(.dirt, roughness: 1, repeatX: 3, repeatY: 1)
        let concrete = TextureLibrary.material(.concrete, roughness: 0.95, repeatX: 3, repeatY: 1)
        let brick = TextureLibrary.material(.brick, roughness: 0.95, repeatX: 3, repeatY: 1)
        let water = SCNMaterial()
        water.lightingModel = .blinn
        water.diffuse.contents = UIColor(red: 0.38, green: 0.45, blue: 0.36, alpha: 1)
        water.specular.contents = UIColor(white: 0.7, alpha: 1)
        water.shininess = 0.8

        // đường làng: đoạn lộ bê tông xen lộ đất
        let roadSegs = 260
        for i in 0..<roadSegs {
            let t0 = Float(i) / Float(roadSegs) * twoPi
            let t1 = Float(i + 1) / Float(roadSegs) * twoPi
            let p0 = SIMD2<Float>(cos(t0) * roadR(t0), sin(t0) * roadR(t0))
            let p1 = SIMD2<Float>(cos(t1) * roadR(t1), sin(t1) * roadR(t1))
            let isDirt = Int(Float(i) / Float(roadSegs) * 9) % 3 == 1
            strip(p0, p1, width: isDirt ? 6.5 : 9, height: 0.5, y: isDirt ? 0.22 : 0.25, isDirt ? dirt : concrete)
        }
        // kênh uốn quanh, hai bờ kè gạch, bề rộng lúc rộng lúc hẹp
        let canalSegs = 300
        for i in 0..<canalSegs {
            let t0 = Float(i) / Float(canalSegs) * twoPi
            let t1 = Float(i + 1) / Float(canalSegs) * twoPi
            let h0 = canalHW(t0), h1 = canalHW(t1)
            strip(cpt(t0), cpt(t1), width: CGFloat(h0 + h1), height: 0.5, y: 0.25, water)
            strip(bank(t0, h0 + 2).p, bank(t1, h1 + 2).p, width: 4, height: 2.4, y: 1.2, brick)
            strip(bank(t0, -(h0 + 2)).p, bank(t1, -(h1 + 2)).p, width: 4, height: 2.4, y: 1.2, brick)
        }
        // đường đất rẽ ra vườn, bắc cầu bê tông qua kênh
        let spurs: [Float] = [0.55, 2.0, 3.6, 5.1]
        for a in spurs {
            let dir = SIMD2<Float>(cos(a), sin(a)), perp = SIMD2<Float>(-sin(a), cos(a))
            let cr = canalR(a), hw = canalHW(a)
            var r = roadR(a) + 3
            func pt(_ r: Float) -> SIMD2<Float> { dir * r + perp * (4 * sin(r * 0.05 + a)) }
            while r < 735 {
                let r2 = r + 10
                let inCanal = r2 > cr - hw - 8 && r < cr + hw + 8
                if !inCanal { strip(pt(r), pt(r2), width: 5, height: 0.5, y: 0.22, dirt) }
                r = r2
            }
            let c = dir * cr
            let deck = SCNBox(width: 6, height: 0.5, length: CGFloat(2 * hw + 16), chamferRadius: 0)
            deck.materials = [concrete]
            let dn = SCNNode(geometry: deck)
            dn.position = SCNVector3(c.x, 2.2, c.y)
            dn.eulerAngles.y = atan2(cos(a), sin(a))
            all.addChildNode(dn)
            for side: Float in [-2.8, 2.8] {
                let rail = SCNBox(width: 0.3, height: 0.9, length: CGFloat(2 * hw + 16), chamferRadius: 0)
                rail.materials = [concrete]
                let rn = SCNNode(geometry: rail)
                rn.position = SCNVector3(c.x + perp.x * side, 2.9, c.y + perp.y * side)
                rn.eulerAngles.y = dn.eulerAngles.y
                all.addChildNode(rn)
            }
        }
        func nearSpur(_ t: Float) -> Bool {
            spurs.contains { var d = abs(t - $0).truncatingRemainder(dividingBy: twoPi); if d > Float.pi { d = twoPi - d }; return d < 0.04 }
        }

        // ---- mô hình thật trong app, phóng to cho nhìn rõ từ xa; rải không đều như thật ----
        let real = SCNNode()
        func place(_ kind: Kind, _ p: SIMD2<Float>, scale: Float, rot: Float? = nil) {
            var it = Item(kind: kind, x: p.x, z: p.y)
            it.rot = rot ?? rng.f(0, 6.28)
            it.scale = scale
            it.colorIndex = rng.nextInt(0, kind.variantCount - 1)
            real.addChildNode(Builder.node(for: it))
        }
        /// Đi dọc bờ kênh, khoảng cách giữa hai điểm không đều.
        func along(_ step: Float, _ body: (Float) -> Void) {
            var t = rng.f(0, step)
            while t < twoPi { body(t); t += step * rng.f(0.6, 1.5) }
        }
        func faceIn(_ n: SIMD2<Float>) -> Float { atan2(-n.x, -n.y) + rng.f(-0.12, 0.12) }

        // bờ gần (giữa đường và kênh): dừa, chuối, cỏ, trâu
        let nearRow: [Kind] = [.coconut, .banana, .nipa, .banana, .coconut, .grass]
        var ni = 0
        along(0.17) { t in
            if nearSpur(t) { return }
            let b = bank(t, -(canalHW(t) + 11 + rng.f(-2, 2)))
            place(nearRow[ni % nearRow.count], b.p, scale: 2.1)
            ni += 1
        }
        along(1.0) { t in
            let b = bank(t, -(canalHW(t) + 13))
            place(.buffalo, b.p, scale: 2.6)
        }
        // bờ xa: nhà quay mặt vào kênh, xen ruộng lúa
        let houseKinds: [Kind] = [.stilt, .tole, .stilt, .stilt, .tole, .tole]   // nhà mái lá và nhà tôn như Cà Mau
        var hi = 0
        along(0.12) { t in
            if nearSpur(t) { return }
            let hw = canalHW(t)
            if sin(5 * t + 1.0) > 0.78 {
                place(.rice, bank(t, hw + 34).p, scale: 3.2)
                return
            }
            let b = bank(t, hw + 22 + rng.f(-3, 3))
            place(houseKinds[hi % houseKinds.count], b.p, scale: 2.5, rot: faceIn(b.n))
            hi += 1
            place(.coconut, bank(t + 0.006, hw + 40).p, scale: 2.7)
            if hi % 2 == 0 { place(.banana, bank(t - 0.008, hw + 35).p, scale: 2.6) }
        }
        // dừa nước ven kênh
        along(0.12) { t in place(.nipa, bank(t, canalHW(t) + 8).p, scale: 2.4) }
        // vườn cây phía sau nhà
        let orchard: [Kind] = [.coconut, .fruit, .coconut, .tree, .banana, .bamboo, .coconut, .mai]
        var oi = 0
        along(0.11) { t in
            if nearSpur(t) { return }
            place(orchard[oi % orchard.count], bank(t, canalHW(t) + 62 + rng.f(0, 35)).p, scale: rng.f(2.8, 3.4))
            oi += 1
        }
        // ghe xuồng trên kênh
        along(0.5) { t in
            let b = bank(t, rng.f(-0.4, 0.4) * canalHW(t))
            place(.boat, b.p, scale: 2.5, rot: atan2(-b.n.y, b.n.x))
        }
        // điểm nhấn xa: chùa Khmer, lò gạch
        place(.chuaKhmer, bank(2.7, canalHW(2.7) + 110).p, scale: 2.6, rot: faceIn(bank(2.7, 0).n))
        for t: Float in [4.4, 5.8] { place(.brickKiln, bank(t, canalHW(t) + 95).p, scale: 2.8) }
        all.addChildNode(real)

        let flat = all.flattenedClone()
        flat.name = "horizon"
        flat.castsShadow = false
        return flat
    }
}

private extension SeededRNG {
    mutating func nextInt(_ lo: Int, _ hi: Int) -> Int {
        lo + Int(next() % UInt64(hi - lo + 1))
    }
}
