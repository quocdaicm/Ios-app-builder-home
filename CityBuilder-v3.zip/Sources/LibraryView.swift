import SwiftUI
import UniformTypeIdentifiers

/// Màn hình quản lý thư viện mô hình: tìm theo tên, chia chuyên mục, nhập vào chuyên mục, sao lưu và đồng bộ.
struct LibraryView: View {
    @ObservedObject var c: SceneController
    var onImport: () -> Void

    @Environment(\.dismiss) private var dismiss
    @State private var showNewCategory = false
    @State private var newCategoryName = ""
    @State private var renameTarget: String? = nil
    @State private var renameText = ""
    @State private var deleteModelName: String? = nil
    @State private var deleteCategoryName: String? = nil

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                chipsBar
                statusBar
                Color.clear
                    .frame(height: 0)
                    .confirmationDialog(
                        "Xóa chuyên mục “\(deleteCategoryName ?? "")”? Mô hình trong đó không bị xóa, chỉ chuyển về “Chưa phân loại”.",
                        isPresented: Binding(get: { deleteCategoryName != nil },
                                             set: { if !$0 { deleteCategoryName = nil } }),
                        titleVisibility: .visible
                    ) {
                        Button("Xóa chuyên mục", role: .destructive) {
                            if let n = deleteCategoryName { c.deleteCategory(n) }
                            deleteCategoryName = nil
                        }
                        Button("Hủy", role: .cancel) { deleteCategoryName = nil }
                    }
                modelList
            }
            .navigationTitle("Thư viện mô hình")
            .navigationBarTitleDisplayMode(.inline)
            .searchable(text: $c.librarySearch,
                        placement: .navigationBarDrawer(displayMode: .always),
                        prompt: "Tìm theo tên hoặc chuyên mục")
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Xong") { dismiss() }
                }
                ToolbarItemGroup(placement: .navigationBarTrailing) {
                    sortMenu
                    moreMenu
                    Button { onImport() } label: {
                        Image(systemName: "plus.circle.fill")
                    }
                }
            }
        }
        .preferredColorScheme(.dark)
        .onDisappear { c.librarySearch = "" }
        .alert("Chuyên mục mới", isPresented: $showNewCategory) {
            TextField("Tên chuyên mục", text: $newCategoryName)
            Button("Tạo") {
                let name = newCategoryName.trimmingCharacters(in: .whitespacesAndNewlines)
                if c.addCategory(name) { c.libraryFilter = .category(name) }
                newCategoryName = ""
            }
            Button("Hủy", role: .cancel) { newCategoryName = "" }
        } message: {
            Text("Chọn chuyên mục rồi bấm + để nhập mô hình thẳng vào đó.")
        }
    }

    // MARK: Thanh chuyên mục

    private var chipsBar: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                chip("Tất cả", .all)
                chip("Chưa phân loại", .uncategorized)
                ForEach(c.library.categories, id: \.self) { cat in
                    chip(cat, .category(cat))
                        .contextMenu {
                            Button {
                                renameText = cat
                                renameTarget = cat
                            } label: { Label("Đổi tên", systemImage: "pencil") }
                            Button(role: .destructive) {
                                deleteCategoryName = cat
                            } label: { Label("Xóa chuyên mục", systemImage: "trash") }
                        }
                }
                Button { showNewCategory = true } label: {
                    Label("Chuyên mục", systemImage: "plus")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundColor(Theme.amber)
                        .padding(.horizontal, 12)
                        .frame(height: 32)
                        .overlay(Capsule().stroke(Theme.amber.opacity(0.6),
                                                  style: StrokeStyle(lineWidth: 1, dash: [4, 3])))
                }
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
        }
        .alert("Đổi tên chuyên mục",
               isPresented: Binding(get: { renameTarget != nil },
                                    set: { if !$0 { renameTarget = nil } })) {
            TextField("Tên mới", text: $renameText)
            Button("Lưu") {
                if let old = renameTarget { c.renameCategory(old, to: renameText) }
                renameTarget = nil
            }
            Button("Hủy", role: .cancel) { renameTarget = nil }
        }
    }

    private func chip(_ title: String, _ f: LibraryFilter) -> some View {
        let on = c.libraryFilter == f
        return Button { c.libraryFilter = f } label: {
            Text("\(title) (\(c.count(in: f)))")
                .font(.system(size: 13, weight: .semibold))
                .foregroundColor(on ? Theme.ink : .white)
                .padding(.horizontal, 12)
                .frame(height: 32)
                .background(on ? Theme.accent : Color.white.opacity(0.10), in: Capsule())
        }
    }

    private var statusBar: some View {
        VStack(alignment: .leading, spacing: 2) {
            if case .category(let n) = c.libraryFilter {
                Text("Mô hình nhập mới sẽ vào chuyên mục “\(n)”.")
            }
            if let f = c.syncFolderName {
                Text("Đồng bộ với thư mục: \(f)")
            }
            if !c.libraryStatus.isEmpty {
                Text(c.libraryStatus).foregroundColor(Theme.amber)
            }
            if c.syncBusy {
                ProgressView().scaleEffect(0.8)
            }
        }
        .font(.caption)
        .foregroundColor(.white.opacity(0.7))
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 14)
        .padding(.bottom, 4)
        .confirmationDialog(
            "Bản sao lưu có kèm thành phố. Thay thế thành phố đang dựng?",
            isPresented: Binding(get: { c.pendingRestoreProject != nil },
                                 set: { if !$0 { c.pendingRestoreProject = nil } }),
            titleVisibility: .visible
        ) {
            Button("Thay thế thành phố hiện tại", role: .destructive) { c.applyRestoredProject() }
            Button("Giữ thành phố hiện tại", role: .cancel) { c.pendingRestoreProject = nil }
        }
    }

    // MARK: Danh sách

    private var groups: [(title: String, items: [String])] {
        let list = c.filteredModels()
        guard c.librarySort == .category else { return [("", list)] }
        var order: [String] = []
        var dict: [String: [String]] = [:]
        for m in list {
            let k = c.category(of: m)
            if dict[k] == nil { order.append(k) }
            dict[k, default: []].append(m)
        }
        return order.map { (title: $0.isEmpty ? "Chưa phân loại" : $0, items: dict[$0] ?? []) }
    }

    private var modelList: some View {
        let g = groups
        return Group {
            if g.allSatisfy({ $0.items.isEmpty }) {
                VStack {
                    Spacer()
                    Text(c.models.isEmpty ? "Chưa có mô hình. Bấm + để nhập." : "Không có mô hình phù hợp.")
                        .foregroundColor(.white.opacity(0.6))
                    Spacer()
                }
                .frame(maxWidth: .infinity)
            } else {
                List {
                    ForEach(Array(g.enumerated()), id: \.offset) { entry in
                        let group = entry.element
                        Section {
                            ForEach(group.items, id: \.self) { name in
                                row(name)
                            }
                        } header: {
                            if !group.title.isEmpty { Text(group.title) }
                        }
                    }
                }
                .listStyle(.insetGrouped)
            }
        }
        .confirmationDialog(
            "Xóa mô hình “\(deleteModelName ?? "")” khỏi thư viện? Các bản đã đặt trong thành phố cũng bị xóa.",
            isPresented: Binding(get: { deleteModelName != nil },
                                 set: { if !$0 { deleteModelName = nil } }),
            titleVisibility: .visible
        ) {
            Button("Xóa", role: .destructive) {
                if let n = deleteModelName { c.deleteModel(n) }
                deleteModelName = nil
            }
            Button("Hủy", role: .cancel) { deleteModelName = nil }
        }
    }

    private func row(_ name: String) -> some View {
        let cat = c.category(of: name)
        return Button {
            c.selectModel(name)
            dismiss()
        } label: {
            HStack(spacing: 12) {
                Image(systemName: "cube.fill")
                    .foregroundColor(Theme.accent2)
                    .frame(width: 28)
                VStack(alignment: .leading, spacing: 2) {
                    Text(name)
                        .font(.body.weight(.semibold))
                        .lineLimit(1)
                    Text(cat.isEmpty ? "Chưa phân loại" : cat)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                Spacer()
                if c.tool == .model && c.currentModel == name {
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundColor(Theme.accent)
                }
            }
        }
        .foregroundColor(.primary)
        .contextMenu {
            Menu("Chuyển vào chuyên mục") {
                Button("Chưa phân loại") { c.setCategory("", for: name) }
                ForEach(c.library.categories, id: \.self) { target in
                    Button(target) { c.setCategory(target, for: name) }
                }
            }
            Button(role: .destructive) {
                deleteModelName = name
            } label: { Label("Xóa khỏi thư viện", systemImage: "trash") }
        }
        .swipeActions(edge: .trailing) {
            Button(role: .destructive) {
                deleteModelName = name
            } label: { Label("Xóa", systemImage: "trash") }
        }
    }

    // MARK: Menu trên thanh công cụ

    private var sortMenu: some View {
        Menu {
            Picker("Sắp xếp", selection: $c.librarySort) {
                ForEach(LibrarySort.allCases) { s in
                    Text(s.title).tag(s)
                }
            }
        } label: {
            Image(systemName: "arrow.up.arrow.down")
        }
    }

    private var moreMenu: some View {
        Menu {
            Section("Sao lưu") {
                Button {
                    // đóng màn hình này trước để bảng chia sẻ file hiện lên được
                    dismiss()
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { c.backup() }
                } label: { Label("Sao lưu thư viện (.zip)", systemImage: "externaldrive.badge.plus") }
                Button {
                    DocPicker.shared.present(types: [.zip]) { urls in
                        if let u = urls.first { c.restoreBackup(from: u) }
                    }
                } label: { Label("Khôi phục từ file sao lưu", systemImage: "arrow.counterclockwise") }
            }
            Section("Đồng bộ giữa các máy") {
                if c.syncFolderName != nil {
                    Button { c.syncNow() } label: { Label("Đồng bộ ngay", systemImage: "arrow.triangle.2.circlepath") }
                    Button { pickSyncFolder() } label: { Label("Đổi thư mục đồng bộ", systemImage: "folder") }
                    Button(role: .destructive) { c.clearSyncFolder() } label: {
                        Label("Ngắt đồng bộ", systemImage: "xmark.icloud")
                    }
                } else {
                    Button { pickSyncFolder() } label: {
                        Label("Chọn thư mục đồng bộ…", systemImage: "folder.badge.plus")
                    }
                }
            }
        } label: {
            Image(systemName: "icloud.and.arrow.up")
        }
    }

    private func pickSyncFolder() {
        DocPicker.shared.present(types: [.folder], asCopy: false, multiple: false) { urls in
            if let u = urls.first { c.setSyncFolder(u) }
        }
    }
}
