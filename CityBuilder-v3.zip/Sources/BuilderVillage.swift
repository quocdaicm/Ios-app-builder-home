import SceneKit
import UIKit
import simd

// MARK: - Đất vườn, bờ ao, đường làng

extension Builder {
    private static func vRep(_ length: Float, _ tile: Float) -> Float {
        max((length / tile * 4).rounded() / 4, 0.25)
    }

    private static func vLineRoot(from a: SIMD2<Float>, to b: SIMD2<Float>) -> (SCNNode, Float) {
        let dx = b.x - a.x
        let dz = b.y - a.y
        let len = max((dx * dx + dz * dz).squareRoot(), 0.5)
        let root = SCNNode()
        root.position = SCNVector3((a.x + b.x) / 2, 0, (a.y + b.y) / 2)
        root.eulerAngles.y = atan2(-dz, dx)
        return (root, len)
    }

    // MARK: Đường làng (nối giữa 2 điểm)

    /// Đường làng hẹp 2,2 m. 0: đường đất đỏ có cỏ giữa và vệt bánh xe; 1: lát gạch tàu có bó vỉa;
    /// 2: đường đan bê tông nông thôn có khe nối. Hai bên là bờ cỏ, rải bụi cỏ dại.
    static func villageRoad(from a: SIMD2<Float>, to b: SIMD2<Float>, variant: Int, seed: UInt64) -> SCNNode {
        let (root, len) = vLineRoot(from: a, to: b)
        var rng = SeededRNG(seed)
        let v = variant % 3
        let width: Float = 2.2
        let h: Float = v == 0 ? 0.05 : 0.08
        let t: Tex = v == 0 ? .dirt : (v == 1 ? .brick : .concrete)
        let tint: UIColor = v == 0 ? rgb(1.12, 0.84, 0.64) : (v == 1 ? rgb(1.0, 0.80, 0.72) : rgb(0.96, 0.96, 0.93))
        let tile: Float = v == 1 ? 1.5 : 3
        let topM = tex(t, tint: tint, rough: 0.95, rx: vRep(len, tile), ry: vRep(width, tile))
        let sideM = tex(t, tint: tint, rough: 0.95, rx: 1, ry: 0.1)

        let g = SCNBox(width: CGFloat(len), height: CGFloat(h), length: CGFloat(width), chamferRadius: 0)
        g.materials = [sideM, sideM, sideM, sideM, topM, sideM]
        let bn = SCNNode(geometry: g)
        bn.position = SCNVector3(0, h / 2, 0)
        root.addChildNode(bn)
        for sign in [Float(-1), Float(1)] {
            let c = SCNCylinder(radius: CGFloat(width / 2), height: CGFloat(h))
            c.radialSegmentCount = 20
            c.materials = [topM, topM, sideM]
            let cn = SCNNode(geometry: c)
            cn.position = SCNVector3(sign * len / 2, h / 2, 0)
            root.addChildNode(cn)
        }

        // bờ cỏ hai bên
        for sign in [Float(-1), Float(1)] {
            root.addChildNode(tbox(len, 0.08, 0.7, .grass, tile: 2, y: 0.04, z: sign * (width / 2 + 0.3)))
        }

        if v == 0 {
            // vệt bánh xe, cỏ mọc giữa đường, sỏi rải rác
            let rut = plain(rgb(0.30, 0.20, 0.13), rough: 1)
            for sign in [Float(-1), Float(1)] {
                let r = SCNBox(width: CGFloat(len - 0.2), height: 0.004, length: 0.38, chamferRadius: 0)
                r.materials = [rut]
                let rn = SCNNode(geometry: r)
                rn.position = SCNVector3(0, h + 0.002, sign * 0.62)
                root.addChildNode(rn)
            }
            root.addChildNode(tbox(max(len - 0.6, 0.3), 0.07, 0.45, .grass, tile: 2, y: 0.035))
            let pebble = plain(rgb(0.62, 0.56, 0.50), rough: 0.9)
            let count = min(Int(len * 1.5), 60)
            for _ in 0..<count {
                let r = rng.f(0.025, 0.055)
                let p = sphere(r, pebble, x: rng.f(-len / 2 + 0.2, len / 2 - 0.2), y: h + r * 0.4,
                               z: rng.f(-width / 2 + 0.15, width / 2 - 0.15), seg: 5)
                p.scale = SCNVector3(1, 0.6, 1)
                root.addChildNode(p)
            }
        } else if v == 1 {
            // bó vỉa bê tông hai mép
            for sign in [Float(-1), Float(1)] {
                root.addChildNode(tbox(len, 0.13, 0.14, .concrete, tile: 1.5, y: 0.065, z: sign * (width / 2 + 0.02)))
            }
        } else {
            // khe nối giữa các tấm đan
            let joint = plain(rgb(0.30, 0.30, 0.29), rough: 1)
            var x = -len / 2 + 2.0
            while x < len / 2 - 0.5 {
                let j = SCNBox(width: 0.035, height: 0.004, length: CGFloat(width), chamferRadius: 0)
                j.materials = [joint]
                let jn = SCNNode(geometry: j)
                jn.position = SCNVector3(x, h + 0.002, 0)
                root.addChildNode(jn)
                x += 2.0
            }
        }

        // bụi cỏ dại ven đường
        let tuft = TextureLibrary.foliageMaterial(.grassTuft, tint: rgb(1.0, 1.05, 0.8))
        let tufts = min(Int(len / 2.2) + 1, 24)
        for sign in [Float(-1), Float(1)] {
            for _ in 0..<tufts {
                let size = rng.f(0.5, 0.85)
                let px = rng.f(-len / 2, len / 2)
                let pz = sign * (width / 2 + rng.f(0.15, 0.6))
                for k in 0..<2 {
                    let plane = SCNPlane(width: CGFloat(size), height: CGFloat(size * 0.85))
                    plane.materials = [tuft]
                    let n = SCNNode(geometry: plane)
                    n.position = SCNVector3(px, 0.08 + size * 0.85 / 2, pz)
                    n.eulerAngles.y = Float(k) * Float.pi / 2 + rng.f(0, 1)
                    n.castsShadow = false
                    root.addChildNode(n)
                }
            }
        }
        return root
    }

    // MARK: Đất vườn

    /// Mảnh vườn 8 x 6 m: năm luống đất đắp cao, rãnh giữa các luống, hàng rào tre ba phía.
    /// 0: luống đất mới xới (có cuốc cắm); 1: rau cải xanh; 2: cải xanh xen cải hoa vàng và hành.
    static func gardenBed(_ variant: Int, seed: UInt64) -> SCNNode {
        let root = SCNNode()
        var rng = SeededRNG(seed)
        let v = variant % 3

        let furrowTint = rgb(0.58, 0.46, 0.37)
        let bedTint = v == 0 ? rgb(0.70, 0.54, 0.42) : rgb(0.54, 0.41, 0.31)
        root.addChildNode(tbox(8.4, 0.06, 6.6, .dirt, tint: furrowTint, rough: 1, tile: 2, y: 0.03))

        // các luống: nửa trụ đất dẹt chạy dọc theo trục Z
        let bedMat = tex(.dirt, tint: bedTint, rough: 1, rx: 1.5, ry: 2.5)
        let radius: Float = 0.62
        let flat: Float = 0.42
        let topY: Float = 0.06 + radius * flat - 0.02
        let xs: [Float] = [-3.2, -1.6, 0, 1.6, 3.2]
        for x in xs {
            let c = SCNCylinder(radius: CGFloat(radius), height: 5.8)
            c.radialSegmentCount = 16
            c.materials = [bedMat, bedMat, bedMat]
            let n = SCNNode(geometry: c)
            n.position = SCNVector3(x, 0.06, 0)
            n.eulerAngles.x = Float.pi / 2
            n.scale = SCNVector3(1, 1, flat)
            root.addChildNode(n)
        }

        if v == 0 {
            // cục đất xới
            let clod = plain(rgb(0.36, 0.26, 0.19), rough: 1)
            for x in xs {
                for _ in 0..<12 {
                    let r = rng.f(0.04, 0.09)
                    let p = sphere(r, clod, x: x + rng.f(-0.4, 0.4), y: topY - 0.03 + r * 0.3,
                                   z: rng.f(-2.7, 2.7), seg: 6)
                    p.scale = SCNVector3(1, 0.7, 1)
                    root.addChildNode(p)
                }
            }
            // cuốc cắm ở góc vườn
            let handle = tex(.wood, tint: rgb(0.85, 0.72, 0.55), rough: 0.9, rx: 1, ry: 2)
            let base = V3(-3.9, 0.06, 3.0)
            root.addChildNode(link(base, V3(-3.65, 1.35, 2.75), r1: 0.025, r2: 0.022, handle, seg: 6))
            let blade = box(0.22, 0.015, 0.16, rgb(0.30, 0.30, 0.32), rough: 0.5, metal: 0.7, x: -3.9, y: 0.1, z: 3.06)
            blade.eulerAngles.x = 0.3
            root.addChildNode(blade)
        } else {
            let brassica = TextureLibrary.foliageMaterial(.leafBroad, tint: rgb(0.85, 1.12, 0.62))
            let onion = TextureLibrary.foliageMaterial(.leafLance, tint: rgb(0.80, 1.10, 0.60))
            var cai = CardBatch()
            var hanh = CardBatch()
            var hoa = CardBatch()
            for (i, x) in xs.enumerated() {
                let mixed = v == 2 && i % 2 == 1
                for j in 0..<11 {
                    let z = -2.5 + Float(j) * 0.5
                    for side in [Float(-0.22), 0.22] {
                        let p = V3(x + side, topY, z + rng.f(-0.05, 0.05))
                        if mixed {
                            for _ in 0..<6 {
                                let d = simd_normalize(V3(rng.f(-0.25, 0.25), 1, rng.f(-0.25, 0.25)))
                                hanh.leaf(at: p, dir: d, spin: rng.f(-3, 3), w: 0.07, h: rng.f(0.30, 0.42),
                                          fold: 0.1, droop: 0.35)
                            }
                            if j % 2 == 0 {
                                let top = p + V3(rng.f(-0.05, 0.05), 0.55, rng.f(-0.05, 0.05))
                                hoa.disc(at: top, normal: V3(0, 1, 0.2), spin: rng.f(0, 6), size: 0.14, dish: 0.3)
                            }
                        } else {
                            for _ in 0..<7 {
                                let a = rng.f(0, 6.28)
                                let d = simd_normalize(V3(cos(a) * 0.85, 1.0, sin(a) * 0.85))
                                cai.leaf(at: p, dir: d, spin: rng.f(-3, 3), w: 0.2, h: rng.f(0.22, 0.30),
                                         fold: 0.15, droop: 0.4)
                            }
                        }
                    }
                }
            }
            if let n = cai.node(brassica, sway: 0.03) { root.addChildNode(n) }
            if let n = hanh.node(onion, sway: 0.03) { root.addChildNode(n) }
            if v == 2 {
                let flowerMat = TextureLibrary.foliageMaterial(.flower5, tint: rgb(1.25, 1.1, 0.25))
                if let n = hoa.node(flowerMat) { root.addChildNode(n) }
            }
            // gàu tưới bằng gỗ ở góc vườn
            root.addChildNode(cyl(0.16, 0.26, rgb(0.50, 0.36, 0.22), rough: 0.9, x: -3.9, y: 0.16, z: 3.0, seg: 12))
            root.addChildNode(cyl(0.145, 0.02, rgb(0.20, 0.30, 0.30), rough: 0.1, metal: 0.2, x: -3.9, y: 0.27, z: 3.0, seg: 12))
        }

        // hàng rào tre: sau lưng và hai bên
        let bam = tex(.bamboo, tint: bambooGreen, rx: 1, ry: 3)
        func fence(_ a: V3, _ b: V3) {
            let n = max(Int(simd_length(b - a) / 1.0), 1)
            for i in 0...n {
                let p = a + (b - a) * (Float(i) / Float(n))
                root.addChildNode(link(p, p + V3(0, 0.95, 0), r1: 0.035, r2: 0.03, bam, seg: 6))
            }
            for y in [Float(0.35), 0.7] {
                root.addChildNode(link(a + V3(0, y, 0), b + V3(0, y, 0), r1: 0.025, r2: 0.025, bam, seg: 6))
            }
        }
        fence(V3(-4.1, 0, -3.2), V3(4.1, 0, -3.2))
        fence(V3(-4.1, 0, -3.2), V3(-4.1, 0, 3.2))
        fence(V3(4.1, 0, -3.2), V3(4.1, 0, 3.2))
        return root
    }

    // MARK: Bờ ao

    /// Ao hình bầu dục khoảng 7 x 5,5 m, mặt nước gợn nhẹ, bờ đất dốc phủ cỏ (0, 1) hoặc kè gạch (2).
    /// 0: bờ đất, lau sậy và bèo; 1: cầu ao tre; 2: kè gạch có bậc xuống ao.
    static func pondBank(_ variant: Int, seed: UInt64) -> SCNNode {
        let root = SCNNode()
        var rng = SeededRNG(seed)
        let v = variant % 3
        let R: Float = 3.6
        let inner = SCNNode()
        inner.scale = SCNVector3(1, 1, 0.8)
        root.addChildNode(inner)

        // mặt nước
        let wm = SCNMaterial()
        wm.lightingModel = .physicallyBased
        wm.diffuse.contents = TextureLibrary.albedo(.water)
        wm.multiply.contents = rgb(0.78, 0.92, 0.80)
        wm.roughness.contents = 0.1
        wm.metalness.contents = 0.1
        if let nm = TextureLibrary.normal(.water) {
            wm.normal.contents = nm
            wm.normal.intensity = 1.0
        }
        for p in [wm.diffuse, wm.normal] {
            p.wrapS = .repeat
            p.wrapT = .repeat
            p.mipFilter = .linear
            p.contentsTransform = SCNMatrix4MakeScale(3, 3, 1)
        }
        let wg = SCNCylinder(radius: CGFloat(R + 0.1), height: 0.05)
        wg.radialSegmentCount = 40
        wg.materials = [wm, wm, wm]
        let wn = SCNNode(geometry: wg)
        wn.position = SCNVector3(0, 0.12, 0)
        wn.castsShadow = false
        let period: Double = 14
        let flow = SCNAction.customAction(duration: period) { _, t in
            let u = Float(t / period)
            var a = SCNMatrix4MakeScale(3, 3, 1)
            a.m41 = -u
            var b = SCNMatrix4MakeScale(3, 3, 1)
            b.m41 = -2 * u
            b.m42 = 0.1 * sin(2 * Float.pi * u)
            wm.diffuse.contentsTransform = a
            wm.normal.contentsTransform = b
        }
        wn.runAction(SCNAction.repeatForever(flow))
        inner.addChildNode(wn)
        // đáy ao
        let bed = SCNCylinder(radius: CGFloat(R + 0.3), height: 0.08)
        bed.radialSegmentCount = 40
        bed.materials = [tex(.dirt, tint: rgb(0.55, 0.48, 0.40), rx: 4, ry: 1)]
        let bedNode = SCNNode(geometry: bed)
        bedNode.position = SCNVector3(0, 0.02, 0)
        inner.addChildNode(bedNode)

        // bờ ao: vòng các đoạn nghiêng ra ngoài
        let N = 36
        let r0 = R + 0.85
        let segLen = 2 * Float.pi * (R + 0.9) / Float(N) * 1.2
        let a0 = Float.pi / 2      // hướng đặt cầu ao / bậc thang (về phía +Z)
        for i in 0..<N {
            let a = Float(i) / Float(N) * 2 * Float.pi
            let nd = SCNNode()
            nd.position = SCNVector3(cos(a) * r0, 0, sin(a) * r0)
            nd.eulerAngles.y = -a                       // trục X cục bộ hướng ra ngoài
            if v == 2 {
                nd.addChildNode(tbox(0.32, 0.5, segLen, .brick, tile: 1.4, x: -0.5, y: 0.25))
                nd.addChildNode(tbox(0.5, 0.07, segLen, .concrete, tile: 1.4, x: -0.5, y: 0.535))
                nd.addChildNode(tbox(1.5, 0.5, segLen, .grass, tile: 2, x: 0.5, y: 0.25))
            } else {
                let slab = tbox(1.35, 0.5, segLen, .dirt, tint: rgb(0.72, 0.64, 0.56), tile: 2, y: 0.12)
                slab.eulerAngles.z = 0.38
                nd.addChildNode(slab)
                nd.addChildNode(tbox(0.8, 0.09, segLen, .grass, tile: 2, x: 0.4, y: 0.34))
            }
            inner.addChildNode(nd)
        }

        func frame() -> SCNNode {
            let f = SCNNode()
            f.eulerAngles.y = -a0
            inner.addChildNode(f)
            return f
        }

        if v == 1 {
            // cầu ao: sàn tre nhô ra mặt nước, cọc tre và tay vịn
            let f = frame()
            let bam = tex(.bamboo, tint: rgb(0.95, 0.90, 0.65), rough: 0.7, rx: 1, ry: 2)
            let rc = R + 0.15
            for k in 0..<5 {
                let pole = SCNCylinder(radius: 0.06, height: 3.0)
                pole.radialSegmentCount = 8
                pole.materials = [bam]
                let pn = SCNNode(geometry: pole)
                pn.position = SCNVector3(rc, 0.56, -0.3 + Float(k) * 0.15)
                pn.eulerAngles.z = Float.pi / 2
                f.addChildNode(pn)
            }
            for x in [rc - 1.2, rc, rc + 1.2] {
                for z in [Float(-0.4), 0.4] {
                    f.addChildNode(link(V3(x, 0.0, z), V3(x, 0.6, z), r1: 0.05, r2: 0.045, bam, seg: 6))
                }
            }
            f.addChildNode(link(V3(rc - 1.2, 1.05, 0.42), V3(rc + 1.2, 1.05, 0.42), r1: 0.035, r2: 0.035, bam, seg: 6))
            for x in [rc - 1.2, rc + 1.2] {
                f.addChildNode(link(V3(x, 0.58, 0.42), V3(x, 1.05, 0.42), r1: 0.035, r2: 0.03, bam, seg: 6))
            }
        } else if v == 2 {
            // bậc gạch xuống ao
            let f = frame()
            let tops: [Float] = [0.56, 0.45, 0.33, 0.21, 0.09]
            for (k, top) in tops.enumerated() {
                let x = R + 0.95 - Float(k) * 0.42
                f.addChildNode(tbox(0.46, top, 1.2, .concrete, tint: rgb(0.88, 0.86, 0.82), tile: 1.2, x: x, y: top / 2))
            }
        }

        // lau sậy và cỏ nước quanh bờ
        let reedMat = TextureLibrary.foliageMaterial(.leafLance, tint: rgb(0.88, 1.08, 0.68))
        var reeds = CardBatch()
        let clumps = v == 0 ? 16 : 7
        var placed = 0
        while placed < clumps {
            let a = rng.f(0, 6.28)
            let da = abs(atan2(sin(a - a0), cos(a - a0)))
            if v != 0 && da < 0.5 { continue }          // chừa chỗ cầu ao / bậc thang
            placed += 1
            let rr = R + rng.f(0.9, 1.5)
            let c = V3(cos(a) * rr, 0.36, sin(a) * rr)
            for _ in 0..<7 {
                let d = simd_normalize(V3(rng.f(-0.3, 0.3), 1, rng.f(-0.3, 0.3)))
                reeds.leaf(at: c + V3(rng.f(-0.1, 0.1), 0, rng.f(-0.1, 0.1)), dir: d, spin: rng.f(-3, 3),
                           w: 0.09, h: rng.f(0.7, 1.2), fold: 0.1, droop: 0.5)
            }
        }
        if let n = reeds.node(reedMat, sway: 0.08) { inner.addChildNode(n) }

        // bèo tây nổi trên mặt nước
        if v == 0 {
            let beoMat = TextureLibrary.foliageMaterial(.leafLotus, tint: rgb(0.72, 1.0, 0.52))
            var beo = CardBatch()
            for _ in 0..<26 {
                let a = rng.f(0, 6.28)
                let rr = (R - 0.5) * rng.f(0, 1).squareRoot()
                beo.disc(at: V3(cos(a) * rr, 0.16, sin(a) * rr), normal: V3(0, 1, 0), spin: rng.f(0, 6.28),
                         size: rng.f(0.35, 0.6), dish: 0.15)
            }
            if let n = beo.node(beoMat) { inner.addChildNode(n) }
        }
        return root
    }
}
