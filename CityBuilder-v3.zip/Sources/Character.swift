import SceneKit
import UIKit
import simd
import ZIPFoundation

// MARK: - Giao diện chung của nhân vật đi dạo

/// Nhân vật điều khiển được trong chế độ đi dạo: nhân vật bà ba có sẵn (Avatar) hoặc nhân vật
/// có xương nhập từ thư viện (RiggedAvatar).
protocol WalkAvatar: AnyObject {
    var root: SCNNode { get }
    /// `speed` = vận tốc thật (m/s), gọi mỗi khung hình.
    func animate(speed: Float, dt: Float)
    func cycleOutfit()
    /// Bấm nút hành động: chạy clip vẫy tay / nhảy múa… hoặc nhảy tại chỗ. Trả về dòng thông báo.
    func doAction() -> String
    /// Xoay mặt nhân vật thêm 90° (khi mô hình bị quay ngược hoặc ngang).
    func turnFacing()
    /// Chạy hoạt ảnh chọn từ menu (vẫy tay, nhảy, ngồi, leo…). Trả về dòng thông báo.
    func perform(_ e: WalkEmote) -> String
    /// Thôi giữ dáng ngồi / leo và đứng dậy.
    func stopEmote()
    /// Tên các hoạt ảnh riêng của nhân vật (clip nhập vào), hiện thêm cuối menu.
    var customActions: [String] { get }
    func playCustom(_ index: Int) -> String
}

/// Hoạt ảnh người đi bộ chọn từ menu.
enum WalkEmote: Int, CaseIterable, Identifiable {
    case wave, jump, dance, work, sit, squat, cross, climb, bow

    var id: Int { rawValue }

    var title: String {
        switch self {
        case .wave:  return "Vẫy tay"
        case .jump:  return "Nhảy"
        case .dance: return "Nhảy múa"
        case .work:  return "Làm việc"
        case .sit:   return "Ngồi bệt"
        case .squat: return "Ngồi xổm"
        case .cross: return "Ngồi xếp bằng"
        case .climb: return "Leo trèo"
        case .bow:   return "Cúi chào"
        }
    }

    var symbol: String {
        switch self {
        case .wave:  return "hand.raised.fill"
        case .jump:  return "arrow.up.to.line"
        case .dance: return "music.note"
        case .work:  return "hammer.fill"
        case .sit:   return "arrow.down.to.line"
        case .squat: return "arrow.down.circle"
        case .cross: return "circle.grid.cross"
        case .climb: return "arrow.up.right"
        case .bow:   return "chevron.down.circle.fill"
        }
    }

    /// Một trong các kiểu ngồi (có thể ngồi lên công trình).
    var sitting: Bool { self == .sit || self == .squat || self == .cross }

    /// Ngồi và leo giữ nguyên tới khi người chơi đi tiếp hoặc chọn "Đứng dậy".
    var holds: Bool { sitting || self == .climb }

    /// Số thứ tự hành động trong `ProceduralRig`.
    var procIndex: Int {
        switch self {
        case .jump:  return 0
        case .wave:  return 1
        case .dance: return 2
        case .work:  return 3
        case .sit:   return 4
        case .climb: return 5
        case .bow:   return 6
        case .squat: return 7
        case .cross: return 8
        }
    }

    /// Từ khóa (không dấu) để tìm clip cùng tên trong file nhân vật hoặc thư viện hoạt ảnh.
    var clipKeys: [String] {
        switch self {
        case .wave:  return ["wave", "hello", "greet", "vay"]
        case .jump:  return ["jump", "nhay"]
        case .dance: return ["dance", "mua", "hiphop", "samba", "twist", "swing"]
        case .work:  return ["work", "hammer", "sweep", "dig", "chop", "mine", "type", "repair", "build", "lam viec"]
        case .sit:   return ["sit", "ngoi", "seat", "chair"]
        case .squat: return ["squat", "crouch", "xom"]
        case .cross: return ["cross", "meditat", "bang"]
        case .climb: return ["climb", "ladder", "leo"]
        case .bow:   return ["bow", "salute", "cui", "chao"]
        }
    }

    var message: String {
        holds ? "\(title) — đi tiếp hoặc chọn “Đứng dậy” để dừng" : title
    }
}

// MARK: - Phân loại hoạt ảnh

enum ClipKind {
    case idle, walk, run, jump, action

    /// Đoán loại clip theo tên (tên khóa trong file hoặc tên file hoạt ảnh).
    static func classify(_ raw: String) -> ClipKind {
        let n = raw.lowercased()
            .replacingOccurrences(of: "đ", with: "d")
            .folding(options: .diacriticInsensitive, locale: nil)
        func has(_ keys: [String]) -> Bool { keys.contains { n.contains($0) } }
        if has(["idle", "stand", "breath", "wait", "dung yen", "dung im"]) { return .idle }
        if has(["jump", "nhay", "leap"]) { return .jump }
        if has(["walk", "di bo", "stroll", "strut"]) { return .walk }
        if has(["run", "sprint", "jog", "chay"]) { return .run }
        return .action
    }

    /// Chọn clip mặc định cho mô hình đặt trong cảnh (không điều khiển).
    static func pick(_ names: [String], walking: Bool) -> Int? {
        guard !names.isEmpty else { return nil }
        let kinds = names.map { classify($0) }
        let order: [ClipKind] = walking ? [.walk, .run, .idle] : [.idle, .walk]
        for k in order {
            if let i = kinds.firstIndex(of: k) { return i }
        }
        return 0
    }
}

/// Một hoạt ảnh của nhân vật: từ glTF (tự lấy mẫu, `manual`) hoặc từ USDZ / DAE / SCN (`player`).
final class RigClip {
    let name: String
    var kind: ClipKind
    let duration: Float
    let manual: GLTFClip?
    let player: SCNAnimationPlayer?

    init(name: String, kind: ClipKind, duration: Float,
         manual: GLTFClip? = nil, player: SCNAnimationPlayer? = nil) {
        self.name = name
        self.kind = kind
        self.duration = duration
        self.manual = manual
        self.player = player
    }
}

// MARK: - Thư viện hoạt ảnh (Documents/Animations)

struct ClipEntry {
    let name: String       // tên hiển thị, cũng dùng để đoán loại (Idle, Walk, Run, Jump, Wave…)
    let entry: URL         // file hoặc thư mục nằm trong Animations
    let url: URL           // file hoạt ảnh chính
}

/// Hoạt ảnh nhập riêng (ví dụ tải từ Mixamo, không kèm hình): dùng chung cho mọi nhân vật có xương.
/// Đặt tên file theo việc: Idle, Walk, Run, Jump; tên khác (Wave, Dance…) thành nút Hành động.
enum ClipLibrary {
    static let extensions = ["dae", "usdz", "usd", "usda", "usdc", "scn", "glb", "gltf", "vrm"]

    static var directory: URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let dir = docs.appendingPathComponent("Animations", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }

    private static func findMain(in dir: URL) -> URL? {
        guard let en = FileManager.default.enumerator(at: dir, includingPropertiesForKeys: nil) else { return nil }
        var best: (rank: Int, url: URL)? = nil
        for case let u as URL in en {
            if u.path.contains("__MACOSX") || u.lastPathComponent.hasPrefix(".") { continue }
            guard let r = extensions.firstIndex(of: u.pathExtension.lowercased()) else { continue }
            if best == nil || r < best!.rank { best = (r, u) }
        }
        return best?.url
    }

    static func entries() -> [ClipEntry] {
        let fm = FileManager.default
        let items = (try? fm.contentsOfDirectory(at: directory, includingPropertiesForKeys: nil,
                                                  options: [.skipsHiddenFiles])) ?? []
        var out: [ClipEntry] = []
        for u in items {
            var isDir: ObjCBool = false
            guard fm.fileExists(atPath: u.path, isDirectory: &isDir) else { continue }
            if isDir.boolValue {
                if let main = findMain(in: u) {
                    out.append(ClipEntry(name: u.lastPathComponent, entry: u, url: main))
                }
            } else if extensions.contains(u.pathExtension.lowercased()) {
                out.append(ClipEntry(name: u.deletingPathExtension().lastPathComponent, entry: u, url: u))
            }
        }
        return out.sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
    }

    static func remove(_ name: String) {
        for e in entries() where e.name == name {
            try? FileManager.default.removeItem(at: e.entry)
        }
    }

    private static func unique(_ base: String) -> String {
        let taken = Set(entries().map { $0.name })
        var name = base
        var n = 2
        while taken.contains(name) || FileManager.default.fileExists(atPath: directory.appendingPathComponent(name).path) {
            name = "\(base) \(n)"
            n += 1
        }
        return name
    }

    /// Trả về lý do nếu file không dùng được làm hoạt ảnh, nil nếu ổn.
    private static func problem(_ url: URL) -> String? {
        let ext = url.pathExtension.lowercased()
        if GLTFLoader.handles(ext) {
            do {
                let imp = try GLTFLoader.load(at: url)
                return imp.clips.isEmpty ? "file không có hoạt ảnh" : nil
            } catch {
                return error.localizedDescription
            }
        }
        guard let sc = Builder.loadScene(at: url) else { return "file không đọc được" }
        var has = false
        sc.rootNode.enumerateHierarchy { n, _ in
            if !n.animationKeys.isEmpty { has = true }
        }
        return has ? nil : "file không có hoạt ảnh"
    }

    /// Nhập file .zip (Mixamo tải về dạng zip), hoặc file lẻ .dae / .usdz / .glb… (kèm .bin, ảnh nếu có).
    static func add(_ urls: [URL]) -> (added: [String], problems: [String]) {
        let fm = FileManager.default
        var added: [String] = []
        var problems: [String] = []
        var loose: [URL] = []
        var sawFBX = false

        for u in urls {
            let ext = u.pathExtension.lowercased()
            if ext == "zip" {
                let tmp = fm.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
                do {
                    try fm.createDirectory(at: tmp, withIntermediateDirectories: true)
                    try fm.unzipItem(at: u, to: tmp)
                } catch {
                    try? fm.removeItem(at: tmp)
                    problems.append("\(u.lastPathComponent): không giải nén được")
                    continue
                }
                guard let main = findMain(in: tmp) else {
                    try? fm.removeItem(at: tmp)
                    problems.append("\(u.lastPathComponent): không thấy file hoạt ảnh (DAE, USDZ, GLB…); FBX cần chuyển sang DAE hoặc GLB")
                    continue
                }
                if let why = problem(main) {
                    try? fm.removeItem(at: tmp)
                    problems.append("\(u.lastPathComponent): \(why)")
                    continue
                }
                let base = unique(u.deletingPathExtension().lastPathComponent)
                do {
                    try fm.moveItem(at: tmp, to: directory.appendingPathComponent(base, isDirectory: true))
                    added.append(base)
                } catch {
                    try? fm.removeItem(at: tmp)
                    problems.append("\(u.lastPathComponent): không lưu được")
                }
            } else if ext == "fbx" {
                sawFBX = true
                problems.append("\(u.lastPathComponent): FBX chưa đọc trực tiếp, hãy tải dạng DAE (Mixamo) hoặc chuyển sang GLB / USDZ")
            } else {
                loose.append(u)
            }
        }

        let models = loose.filter { extensions.contains($0.pathExtension.lowercased()) }
        let support = loose.filter { !extensions.contains($0.pathExtension.lowercased()) }
        if models.isEmpty && !loose.isEmpty && !sawFBX {
            problems.append("Không thấy file hoạt ảnh (DAE, USDZ, GLB…) trong những file đã chọn")
        }
        for m in models {
            let base = unique(m.deletingPathExtension().lastPathComponent)
            var created: URL
            var main: URL
            do {
                if support.isEmpty {
                    created = directory.appendingPathComponent(base + "." + m.pathExtension.lowercased())
                    try fm.copyItem(at: m, to: created)
                    main = created
                } else {
                    created = directory.appendingPathComponent(base, isDirectory: true)
                    try fm.createDirectory(at: created, withIntermediateDirectories: true)
                    for f in [m] + support {
                        try fm.copyItem(at: f, to: created.appendingPathComponent(f.lastPathComponent))
                    }
                    main = created.appendingPathComponent(m.lastPathComponent)
                }
            } catch {
                problems.append("\(m.lastPathComponent): không lưu được")
                continue
            }
            if let why = problem(main) {
                try? fm.removeItem(at: created)
                problems.append("\(m.lastPathComponent): \(why)")
            } else {
                added.append(base)
            }
        }
        return (added, problems)
    }
}

// MARK: - Nhân vật có xương nhập từ thư viện

/// Nhân vật 3D có xương (USDZ / DAE / SCN / GLB / GLTF / VRM) đi lại được:
/// - tự co về cao 1,7 m, chân chạm đất, quay mặt về +Z (nút xoay mặt để chỉnh nếu bị ngược);
/// - chạy clip Đứng / Đi / Chạy theo vận tốc, trộn mượt khi chuyển, tốc độ clip theo quãng đường đi;
/// - clip lấy từ chính file nhân vật hoặc từ thư viện hoạt ảnh (khớp theo tên xương);
/// - nút Hành động chạy lần lượt các clip còn lại (vẫy tay, nhảy múa…), hoặc nhảy tại chỗ;
/// - không có hoạt ảnh nào thì nhún và nghiêng người theo bước đi.
final class RiggedAvatar: WalkAvatar {
    let root = SCNNode()
    private let body = SCNNode()       // nhảy, nhún
    private let face = SCNNode()       // xoay mặt về +Z
    private let modelName: String
    private var faceTurn = 0
    private var nodesByName: [String: SCNNode] = [:]

    private var idleClip: RigClip?
    private var walkClip: RigClip?
    private var runClip: RigClip?
    private var jumpClip: RigClip?
    private var actionClips: [RigClip] = []

    private var current: RigClip?
    private var previous: RigClip?
    private var curTime: Float = 0
    private var prevTime: Float = 0
    private var fade: Float = 1
    private var actionClip: RigClip?
    private var actionT: Float = 0
    private var actionIndex = 0
    private var actionHold = false      // clip ngồi / leo: dừng ở khung cuối, giữ tới khi đi tiếp

    private var proc: ProceduralRig?    // xương tự dựng từ các điểm người dùng đặt (mô hình tĩnh)
    private var phase: Float = 0       // nhún theo bước khi không có clip
    private var amount: Float = 0
    private var jumpT: Float = -1

    private init(name: String) {
        modelName = name
        root.addChildNode(body)
        body.addChildNode(face)
    }

    private static func clampf(_ x: Float, _ lo: Float, _ hi: Float) -> Float { min(max(x, lo), hi) }

    private static func wrap(_ t: Float, _ d: Float) -> Float {
        d > 0 ? t.truncatingRemainder(dividingBy: d) : 0
    }

    private static func nativePlayers(in root: SCNNode) -> [(node: SCNNode, key: String, player: SCNAnimationPlayer)] {
        var out: [(node: SCNNode, key: String, player: SCNAnimationPlayer)] = []
        root.enumerateHierarchy { node, _ in
            for key in node.animationKeys {
                if let p = node.animationPlayer(forKey: key) { out.append((node, key, p)) }
            }
        }
        return out
    }

    private static func prepare(_ p: SCNAnimationPlayer) {
        p.animation.repeatCount = .infinity
        p.animation.usesSceneTimeBase = false
        p.animation.blendInDuration = 0.2
        p.animation.blendOutDuration = 0.2
        p.animation.isRemovedOnCompletion = false
        p.stop()
    }

    private static func duration(_ p: SCNAnimationPlayer) -> Float {
        let d = Float(p.animation.duration)
        return d > 0.05 ? d : 1
    }

    // MARK: Dựng nhân vật

    /// Đọc mô hình thành một node nội dung (chưa co giãn), kèm hoạt ảnh glTF nếu có.
    static func loadContent(modelName: String) -> (content: SCNNode, gclips: [GLTFClip], legacyVRM: Bool)? {
        guard let url = Builder.mainModelURL(for: modelName) else { return nil }
        let ext = url.pathExtension.lowercased()

        var scene: SCNScene? = nil
        var gclips: [GLTFClip] = []
        var legacyVRM = false
        if GLTFLoader.handles(ext) {
            guard let imp = try? GLTFLoader.load(at: url) else { return nil }
            scene = imp.scene
            gclips = imp.clips
            legacyVRM = imp.legacyVRM
        } else {
            scene = Builder.loadScene(at: url)
        }
        guard let sc = scene else { return nil }

        let content = SCNNode()
        for c in sc.rootNode.childNodes { content.addChildNode(c) }
        content.enumerateHierarchy { node, _ in
            guard let g = node.geometry else { return }
            for m in g.materials where m.diffuse.contents == nil {
                m.diffuse.contents = UIColor(white: 0.78, alpha: 1)
            }
        }
        return (content, gclips, legacyVRM)
    }

    static func load(modelName: String) -> RiggedAvatar? {
        guard let loaded = loadContent(modelName: modelName) else { return nil }
        let content = loaded.content
        let gclips = loaded.gclips
        let legacyVRM = loaded.legacyVRM
        let av = RiggedAvatar(name: modelName)

        // mô hình tĩnh (chưa có xương) mà người dùng đã đặt các điểm khớp: tự dựng xương và chuyển động
        var hasSkin = false
        content.enumerateHierarchy { node, _ in
            if node.skinner != nil { hasSkin = true }
        }
        if !hasSkin, let pts = RigStore.load(modelName) {
            av.proc = ProceduralRig.build(content: content, joints: pts)
        }

        // cao 1,7 m, chân chạm đất, căn giữa
        let (lo, hi) = content.boundingBox
        let h = hi.y - lo.y
        guard h.isFinite, h > 0.0001 else { return nil }
        let s = 1.7 / h
        content.scale = SCNVector3(s, s, s)
        content.position = SCNVector3(-(lo.x + hi.x) / 2 * s, -lo.y * s, -(lo.z + hi.z) / 2 * s)
        av.face.addChildNode(content)

        let key = "walk.face." + modelName
        if UserDefaults.standard.object(forKey: key) != nil {
            av.faceTurn = UserDefaults.standard.integer(forKey: key) % 4
        } else {
            av.faceTurn = legacyVRM ? 2 : 0      // VRM 0.x quay mặt về -Z
        }
        av.face.eulerAngles.y = Float(av.faceTurn) * Float.pi / 2

        content.enumerateHierarchy { node, _ in
            if let nm = node.name, av.nodesByName[GLTFClip.key(nm)] == nil { av.nodesByName[GLTFClip.key(nm)] = node }
        }

        // 1) hoạt ảnh nằm sẵn trong file nhân vật
        var found: [RigClip] = []
        for g in gclips {
            found.append(RigClip(name: g.name, kind: ClipKind.classify(g.name), duration: g.duration, manual: g))
        }
        for np in nativePlayers(in: content) {
            prepare(np.player)
            found.append(RigClip(name: np.key, kind: ClipKind.classify(np.key),
                                 duration: duration(np.player), player: np.player))
        }
        // chỉ có đúng một clip mà không rõ tên: coi là clip đi bộ
        if found.count == 1 && found[0].kind == .action { found[0].kind = .walk }

        // 2) hoạt ảnh nhập riêng trong thư viện hoạt ảnh
        for entry in ClipLibrary.entries().prefix(16) {
            let cext = entry.url.pathExtension.lowercased()
            if GLTFLoader.handles(cext) {
                guard let imp = try? GLTFLoader.load(at: entry.url) else { continue }
                for g in imp.clips {
                    let nm = imp.clips.count == 1 ? entry.name : "\(entry.name) \(g.name)"
                    found.append(RigClip(name: nm, kind: ClipKind.classify(nm), duration: g.duration, manual: g))
                }
            } else if let csc = Builder.loadScene(at: entry.url),
                      let np = nativePlayers(in: csc.rootNode).first {
                let target = av.nodesByName[GLTFClip.key(np.node.name ?? "")] ?? content
                target.addAnimationPlayer(np.player, forKey: "ext_" + entry.name)
                prepare(np.player)
                found.append(RigClip(name: entry.name, kind: ClipKind.classify(entry.name),
                                     duration: duration(np.player), player: np.player))
            }
        }

        func first(_ k: ClipKind) -> RigClip? { found.first { $0.kind == k } }
        av.idleClip = first(.idle)
        av.walkClip = first(.walk)
        av.runClip = first(.run)
        av.jumpClip = first(.jump)
        av.actionClips = found.filter { $0.kind == .action }

        // Không có clip nào dùng được (đứng, đi, chạy, nhảy, hành động): tự dựng xương theo khung bao,
        // để tay hạ xuống khỏi tư thế chữ T và tay chân vung khi đi. Muốn chính xác hơn thì dùng
        // "Gắn xương cho nhân vật…" trong Thư viện để tự chạm đặt từng điểm.
        if av.proc == nil && found.isEmpty {
            let lo3 = SIMD3<Float>(lo.x, lo.y, lo.z)
            let hi3 = SIMD3<Float>(hi.x, hi.y, hi.z)
            av.proc = ProceduralRig.build(content: content, joints: RigStore.guess(lo: lo3, hi: hi3))
        }
        return av
    }

    // MARK: Chạy hoạt ảnh

    private func switchTo(_ c: RigClip?) {
        if let old = current {
            old.player?.stop(withBlendOutDuration: 0.2)
            if old.manual != nil && c?.manual != nil {
                previous = old
                prevTime = curTime
                fade = 0
            } else {
                previous = nil
                fade = 1
            }
        }
        var start: Float = 0
        if let old = current, let n = c,
           (old.kind == .walk || old.kind == .run), (n.kind == .walk || n.kind == .run), old.duration > 0 {
            // đi <-> chạy: giữ nguyên nhịp bước để không giật
            start = RiggedAvatar.wrap(curTime / old.duration, 1) * n.duration
        }
        current = c
        curTime = start
        if let p = c?.player {
            p.speed = 1
            p.play()
        }
    }

    func animate(speed: Float, dt: Float) {
        var wanted: RigClip? = nil
        var rate: Float = 1
        var paused = false
        var oneShot = false

        if speed > 0.15 { stopEmote() }        // đi tiếp thì đứng dậy khỏi dáng ngồi / leo
        if let a = actionClip {
            actionT += dt
            if actionT >= a.duration && !actionHold { actionClip = nil } else { wanted = a; oneShot = true }
        }
        if wanted == nil {
            if speed > 0.15 {
                if speed > 5.5, let r = runClip {
                    wanted = r
                    rate = RiggedAvatar.clampf(speed / 6, 0.7, 1.8)
                } else if let w = walkClip {
                    wanted = w
                    rate = RiggedAvatar.clampf(speed / 2.2, 0.5, 3.0)
                } else if let r = runClip {
                    wanted = r
                    rate = RiggedAvatar.clampf(speed / 6, 0.4, 1.8)
                } else {
                    wanted = idleClip
                }
            } else if let i = idleClip {
                wanted = i
            } else if let w = walkClip {
                wanted = w          // chưa có clip đứng yên: dừng clip đi bộ ở khung đầu
                paused = true
            }
        }
        if wanted !== current { switchTo(wanted) }

        var bobY: Float = 0
        var tiltX: Float = 0
        var tiltZ: Float = 0

        if let pr = proc, pr.isActing, current != nil {
            pr.pose(speed: speed, dt: dt)       // hành động của xương tự dựng chạy đè lên clip
        } else if let c = current {
            let r: Float = paused ? 0 : rate
            curTime += dt * r
            curTime = oneShot ? min(curTime, c.duration) : RiggedAvatar.wrap(curTime, c.duration)
            c.player?.speed = CGFloat(r)
            if let m = c.manual {
                if fade < 1, let p = previous, let pm = p.manual {
                    prevTime = RiggedAvatar.wrap(prevTime + dt, p.duration)
                    pm.apply(at: prevTime, to: nodesByName)
                    fade = min(1, fade + dt / 0.2)
                    m.apply(at: curTime, to: nodesByName, weight: fade)
                } else {
                    previous = nil
                    m.apply(at: curTime, to: nodesByName)
                }
            }
        } else if let pr = proc {
            // xương tự dựng: tay chân đi, chạy, nhảy theo vận tốc
            pr.pose(speed: speed, dt: dt)
        } else {
            // không có clip: nhún và nghiêng người theo bước đi
            let target = min(speed / 4.0, 2.2)
            amount += (target - amount) * min(1, dt * 8)
            if speed > 0.15 {
                phase += speed * dt / 1.5 * 2 * Float.pi
                if phase > 2 * Float.pi { phase -= 2 * Float.pi }
            }
            let k = amount
            bobY = 0.04 * min(k, 1.5) * abs(sin(phase))
            tiltZ = 0.05 * min(k, 1.5) * sin(phase)
            tiltX = 0.08 * min(k, 2.2)
        }

        if jumpT >= 0 {
            jumpT += dt
            let d: Float = 0.6
            if jumpT >= d {
                jumpT = -1
            } else {
                let u = jumpT / d
                bobY += 0.6 * 4 * u * (1 - u)
            }
        }
        body.position.y = bobY
        body.eulerAngles.x = tiltX
        body.eulerAngles.z = tiltZ
    }

    /// Đang chạy một hành động (clip, xương tự dựng hoặc nhảy tại chỗ).
    var isActing: Bool { actionClip != nil || (proc?.isActing ?? false) || jumpT >= 0 }

    /// Dùng cho NPC: chạy một hành động theo tên clip (dance, wave, work, jump…);
    /// không có clip phù hợp thì dùng chuyển động của xương tự dựng. Trả về false nếu không làm được.
    func play(_ a: NPCAction) -> Bool {
        if isActing { return true }
        let keys: [String]
        switch a {
        case .jump:  keys = ["jump", "nhay"]
        case .wave:  keys = ["wave", "hello", "greet", "vay"]
        case .dance: keys = ["dance", "mua", "hiphop", "samba", "twist", "swing"]
        case .work:  keys = ["work", "hammer", "sweep", "dig", "chop", "mine", "type", "repair", "build", "lam viec"]
        }
        var pool = actionClips
        if let j = jumpClip { pool.append(j) }
        func norm(_ s: String) -> String {
            s.lowercased().replacingOccurrences(of: "đ", with: "d")
                .folding(options: .diacriticInsensitive, locale: nil)
        }
        if let c = pool.first(where: { clip in keys.contains { norm(clip.name).contains($0) } }) {
            actionClip = c
            actionT = 0
            return true
        }
        if let pr = proc {
            switch a {
            case .jump:  pr.start(0)
            case .wave:  pr.start(1)
            case .dance: pr.start(2)
            case .work:  pr.start(3)
            }
            return true
        }
        if a == .jump { jumpT = 0; return true }
        if a == .dance || a == .work, let any = actionClips.first {
            actionClip = any
            actionT = 0
            return true
        }
        return false
    }

    func cycleOutfit() {}

    // MARK: Menu hoạt ảnh

    private static func norm(_ s: String) -> String {
        s.lowercased().replacingOccurrences(of: "đ", with: "d")
            .folding(options: .diacriticInsensitive, locale: nil)
    }

    func perform(_ e: WalkEmote) -> String {
        // 1) clip cùng tên trong file nhân vật / thư viện hoạt ảnh
        var pool = actionClips
        if let j = jumpClip { pool.append(j) }
        if let c = pool.first(where: { clip in e.clipKeys.contains { RiggedAvatar.norm(clip.name).contains($0) } }) {
            proc?.release()
            actionClip = c
            actionT = 0
            actionHold = e.holds
            return e.message
        }
        // 2) xương tự dựng
        if let pr = proc {
            actionClip = nil
            actionHold = false
            pr.start(e.procIndex, hold: e.holds, force: true)
            return e.message
        }
        // 3) không có gì: nhảy tại chỗ thì vẫn làm được
        if e == .jump {
            if jumpT < 0 { jumpT = 0 }
            return e.title
        }
        return "Nhân vật này chưa có hoạt ảnh “\(e.title)”. Nhập clip có tên “\(e.clipKeys[0])” trong Thư viện để dùng."
    }

    func stopEmote() {
        proc?.release()
        if actionHold {
            actionHold = false
            actionClip = nil
        }
    }

    var customActions: [String] { actionClips.map { $0.name } }

    func playCustom(_ index: Int) -> String {
        guard actionClips.indices.contains(index) else { return "" }
        let c = actionClips[index]
        proc?.release()
        actionClip = c
        actionT = 0
        actionHold = false
        return "Hoạt ảnh: \(c.name)"
    }

    func doAction() -> String {
        if let pr = proc, actionClips.isEmpty, jumpClip == nil { return pr.startAction() }
        var pool = actionClips
        if let j = jumpClip { pool.insert(j, at: 0) }
        if pool.isEmpty {
            if jumpT < 0 { jumpT = 0 }
            return "Nhảy"
        }
        if actionClip != nil { return "Đang thực hiện hành động…" }
        let c = pool[actionIndex % pool.count]
        actionIndex += 1
        actionClip = c
        actionT = 0
        return "Hành động: \(c.name)"
    }

    func turnFacing() {
        faceTurn = (faceTurn + 1) % 4
        UserDefaults.standard.set(faceTurn, forKey: "walk.face." + modelName)
        face.eulerAngles.y = Float(faceTurn) * Float.pi / 2
    }
}
