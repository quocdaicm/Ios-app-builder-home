import SceneKit
import SwiftUI
import UIKit

struct ShareSheet: UIViewControllerRepresentable {
    let url: URL

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: [url], applicationActivities: nil)
    }

    func updateUIViewController(_ vc: UIActivityViewController, context: Context) {}
}

struct SceneContainer: UIViewRepresentable {
    let controller: SceneController

    func makeCoordinator() -> Coordinator {
        Coordinator(controller)
    }

    func makeUIView(context: Context) -> SCNView {
        let v = SCNView()
        v.scene = controller.scene
        v.pointOfView = controller.cameraNode
        v.allowsCameraControl = true
        v.antialiasingMode = .multisampling4X
        v.autoenablesDefaultLighting = false
        v.rendersContinuously = true      // để mặt nước chuyển động
        v.preferredFramesPerSecond = 60

        let cc = v.defaultCameraController
        cc.interactionMode = .orbitTurntable
        cc.maximumVerticalAngle = 85
        cc.minimumVerticalAngle = 5
        cc.target = SCNVector3(0, 0, 0)

        let tap = UITapGestureRecognizer(target: context.coordinator,
                                         action: #selector(Coordinator.tapped(_:)))
        v.addGestureRecognizer(tap)
        context.coordinator.view = v
        return v
    }

    func updateUIView(_ uiView: SCNView, context: Context) {}

    final class Coordinator: NSObject {
        let controller: SceneController
        weak var view: SCNView?

        init(_ controller: SceneController) {
            self.controller = controller
        }

        @objc func tapped(_ g: UITapGestureRecognizer) {
            guard let v = view else { return }
            controller.handleTap(at: g.location(in: v), in: v)
        }
    }
}

struct ContentView: View {
    @StateObject private var c = SceneController()
    @State private var confirmClear = false

    var body: some View {
        ZStack {
            SceneContainer(controller: c)
                .ignoresSafeArea()

            VStack(spacing: 8) {
                topBar
                Spacer()
                if c.tool.isLine, c.roadStart != nil {
                    pill("⏹ Dừng") { c.stopRoad() }
                }
                if c.selectedID != nil {
                    actionBar
                }
                toolBar
            }
            .padding(.horizontal, 10)
            .padding(.bottom, 6)
        }
        .sheet(item: $c.shareItem) { item in
            ShareSheet(url: item.url)
        }
        .confirmationDialog("Xóa toàn bộ thành phố?", isPresented: $confirmClear, titleVisibility: .visible) {
            Button("Xóa tất cả", role: .destructive) { c.clearAll() }
        }
    }

    private var topBar: some View {
        HStack(alignment: .top) {
            Text(c.message)
                .font(.footnote)
                .padding(8)
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 10))
            Spacer()
            Menu {
                Button("Tạo xóm miền Tây mẫu") { c.addSampleMekong() }
                Button("Tạo khu phố mẫu") { c.addSample() }
                Button("Hoàn tác") { c.undo() }
                Toggle("Căn theo lưới", isOn: $c.snapToGrid)
                Toggle("Kèm mặt đất khi xuất", isOn: $c.includeGround)
                Divider()
                Button("Xuất OBJ (cho game)") { c.export(.obj) }
                Button("Xuất USDZ") { c.export(.usdz) }
                Button("Xuất SCN (SceneKit)") { c.export(.scn) }
                Divider()
                Button("Xóa tất cả", role: .destructive) { confirmClear = true }
            } label: {
                Text("☰ Menu")
                    .font(.footnote.bold())
                    .padding(.horizontal, 12)
                    .padding(.vertical, 9)
                    .background(.ultraThinMaterial, in: Capsule())
            }
        }
    }

    private var actionBar: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                pill("↻ Xoay") { c.rotateSelected() }
                pill("＋ To") { c.scaleSelected(1.2) }
                pill("－ Nhỏ") { c.scaleSelected(1 / 1.2) }
                pill("🎨 Màu") { c.recolorSelected() }
                pill(c.moveMode ? "📍 Chạm nơi đặt" : "✥ Dời", highlighted: c.moveMode) { c.toggleMove() }
                pill("🗑 Xóa") { c.deleteSelected() }
            }
        }
    }

    private var toolBar: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(Tool.allCases) { t in
                    Button {
                        c.setTool(t)
                    } label: {
                        VStack(spacing: 2) {
                            Text(t.icon).font(.title2)
                            Text(t.title).font(.caption2)
                        }
                        .frame(width: 70, height: 56)
                        .foregroundColor(.white)
                        .background(c.tool == t ? Color.accentColor : Color.black.opacity(0.4),
                                    in: RoundedRectangle(cornerRadius: 12))
                    }
                }
            }
            .padding(8)
        }
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
    }

    private func pill(_ title: String, highlighted: Bool = false, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
                .font(.footnote.bold())
                .padding(.horizontal, 12)
                .padding(.vertical, 9)
                .foregroundColor(.white)
                .background(highlighted ? Color.orange : Color.black.opacity(0.5), in: Capsule())
        }
    }
}
